/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/**
 * @file    app_led.h
 * @brief   LED task API data object and task function declarations
 * @author  M91406
 */


// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef APPLICATION_LAYER_DEBUGGING_LED_H
#define	APPLICATION_LAYER_DEBUGGING_LED_H

#include <xc_pral.h> // include device peripheral register abstraction layer

// CUSTOM DECLARATIONS
#define DBGLED_PERIOD_FAST      2499
#define DBGLED_PERIOD_DEFAULT   4999
#define DBGLED_PERIOD_STANDBY   9999

/***********************************************************************************
 * @ingroup apps-layer-led-debug-properties-public-data-types
 * @brief   Debugging LED settings data object
 * @details
 *  This data structure holds all adjustable parameters used by the debugging 
 *  LED driver required to tailor the driver functions to specific application
 *  requirements. 
 *
 **********************************************************************************/
struct DEBUGGING_LED_STATUS_s {
    unsigned on : 1;    // Bit #0:  Flag bit, set and cleared by software driver, indicating the debugging LED is currently on (read only)
    unsigned : 1;       // Bit #1:  (reserved)
    unsigned : 1;       // Bit #2:  (reserved)
    unsigned : 1;       // Bit #3:  (reserved)
    unsigned : 1;       // Bit #4:  (reserved)
    unsigned : 1;       // Bit #5:  (reserved)
    unsigned : 1;       // Bit #6:  (reserved)
    unsigned : 1;       // Bit #7:  (reserved)

    unsigned : 1;       // Bit #8:  (reserved)
    unsigned : 1;       // Bit #9:  (reserved)
    unsigned : 1;       // Bit #10: (reserved)
    unsigned : 1;       // Bit #11: (reserved)
    unsigned : 1;       // Bit #12: (reserved)
    unsigned : 1;       // Bit #13: (reserved)
    unsigned : 1;       // Bit #14: (reserved)
    unsigned enabled;   // Bit #15: Control bit enabling and disabling the Debugging LED function
} __attribute__((packed)); ///< data structure for single bit addressing operations

/***********************************************************************************
 * @ingroup apps-layer-led-debug-properties-public-data-types
 * @brief   Debugging LED Status Control
 **********************************************************************************/
union DEBUGGING_LED_STATUS_u 
{
    struct DEBUGGING_LED_STATUS_s bits;  ///< Debugging LED status control bit-field
	uint16_t value; ///< Debugging LED status word for 16-bit word read/write operations
}; 
typedef union DEBUGGING_LED_STATUS_u DEBUGGING_LED_STATUS_t;

/***********************************************************************************
 * @ingroup apps-layer-led-debug-properties-public-data-types
 * @brief   Status Word of the Debugging LED driver
 **********************************************************************************/
struct DEBUGGING_LED_s
{
    const P33C_GPIO_t* ioPin; ///< Pin driving the connected on-board LED
    DEBUGGING_LED_STATUS_t Status; ///< Status word of the Debugging LED driver
    uint16_t OnTime; ///< Period setting specifying how long the Debugging LED should stay on
    uint16_t Period; ///< Debugging LED toggle interval period setting
};    
typedef struct DEBUGGING_LED_s DEBUGGING_LED_t;

// PUBLIC VARIABLE DECLARATION
extern DEBUGGING_LED_t debugLed;

// PUBLIC FUNCTION PROTOTYPE DECLARATION
extern uint16_t appLED_Initialize(void);
extern uint16_t appLED_Execute(void);
extern uint16_t appLED_Start(void);
extern uint16_t appLED_Dispose(void);

#endif	/* APPLICATION_LAYER_DEBUGGING_LED_H */

