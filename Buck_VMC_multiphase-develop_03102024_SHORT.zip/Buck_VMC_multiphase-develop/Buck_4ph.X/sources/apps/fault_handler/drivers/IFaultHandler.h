/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * @file    IFaultHandler.h
 * @author  M91406
 * @brief   Global fault handler interface header file
 * @version 1.0
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef FAULT_HANDLER_INTERFACE_H
#define	FAULT_HANDLER_INTERFACE_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer types header file
#include <stdbool.h> // include standard boolean types header file

#include "drv_fault_handler.h"

/**********************************************************************************
 * @ingroup lib-layer-fault-properties-public-data-types
 * @struct FAULT_OBJECT_s
 * @brief This data structure is a collection of data structures for fault handling.
 *********************************************************************************/
struct FAULT_OBJECT_s {

	volatile FLT_OBJECT_STATUS_t Status;            ///< Status word of this fault object
	volatile uint16_t Counter;                      ///< Fault event counter (controlled by FAULT HANDLER)
	volatile FLT_COMPARE_OBJECT_t SourceObject;     ///< Object which should be monitored
	volatile FLT_COMPARE_OBJECT_t ReferenceObject;  ///< Reference object the source should be compared with
    volatile FLT_EVENT_RESPONSE_t TripResponse;     ///< Settings defining the fault trip event
    volatile FLT_EVENT_RESPONSE_t RecoveryResponse; ///< Settings defining the fault recovery event

}; ///< Generic fault object 
typedef struct FAULT_OBJECT_s FAULT_OBJECT_t; ///< Generic fault object data type

/*********************************************************************************
 * @ingroup lib-layer-fault-properties-public-variables 
 * @var     FaultMonitor
 * @brief   Global fault monitor object
 * @details
 *  ADD_DESCRIPTION_HERE
 **********************************************************************************/
extern volatile FAULT_MONITOR_t FaultMonitor; ///< Global fault monitor object

// Public Function Prototypes
extern volatile uint16_t drv_FaultHandler_ScanObjects(volatile FAULT_OBJECT_t* fltObjectList[], volatile uint16_t size);
extern volatile uint16_t drv_FaultHandler_Dispose(volatile FAULT_OBJECT_t* fltObjectList[], volatile uint16_t size);



#endif	/* FAULT_HANDLER_INTERFACE_H */

