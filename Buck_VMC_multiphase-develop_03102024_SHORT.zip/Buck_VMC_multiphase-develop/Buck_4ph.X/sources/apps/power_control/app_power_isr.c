/*
 * @file   app_power_isr.c
 * @author M91169
 *
 * Created on April , 2022, 1:10 AM
 */

#include "./app_power_control.h"
#include "./devices/dev_psfb_pconfig.h"

#ifdef __WITH_PIL__
#include "pil/pil_main.h"
#endif

#if BUCK_FREQUENCY_JITTER==1

uint16_t jitter_cnt=0,rnd[NUM_JITTER_SAMPLE]={957,994,914,910,930,944,993,999,987,939,924,951,933,983,974,935,943,979,959,909,958,906,999,984,926,974,931,930,958,935,910,979,924,996,907,956,967,947,912,938,932,915,993,995,984,968,984,967,996,966,955,996,938,909,937,944,942,945,934,978,943,912,970,951,947,924,921,973,933,939,994,925,930,909,930,935,908,921,924,990,936,970,913,913,949,944,934,959,993,982,945,917,958,982,920,933,934,949,978,924};

#endif

volatile uint16_t dummy;
volatile uint16_t vout[1000],cnt=0;

/*********************************************************************************
 * @ingroup app-layer-power-control-events
 * @brief   Voltage Control Interrupt
 * @details
 * The control interrupt is calling the voltage control loop. 
 * 
 *********************************************************************************/
uint16_t tmp_dc=100;
volatile uint16_t pin;
void __attribute__((__interrupt__, no_auto_psv, context))VLOOP_Interrupt(void)
{
    #ifdef __WITH_PIL__
    
    uint16_t pil_dummy=0;;
    
    
    
    //PG1CONLbits.ON = 0; // PG1 is stopped to avoid triggering the ADC during PIL processing
    PIL_BEGIN_INT_CALL(PilHandle); // It doesn't change the behavior if it is called in ADCAN0 or ADCAN2 interrupts
    SET_OPROBE(PilProbes.Vin_prot, pil_dummy);  // If _probeF is true PilProbes.Input1 is updated with ADCBUF0 value. If false the value come from PLECS
    SET_OPROBE(PilProbes.Vin, pil_dummy);  
    SET_OPROBE(PilProbes.Vout, pil_dummy);  
    SET_OPROBE(PilProbes.Start, pil_dummy);  
    SET_OPROBE(PilProbes.Ibuck1, pil_dummy);  
    SET_OPROBE(PilProbes.Ibuck2, pil_dummy);  
    SET_OPROBE(PilProbes.Ibuck3, pil_dummy);  
    SET_OPROBE(PilProbes.Ibuck4, pil_dummy);  
    
    // ToDo: Runtime data is captured in power supply state machine call.
//    buck_4ph.Data.Vout = *buck_4ph.Feedback.ad_vout.adc_buffer;  
//    buck_4ph.Data.Vin = *buck_4ph.Feedback.ad_ibuck1.adc_buffer; 
//    buck_4ph.Data.Ibuck1 = *buck_4ph.Feedback.ad_ibuck2.adc_buffer;  
//    buck_4ph.Data.Ibuck2 = *buck_4ph.Feedback.ad_ibuck3.adc_buffer; 

    #endif  
    
//    if(buck_4ph.VLoop.controller->status.bits.enabled)
//    {
//        vout[cnt++]=buck_4ph.Data.Vout;
//        if(cnt>=500)
//        {
//            cnt=0;
//        }
//    }
//    else
//    {
////        PilProbes.PG1DC=666;
////        PilProbes.PG1trigb=333;
//    }
    
    buck_4ph.Status.bits.adc_active = true;

    #if defined (__NO_PIL__) && (HW_OPEN_LOOP_TEST == true) 
    
    
    
    #else  

 #ifdef __WITH_PIL__    
    // To be sure PWM registers are updated
    while(PG1STATbits.UPDATE==1);
    while(PG2STATbits.UPDATE==1);
    while(PG3STATbits.UPDATE==1);
    while(PG4STATbits.UPDATE==1);
#endif
    
    buck_4ph.VLoop.ctrl_Update(buck_4ph.VLoop.controller);
    
//    tmp_dc++;
//    if(tmp_dc>39000)
//    {
//        tmp_dc=100;
//    }
//    PG2DC=tmp_dc;
//    PG3DC=tmp_dc;
//    PG4DC=tmp_dc;
//    
//    PG1TRIGB=tmp_dc>>1;
//    PG2TRIGB=tmp_dc>>1;
//    PG3TRIGB=tmp_dc>>1;
//    PG4TRIGB=tmp_dc>>1;
//    
//    PG1DC=tmp_dc;
    
    
    #endif
    
//    if(1==buck_4ph.VLoop.controller->status.bits.enabled)
//    {
//        // TODO move to a compensator hook
//        // Left shift nominal_duty by PWM_DUTY_SHIFT before using it
//        // In the hook calculates the trigger removing it from the compensator
//        
//        PWM1H.Objects.PG->PGxDC.value=(buck_4ph.SetValues.nominal_duty);
//        PWM2H.Objects.PG->PGxDC.value=buck_4ph.SetValues.nominal_duty+buck_4ph.Balancing.Buck2_dc_offset;
//        PWM3H.Objects.PG->PGxDC.value=buck_4ph.SetValues.nominal_duty+buck_4ph.Balancing.Buck3_dc_offset;
//        PWM4H.Objects.PG->PGxDC.value=buck_4ph.SetValues.nominal_duty+buck_4ph.Balancing.Buck4_dc_offset;
//
//        PWM1H.Objects.PG->PGxTRIGB.value=buck_4ph.SetValues.nominal_adc_trigger;
//        PWM2H.Objects.PG->PGxTRIGB.value=buck_4ph.SetValues.nominal_adc_trigger+(buck_4ph.Balancing.Buck2_dc_offset>>1);
//        PWM3H.Objects.PG->PGxTRIGB.value=buck_4ph.SetValues.nominal_adc_trigger+(buck_4ph.Balancing.Buck3_dc_offset>>1);
//        PWM4H.Objects.PG->PGxTRIGB.value=buck_4ph.SetValues.nominal_adc_trigger+(buck_4ph.Balancing.Buck4_dc_offset>>1);
//
//        PG1STATbits.UPDREQ=1;   // UPDATE PWM1 registers and Broadcast update request for PWM2,3,4 registers
//    }
    
    
    
    
    #if (PLANT_MEASUREMENT == false)
    //psfb.vbulkMonitor.filter_Update(psfb.vbulkMonitor.controller);
    #else
    v_loop_PTermUpdate(&v_loop);
    #endif

    // Frequency jittering
    
    #if BUCK_FREQUENCY_JITTER==1
    
    FSCL=rnd[jitter_cnt];
    if(jitter_cnt++>=NUM_JITTER_SAMPLE)
    {
        jitter_cnt=0;
    }
    
    #endif
    
// TODO 
#ifdef __WITH_PIL__
    // Do not use PGx register directly as they may not be updated
    
    // TODO for debug only remove
    if(buck_4ph.Status.bits.fault_active==1)
    {
        Nop();
        Nop();
        Nop();
        
    }
    
    
    //PilProbes.DEBUG1=buck_4ph.SetValues.v_ref-buck_4ph.Data.Vout;
//    PilProbes.PG1DC=(buck_4ph.SetValues.nominal_duty<<PWM_DUTY_SHIFT);
//    PilProbes.PG2DC=(buck_4ph.SetValues.nominal_duty<<PWM_DUTY_SHIFT)+buck_4ph.Balancing.Buck2_dc_offset;
//    PilProbes.PG3DC=(buck_4ph.SetValues.nominal_duty<<PWM_DUTY_SHIFT)+buck_4ph.Balancing.Buck3_dc_offset;
//    PilProbes.PG4DC=(buck_4ph.SetValues.nominal_duty<<PWM_DUTY_SHIFT)+buck_4ph.Balancing.Buck4_dc_offset;
//    
//    PilProbes.PGxdth=PG1DTH;
//    PilProbes.PGxdtl=PG1DTL;
//    
//    // With real PWMs TRIGA are all the same because every PWM timebase is already phase shifted
//    PilProbes.PG1triga= PG1PER>>2;
//    PilProbes.PG2triga= PilProbes.PG1triga+(PG1PER>>2);
//    PilProbes.PG3triga= PilProbes.PG2triga+(PG1PER>>2);
//                                                                  
//    PilProbes.PG1trigb=(buck_4ph.SetValues.nominal_duty);
//    PilProbes.PG2trigb=(buck_4ph.SetValues.nominal_duty)+(buck_4ph.Balancing.Buck2_dc_offset>>1);
//    PilProbes.PG3trigb=(buck_4ph.SetValues.nominal_duty)+(buck_4ph.Balancing.Buck3_dc_offset>>1);
//    PilProbes.PG4trigb=(buck_4ph.SetValues.nominal_duty)+(buck_4ph.Balancing.Buck4_dc_offset>>1);
    
    
    
    PilProbes.PG1DC=PG1DC;
    PilProbes.PG2DC=PG2DC;
    PilProbes.PG3DC=PG3DC;
    PilProbes.PG4DC=PG4DC;
    
    PilProbes.PGxdth=PG1DTH;
    PilProbes.PGxdtl=PG1DTL;
    
    // With real PWMs TRIGA are all the same because every PWM timebase is already phase shifted
    PilProbes.PG1triga= PG1PER>>2;
    PilProbes.PG2triga= PilProbes.PG1triga+(PG1PER>>2);
    PilProbes.PG3triga= PilProbes.PG2triga+(PG1PER>>2);
                                                                  
    PilProbes.PG1trigb=PG1TRIGB;
    PilProbes.PG2trigb=PG2TRIGB;
    PilProbes.PG3trigb=PG3TRIGB;
    PilProbes.PG4trigb=PG4TRIGB;
    
    PilProbes.DAC1dath=DAC1DATH;
    PilProbes.Pgx_ovr=(PG4IOCONLbits.OVRENH<<7)+(PG4IOCONLbits.OVRENL<<6)+(PG3IOCONLbits.OVRENH<<5)+(PG3IOCONLbits.OVRENL<<4)+(PG2IOCONLbits.OVRENH<<3)+(PG2IOCONLbits.OVRENL<<2)+(PG1IOCONLbits.OVRENH<<1)+(PG1IOCONLbits.OVRENL);
    
    pin=converterGPIO_GetPinState(&buck_4ph.Gpio.EN_DCDC_Idealdiode);
    pin=converterGPIO_GetPinState(&buck_4ph.Gpio.EN_DCDC_Inrush);
    pin=converterGPIO_GetPinState(&buck_4ph.Gpio.EN_Inrush);
    pin=converterGPIO_GetPinState(&buck_4ph.Gpio.EN_Bypass);
    
    PilProbes.Inrush=(converterGPIO_GetPinState(&buck_4ph.Gpio.EN_Bypass)<<3)+(converterGPIO_GetPinState(&buck_4ph.Gpio.EN_Inrush)<<2)+(converterGPIO_GetPinState(&buck_4ph.Gpio.EN_DCDC_Inrush)<<1)+converterGPIO_GetPinState(&buck_4ph.Gpio.EN_DCDC_Idealdiode);
    dummy=*p33c_Gpio_GetAnalogInputBuffer(VOUT.Properties.ADCAN); // Dummy-read the ADC buffer preventing stalling the ISR
    
    
#endif
    
    VOUT_ADCANxIF = 0;  // Clear the ADCANx interrupt flag 
}

/*********************************************************************************
 * @fn      void PSFB_IPRI_LOOP_Interrupt(void)
 * @ingroup app-layer-power-control-events
 * @brief  Current loop Control Interrupt 
 * @param   void
 * @return  void
 *   
 * @details
 * The control interrupt is calling the current control loop A.
 * 
 *********************************************************************************/
#ifdef ILOOP1_Interrupt
void __attribute__((__interrupt__, no_auto_psv, context))ILOOP1_Interrupt(void)
{
    


    
    buck_4ph.Status.bits.adc_active = true;
    buck_4ph.Data.Vin = *buck_4ph.Feedback.ad_ibuck1.adc_buffer; 
    
    IBUCK1_ADCANxIF = 0;
    
}
#endif

// __________________________
// end of file
