/* *********************************************************************************
 * PowerSmart Digital Control Library Designer, Version 1.9.15.709
 * *********************************************************************************
 * 3p3z controller function declarations and compensation filter coefficients
 * derived for following operating conditions:
 * *********************************************************************************
 *
 *  Controller Type:    3P3Z - Basic Voltage Mode Compensator
 *  Sampling Frequency: 100000 Hz
 *  Fixed Point Format: Q15
 *  Scaling Mode:       4 - Fast Floating Point Coefficient Scaling
 *  Input Gain:         1
 *
 * *********************************************************************************
 * CGS Version:         3.0.11
 * CGS Date:            01/06/2022
 * *********************************************************************************
 * User:                M91169
 * Date/Time:           05/02/2024 16:43:14
 * ********************************************************************************/

#include "vout_loop_vmc.h"

/* *********************************************************************************
 * Data Arrays:
 * ============
 *
 * This source file declares the default parameters of the z-domain compensation
 * filter. The NPNZ16b_s data structure contains two pointers to A- and B-
 * coefficient arrays and two pointers to control and error history arrays.
 *
 * For optimized data processing during DSP computations, these arrays must be
 * located in specific memory locations (X-space for coefficient arrays and
 * Y-space for control and error history arrays).
 *
 * The following declarations are used to define the array data contents, their
 * length and memory location. These declarations are made publicly accessible
 * through extern declarations in header file vout_loop_vmc.h
 * ********************************************************************************/

volatile struct VOUT_LOOP_VMC_CONTROL_LOOP_COEFFICIENTS_s __attribute__((space(xmemory), near)) vout_loop_vmc_coefficients; // A/B-Coefficients
volatile uint16_t vout_loop_vmc_ACoefficients_size = (sizeof(vout_loop_vmc_coefficients.ACoefficients)/sizeof(vout_loop_vmc_coefficients.ACoefficients[0])); // A-coefficient array size
volatile uint16_t vout_loop_vmc_BCoefficients_size = (sizeof(vout_loop_vmc_coefficients.BCoefficients)/sizeof(vout_loop_vmc_coefficients.BCoefficients[0])); // B-coefficient array size

volatile struct VOUT_LOOP_VMC_CONTROL_LOOP_HISTORIES_s __attribute__((space(ymemory), far)) vout_loop_vmc_histories; // Control/Error Histories
volatile uint16_t vout_loop_vmc_ControlHistory_size = (sizeof(vout_loop_vmc_histories.ControlHistory)/sizeof(vout_loop_vmc_histories.ControlHistory[0])); // Control history array size
volatile uint16_t vout_loop_vmc_ErrorHistory_size = (sizeof(vout_loop_vmc_histories.ErrorHistory)/sizeof(vout_loop_vmc_histories.ErrorHistory[0])); // Error history array size

/* *********************************************************************************
 * Pole&Zero Placement:
 * *********************************************************************************
 *
 *    fP0:    3000 Hz
 *    fP1:    22000 Hz
 *    fP2:    50000 Hz
 *    fZ1:    600 Hz
 *    fZ2:    600 Hz
 *
 * *********************************************************************************
 * Filter Coefficients and Parameters:
 * ********************************************************************************/

volatile int32_t vout_loop_vmc_ACoefficients [3] =
{
    0x7AF50000, // Coefficient A1 will be multiplied with controller output u(n-1)
    0x51E00003, // Coefficient A2 will be multiplied with controller output u(n-2)
    0xACF50004  // Coefficient A3 will be multiplied with controller output u(n-3)
};

//ORIGINAL
//volatile int32_t vout_loop_vmc_BCoefficients [4] =
//{
//    0x495CFFFE, // Coefficient B0 will be multiplied with error input e(n-0)
//    0xBC12FFFE, // Coefficient B1 will be multiplied with error input e(n-1)
//    0xB6BEFFFE, // Coefficient B2 will be multiplied with error input e(n-2)
//    0x4408FFFE  // Coefficient B3 will be multiplied with error input e(n-3)
//};

//FASTER
//volatile int32_t vout_loop_vmc_BCoefficients [4] =
//{
//    0x6C04FFFC, // Coefficient B0 will be multiplied with error input e(n-0)
//    0x9806FFFC, // Coefficient B1 will be multiplied with error input e(n-1)
//    0x9407FFFC, // Coefficient B2 will be multiplied with error input e(n-2)
//    0x6805FFFC  // Coefficient B3 will be multiplied with error input e(n-3)
//};

//SLOWER
volatile int32_t vout_loop_vmc_BCoefficients [4] =
{
    0x4803FFFD, // Coefficient B0 will be multiplied with error input e(n-0)
    0xBAAFFFFD, // Coefficient B1 will be multiplied with error input e(n-1)
    0xB805FFFD, // Coefficient B2 will be multiplied with error input e(n-2)
    0x4559FFFD  // Coefficient B3 will be multiplied with error input e(n-3)
};


// Coefficient normalization factors
volatile int16_t vout_loop_vmc_pre_shift = 3;     // Bit-shift value used to perform input value normalization
volatile int16_t vout_loop_vmc_post_shift_A = 0;  // Bit-shift value A used to perform control output value backward normalization
volatile int16_t vout_loop_vmc_post_shift_B = 0;  // Bit-shift value B used to perform control output value backward normalization
volatile fractional vout_loop_vmc_post_scaler = 0x0000; // Q15 fractional factor used to perform control output value backward normalization

//Adaptive Gain Control Coefficient
volatile int16_t vout_loop_vmc_agc_factor_default = 0x7FFF; // Q15 fractional of the AGC factor

//BECOM-TODO: changed from 0x0000 to 0x0002 -> no overcurrent at startup!!
volatile int16_t vout_loop_vmc_agc_scaler_default = 0x0000; // Bit-shift scaler of the AGC factor


// User-defined NPNZ16b_s controller data object
volatile struct NPNZ16b_s vout_loop_vmc;          // user-controller data object

/* ********************************************************************************/

/* *********************************************************************************
 * Controller Initialization:
 * ==========================
  *
 * Public controller initialization function loading known default settings
 * into the NPNZ16b data structure.
 *
 * ********************************************************************************/

volatile uint16_t vout_loop_vmc_Initialize(volatile struct NPNZ16b_s* controller)
{
    volatile uint16_t i=0;

    // Initialize controller data structure at runtime with pre-defined default values
    controller->status.value = NPNZ_STATUS_CLEAR; // clear all status flag bits (will turn off execution))

    controller->Filter.ptrACoefficients = &vout_loop_vmc_coefficients.ACoefficients[0]; // initialize pointer to A-coefficients array
    controller->Filter.ptrBCoefficients = &vout_loop_vmc_coefficients.BCoefficients[0]; // initialize pointer to B-coefficients array
    controller->Filter.ptrControlHistory = &vout_loop_vmc_histories.ControlHistory[0]; // initialize pointer to control history array
    controller->Filter.ptrErrorHistory = &vout_loop_vmc_histories.ErrorHistory[0]; // initialize pointer to error history array
    controller->Filter.normPostShiftA = vout_loop_vmc_post_shift_A; // initialize A-coefficients/single bit-shift scaler
    controller->Filter.normPostShiftB = vout_loop_vmc_post_shift_B; // initialize B-coefficients/dual/post scale factor bit-shift scaler
    controller->Filter.normPostScaler = vout_loop_vmc_post_scaler; // initialize control output value normalization scaling factor
    controller->Filter.normPreShift = vout_loop_vmc_pre_shift; // initialize A-coefficients/single bit-shift scaler
    
    controller->Filter.ACoefficientsArraySize = vout_loop_vmc_ACoefficients_size; // initialize A-coefficients array size
    controller->Filter.BCoefficientsArraySize = vout_loop_vmc_BCoefficients_size; // initialize B-coefficients array size
    controller->Filter.ControlHistoryArraySize = vout_loop_vmc_ControlHistory_size; // initialize control history array size
    controller->Filter.ErrorHistoryArraySize = vout_loop_vmc_ErrorHistory_size; // initialize error history array size

    // Load default set of A-coefficients from user RAM into controller A-array located in X-Space
    for(i=0; i<controller->Filter.ACoefficientsArraySize; i++)
    {
        vout_loop_vmc_coefficients.ACoefficients[i] = vout_loop_vmc_ACoefficients[i]; // Load coefficient A(n) value into vout_loop_vmc coefficient(i) data space
    }

    // Load default set of B-coefficients from user RAM into controller B-array located in X-Space
    for(i=0; i<controller->Filter.BCoefficientsArraySize; i++)
    {
        vout_loop_vmc_coefficients.BCoefficients[i] = vout_loop_vmc_BCoefficients[i]; // Load coefficient B(n) value into vout_loop_vmc coefficient(i) data space
    }

    // Clear error and control histories of the 3P3Z controller
    vout_loop_vmc_Reset(&vout_loop_vmc);
    
    // Load initial AGC factor and scaler into data structure
    controller->GainControl.AgcFactor = vout_loop_vmc_agc_factor_default;
    controller->GainControl.AgcScaler = vout_loop_vmc_agc_scaler_default;
    
    return(1);
}


//**********************************************************************************
// Download latest version of this tool here:
//      https://www.microchip.com/powersmart
//**********************************************************************************

