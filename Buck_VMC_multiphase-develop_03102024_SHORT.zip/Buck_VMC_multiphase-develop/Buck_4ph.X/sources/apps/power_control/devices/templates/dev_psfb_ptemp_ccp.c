/* 
 * @file   dev_psfb_ptemp_ccp.c
 * @author M91406
 * @brief
 * Revision history: 
 */

#include <xc_pral.h> // include peripheral register abstraction layer drivers
#include "dev_psfb_ptemp_ccp.h"
/****************************************************************************************************
 * @ingroup lib-layer-psfb-ptemplate-properties-variables
 * @var ccpConfigRelayControl
 * @brief CCP generator default configuration for relay operation
 *****************************************************************************************************/

volatile P33C_CCP_INSTANCE_t ccpConfigRelayControl = {
    
        .CCPxCON1L.value = REG_CCPxCON1L ,
        .CCPxCON1H.value = 0x0000,
        .CCPxCON2L.value = 0x0000,
        .CCPxCON2H.value = 0x0000,
        .CCPxCON3H.value = 0x0000,
        .CCPxSTATL.value = 0x0000,
        .CCPxTMRL.value = 0x0000,
        .CCPxTMRH.value = 0x0000,
        .CCPxPRL.value = 0x0000,
        .CCPxPRH.value = 0x0000,
        .CCPxRAL.value = 0x0000,
        .CCPxRBL.value = 0x0000,
        .CCPxBUFL.value = 0x0000,
        .CCPxBUFH.value = 0x0000
            
    };
