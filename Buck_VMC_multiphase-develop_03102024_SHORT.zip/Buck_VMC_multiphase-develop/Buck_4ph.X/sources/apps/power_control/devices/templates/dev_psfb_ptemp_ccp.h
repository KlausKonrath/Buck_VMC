/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * @file   dev_psfb_ptemp_ccp.h
 * @author M91406
 * @brief
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef PSFB_CONVERTER_PERIPHERAL_CONFIGURATION_CCP_H
#define	PSFB_CONVERTER_PERIPHERAL_CONFIGURATION_CCP_H

/**
 * @ingroup lib-layer-psfb-ptemplate-properties-defines
 * @{
 */
/* *********************************************************************************
 * Output Compare Module Configuration of Relay Control Signal
 * ********************************************************************************/
/**
 * @def CCPxCON1L
 * @brief CCPxCON1L: CCP CONTROL REGISTER
 */
/* CCPxCON1L: PWM GENERATOR x CONTROL REGISTER LOW

                             ________________ BIT 15: ON: Enable: CCP Generator Enable
                            | _______________ BIT 14: (unimplemented) 
                            || ______________ BIT 13: CCPSIDL: CCPx Stop in Idle Mode Bit 
                            ||| _____________ BIT 12: CCPSLP: CCPx Sleep Mode Enable bit
                            |||| ____________ BIT 11: TMRSYNC: Time Base Clock Synchronization bit
                            ||||| ___________ BIT 10: CLKSEL[2:0]: CCPx Time Base Clock Select bits
                            |||||| __________ BIT  9: 
                            ||||||| _________ BIT  8: 
                            |||||||| ________ BIT  7: TMRPS[1:0]: Time Base Prescale Select bits
                            ||||||||| _______ BIT  6: 
                            |||||||||| ______ BIT  5: T32: 32-Bit Time Base Select bit
                            ||||||||||| _____ BIT  4: CCSEL: Capture/Compare Mode Select bit
                            |||||||||||| ____ BIT  3: MODSEL[3:0]: Mode Selection
                            ||||||||||||| ___ BIT  2: 
                            |||||||||||||| __ BIT  1: 
                            ||||||||||||||| _ BIT  0: 
                            ||||||||||||||||  */
#define REG_CCPxCON1L     0b1000000000000101

/**@}*/
#endif	/* XC_HEADER_TEMPLATE_H */

