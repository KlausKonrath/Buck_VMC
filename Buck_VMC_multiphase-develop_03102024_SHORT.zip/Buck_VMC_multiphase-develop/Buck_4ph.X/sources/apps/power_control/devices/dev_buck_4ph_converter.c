/*
 * @file   dev_psfb_converter.c
 * @author M91406
 *
 * Created on July 9, 2019, 1:10 PM
 */


#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
#define FCY 100000000UL
#include <libpic30.h>

#include "dev_buck_4ph_typedef.h"
#include "dev_psfb_opstates.h"
#include "dev_psfb_pconfig.h"

#include "config/apps.h"
#include "./apps/power_control/devices/dev_buck_4ph_typedef.h"   // include  Converter type definitions
#include "./apps/power_control/devices/dev_psfb_converter.h" // include  Converter object header
#include "./apps/power_control/devices/dev_psfb_pconfig.h"
#include "./apps/power_control/drivers/vout_loop_vmc.h"   
#include "./apps/power_control/drivers/vout_loop_agc.h"  

/** ********************************************************************************
 * @fn uint16_t drv_Converter_Initialize
 * @ingroup lib-layer-converter-functions-public
 * @brief   Initializes the  Converter peripherals
 * @param   POWER_CONTROLLER_t *pcInstance
 * @return  uint16_t (0 = failure, 1 = success)
 * @details
 * This function initializes the PWM module, PWM channels, ADC channels for temperature,
 *  input voltage, output voltage and phase current. The boost PFC IO pins are also initialize
 * while keeping the psfb converter operation disabled. The state machine is set to Initialize. 
 *
 ** *******************************************************************************/
uint16_t drv_Converter_Initialize(volatile POWER_CONTROLLER_t *pcInstance) 
{
    uint16_t retval=1;
     
    retval &= PWM_ModuleInitialize(pcInstance); // Initialize PWM Module
    
    // Initialize the PWM frequency scaling
    FSMINPER=NOM_FREQ;
    FSCL=SCALED_FREQ;
            
    retval &= PWM_GeneratorInitialize(pcInstance);  // Initialize PWM Channels of PSFB Converter
    
    /* RC15 - Output*/
    TRISCbits.TRISC15 = 0;
    
    /* BEGIN - PWM6 Configuration */
    PG6DC = PWM6_DC_0_PERC;
    PG6DCA = 0;
    PG6PER = PWM_PERIOD;
    PG6CONLbits.HREN = 1;
    PG6PHASE = 0x0000;
    PG6CONHbits.MSTEN = 0;
    PG6CONHbits.SOCS = 0;
    PG6CONLbits.CLKSEL = PWM_CKSEL;
    PG6IOCONHbits.POLL = 1;
    PG6IOCONHbits.PENL = 1;
    PG6CONLbits.ON = 1;
    /* END - PWM6 Configuration */
    
    retval &= ADC_ModuleInitialize();                                       // Initialize ADC Module
    retval &= ADC_Channel_Initialize(&pcInstance->Feedback.ad_vout);        // Initialize vout channel
    retval &= ADC_Channel_Initialize(&pcInstance->Feedback.ad_vin);         // Initialize vin channel
    retval &= ADC_Channel_Initialize(&pcInstance->Feedback.ad_vin_prot);    // Initialize vin_prot channel
    retval &= ADC_Channel_Initialize(&pcInstance->Feedback.ad_v_dcdc);      // Initialize v_dcdc channel
    retval &= ADC_Channel_Initialize(&pcInstance->Feedback.ad_v_motor);     // Initialize v_motor channel
    retval &= ADC_Channel_Initialize(&pcInstance->Feedback.ad_v_aux);       // Initialize v_aux channel
    retval &= ADC_Channel_Initialize(&pcInstance->Feedback.ad_v_24volt);    // Initialize v_24volt channel
    retval &= ADC_Channel_Initialize(&pcInstance->Feedback.ad_i_200watt);   // Initialize i_200watt channel
    retval &= ADC_Channel_Initialize(&pcInstance->Feedback.ad_ibuck1);      // Initialize buck1 current channel
    retval &= ADC_Channel_Initialize(&pcInstance->Feedback.ad_ibuck2);      // Initialize buck2 current channel
    retval &= ADC_Channel_Initialize(&pcInstance->Feedback.ad_ibuck3);      // Initialize buck3 current channel
    retval &= ADC_Channel_Initialize(&pcInstance->Feedback.ad_ibuck4);      // Initialize buck4 current channel
    
    retval &= GPIO_Initialize(pcInstance);                                  // Initialize additional control IOs
    retval &= DAC_ModuleInitialize(pcInstance);                             // Initialize DAC module
    retval &= DAC_GeneratorInitialize(pcInstance);                          // Initialize DAC instance
    
    DAC1CONL = 0x0000;
    DAC2CONL = 0x8000;
    DAC2CONLbits.IRQM = 0b11;
    IPC19bits.CMP2IP = 6;
    IFS4bits.CMP2IF = 0;
    IEC4bits.CMP2IE = 0;
    
    DAC2DATH = buck_4ph.SwNode1.dac_threshold;
    
    // TODO For DEBUG only
    
//    _TRISA3=0;
//    DAC2CONLbits.DACEN=1;
//    DAC2CONLbits.DACOEN=1;
//    DAC2DATH=2048;
    
    return(retval);
}

/** ********************************************************************************
 * @fn uint16_t drv_Converter_Execute
 * @ingroup lib-layer-converter-functions-public
 * @brief  Continuous Converter state machine main function
 * @param  POWER_CONTROLLER_t *pcInstance
 * @return uint16_t (0 = failure, 1 = success)
 * @details
 *  This function performs tasks in the state machine.  
 *  - If state machine state returns ERROR, switch to ERROR state in next execution cycle
 *  - If state machine state signals state completion, move on to next state in line
 *  - When state machine state returns REPEAT, the recent state function will be called again
 *  - When state machine state returns an unknown result, the state machine will be reset to INITIALIZE again 
 *
 ** *******************************************************************************/
uint16_t drv_Converter_Execute(volatile POWER_CONTROLLER_t *pcInstance) 
{
    uint16_t retval=1;
    
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    /* NULL POINTER PROTECTION                                                            */
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    // If no boost instance has been declared, leave here
    if(pcInstance == NULL)
        return(0);
    
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    /* CAPTURE ENABLE PIN STATE IF ENABLED BY USER CODE                                   */
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    
    
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    /* DISABLE-RESET                                                                      */
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    // When enable status has changed from ENABLED to DISABLED, reset the state machine
    #ifdef __WITH_PIL__
    //PilProbes.DEBUG1=pcInstance->StateId.bits.opstate_id;
    #endif
    
    if ((!pcInstance->Status.bits.Enabled) || (pcInstance->Status.bits.suspend) || (pcInstance->Status.bits.fault_active)) 
    {
        if (!pcInstance->Status.bits.ready)
        {
            pcInstance->StateId.value = (uint32_t)CONVERTER_OPSTATE_INITIALIZE;
            Nop(); /* Breakpoint Placement */
            Nop();
            Nop();
        }
        else
        {
            pcInstance->StateId.value= (uint32_t)CONVERTER_OPSTATE_RESET;
            Nop(); /* Breakpoint Placement */
            Nop();
            Nop();
        }
        
        // TODO remove
        // Used to force the PWM on with NO_PIL for debug
        {
//            pcInstance->StateId.bits.opstate_id = 3;      
//            pcInstance->Status.bits.Enabled=1;
//            pcInstance->Status.bits.autorun   = 1;   
        } 
        
        retval = ConverterStateMachine[pcInstance->StateId.bits.opstate_id](pcInstance);
                
        return((bool)(retval>0)); // Return        
    }    
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    /* FUNCTION CALL PROTECTION                                                           */
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    if(pcInstance->StateId.bits.opstate_id >= ConverterStateList_size)
        pcInstance->StateId.value = (uint32_t)CONVERTER_OPSTATE_INITIALIZE;
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/

    // Call state machine
    retval = ConverterStateMachine[pcInstance->StateId.bits.opstate_id](pcInstance);
    // Validate state return value
    switch (retval) 
    {
        /* IF state machine state signals state completion, move on to next state in line */
        case CONVERTER_OPSRET_COMPLETE:
            
            // Increment main operating state pointer by one tick
            pcInstance->StateId.value = (uint32_t)(pcInstance->StateId.bits.opstate_id++);
            
            // Check if new index is out of range, reset to RESET if so
            if (pcInstance->StateId.bits.opstate_id >= ConverterStateList_size)
                pcInstance->StateId.value = (uint32_t)CONVERTER_OPSTATE_INITIALIZE;

            retval = 1;
            break;
            
        /* When state machine state returns REPEAT, the recent state function will be called again */
        case CONVERTER_OPSRET_REPEAT:
            // Do nothing, same state will be called next time
            retval = 1;
            break;
            
        /* When state machine state returns an unknown result, the 
         * state machine will be reset to INITIALIZE again */
        default:
            // In case an ERROR or undefined return value has been 
            // received, reset state machine and start from scratch
            pcInstance->StateId.value = (uint32_t)CONVERTER_OPSTATE_INITIALIZE;
            retval = 0;
            break;

    }
    
    return(retval);
}

/** ********************************************************************************
 * @fn uint16_t drv_Converter_Start
 * @ingroup lib-layer-converter-functions-public
 * @brief  Starts the  Converter peripherals while keeping switching signals disables
 * @param  POWER_CONTROLLER_t *pcInstance
 * @return uint16_t (0 = failure, 1 = success)
 * @details
  * This function starts the converter operation by enabling the converter PWM and ADC peripherals, 
 * enabling the converter and reseting the state machine to Initialize. 
 *
 ** *******************************************************************************/
uint16_t drv_Converter_Start(volatile POWER_CONTROLLER_t *pcInstance)
{
    uint16_t retval=1;
        
    // Disable control loops
    pcInstance->VLoop.controller->status.bits.enabled = false; // Disable voltage loop
    pcInstance->VLoop.ctrl_Reset(pcInstance->VLoop.controller); // Reset voltage loop histories

    // Start ADC and all PWM generators with their outputs disabled
    retval &= ADC_Start();                // Start ADC
    retval &= PWM_Start(pcInstance);   // Start PWM (generators actors, all outputs disabled)
    if (retval) pcInstance->Status.bits.pwm_active = 1; // IF PWM startup was successful, set PWM_ACTIVE flag

    pcInstance->Status.bits.Enabled = true;   // Enable the Converter
    pcInstance->StateId.value = (uint32_t)CONVERTER_OPSTATE_INITIALIZE;
    
    converterGPIO_Set(&pcInstance->Gpio.EN_DCDC_Idealdiode);// Enable isolated DCDC converter used for the Idealdiode
    
    //delay
    __delay_ms(10);
    
    converterGPIO_Set(&pcInstance->Gpio.EN_DCDC_Inrush);    // Enable isolated DCDC converter used for the Inrush TODO verify
    
    return(retval);
}

/** ********************************************************************************
 * @fn uint16_t drv_Converter_Stop
 * @ingroup lib-layer-converter-functions-public
 * @brief  Stops the Converter and shuts down all peripherals
 * @param  POWER_CONTROLLER_t *pcInstance
 * @return uint16_t (0 = failure, 1 = success)
 * @details
 *  This function stops the  converter operation by shutting down the PWM generator, 
 * disabling the voltage/current loop and reset the state machine to Initialize.
 * 
 *
 ** *******************************************************************************/
uint16_t drv_Converter_Stop(volatile POWER_CONTROLLER_t *pcInstance)
{
    uint16_t retval=1;
    
    // Stop all PWM generators 
    retval &= PWM_Stop(pcInstance); // Stop PWM
    
    pcInstance->VLoop.controller->status.bits.enabled = false; // Disable voltage loop
    
    pcInstance->Status.bits.Enabled = false;  // Disable PSFB Converter
    pcInstance->StateId.value = (uint32_t)CONVERTER_OPSTATE_INITIALIZE;// Reset state machine

    return(retval);
}

/** ********************************************************************************
 * @fn uint16_t drv_Converter_Suspend
 * @ingroup lib-layer-converter-functions-public
 * @brief  Suspends the  Converter operation by turning off controller and switching outputs while keep peripherals running
 * @param  POWER_CONTROLLER_t *pcInstance
 * @return uint16_t (0 = failure, 1 = success)
 * @details
 * * This function sets the suspend bit terminating operation. This bit will be evaluated in the
 * State machine tasks which eventually shuts down the operation of the  converter.
 *
 ** *******************************************************************************/
 uint16_t drv_Converter_Suspend(volatile POWER_CONTROLLER_t *pcInstance)
 {
    uint16_t retval=1;

    // Reset state machine state and enforce a state switch
    pcInstance->Status.bits.suspend = true;  // Set SUSPEND bit terminating operation
    retval &= drv_Converter_Execute(pcInstance);
    
    return(retval);
}

/** ********************************************************************************
 * @fn uint16_t drv_Converter_Resume
 * @ingroup lib-layer-converter-functions-public
 * @brief  Resumes the  Converter operation by resetting state machine to RESET
 * @param  POWER_CONTROLLER_t *pcInstance
 * @return uint16_t (0 = failure, 1 = success)
 * @details
 * This function executes the latest task in the state machine enforcing state switch immediately.
 *
 ** *******************************************************************************/
uint16_t drv_Converter_Resume(volatile POWER_CONTROLLER_t *pcInstance)
{
    uint16_t retval=1;
    
    // Reset state machine state and enforce a state switch
    pcInstance->Status.bits.suspend = false;  // Reset running state machine
    retval &= drv_Converter_Execute(pcInstance);
    
    return(retval);
}

// ______________________________________
// END OF FILE
