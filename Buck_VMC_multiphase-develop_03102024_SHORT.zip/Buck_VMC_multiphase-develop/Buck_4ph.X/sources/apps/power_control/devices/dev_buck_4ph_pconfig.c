/*
 * @file   dev_psfb_pconfig.c
 * @author M91406
 *
 * Created on March 12, 2020, 4:31 PM
 */

// Include PSFB Converter driver files
#include <xc_pral.h>
#include "dev_psfb_pconfig.h"
#include "dev_psfb_templates.h"

/* PRIVATE VARIABLES */
/**
 * @var adcore_mask
 * @ingroup lib-layer-psfb-pconfig-properties-variables
 * @brief This variable is use to set the ADC core mask
 */
static uint16_t adcore_mask=0;

/**
 * @var adcore_diff_mask
 * @ingroup lib-layer-psfb-pconfig-properties-variables
 * @brief This variable is use to set the ADC core mask
 */
static uint16_t adcore_diff_mask=0;

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   Initializes the  PWM module by resetting its registers to default
 * @param	pcInstance  Pointer to the Converter data object of type POWER_CONTROLLER_t
 * @return  unsigned integer (0=failure, 1=success)
 *  
 * @details
 *    This function initializes the psfb PWM module base registers with default
 *     values for maximum performance. 
 * 
 *     Default configuration:
 *         - all PWM peripheral power is enabled
 *         - all PWM generators are disabled
 *         - default PWM Module configurations are written in PWM module base registers 
 *********************************************************************************/
uint16_t PWM_ModuleInitialize(volatile POWER_CONTROLLER_t* pcInstance)
{
    uint16_t retval=1;
    volatile P33C_PWM_MODULE_t* pwm;
    
    // Make sure power to the peripheral is enabled
    PMD1bits.PWMMD = 0; // PWM Module Disable: PWM module is enabled
    
    // Initialize PWM module in default mode with Aux PLL = 500 MHz input frequency
    retval = p33c_PwmModule_Initialize(); 
    pwm = p33c_PwmModule_GetHandle();
    
    if (pcInstance->SwNode1.master_period_enable)
    {
        pwm->MPER.value = pcInstance->SwNode1.Period; // Set Period
    }
    if (pcInstance->SwNode2.master_period_enable)
    {
        pwm->MPER.value = pcInstance->SwNode2.Period; // Set Period
    }
    if (pcInstance->SwNode3.master_period_enable)
    {
        pwm->MPER.value = pcInstance->SwNode3.Period; // Set Period
    }
    if (pcInstance->SwNode4.master_period_enable)
    {
        pwm->MPER.value = pcInstance->SwNode4.Period; // Set Period
    }
   
    
    // Return success of PWM module configuration
    return(retval);    

}

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   This function initializes the output pins for the PWM output and the default  PWM settings
 * @param	pcInstance  Pointer to a PSFB Converter data object of type PSFB_POWER_CONTROLLER_t
 * @return  unsigned integer (0=failure, 1=success)
 *  
 * @details
 *    This function initializes the psfb PWM channel with default values for maximum performance. 
 * 
 *     Default configuration:
 *         - selected PWM outputs are enabled 
 *         - PWM timing settings are loaded (i.e., duty cycle, period, dead-times, blanking)
 *         - PWM synchronization is established
 *********************************************************************************/
uint16_t PWM_GeneratorInitialize(volatile POWER_CONTROLLER_t* pcInstance)
{
    uint16_t retval=1;
        
    volatile P33C_PWM_INSTANCE_t* pg;
    volatile P33C_PORT_INSTANCE_t* gpio;

    /* CONFIGURE PRIMARY PWM1 */
    
    // Capture  PWM1 generator GPIO instance 
    gpio = p33c_PortInstance_GetHandle(pcInstance->SwNode1.gpio_instance);

    // Capture  PWM1 generator instance 
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode1.pwm_instance);

    // WRITE GPIO CONFIGURATION OF PWM OUTPUT(S)
    gpio->LATx.value  &= ~(0x0001 << pcInstance->SwNode1.gpio_high);  // Clear PWMxH output LOW
    gpio->TRISx.value &= ~(0x0001 << pcInstance->SwNode1.gpio_high);  // Set PWMxH output to OUTPUT
    gpio->CNPUx.value &= ~(0x0001 << pcInstance->SwNode1.gpio_high);  // Disable internal pull up register (PWMxH)
    gpio->CNPDx.value |=  (0x0001 << pcInstance->SwNode1.gpio_high);  // Enable internal pull down register (PWMxH)
    gpio->ODCx.value  &= ~(0x0001 << pcInstance->SwNode1.gpio_high);  // Disable internal open drain register (PWMxH)

    // Configure synchronous drive 
    if (pcInstance->SwNode1.sync_drive)
    { // Sync output is enabled
        gpio->LATx.value  &= ~(0x0001 << pcInstance->SwNode1.gpio_low); // Clear PWMxL output LOW
        gpio->TRISx.value &= ~(0x0001 << pcInstance->SwNode1.gpio_low); // Set PWMxL output to OUTPUT
        gpio->CNPUx.value &= ~(0x0001 << pcInstance->SwNode1.gpio_low); // Disable internal pull up register (PWMxL)
        gpio->CNPDx.value |= (0x0001 << pcInstance->SwNode1.gpio_low);  // Enable internal pull down register (PWMxL)
        gpio->ODCx.value  &= ~(0x0001 << pcInstance->SwNode1.gpio_low); // Disable internal open drain register (PWMxL)
    }
    else if (pcInstance->SwNode1.gpio_low > 0)
    { // Sync output is disabled
        gpio->LATx.value  &= ~(0x0001 << pcInstance->SwNode1.gpio_low); // Clear PWMxL output LOW
        gpio->TRISx.value |= (0x0001 << pcInstance->SwNode1.gpio_low); // Set PWMxL output to OUTPUT
        gpio->CNPUx.value &= ~(0x0001 << pcInstance->SwNode1.gpio_low); // Disable internal pull up register (PWMxL)
        gpio->CNPDx.value |= (0x0001 << pcInstance->SwNode1.gpio_low);  // Enable internal pull down register (PWMxL)
        gpio->ODCx.value  &= ~(0x0001 << pcInstance->SwNode1.gpio_low); // Disable internal open drain register (PWMxL)
    }


    // COPY CONFIGURATION FROM TEMPLATE TO PWM GENERATOR x CONTROL REGISTERS
    retval = p33c_PwmInstance_SetConfig(pcInstance->SwNode1.pwm_instance, pgConfigPWM);

    // LOAD USER PWM GENERATOR CONFIGURATION FROM THE CONVERTER OBJECT
    pg->PGxDC.value =  PWM_DC_MIN; // PGxDC: PWM GENERATOR x DUTY CYCLE REGISTER TODO impostare il minimo DC
    pg->PGxDCA.value = 0; // PGxDCA: PWM GENERATOR x DUTY CYCLE ADJUSTMENT REGISTER (not used)
    pg->PGxPER.value = pcInstance->SwNode1.Period; // PGxPER: PWM GENERATOR x PERIOD REGISTER
    pg->PGxTRIGA.value = pcInstance->SwNode1.PhaseShift_TrigA_Init; // PGxTRIGA: PWM GENERATOR x TRIGGER A REGISTER
    pg->PGxTRIGB.value = pg->PGxDC.value/2; // PGxTRIGB: PWM GENERATOR x TRIGGER B REGISTER 
    pg->PGxDTL.value = pcInstance->SwNode1.dead_time_falling; // PGxDTL: PWM GENERATOR x DEAD-TIME REGISTER LOW
    pg->PGxDTH.value = pcInstance->SwNode1.dead_time_rising; // PGxDTH: PWM GENERATOR x DEAD-TIME REGISTER HIGH
    pg->PGxLEBL.value = pcInstance->SwNode1.LebPeriod; // PWM GENERATOR x LEADING-EDGE BLANKING REGISTER LOW 

    pg->PGxCONL.bits.HREN = pcInstance->SwNode1.high_resolution_enable; // Enable/Disable High Resolution Mode
    pg->PGxPHASE.value = 0; // PGxPHASE: PWM GENERATOR x PHASE REGISTER

    
    // PWM synchronization only work within groups of 4 (PG1-PG4 or PG5-PG8)
    
    pg->PGxCONH.bits.MSTEN = 1; // Enable Master synchronization mode
    pg->PGxCONH.bits.SOCS = 0b0000; // Master PWM always triggers itself
    pg->PGxEVTL.bits.PGTRGSEL = 0b001; // PGxTRIGA generates the trigger output
    pg->PGxCONH.bits.UPDMOD = 0b000; // SOC update
    pg->PGxEVTL.bits.UPDTRG = 0b01; // PWM registers updated when writing PWM1 DC
    pg->PGxEVTL.bits.ADTR1PS = SAMPLING_DIVIDER;
    
    pg->PGxCONL.bits.CLKSEL=PWM_CKSEL;  // Selects the PWM clock source
    
    
    /* CONFIGURE PRIMARY PWM1 - END */
    
    
    
    /* CONFIGURE SLAVED PWM2 */
    
    // Capture  PWM2 generator GPIO instance 
    gpio = p33c_PortInstance_GetHandle(pcInstance->SwNode2.gpio_instance);

    // Capture  PWM2 generator instance 
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode2.pwm_instance);

    // WRITE GPIO CONFIGURATION OF PWM OUTPUT(S)
    gpio->LATx.value  &= ~(0x0001 << pcInstance->SwNode2.gpio_high);  // Clear PWMxH output LOW
    gpio->TRISx.value &= ~(0x0001 << pcInstance->SwNode2.gpio_high);  // Set PWMxH output to OUTPUT
    gpio->CNPUx.value &= ~(0x0001 << pcInstance->SwNode2.gpio_high);  // Disable internal pull up register (PWMxH)
    gpio->CNPDx.value |=  (0x0001 << pcInstance->SwNode2.gpio_high);  // Enable internal pull down register (PWMxH)
    gpio->ODCx.value  &= ~(0x0001 << pcInstance->SwNode2.gpio_high);  // Disable internal open drain register (PWMxH)

    // Configure synchronous drive 
    if (pcInstance->SwNode2.sync_drive)
    { // Sync output is enabled
        gpio->LATx.value  &= ~(0x0001 << pcInstance->SwNode2.gpio_low); // Clear PWMxL output LOW
        gpio->TRISx.value &= ~(0x0001 << pcInstance->SwNode2.gpio_low); // Set PWMxL output to OUTPUT
        gpio->CNPUx.value &= ~(0x0001 << pcInstance->SwNode2.gpio_low); // Disable internal pull up register (PWMxL)
        gpio->CNPDx.value |= (0x0001 << pcInstance->SwNode2.gpio_low);  // Enable internal pull down register (PWMxL)
        gpio->ODCx.value  &= ~(0x0001 << pcInstance->SwNode2.gpio_low); // Disable internal open drain register (PWMxL)
    }
    else if (pcInstance->SwNode2.gpio_low > 0)
    { // Sync output is disabled
        gpio->LATx.value  &= ~(0x0001 << pcInstance->SwNode2.gpio_low); // Clear PWMxL output LOW
        gpio->TRISx.value |= (0x0001 << pcInstance->SwNode2.gpio_low); // Set PWMxL output to OUTPUT
        gpio->CNPUx.value &= ~(0x0001 << pcInstance->SwNode2.gpio_low); // Disable internal pull up register (PWMxL)
        gpio->CNPDx.value |= (0x0001 << pcInstance->SwNode2.gpio_low);  // Enable internal pull down register (PWMxL)
        gpio->ODCx.value  &= ~(0x0001 << pcInstance->SwNode2.gpio_low); // Disable internal open drain register (PWMxL)
    }


    // COPY CONFIGURATION FROM TEMPLATE TO PWM GENERATOR x CONTROL REGISTERS
    retval = p33c_PwmInstance_SetConfig(pcInstance->SwNode2.pwm_instance, pgConfigPWM);

    // LOAD USER PWM GENERATOR CONFIGURATION FROM THE CONVERTER OBJECT
    pg->PGxDC.value =  PWM_DC_MIN; // PGxDC: PWM GENERATOR x DUTY CYCLE REGISTER
    pg->PGxPER.value = pcInstance->SwNode2.Period; // PGxPER: PWM GENERATOR x PERIOD REGISTER
    pg->PGxTRIGA.value = pcInstance->SwNode2.PhaseShift_TrigA_Init; // PGxTRIGA: PWM GENERATOR x TRIGGER A REGISTER
    pg->PGxTRIGB.value = pg->PGxDC.value/2; // PGxTRIGB: PWM GENERATOR x TRIGGER B REGISTER 
    pg->PGxDTL.value = pcInstance->SwNode2.dead_time_falling; // PGxDTL: PWM GENERATOR x DEAD-TIME REGISTER LOW
    pg->PGxDTH.value = pcInstance->SwNode2.dead_time_rising; // PGxDTH: PWM GENERATOR x DEAD-TIME REGISTER HIGH
    pg->PGxLEBL.value = pcInstance->SwNode2.LebPeriod; // PWM GENERATOR x LEADING-EDGE BLANKING REGISTER LOW 

    pg->PGxCONL.bits.HREN = pcInstance->SwNode2.high_resolution_enable; // Enable/Disable High Resolution Mode
    pg->PGxPHASE.value = 0; // PGxPHASE: PWM GENERATOR x PHASE REGISTER

    
    // PWM synchronization only work within groups of 4 (PG1-PG4 or PG5-PG8)
    
    pg->PGxCONH.bits.SOCS = pcInstance->SwNode1.pwm_instance; // PWM2 is triggered by PWM1
    pg->PGxEVTL.bits.PGTRGSEL = 0b001; // PGxTRIGA generates the trigger output
    pg->PGxCONH.bits.UPDMOD = 0b010; // Client SOC update
    pg->PGxEVTL.bits.ADTR1PS = SAMPLING_DIVIDER;
    
    pg->PGxCONL.bits.CLKSEL=PWM_CKSEL;  // Selects the PWM clock source
   
    /* CONFIGURE SLAVED PWM2 - END */ 
    
    
    /* CONFIGURE SLAVED PWM3 */
    
    // Capture PWM3 generator GPIO instance 
    gpio = p33c_PortInstance_GetHandle(pcInstance->SwNode3.gpio_instance);

    // Capture primary PWM3 generator instance 
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode3.pwm_instance);

    // WRITE GPIO CONFIGURATION OF PWM OUTPUT(S)
    gpio->LATx.value  &= ~(0x0001 << pcInstance->SwNode3.gpio_high);  // Clear PWMxH output LOW
    gpio->TRISx.value &= ~(0x0001 << pcInstance->SwNode3.gpio_high);  // Set PWMxH output to OUTPUT
    gpio->CNPUx.value &= ~(0x0001 << pcInstance->SwNode3.gpio_high);  // Disable internal pull up register (PWMxH)
    gpio->CNPDx.value |=  (0x0001 << pcInstance->SwNode3.gpio_high);  // Enable internal pull down register (PWMxH)
    gpio->ODCx.value  &= ~(0x0001 << pcInstance->SwNode3.gpio_high);  // Disable internal open drain register (PWMxH)

    // Configure synchronous drive 
    if (pcInstance->SwNode3.sync_drive)
    { // Sync output is enabled
        gpio->LATx.value  &= ~(0x0001 << pcInstance->SwNode3.gpio_low); // Clear PWMxL output LOW
        gpio->TRISx.value &= ~(0x0001 << pcInstance->SwNode3.gpio_low); // Set PWMxL output to OUTPUT
        gpio->CNPUx.value &= ~(0x0001 << pcInstance->SwNode3.gpio_low); // Disable internal pull up register (PWMxL)
        gpio->CNPDx.value |= (0x0001 << pcInstance->SwNode3.gpio_low);  // Enable internal pull down register (PWMxL)
        gpio->ODCx.value  &= ~(0x0001 << pcInstance->SwNode3.gpio_low); // Disable internal open drain register (PWMxL)
    }
    else if (pcInstance->SwNode3.gpio_low > 0)
    { // Sync output is disabled
        gpio->LATx.value  &= ~(0x0001 << pcInstance->SwNode3.gpio_low); // Clear PWMxL output LOW
        gpio->TRISx.value |= (0x0001 << pcInstance->SwNode3.gpio_low); // Set PWMxL output to OUTPUT
        gpio->CNPUx.value &= ~(0x0001 << pcInstance->SwNode3.gpio_low); // Disable internal pull up register (PWMxL)
        gpio->CNPDx.value |= (0x0001 << pcInstance->SwNode3.gpio_low);  // Enable internal pull down register (PWMxL)
        gpio->ODCx.value  &= ~(0x0001 << pcInstance->SwNode3.gpio_low); // Disable internal open drain register (PWMxL)
    }


    // COPY CONFIGURATION FROM TEMPLATE TO PWM GENERATOR x CONTROL REGISTERS
    retval = p33c_PwmInstance_SetConfig(pcInstance->SwNode3.pwm_instance, pgConfigPWM);

    // LOAD USER PWM GENERATOR CONFIGURATION FROM THE CONVERTER OBJECT
    pg->PGxDC.value =  PWM_DC_MIN; // PGxDC: PWM GENERATOR x DUTY CYCLE REGISTER
    pg->PGxPER.value = pcInstance->SwNode3.Period; // PGxPER: PWM GENERATOR x PERIOD REGISTER
    pg->PGxTRIGA.value = pcInstance->SwNode3.PhaseShift_TrigA_Init; // PGxTRIGA: PWM GENERATOR x TRIGGER A REGISTER
    pg->PGxTRIGB.value = pg->PGxDC.value/2; // PGxTRIGB: PWM GENERATOR x TRIGGER B REGISTER 
    pg->PGxDTL.value = pcInstance->SwNode3.dead_time_falling; // PGxDTL: PWM GENERATOR x DEAD-TIME REGISTER LOW
    pg->PGxDTH.value = pcInstance->SwNode3.dead_time_rising; // PGxDTH: PWM GENERATOR x DEAD-TIME REGISTER HIGH
    pg->PGxLEBL.value = pcInstance->SwNode3.LebPeriod; // PWM GENERATOR x LEADING-EDGE BLANKING REGISTER LOW 

    pg->PGxCONL.bits.HREN = pcInstance->SwNode3.high_resolution_enable; // Enable/Disable High Resolution Mode
    pg->PGxPHASE.value = 0; // PGxPHASE: PWM GENERATOR x PHASE REGISTER

    
    // PWM synchronization only work within groups of 4 (PG1-PG4 or PG5-PG8)
    
    pg->PGxCONH.bits.SOCS = pcInstance->SwNode2.pwm_instance; // PWM3 is triggered by PWM2
    pg->PGxEVTL.bits.PGTRGSEL = 0b001; // PGxTRIGA generates the trigger output
    pg->PGxCONH.bits.UPDMOD = 0b010; // Client SOC update
    pg->PGxEVTL.bits.ADTR1PS = SAMPLING_DIVIDER;
    
    pg->PGxCONL.bits.CLKSEL=PWM_CKSEL;  // Selects the PWM clock source

    /* CONFIGURE SLAVED PWM3 - END */ 
   
    /* CONFIGURE SLAVED PWM4 */
    
    // Capture PWM4 generator GPIO instance 
    gpio = p33c_PortInstance_GetHandle(pcInstance->SwNode4.gpio_instance);

    // Capture PWM4 generator instance 
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode4.pwm_instance);

    // WRITE GPIO CONFIGURATION OF PWM OUTPUT(S)
    gpio->LATx.value  &= ~(0x0001 << pcInstance->SwNode4.gpio_high);  // Clear PWMxH output LOW
    gpio->TRISx.value &= ~(0x0001 << pcInstance->SwNode4.gpio_high);  // Set PWMxH output to OUTPUT
    gpio->CNPUx.value &= ~(0x0001 << pcInstance->SwNode4.gpio_high);  // Disable internal pull up register (PWMxH)
    gpio->CNPDx.value |=  (0x0001 << pcInstance->SwNode4.gpio_high);  // Enable internal pull down register (PWMxH)
    gpio->ODCx.value  &= ~(0x0001 << pcInstance->SwNode4.gpio_high);  // Disable internal open drain register (PWMxH)

    // Configure synchronous drive 
    if (pcInstance->SwNode4.sync_drive)
    { // Sync output is enabled
        gpio->LATx.value  &= ~(0x0001 << pcInstance->SwNode4.gpio_low); // Clear PWMxL output LOW
        gpio->TRISx.value &= ~(0x0001 << pcInstance->SwNode4.gpio_low); // Set PWMxL output to OUTPUT
        gpio->CNPUx.value &= ~(0x0001 << pcInstance->SwNode4.gpio_low); // Disable internal pull up register (PWMxL)
        gpio->CNPDx.value |= (0x0001 << pcInstance->SwNode4.gpio_low);  // Enable internal pull down register (PWMxL)
        gpio->ODCx.value  &= ~(0x0001 << pcInstance->SwNode4.gpio_low); // Disable internal open drain register (PWMxL)
    }
    else if (pcInstance->SwNode4.gpio_low > 0)
    { // Sync output is disabled
        gpio->LATx.value  &= ~(0x0001 << pcInstance->SwNode4.gpio_low); // Clear PWMxL output LOW
        gpio->TRISx.value |= (0x0001 << pcInstance->SwNode4.gpio_low); // Set PWMxL output to OUTPUT
        gpio->CNPUx.value &= ~(0x0001 << pcInstance->SwNode4.gpio_low); // Disable internal pull up register (PWMxL)
        gpio->CNPDx.value |= (0x0001 << pcInstance->SwNode4.gpio_low);  // Enable internal pull down register (PWMxL)
        gpio->ODCx.value  &= ~(0x0001 << pcInstance->SwNode4.gpio_low); // Disable internal open drain register (PWMxL)
    }


    // COPY CONFIGURATION FROM TEMPLATE TO PWM GENERATOR x CONTROL REGISTERS
    retval = p33c_PwmInstance_SetConfig(pcInstance->SwNode4.pwm_instance, pgConfigPWM);

    // LOAD USER PWM GENERATOR CONFIGURATION FROM THE CONVERTER OBJECT
    pg->PGxDC.value =  PWM_DC_MIN; // PGxDC: PWM GENERATOR x DUTY CYCLE REGISTER
    pg->PGxPER.value = pcInstance->SwNode4.Period; // PGxPER: PWM GENERATOR x PERIOD REGISTER
    pg->PGxTRIGA.value = pcInstance->SwNode4.PhaseShift_TrigA_Init; // PGxTRIGA: PWM GENERATOR x TRIGGER A REGISTER
    pg->PGxTRIGB.value = pg->PGxDC.value/2; // PGxTRIGB: PWM GENERATOR x TRIGGER B REGISTER 
    pg->PGxDTL.value = pcInstance->SwNode4.dead_time_falling; // PGxDTL: PWM GENERATOR x DEAD-TIME REGISTER LOW
    pg->PGxDTH.value = pcInstance->SwNode4.dead_time_rising; // PGxDTH: PWM GENERATOR x DEAD-TIME REGISTER HIGH
    pg->PGxLEBL.value = pcInstance->SwNode4.LebPeriod; // PWM GENERATOR x LEADING-EDGE BLANKING REGISTER LOW 

    pg->PGxCONL.bits.HREN = pcInstance->SwNode4.high_resolution_enable; // Enable/Disable High Resolution Mode
    pg->PGxPHASE.value = 0; // PGxPHASE: PWM GENERATOR x PHASE REGISTER

    
    // PWM synchronization only work within groups of 4 (PG1-PG4 or PG5-PG8)
    
    pg->PGxCONH.bits.SOCS = pcInstance->SwNode3.pwm_instance; // PWM4 is triggered by PWM3
    pg->PGxEVTL.bits.PGTRGSEL = 0b001; // PGxTRIGA generates the trigger output
    pg->PGxCONH.bits.UPDMOD = 0b010; // Client SOC update
    pg->PGxEVTL.bits.ADTR1PS = SAMPLING_DIVIDER;
    
    pg->PGxCONL.bits.CLKSEL=PWM_CKSEL;  // Selects the PWM clock source

    /* CONFIGURE SLAVED PWM4 - END */ 
   
    return(retval);    
}

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   This function enables the converter PWM operation
 * @param	pcInstance  Pointer to a  Converter data object of type PSFB_POWER_CONTROLLER_t
 * @return  unsigned integer (0=failure, 1=success)
 *  
 * @details
 * This function starts the operation of the psfb PWM by enabling the PWM 
 * generator and its output pins.
 *********************************************************************************/
uint16_t PWM_Start(volatile POWER_CONTROLLER_t* pcInstance) 
{
    uint16_t retval=1;
    uint16_t timeout=0;
    volatile P33C_PWM_INSTANCE_t* pg;
    
    
    // Reset duty cycle and trigger values
    pcInstance->SetValues.nominal_duty=PWM_DC_MIN;
    pcInstance->SetValues.nominal_adc_trigger=PWM_DC_MIN/2;
    
    // Reset duty cycle offset values
    pcInstance->Balancing.Buck2_dc_offset=0;
    pcInstance->Balancing.Buck3_dc_offset=0;
    pcInstance->Balancing.Buck4_dc_offset=0;
    
    // Resets IIR filters
    pcInstance->Balancing.IBuck1_iir=0;
    pcInstance->Balancing.IBuck2_iir=0;
    pcInstance->Balancing.IBuck3_iir=0;
    pcInstance->Balancing.IBuck4_iir=0;
    
    /****************** PWM2 CONFIGURATION ************************/
    
    // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode2.pwm_instance);

    pg->PGxIOCONL.value |= P33C_PGxIOCONL_OVREN; // PWMxH/L Output Override Enable: PWM generator controls the PWMxH output pin
    pg->PGxIOCONH.value &= ~(P33C_PGxIOCONH_PEN); // PWMxH/L Output Port Disable: PWM generator controls the PWMxH output pin

    pg->PGxCONL.value |= P33C_PGxCONL_PWM_ON; // PWM Generator Enable: PWM Generator is enabled
    
//    // Update all PWM registers independently from the update trigger source
//    pg->PGxSTAT.value |= P33C_PGxSTAT_UPDREQ;   // Update all PWM registers
//    pg->PGxTRIGA.value = pg->PGxTRIGA.value;    // Update all PWM registers
//    pg->PGxPHASE.value = pg->PGxPHASE.value;    // Update all PWM registers
//    pg->PGxDC.value = pg->PGxDC.value;          // Update all PWM registers
    
    if(pg->PGxCONL.value & P33C_PGxCONL_HRES_EN) { // If high resolution is enabled
        while((!PCLKCONbits.HRRDY) && (timeout++ < 5000));  // wait for high resolution to get ready
        if ((timeout >= 5000) || (PCLKCONbits.HRERR))       // if there is an error
            return(0);  // return ERROR
    }

    if(pcInstance->SwNode2.sync_drive)
        // PWMxH/L Output Port Enable: PWM generator controls the PWMxH output pin
        pg->PGxIOCONH.value |= P33C_PGxIOCONH_PEN; 
    else
        // PWMxH Output Port Enable: PWM generator controls the PWMxH output pin
       pg->PGxIOCONH.value |= (P33C_PGxIOCONH_PEN & REG_PGxIOCONH_ASYNC_MASK); 
    
    /****************** PWM2 CONFIGURATION END ********************/
    
     /****************** PWM3 CONFIGURATION ************************/
    
    // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode3.pwm_instance);

    pg->PGxIOCONL.value |= P33C_PGxIOCONL_OVREN; // PWMxH/L Output Override Enable: PWM generator controls the PWMxH output pin
    pg->PGxIOCONH.value &= ~(P33C_PGxIOCONH_PEN); // PWMxH/L Output Port Disable: PWM generator controls the PWMxH output pin

    pg->PGxCONL.value |= P33C_PGxCONL_PWM_ON; // PWM Generator Enable: PWM Generator is enabled
    
//    // Update all PWM registers independently from the update trigger source
//    pg->PGxSTAT.value |= P33C_PGxSTAT_UPDREQ;   // Update all PWM registers
//    pg->PGxTRIGA.value = pg->PGxTRIGA.value;    // Update all PWM registers
//    pg->PGxPHASE.value = pg->PGxPHASE.value;    // Update all PWM registers
//    pg->PGxDC.value = pg->PGxDC.value;          // Update all PWM registers
    
    if(pg->PGxCONL.value & P33C_PGxCONL_HRES_EN) { // If high resolution is enabled
        while((!PCLKCONbits.HRRDY) && (timeout++ < 5000));  // wait for high resolution to get ready
        if ((timeout >= 5000) || (PCLKCONbits.HRERR))       // if there is an error
            return(0);  // return ERROR
    }

    if(pcInstance->SwNode3.sync_drive)
        // PWMxH/L Output Port Enable: PWM generator controls the PWMxH output pin
        pg->PGxIOCONH.value |= P33C_PGxIOCONH_PEN; 
    else
        // PWMxH Output Port Enable: PWM generator controls the PWMxH output pin
       pg->PGxIOCONH.value |= (P33C_PGxIOCONH_PEN & REG_PGxIOCONH_ASYNC_MASK); 
    
    /****************** PWM3 CONFIGURATION END ********************/
    
     /****************** PWM4 CONFIGURATION ************************/
    
    // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode4.pwm_instance);

    pg->PGxIOCONL.value |= P33C_PGxIOCONL_OVREN; // PWMxH/L Output Override Enable: PWM generator controls the PWMxH output pin
    pg->PGxIOCONH.value &= ~(P33C_PGxIOCONH_PEN); // PWMxH/L Output Port Disable: PWM generator controls the PWMxH output pin

    pg->PGxCONL.value |= P33C_PGxCONL_PWM_ON; // PWM Generator Enable: PWM Generator is enabled
    
//    // Update all PWM registers independently from the update trigger source
//    pg->PGxSTAT.value |= P33C_PGxSTAT_UPDREQ;   // Update all PWM registers
//    pg->PGxTRIGA.value = pg->PGxTRIGA.value;    // Update all PWM registers
//    pg->PGxPHASE.value = pg->PGxPHASE.value;    // Update all PWM registers
//    pg->PGxDC.value = pg->PGxDC.value;          // Update all PWM registers
    
    if(pg->PGxCONL.value & P33C_PGxCONL_HRES_EN) { // If high resolution is enabled
        while((!PCLKCONbits.HRRDY) && (timeout++ < 5000));  // wait for high resolution to get ready
        if ((timeout >= 5000) || (PCLKCONbits.HRERR))       // if there is an error
            return(0);  // return ERROR
    }

    if(pcInstance->SwNode4.sync_drive)
        // PWMxH/L Output Port Enable: PWM generator controls the PWMxH output pin
        pg->PGxIOCONH.value |= P33C_PGxIOCONH_PEN; 
    else
        // PWMxH Output Port Enable: PWM generator controls the PWMxH output pin
       pg->PGxIOCONH.value |= (P33C_PGxIOCONH_PEN & REG_PGxIOCONH_ASYNC_MASK); 
    
    /****************** PWM4 CONFIGURATION END ********************/
    
    
    /****************** PWM1 CONFIGURATION ************************/
    
    // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode1.pwm_instance);

    pg->PGxIOCONL.value |= P33C_PGxIOCONL_OVREN; // PWMxH/L Output Override Enable: PWM generator controls the PWMxH output pin
    pg->PGxIOCONH.value &= ~(P33C_PGxIOCONH_PEN); // PWMxH/L Output Port Disable: PWM generator controls the PWMxH output pin

    pg->PGxCONL.value |= P33C_PGxCONL_PWM_ON; // PWM Generator Enable: PWM Generator is enabled
    
    // Update all PWM registers independently from the update trigger source
    pg->PGxSTAT.value |= P33C_PGxSTAT_UPDREQ;   // Update all PWM registers
    pg->PGxTRIGA.value = pg->PGxTRIGA.value;    // Update all PWM registers
    pg->PGxPHASE.value = pg->PGxPHASE.value;    // Update all PWM registers
    pg->PGxDC.value = pg->PGxDC.value;          // Update all PWM registers
    
    if(pg->PGxCONL.value & P33C_PGxCONL_HRES_EN) { // If high resolution is enabled
        while((!PCLKCONbits.HRRDY) && (timeout++ < 5000));  // wait for high resolution to get ready
        if ((timeout >= 5000) || (PCLKCONbits.HRERR))       // if there is an error
            return(0);  // return ERROR
    }

    if(pcInstance->SwNode1.sync_drive)
        // PWMxH/L Output Port Enable: PWM generator controls the PWMxH output pin
        pg->PGxIOCONH.value |= P33C_PGxIOCONH_PEN; 
    else
        // PWMxH Output Port Enable: PWM generator controls the PWMxH output pin
       pg->PGxIOCONH.value |= (P33C_PGxIOCONH_PEN & REG_PGxIOCONH_ASYNC_MASK); 
    
    /****************** PWM1 CONFIGURATION END ********************/
           
    
    
    
        
    return(retval);    
}

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   This function stops the psfb PWM output
 * @param	pcInstance  Pointer to a PSFB Converter data object of type PSFB_POWER_CONTROLLER_t
 * @return  unsigned integer (0=failure, 1=success)
 *  
 * @details
 * This function shuts down the PWM output by disabling all PWM channels of the recent psfb
 * converter object, overriding the output pins and resetting the psfb PWM duty cycle to
 * its minimum duty ratio. 
 * 
 * If the Power Good output is enabled, this output pin will also be reset.
 *********************************************************************************/
uint16_t PWM_Stop(volatile POWER_CONTROLLER_t* pcInstance) 
{
    uint16_t retval=1;
    volatile P33C_PWM_INSTANCE_t* pg;

    /****************** PWM2 CONFIGURATION ************************/
    
        // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode2.pwm_instance);

    pg->PGxIOCONL.value |= P33C_PGxIOCONL_OVREN;  // PWMxH/L Output Override Enable
    pg->PGxIOCONH.value &= ~(P33C_PGxIOCONH_PEN); // PWMxH/L Output Pint Control Disable
    pg->PGxCONL.value &= ~(P33C_PGxCONL_PWM_ON);  // PWM Generator Disable
    pg->PGxDC.value = PWM_DC_MIN;  // Reset Duty Cycle
    pg->PGxTRIGB.value = PWM_DC_MIN/2;  
    pg->PGxTRIGA.value= pcInstance->SwNode1.PhaseShift_TrigA_Init;
    
    /****************** PWM2 CONFIGURATION END ********************/
    
    /****************** PWM3 CONFIGURATION ************************/
    
        // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode3.pwm_instance);

    pg->PGxIOCONL.value |= P33C_PGxIOCONL_OVREN;  // PWMxH/L Output Override Enable
    pg->PGxIOCONH.value &= ~(P33C_PGxIOCONH_PEN); // PWMxH/L Output Pint Control Disable
    pg->PGxCONL.value &= ~(P33C_PGxCONL_PWM_ON);  // PWM Generator Disable
    pg->PGxDC.value = PWM_DC_MIN;  // Reset Duty Cycle
    pg->PGxTRIGB.value = PWM_DC_MIN/2;  
    pg->PGxTRIGA.value= pcInstance->SwNode1.PhaseShift_TrigA_Init;
    
    /****************** PWM3 CONFIGURATION END ********************/
    
    /****************** PWM4 CONFIGURATION ************************/
    
        // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode4.pwm_instance);

    pg->PGxIOCONL.value |= P33C_PGxIOCONL_OVREN;  // PWMxH/L Output Override Enable
    pg->PGxIOCONH.value &= ~(P33C_PGxIOCONH_PEN); // PWMxH/L Output Pint Control Disable
    pg->PGxCONL.value &= ~(P33C_PGxCONL_PWM_ON);  // PWM Generator Disable
    pg->PGxDC.value = PWM_DC_MIN;  // Reset Duty Cycle
    pg->PGxTRIGB.value = PWM_DC_MIN/2;  
    pg->PGxTRIGA.value= pcInstance->SwNode1.PhaseShift_TrigA_Init;
    
    /****************** PWM4 CONFIGURATION END ********************/
    
    /****************** PWM1 CONFIGURATION ************************/
    
        // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode1.pwm_instance);

    pg->PGxIOCONL.value |= P33C_PGxIOCONL_OVREN;  // PWMxH/L Output Override Enable
    pg->PGxIOCONH.value &= ~(P33C_PGxIOCONH_PEN); // PWMxH/L Output Pint Control Disable
    pg->PGxCONL.value &= ~(P33C_PGxCONL_PWM_ON);  // PWM Generator Disable
    pg->PGxDC.value = PWM_DC_MIN;  // Reset Duty Cycle
    pg->PGxTRIGB.value = PWM_DC_MIN/2;  
    pg->PGxTRIGA.value= pcInstance->SwNode1.PhaseShift_TrigA_Init;
    
    pg->PGxSTAT.value |= P33C_PGxSTAT_UPDREQ;   // Update all PWM registers
    pg->PGxTRIGA.value = pg->PGxTRIGA.value;    // Update all PWM registers
    pg->PGxPHASE.value = pg->PGxPHASE.value;    // Update all PWM registers
    pg->PGxDC.value = pg->PGxDC.value;          // Update all PWM registers
    
    /****************** PWM1 CONFIGURATION END ********************/
    
    // Reset duty cycle and trigger values
    pcInstance->SetValues.nominal_duty=PWM_DC_MIN;
    pcInstance->SetValues.nominal_adc_trigger=PWM_DC_MIN/2;
    
    // Reset duty cycle offset values
    pcInstance->Balancing.Buck2_dc_offset=0;
    pcInstance->Balancing.Buck3_dc_offset=0;
    pcInstance->Balancing.Buck4_dc_offset=0;
    
    // Resets IIR filters
    pcInstance->Balancing.IBuck1_iir=0;
    pcInstance->Balancing.IBuck2_iir=0;
    pcInstance->Balancing.IBuck3_iir=0;
    pcInstance->Balancing.IBuck4_iir=0;
    
    return(retval);    
}

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   This function disables the PWM generator IOs
 * @param	pcInstance  Pointer to a PSFB Converter data object of type PSFB_POWER_CONTROLLER_t
 * @return  unsigned integer (0=failure, 1=success)
 *  
 * @details
 * This function suspends the psfb PWM operation by disabling all PWM outputs of the recent 
 * psfb converter configuration, overriding the PWM output pins and setting the 
 * duty cycle to 0.
 *********************************************************************************/
uint16_t psfbPWM_Suspend(volatile POWER_CONTROLLER_t* pcInstance) 
{
    uint16_t retval=1;
    volatile P33C_PWM_INSTANCE_t* pg;
    
    
    
    
    /****************** PWM2 CONFIGURATION ************************/
    // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode2.pwm_instance);
    
    //Fault PCI only reset if the converter is disabled
    if(0==pcInstance->Status.bits.Enabled)
    {
        pg->PGxFPCIL.bits.SWTERM=1;
        pg->PGxFPCIL.bits.SWTERM=0;
    }
    
    pg->PGxIOCONL.value |= P33C_PGxIOCONL_OVREN; // PWMxH/L Output Override Enable
    pg->PGxDC.value = PWM_DC_MIN;  // Reset Duty Cycle
    pg->PGxTRIGB.value = PWM_DC_MIN/2;  
    pg->PGxTRIGA.value= pcInstance->SwNode1.PhaseShift_TrigA_Init;

    
    // Update all PWM registers independently from the update trigger source
//    pg->PGxSTAT.value |= P33C_PGxSTAT_UPDREQ;   // Update all PWM registers
//    pg->PGxTRIGA.value = pg->PGxTRIGA.value;    // Update all PWM registers
//    pg->PGxPHASE.value = pg->PGxPHASE.value;    // Update all PWM registers
//    pg->PGxDC.value = pg->PGxDC.value;          // Update all PWM registers
    
    retval &= (bool)(pg->PGxIOCONL.value & P33C_PGxIOCONL_OVREN);
        
    /****************** PWM2 CONFIGURATION END ********************/
    
    /****************** PWM3 CONFIGURATION ************************/
    // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode3.pwm_instance);
    
    //Fault PCI only reset if the converter is disabled
    if(0==pcInstance->Status.bits.Enabled)
    {
        pg->PGxFPCIL.bits.SWTERM=1;
        pg->PGxFPCIL.bits.SWTERM=0;
    }
    
    pg->PGxIOCONL.value |= P33C_PGxIOCONL_OVREN; // PWMxH/L Output Override Enable
    pg->PGxDC.value = PWM_DC_MIN;  // Reset Duty Cycle
    pg->PGxTRIGB.value = PWM_DC_MIN/2;  
    pg->PGxTRIGA.value= pcInstance->SwNode1.PhaseShift_TrigA_Init;

    
    // Update all PWM registers independently from the update trigger source
//    pg->PGxSTAT.value |= P33C_PGxSTAT_UPDREQ;   // Update all PWM registers
//    pg->PGxTRIGA.value = pg->PGxTRIGA.value;    // Update all PWM registers
//    pg->PGxPHASE.value = pg->PGxPHASE.value;    // Update all PWM registers
//    pg->PGxDC.value = pg->PGxDC.value;          // Update all PWM registers
    
    retval &= (bool)(pg->PGxIOCONL.value & P33C_PGxIOCONL_OVREN);
        
    /****************** PWM3 CONFIGURATION END ********************/
    
    /****************** PWM4 CONFIGURATION ************************/
    // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode4.pwm_instance);
    
    //Fault PCI only reset if the converter is disabled
    if(0==pcInstance->Status.bits.Enabled)
    {
        pg->PGxFPCIL.bits.SWTERM=1;
        pg->PGxFPCIL.bits.SWTERM=0;
    }
    
    pg->PGxIOCONL.value |= P33C_PGxIOCONL_OVREN; // PWMxH/L Output Override Enable
    pg->PGxDC.value = PWM_DC_MIN;  // Reset Duty Cycle
    pg->PGxTRIGB.value = PWM_DC_MIN/2;  
    pg->PGxTRIGA.value= pcInstance->SwNode1.PhaseShift_TrigA_Init;

    
    // Update all PWM registers independently from the update trigger source
//    pg->PGxSTAT.value |= P33C_PGxSTAT_UPDREQ;   // Update all PWM registers
//    pg->PGxTRIGA.value = pg->PGxTRIGA.value;    // Update all PWM registers
//    pg->PGxPHASE.value = pg->PGxPHASE.value;    // Update all PWM registers
//    pg->PGxDC.value = pg->PGxDC.value;          // Update all PWM registers
    
    retval &= (bool)(pg->PGxIOCONL.value & P33C_PGxIOCONL_OVREN);
        
    /****************** PWM4 CONFIGURATION END ********************/
    
    /****************** PWM1 CONFIGURATION ************************/
    // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode1.pwm_instance);
    
    //Fault PCI only reset if the converter is disabled
    if(0==pcInstance->Status.bits.Enabled)
    {
        pg->PGxFPCIL.bits.SWTERM=1;
        pg->PGxFPCIL.bits.SWTERM=0;
    }
    
    pg->PGxIOCONL.value |= P33C_PGxIOCONL_OVREN; // PWMxH/L Output Override Enable
    pg->PGxDC.value = PWM_DC_MIN;  // Reset Duty Cycle
    pg->PGxTRIGB.value = PWM_DC_MIN/2;  
    pg->PGxTRIGA.value= pcInstance->SwNode1.PhaseShift_TrigA_Init;

    
    // Update all PWM registers independently from the update trigger source
    pg->PGxSTAT.value |= P33C_PGxSTAT_UPDREQ;   // Update all PWM registers
    pg->PGxTRIGA.value = pg->PGxTRIGA.value;    // Update all PWM registers
    pg->PGxPHASE.value = pg->PGxPHASE.value;    // Update all PWM registers
    pg->PGxDC.value = pg->PGxDC.value;          // Update all PWM registers
    
    retval &= (bool)(pg->PGxIOCONL.value & P33C_PGxIOCONL_OVREN);
        
    /****************** PWM1 CONFIGURATION END ********************/
    
    // Reset duty cycle and trigger values
    pcInstance->SetValues.nominal_duty=PWM_DC_MIN;
    pcInstance->SetValues.nominal_adc_trigger=PWM_DC_MIN/2;
    
    // Reset duty cycle offset values
    pcInstance->Balancing.Buck2_dc_offset=0;
    pcInstance->Balancing.Buck3_dc_offset=0;
    pcInstance->Balancing.Buck4_dc_offset=0;
    
    // Resets IIR filters
    pcInstance->Balancing.IBuck1_iir=0;
    pcInstance->Balancing.IBuck2_iir=0;
    pcInstance->Balancing.IBuck3_iir=0;
    pcInstance->Balancing.IBuck4_iir=0;
    
    return(retval);    
}

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   This function resumes the buck PWM operation
 * @param	pcInstance  Pointer to a Converter data object of type struct POWER_CONTROLLER_s
 * @return  unsigned integer (0=failure, 1=success)
 *  
 * @details
 * THis function updates the PWM timing bit and the PWM output pins are enabled.
 *********************************************************************************/
uint16_t psfbPWM_Resume(volatile POWER_CONTROLLER_t* pcInstance) 
{
    uint16_t retval=1;
    volatile P33C_PWM_INSTANCE_t* pg;
    
    
    // Reset duty cycle and trigger values
    pcInstance->SetValues.nominal_duty=PWM_DC_MIN;
    pcInstance->SetValues.nominal_adc_trigger=PWM_DC_MIN/2;       
    
    // Reset duty cycle offset values
    pcInstance->Balancing.Buck2_dc_offset=0;
    pcInstance->Balancing.Buck3_dc_offset=0;
    pcInstance->Balancing.Buck4_dc_offset=0;
    
    // Resets IIR filters
    pcInstance->Balancing.IBuck1_iir=0;
    pcInstance->Balancing.IBuck2_iir=0;
    pcInstance->Balancing.IBuck3_iir=0;
    pcInstance->Balancing.IBuck4_iir=0;
    
    
    /****************** PWM2 CONFIGURATION ************************/
    
        // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode2.pwm_instance);
    
    // Update all PWM registers independently from the update trigger source
//    pg->PGxSTAT.value |= P33C_PGxSTAT_UPDREQ;   // Update all PWM registers
    
    if(pcInstance->SwNode2.sync_drive) {
        // PWMxH/PWMxL Output Override Disable
        pg->PGxIOCONL.value &= ~(P33C_PGxIOCONL_OVREN); 
        retval = (bool)(pg->PGxIOCONL.value & P33C_PGxIOCONL_OVREN);
    }
    else {
        // PWMxH Output Override Disable only
       pg->PGxIOCONL.value &= ~(P33C_PGxIOCONL_OVREN & REG_PGxIOCONL_ASYNC_MASK); 
       retval = (bool)(pg->PGxIOCONL.value & (P33C_PGxIOCONL_OVREN & REG_PGxIOCONL_ASYNC_MASK));
    }        
    
    /****************** PWM2 CONFIGURATION END ********************/
    
    /****************** PWM3 CONFIGURATION ************************/
    
        // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode3.pwm_instance);
    
    // Update all PWM registers independently from the update trigger source
//    pg->PGxSTAT.value |= P33C_PGxSTAT_UPDREQ;   // Update all PWM registers
    
    if(pcInstance->SwNode3.sync_drive) {
        // PWMxH/PWMxL Output Override Disable
        pg->PGxIOCONL.value &= ~(P33C_PGxIOCONL_OVREN); 
        retval = (bool)(pg->PGxIOCONL.value & P33C_PGxIOCONL_OVREN);
    }
    else {
        // PWMxH Output Override Disable only
       pg->PGxIOCONL.value &= ~(P33C_PGxIOCONL_OVREN & REG_PGxIOCONL_ASYNC_MASK); 
       retval = (bool)(pg->PGxIOCONL.value & (P33C_PGxIOCONL_OVREN & REG_PGxIOCONL_ASYNC_MASK));
    }        
    
    /****************** PWM3 CONFIGURATION END ********************/
    
    /****************** PWM4 CONFIGURATION ************************/
    
        // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode4.pwm_instance);
    
    // Update all PWM registers independently from the update trigger source
//    pg->PGxSTAT.value |= P33C_PGxSTAT_UPDREQ;   // Update all PWM registers
    
    if(pcInstance->SwNode4.sync_drive) {
        // PWMxH/PWMxL Output Override Disable
        pg->PGxIOCONL.value &= ~(P33C_PGxIOCONL_OVREN); 
        retval = (bool)(pg->PGxIOCONL.value & P33C_PGxIOCONL_OVREN);
    }
    else {
        // PWMxH Output Override Disable only
       pg->PGxIOCONL.value &= ~(P33C_PGxIOCONL_OVREN & REG_PGxIOCONL_ASYNC_MASK); 
       retval = (bool)(pg->PGxIOCONL.value & (P33C_PGxIOCONL_OVREN & REG_PGxIOCONL_ASYNC_MASK));
    }        
    
    /****************** PWM4 CONFIGURATION END ********************/
    
    /****************** PWM1 CONFIGURATION ************************/
    
        // Capture PWM generator instance
    pg = p33c_PwmInstance_GetHandle(pcInstance->SwNode1.pwm_instance);
    
    // Update all PWM registers independently from the update trigger source
    pg->PGxSTAT.value |= P33C_PGxSTAT_UPDREQ;   // Update all PWM registers
    pg->PGxTRIGA.value = pg->PGxTRIGA.value;    // Update all PWM registers
    pg->PGxPHASE.value = pg->PGxPHASE.value;    // Update all PWM registers
    pg->PGxDC.value = pg->PGxDC.value;          // Update all PWM registers
    
    if(pcInstance->SwNode1.sync_drive) {
        // PWMxH/PWMxL Output Override Disable
        pg->PGxIOCONL.value &= ~(P33C_PGxIOCONL_OVREN); 
        retval = (bool)(pg->PGxIOCONL.value & P33C_PGxIOCONL_OVREN);
    }
    else {
        // PWMxH Output Override Disable only
       pg->PGxIOCONL.value &= ~(P33C_PGxIOCONL_OVREN & REG_PGxIOCONL_ASYNC_MASK); 
       retval = (bool)(pg->PGxIOCONL.value & (P33C_PGxIOCONL_OVREN & REG_PGxIOCONL_ASYNC_MASK));
    }        
    
    /****************** PWM1 CONFIGURATION END ********************/
        
    return(retval);    
}

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   This function initializes the psfb by resetting all its registers to default
 * @param	void
 * @return  unsigned integer (0=failure, 1=success)
 *  
 * @details
 * The ADC initialization covers basic configurations like data format, clock sources and dividers
 * as well as specific configurations for ADC cores. These settings are general, basic settings
 * and not related to specific analog inputs. The standard configuration set here sets up the 
 * ADC module and ADC cores for maximum performance.
 *********************************************************************************/
uint16_t ADC_ModuleInitialize(void) 
{
    uint16_t retval=1;
    
    // Make sure power to peripheral is enabled
    PMD1bits.ADC1MD = 0; // ADC Module Power Disable: ADC module power is enabled
    
    // ADCON1L: ADC CONTROL REGISTER 1 LOW
    ADCON1Lbits.ADON = 0; // ADC Enable: ADC module is off during configuration
    ADCON1Lbits.ADSIDL = 0; // ADC Stop in Idle Mode: Continues module operation in Idle mode
    
    // ADCON1H: ADC CONTROL REGISTER 1 HIGH
    ADCON1Hbits.SHRRES = 0b11; // Shared ADC Core Resolution Selection: 12-bit resolution ADC resolution = 12-bit (0...4095 ticks)
    ADCON1Hbits.FORM = 0; // Fractional Data Output Format: Integer

    // ADCON2L: ADC CONTROL REGISTER 2 LOW
    ADCON2Lbits.REFCIE = 0;; // Band Gap and Reference Voltage Ready Common Interrupt Enable: Common interrupt is disabled for the band gap ready event
    ADCON2Lbits.REFERCIE = 0; // Band Gap or Reference Voltage Error Common Interrupt Enable: Disabled
    ADCON2Lbits.EIEN = 1; // Early Interrupts Enable: The early interrupt feature is enabled
    ADCON2Lbits.PTGEN = 0; // External Conversion Request Interface: Disabled
    ADCON2Lbits.SHREISEL = 0b111; // Shared Core Early Interrupt Time Selection: Early interrupt is set and interrupt is generated 8 TADCORE clocks prior to when the data are ready
    ADCON2Lbits.SHRADCS = 0b0000001; // Shared ADC Core Input Clock Divider: 2:1 (minimum)

    // ADCON2H: ADC CONTROL REGISTER 2 HIGH
    ADCON2Hbits.SHRSAMC = 8; // Shared ADC Core Sample Time Selection: 8x TADs sampling time 
    ADCON2Hbits.REFERR = 0; // reset error flag
    ADCON2Hbits.REFRDY = 0; // reset bandgap status bit

    // ADCON3L: ADC CONTROL REGISTER 3 LOW
    ADCON3Lbits.REFSEL = 0b000; // ADC Reference Voltage Selection: AVDD-toAVSS
    ADCON3Lbits.SUSPEND = 0; // All ADC Core Triggers Disable: All ADC cores can be triggered
    ADCON3Lbits.SUSPCIE = 0; // Suspend All ADC Cores Common Interrupt Enable: Common interrupt is not generated for suspend ADC cores
    ADCON3Lbits.SUSPRDY = 0; // All ADC Cores Suspended Flag: ADC cores have previous conversions in progress
    ADCON3Lbits.SHRSAMP = 0; // Shared ADC Core Sampling Direct Control: use hardware trigger
    ADCON3Lbits.CNVRTCH = 0; // Software Individual Channel Conversion Trigger: Next individual channel conversion trigger can be generated (not used)
    ADCON3Lbits.SWLCTRG = 0; // Software Level-Sensitive Common Trigger: No software, level-sensitive common triggers are generated (not used)
    ADCON3Lbits.SWCTRG = 0; // Software Common Trigger: Ready to generate the next software common trigger (not used)
    ADCON3Lbits.CNVCHSEL = 0; // Channel Number Selection for Software Individual Channel Conversion Trigger: AN0 (not used)
    
    // ADCON3H: ADC CONTROL REGISTER 3 HIGH
    ADCON3Hbits.CLKSEL = 0b10; // ADC Module Clock Source Selection: AVCODIV
    ADCON3Hbits.CLKDIV = 0b000011; // ADC Module Clock Source Divider: 1 Source Clock Period
    ADCON3Hbits.SHREN = 0; // Shared ADC Core Enable: Shared ADC core is disabled
    ADCON3Hbits.C0EN = 0; // Dedicated ADC Core 0 Enable: Dedicated ADC Core 0 is disabled
    ADCON3Hbits.C1EN = 0; // Dedicated ADC Core 1 Enable: Dedicated ADC Core 1 is disabled
    
    // ADCON4L: ADC CONTROL REGISTER 4 LOW
    ADCON4Lbits.SAMC0EN = 0;  // Dedicated ADC Core 0 Conversion Delay Enable: Immediate conversion
    ADCON4Lbits.SAMC1EN = 0;  // Dedicated ADC Core 1 Conversion Delay Enable: Immediate conversion
    
    // ADCON4H: ADC CONTROL REGISTER 4 HIGH
    ADCON4Hbits.C0CHS = 0b00; // Dedicated ADC Core 0 Input Channel Selection: AN0
    ADCON4Hbits.C1CHS = 0b00; // Dedicated ADC Core 1 Input Channel Selection: ANA1

    // ADCON5L: ADC CONTROL REGISTER 5 LOW
    
    ADCON5Lbits.SHRPWR = 0; // Shared ADC Core Power Enable: ADC core is off
    ADCON5Lbits.C0PWR = 0; // Dedicated ADC Core 0 Power Enable: ADC core is off
    ADCON5Lbits.C1PWR = 0; // Dedicated ADC Core 1 Power Enable: ADC core is off
  
    // ADCON5H: ADC CONTROL REGISTER 5 HIGH
    ADCON5Hbits.WARMTIME = 0b1111; // ADC Dedicated Core x Power-up Delay: 32768 Source Clock Periods
    ADCON5Hbits.SHRCIE = 0; // Shared ADC Core Ready Common Interrupt Enable: Common interrupt is disabled for an ADC core ready event
    ADCON5Hbits.C0CIE = 0; // C1CIE: Dedicated ADC Core 0 Ready Common Interrupt Enable: Common interrupt is disabled
    ADCON5Hbits.C1CIE = 0; // C1CIE: Dedicated ADC Core 1 Ready Common Interrupt Enable: Common interrupt is disabled
    
    // ADCORExL: DEDICATED ADC CORE x CONTROL REGISTER LOW
    ADCORE1Lbits.SAMC = 0b0000000000;   // Dedicated ADC Core 1 Conversion Delay Selection: 2 TADCORE (minimum)
    ADCORE0Lbits.SAMC = 0b0000000000;   // Dedicated ADC Core 0 Conversion Delay Selection: 2 TADCORE (minimum)

    // ADCORExH: DEDICATED ADC CORE x CONTROL REGISTER HIGH
    ADCORE0Hbits.RES = 0b11; // ADC Core x Resolution Selection: 12 bit
    ADCORE0Hbits.ADCS = 0b0000000; // ADC Core x Input Clock Divider: 2 Source Clock Periods
    ADCORE0Hbits.EISEL = 0b111; // Early interrupt is set and an interrupt is generated 8 TADCORE clocks prior

    ADCORE1Hbits.RES = 0b11; // ADC Core x Resolution Selection: 12 bit
    ADCORE1Hbits.ADCS = 0b0000000; // ADC Core x Input Clock Divider: 2 Source Clock Periods
    ADCORE1Hbits.EISEL = 0b111; // Early interrupt is set and an interrupt is generated 8 TADCORE clocks prior
    
    return(retval);    
}

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   This function initializes the settings for the ADC channel
 * @param	adcInstance  Pointer to an ADC Input Configuration data object of type PSFB_ADC_INPUT_SETTINGS_t
 * @return  unsigned integer (0=failure, 1=success)
 *  
 * @details
 * This function initializes the ADC input registers based on the selected ADC channel. 
 * This function sets the input channel trigger source, input mode, and the ADC core 
 * connected to the selected channel. 
 *********************************************************************************/
uint16_t ADC_Channel_Initialize(volatile CONVERTER_ADC_INPUT_t* adcInstance) 
{
    uint16_t retval=1;
    volatile uint8_t* ptrADCRegister;
    uint8_t bit_offset;
    
    // Initialize ADC input registers
    if (adcInstance->enabled) {

        // Write level trigger setting
        if (adcInstance->adc_input < 16) {
            ADLVLTRGL |= ((uint16_t)(adcInstance->level_trigger) << adcInstance->adc_input);
            ADEIEL |= ((uint16_t)(adcInstance->early_interrupt_enable) << adcInstance->adc_input);
            ADIEL |= ((uint16_t)(adcInstance->interrupt_enable) << adcInstance->adc_input);
        }
        else if (adcInstance->adc_input < 32) {
            ADLVLTRGH |= ((uint16_t)(adcInstance->level_trigger) << (adcInstance->adc_input - 16));
            ADEIEH |= ((uint16_t)(adcInstance->early_interrupt_enable) << (adcInstance->adc_input - 16));
            ADIEH |= ((uint16_t)(adcInstance->interrupt_enable) << (adcInstance->adc_input - 16));
        }
        else {
            return(0); // ADC input number out of range
        }

        // write input mode setting
        ptrADCRegister = (volatile uint8_t *)((volatile uint8_t *)&ADMOD0L + (volatile uint8_t)(adcInstance->adc_input >> 8));
        if (adcInstance->adc_input < 8)
            bit_offset = (2 * adcInstance->adc_input);
        else if (adcInstance->adc_input < 16)
            bit_offset = (2 * (adcInstance->adc_input-8));
        else if (adcInstance->adc_input < 24)
            bit_offset = (2 * (adcInstance->adc_input-16));
        else if (adcInstance->adc_input < 32)
            bit_offset = (2 * (adcInstance->adc_input-24));
        else
            return(0); // ADC input number out of range
        
        *ptrADCRegister |= ((unsigned int)adcInstance->signed_result << bit_offset);
        *ptrADCRegister |= ((unsigned int)adcInstance->differential_input << (bit_offset + 1));
       
        // Write ADC trigger source setting
        ptrADCRegister = (volatile uint8_t *)((volatile uint8_t *)&ADTRIG0L + adcInstance->adc_input);
        *ptrADCRegister = adcInstance->trigger_source;
        
        // Register ADC core to be active
        switch (adcInstance->adc_core) {
            case 0:
                adcore_mask |= ADC_CORE0_MASK_INDEX;
                if (adcInstance->differential_input)
                    adcore_diff_mask |= ADC_CORE0_MASK_INDEX;
                break;
            case 1:
                adcore_mask |= ADC_CORE1_MASK_INDEX;
                if (adcInstance->differential_input)
                    adcore_diff_mask |= ADC_CORE1_MASK_INDEX;
                break;
            case 2:
                adcore_mask |= ADC_CORE2_MASK_INDEX;
                if (adcInstance->differential_input)
                    adcore_diff_mask |= ADC_CORE2_MASK_INDEX;
                break;
            case 3:
                adcore_mask |= ADC_CORE3_MASK_INDEX;
                if (adcInstance->differential_input)
                    adcore_diff_mask |= ADC_CORE3_MASK_INDEX;
                break;
            default:
                adcore_mask |= ADC_SHRCORE_MASK_INDEX;
                if (adcInstance->differential_input)
                    adcore_diff_mask |= ADC_SHRCORE_MASK_INDEX;
                break;
        }
        
    }
    
    return(retval);
}

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   This function enables the ADC module and starts the ADC cores analog inputs for the required input signals 
 * @param	void
 * @return  unsigned integer (0=failure, 1=success)
 *  
 * @details
 * This function enables the ADC module, powers-up and enables the ADC cores used and waits 
 * until ADC cores are ready.
 *********************************************************************************/
uint16_t ADC_Start(void) 
{
    uint16_t retval=1;
    uint16_t timeout=0;
    uint16_t adcore_mask_compare=0;
    
    // Turn on ADC module
    ADCON1Lbits.ADON = 1;

    ADCON5L = adcore_mask;    // Enable power to all used ADC cores
    adcore_mask_compare = ((adcore_mask << 8) | adcore_mask); // Set ADC Core Ready Bit Mask
    
    while ((ADCON5L != adcore_mask_compare) & (timeout++ < ADC_POWERUP_TIMEOUT)); // Wait until ADC cores are ready
    if (timeout >= ADC_POWERUP_TIMEOUT) return(0); // Skip if powering up ADC cores was unsuccessful
    ADCON3H &= (0xFF00);
    ADCON3H |= (adcore_mask & 0x00FF) ; // Enable ADC cores
    

    return(retval);    
}

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   This function sets the selected general purpose input/ouput pins 
 * @param	gpioInstance  Pointer to a GPIO instance data object of type PSFB_GPIO_INSTANCE_t
 * @return  unsigned integer (0=failure, 1=success)
 *  
 * @details
 * This function captures the user selected pin to be activated through LAT register.
 *********************************************************************************/
uint16_t converterGPIO_Set(volatile CONVERTER_GPIO_INSTANCE_t* gpioInstance)
{
    uint16_t retval=1;

    // Set pin to ACTIVE state
    if (gpioInstance->Polarity == 0)
        gpioInstance->IoPin.Methods.Set(); // Set pin bit in register  
    else
        gpioInstance->IoPin.Methods.Clear(); // Clear pin bit in register            

    // Verify that pin state is not matching polarity
    retval &= (uint16_t)(bool)(gpioInstance->IoPin.Methods.Get() != gpioInstance->Polarity);
    
    return(retval);
}

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   This function clears the selected general purpose input/output pin
 * @param	gpioInstance  Pointer to a GPIO instance data object of type PSFB_GPIO_INSTANCE_t
 * @return  unsigned integer (0=failure, 1=success)
 *  
 * @details
 * This function captures the pin that the use desired to be put in inactive state. 
 *********************************************************************************/
uint16_t converterGPIO_Clear(volatile CONVERTER_GPIO_INSTANCE_t* gpioInstance)
{
    uint16_t retval=1;

    // Set pin to INACTIVE state
    if (gpioInstance->Polarity == 0)
        gpioInstance->IoPin.Methods.Clear(); // Clear pin bit in register            
    else
        gpioInstance->IoPin.Methods.Set(); // Set pin bit in register  
    
    // Verify that pin state is not matching polarity
    retval &= (uint16_t)(bool)(gpioInstance->IoPin.Methods.Get() != gpioInstance->Polarity);
    
    return(retval);
}

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   This function gets the state of the selected pin
 * @param	 gpioInstance  Pointer to a GPIO instance data object of type PSFB_GPIO_INSTANCE_t
 * @return  unsigned integer (0=failure, 1=success)
 *  
 * @details
 * This function captures the selected pin and read its state.
 *********************************************************************************/
bool converterGPIO_GetPinState(volatile CONVERTER_GPIO_INSTANCE_t* gpioInstance)
{
    return(gpioInstance->IoPin.Methods.Get());
}

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   This function initializes a BDBB device pin
 * @param   pcInstance  Pointer to a power converter device pin data object of type PSFB_GPIO_INSTANCE_t
 * @return  unsigned integer (0=failure, 1=success)
 * @details
 *  This function initializes a power supply-related device pin in accordance 
 *  with the user configuration of that pin. This function is private.
 * 
 * @see
 *  psfbGPIO_Initialize
 *********************************************************************************/
static uint16_t psfbGpio_IoInitialize(volatile CONVERTER_GPIO_INSTANCE_t* gpio)
{
    uint16_t retval=1;

    if (p33c_Gpio_IsInitialized((P33C_GPIO_t*)&gpio->IoPin))
    {
        gpio->IoPin.Methods.SetDigital(); // Disable analog functions

        switch (gpio->IoType)
        {
            case 0: // Configure device pin as standard push-pull output

                gpio->IoPin.Methods.SetPullDown(0); // Disable pull-down resistor
                gpio->IoPin.Methods.SetPullUp(0); // Disable pull-up resistor
                gpio->IoPin.Methods.SetOpenDrain(0); // Set Push-Pull Mode (disables open-drain mode)
                gpio->IoPin.Methods.Init(0, gpio->Polarity); // Set device pin as output

                break;

            case 2: // Configure device pin as open-drain output

                if (gpio->Polarity == 0) // Signal is Active Low
                {
                    gpio->IoPin.Methods.SetPullDown(0); // Disable pull-down resistor
                    gpio->IoPin.Methods.SetPullUp(1); // Enable pull-up resistor
                }
                else  // Signal is Active High
                {
                    gpio->IoPin.Methods.SetPullUp(0); // Disable pull-up resistor
                    gpio->IoPin.Methods.SetPullDown(1); // Enable pull-down resistor
                }

                gpio->IoPin.Methods.SetOpenDrain(1); // Set Open-Drain Mode
                gpio->IoPin.Methods.Init(0, gpio->Polarity); // Set device pin as output

                break;

            default:

                gpio->IoPin.Methods.SetPullDown(0); // Disable pull-down resistor
                gpio->IoPin.Methods.SetPullUp(0); // Disable pull-up resistor
                gpio->IoPin.Methods.SetOpenDrain(0); // Set Push-Pull Mode (disables open-drain mode)
                gpio->IoPin.Methods.Init(1, gpio->Polarity); // Set device pin as input
                break;
        }

    }
    else { retval = 0; }

    return(retval);
}

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   This function sets the pin as input or output 
 * @param	gpioInstance  Pointer to a GPIO instance data object of type PSFB_GPIO_INSTANCE_t
 * @return  unsigned integer (0=failure, 1=success)
 *  
 * @details
 * This function captures the user selected pin then set the pin to inactive and
 * set it as digital input or output pin. 
 *********************************************************************************/
uint16_t GPIO_Initialize(volatile POWER_CONTROLLER_t* pcInstance)
{
    uint16_t retval=1;

    // Initialize PGOOD_5V_BUCK input pin
    if(pcInstance->Gpio.PowerGood_5V_Buck.Enabled)
    {
        retval &= psfbGpio_IoInitialize(&pcInstance->Gpio.PowerGood_5V_Buck);
    }
    
    // Initialize PowerGood_FC_Dart_Buck input pin
    if(pcInstance->Gpio.PowerGood_FC_Dart_Buck.Enabled)
    {
        retval &= psfbGpio_IoInitialize(&pcInstance->Gpio.PowerGood_FC_Dart_Buck);
    }
    
    // Initialize PowerGood_Aux_Buck input pin
    if(pcInstance->Gpio.PowerGood_Aux_Buck.Enabled)
    {
        retval &= psfbGpio_IoInitialize(&pcInstance->Gpio.PowerGood_Aux_Buck);
    }
    
    // Initialize PowerGood_200Watt input pin
    if(pcInstance->Gpio.PowerGood_200Watt.Enabled)
    {
        retval &= psfbGpio_IoInitialize(&pcInstance->Gpio.PowerGood_200Watt);
    }
    
    // Initialize Variant input pin
    if(pcInstance->Gpio.Variant.Enabled)
    {
        retval &= psfbGpio_IoInitialize(&pcInstance->Gpio.Variant);
    }
    
    // Initialize Sync_200Watt output pin
    if(pcInstance->Gpio.Sync_200Watt.Enabled)
    {
        retval &= psfbGpio_IoInitialize(&pcInstance->Gpio.Sync_200Watt);
    }
    
    // Initialize Dis_200Watt output pin
    if(pcInstance->Gpio.Dis_U_200Watt.Enabled)
    {
        retval &= psfbGpio_IoInitialize(&pcInstance->Gpio.Dis_U_200Watt);
    }
            
    // Initialize EN_INRUSH output pin
    if(pcInstance->Gpio.EN_Inrush.Enabled)
        retval &= psfbGpio_IoInitialize(&pcInstance->Gpio.EN_Inrush);
    
    // Initialize EN_BYPASS output pin
    if(pcInstance->Gpio.EN_Bypass.Enabled)
        retval &= psfbGpio_IoInitialize(&pcInstance->Gpio.EN_Bypass);
    
    // Initialize EN_DCDC_Inrush output pin
    if(pcInstance->Gpio.EN_DCDC_Inrush.Enabled)
        retval &= psfbGpio_IoInitialize(&pcInstance->Gpio.EN_DCDC_Inrush);
    
    // Initialize EN_DCDC_Idealdiode output pin
    if(pcInstance->Gpio.EN_DCDC_Idealdiode.Enabled)
    {
        retval &= psfbGpio_IoInitialize(&pcInstance->Gpio.EN_DCDC_Idealdiode);
    }
    
    // Initialize V_Comparator input pin
    if(pcInstance->Gpio.V_Comparator.Enabled)
    {
        retval &= psfbGpio_IoInitialize(&pcInstance->Gpio.V_Comparator);
        
        /* configure Interrupt on-change */
        CNCONCbits.CNSTYLE = 1U;
        CNCONCbits.ON = 1U;
        CNEN1Cbits.CNEN1C14 = 1U;
        CNEN0Cbits.CNEN0C14 = 0U;
        
        IPC4bits.CNCIP = 6U;
        IFS1bits.CNCIF = 0U;
        IEC1bits.CNCIE = 1U;
    }
    
    return(retval);
}

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   This function initializes the psfb DAC by resetting all its registers to default
 * @param	pcInstance  Pointer to a PSFB Converter data object of type PSFB_POWER_CONTROLLER_t
 * @return  unsigned integer (0=failure, 1=success)
 *  
 * @details
 * The DAC initialization covers basic configurations like data format, clock sources and dividers
 * as well as specific configurations for DAC modules. These settings are general, basic settings
 * and not related to specific analog inputs. The standard configuration set here sets up the 
 * DAC module for maximum performance.
 *********************************************************************************/
uint16_t DAC_ModuleInitialize(volatile POWER_CONTROLLER_t* pcInstance)
{
    uint16_t retval=1;
    volatile P33C_DAC_MODULE_t* dac;
    
    dac = p33c_DacModule_GetHandle();
        retval=  p33c_DacModule_SetConfig(psfbDacModuleInitConfig);
        dac->DACCTRL1L.bits.DACON = 1;
   
    return(retval);
   
}

/*******************************************************************************
 * @ingroup lib-layer-pconfig-functions
 * @brief   This function initializes the default psfb DAC generator settings
 * @param	pcInstance  Pointer to a PSFB Converter data object of type PSFB_POWER_CONTROLLER_t
 * @return  unsigned integer (0=failure, 1=success)
 *  
 * @details
 *    This function initializes the psfb DAC generator with default values for maximum performance. 
 * 
 *********************************************************************************/
uint16_t DAC_GeneratorInitialize(volatile POWER_CONTROLLER_t* pcInstance)
{
    uint16_t retval=1;
    volatile P33C_DAC_INSTANCE_t* dac;
    
    dac = p33c_DacInstance_GetHandle(pcInstance->SwNode1.dac_instance);
    p33c_DacInstance_SetConfig(pcInstance->SwNode1.dac_instance,psfbDacInstanceConfig);
    dac->DACxDATH.value=pcInstance->SwNode1.dac_threshold;       // Sets the primary current fault level
    
    // Add here other DAC config if needed
    
    return(retval);

}

// _____________________
// end of file
