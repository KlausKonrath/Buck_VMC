/* 
 * @file   dev_psfb_templates.h
 * @author I62419
 *
 * Created on November 2, 2020, 7:32 PM
 */

#ifndef PSFB_CONVERTER_PERIPHERAL_CONFIGURATION_TEMPLATES_H
#define	PSFB_CONVERTER_PERIPHERAL_CONFIGURATION_TEMPLATES_H

#include <xc_pral.h> // include peripheral register abstraction layer drivers

#include "./templates/dev_psfb_ptemp_ccp.h" // Include CCP configuration template header file
#include "./templates/dev_psfb_ptemp_pwm.h" // Include PWM configuration template header file
#include "./templates/dev_psfb_ptemp_adc.h" // Include ADC configuration template header file
#include "./templates/dev_psfb_ptemp_dac.h" // Include DAC configuration template header file

#endif	/* PSFB_CONVERTER_PERIPHERAL_CONFIGURATION_TEMPLATES_H */

// ___________________
// end of file
