/*
 * @file   dev_psfb_opstates.c
 * @author M91406
 *
 * Created on October 9, 2020, 9:16 AM
 */

#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types

#include "dev_psfb_pconfig.h" // include PSFB Converter
//#include "dev_psfb_typedef.h" // include PSFB Converter data object declarations
#include "dev_psfb_converter.h" // include PSFB Converter API declarations

#define FCY 100000000UL
#include <libpic30.h>

#ifdef __WITH_PIL__
#include "pil/pil_main.h"
#include "apps/power_control/app_power_control.h"
#endif

// Private function prototypes of state functions
static uint16_t State_Error(volatile POWER_CONTROLLER_t *pcInstance);
static uint16_t State_Initialize(volatile POWER_CONTROLLER_t *pcInstance);
static uint16_t State_Reset(volatile POWER_CONTROLLER_t *pcInstance);
static uint16_t State_Standby(volatile POWER_CONTROLLER_t *pcInstance);
static uint16_t State_RampUp(volatile POWER_CONTROLLER_t *pcInstance);
static uint16_t State_Online(volatile POWER_CONTROLLER_t *pcInstance);

static uint8_t ct_Delay = 0x00U;
static uint8_t ct_Retry = 0x00U;
static uint8_t ct_Wait = 0x00U;

uint16_t (*ConverterStateMachine[])(volatile POWER_CONTROLLER_t *pcInstance) = {

    State_Error,        ///< State #0: That's the blank "undefined default state", causing the state machine to reset
    State_Initialize,   ///< State #1: Initialize state machine by resetting all runtime flags to default
    State_Reset,        ///< State #2: Reset key runtime flags when power converter was already turned on
    State_Standby,      ///< State #3: After successful initialization, power converter waits to be launched
    State_RampUp,       ///< State #4: Topology-specific startup sub-state machine managing topology specific Ramp-Up function sequence
    State_Online        ///< State #5: During normal operation the converter responds to changes in reference

};

// PSFB Converter state machine function pointer array size
uint16_t ConverterStateList_size = (sizeof(ConverterStateMachine)/sizeof(ConverterStateMachine[0])); 

/*******************************************************************************
 * @fn static uint16_t State_Initialize(volatile PSFB_POWER_CONTROLLER_t *pcInstance)
 * @ingroup lib-layer-psfb-state-machine-functions
 * @param	PSFB_POWER_CONTROLLER_s  pointer to PSFB Converter data structure
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief 
 * 
 * <b>Description</b> 
 * If the controller has not been run yet, the POWER ON and POWER GOOD delay
 * counters are reset and all conditional flag bits are cleared. Status of 
 * power source, ADC and current sensor calibration have to be set during
 * runtime by system check routines. 
 *********************************************************************************/
static uint16_t State_Initialize(volatile POWER_CONTROLLER_t *pcInstance)
{
        
    //PilProbes.DEBUG1=1;
    pcInstance->StartUp.power_on_delay.counter = 0;   // Reset power on counter
    pcInstance->StartUp.power_good_delay.counter = 0; // Reset power good counter
    pcInstance->StartUp.inrush_delay.counter = 0;   // Reset inrush counter

    // Reset all status bits
    pcInstance->Status.bits.adc_active = false;

    // Initiate current sensor calibration flag bit
     if (pcInstance->Status.bits.cs_calib_enable)
        pcInstance->Status.bits.cs_calib_complete = false; 
    else 
        pcInstance->Status.bits.cs_calib_complete = true; 
    
    // Disable control loops
    pcInstance->VLoop.controller->status.bits.enabled = false; // Disable voltage loop
    
    // Clear busy bit
    pcInstance->Status.bits.busy = false; // Clear BUSY bit
    pcInstance->Status.bits.ready = true; // Set READY bit indicating state machine has passed INITIALIZED state
#ifdef __WITH_PIL__
    //PilProbes.LOAD_ON=0;
#endif
    // Transition to STATE_RESET
    return(CONVERTER_OPSRET_COMPLETE); 
    
}

/*******************************************************************************
 * @fn static uint16_t State_Reset(volatile PSFB_POWER_CONTROLLER_t *pcInstance)
 * @ingroup lib-layer-psfb-state-machine-functions
 * @param	PSFB_POWER_CONTROLLER_s  pointer to PSFB Converter data structure
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief 
 * 
 * <b>Description</b> 
 * After successful initialization or after an externally triggered state machine reset,
 * the state machine returns to this RESET mode, re-initiating control mode, references 
 * and status bits before switching further into STANDBY mode. 
 *********************************************************************************/
static uint16_t State_Reset(volatile POWER_CONTROLLER_t *pcInstance)
{
    uint16_t retval=1;
    
    //PilProbes.DEBUG1=2;
    // Disable all PWM outputs & control loops (immediate power cut-off)
    retval &= psfbPWM_Suspend(pcInstance); // Disable PWM outputs
    
    converterGPIO_Clear(&pcInstance->Gpio.EN_Bypass);
    converterGPIO_Clear(&pcInstance->Gpio.EN_Inrush);
    
    
    // Disable voltage loop controller and reset control loop histories
    pcInstance->VLoop.controller->status.bits.enabled = false; // disable voltage control loop
    pcInstance->VLoop.ctrl_Reset(pcInstance->VLoop.controller); // Reset control histories of outer voltage controller
    //*pcInstance->VLoop.controller->Ports.Target.ptrAddress = 0;
    
    

    // Reset sub-state wait period counters
    pcInstance->StartUp.power_on_delay.counter = 0; // Clear Power On Delay counter
    pcInstance->StartUp.power_good_delay.counter = 0; // Clear Power Good Delay counter
    pcInstance->StartUp.power_good_delay.timeout_counter= 0; // Clear Power Good Delay timeout counter
    pcInstance->StartUp.inrush_delay.timeout_counter = 0;   // Reset inrush counter

    
    // Clear Voltage Ramp-Up temporary values
    pcInstance->StartUp.v_ramp.counter = 0;    // Reset all status bits

    pcInstance->Status.bits.busy = false; // Clear BUSY bit
    
    // If any sub-function calls went unsuccessful, reset state machine
    // else, move on to next state
    
    if (retval)
        return(CONVERTER_OPSRET_COMPLETE);
    else
        return(CONVERTER_OPSRET_ERROR);
    
}
                
/*******************************************************************************
 * @fn static uint16_t State_Standby(volatile PSFB_POWER_CONTROLLER_t *pcInstance)
 * @ingroup lib-layer-psfb-state-machine-functions
 * @param	PSFB_POWER_CONTROLLER_s  pointer to PSFB Converter data structure
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief 
 * 
 * <b>Description</b> 
 * After a successful state machine reset, the state machine waits in  
 * STANDBY mode until all conditional flag bits are set/cleared allowing  
 * the converter to run.
 *********************************************************************************/
static uint16_t State_Standby(volatile POWER_CONTROLLER_t *pcInstance)
{
    // if the 'autorun' option is set, automatically set the GO bit when the 
    // converter is enabled
    
    
    if ((pcInstance->Status.bits.Enabled) && (pcInstance->Status.bits.autorun))
    { 
        pcInstance->Status.bits.GO = true; 
    }

//    /* check retry counter */
//    if(ct_Retry >= 3U)
//    {
//        /* repeat function */
//        return(CONVERTER_OPSRET_REPEAT);   
//    }
//    else
//    {
//        /* everything ok - go forward */
//    }
    
//    
//    /* check 100ms waiting counter */
//    if(ct_Wait > 0x00U)
//    {
//        /* decrement counter */
//        ct_Wait--;
//        
//        /* repeat function */
//        return(CONVERTER_OPSRET_REPEAT); 
//    }
//    else
//    {
//        /* enable Inrush */
        converterGPIO_Set(&pcInstance->Gpio.EN_Inrush);
//    }
    
    /* check if 10ms delay reached or V_dcdc is greater than 3V */
//    if((ct_Delay >= 10U) || (pcInstance->Data.Vin_prot-pcInstance->Data.V_dcdc >= V_DCDC_MIN_VOLT))
        if(pcInstance->Data.Vin_prot-pcInstance->Data.V_dcdc >= V_DCDC_MIN_VOLT)
    {
//        /* check if time elapsed */
//        if(ct_Delay >= 10U)
//        {
            /* error occured - shut off EN_Inrush */
//            converterGPIO_Clear(&pcInstance->Gpio.EN_Inrush);
            
//            /* increment retry counter */
//            ct_Retry++;
//            
//            /* re-load 100ms waiting counter */
//            ct_Wait = 100U;
//            
//            /* repeat function */
//            return(CONVERTER_OPSRET_REPEAT); 
//        }
//        else
//        {
//            /* everything ok - go forward */
//        }
//        
//        
//        /* clear delay counter */
//        ct_Delay = 0x00U;
    }
    else
    {
        /* increment delay counter */
//        ct_Delay++;
        
        /* repeat function */
        return(CONVERTER_OPSRET_REPEAT);
    }
    
    

    //delay
    __delay_ms(5);
        
    converterGPIO_Clear(&pcInstance->Gpio.EN_Inrush);
    converterGPIO_Set(&pcInstance->Gpio.EN_Bypass);

    
        
    // Wait for all startup conditions to be met
    if ((pcInstance->Status.bits.Enabled) &&          // state machine needs to be enabled
        (pcInstance->Status.bits.GO) &&               // GO-bit needs to be set
        (pcInstance->Status.bits.adc_active) &&       // ADC needs to be running
        (pcInstance->Status.bits.pwm_active) &&       // PWM needs to be running 
        (!pcInstance->Status.bits.fault_active) &&    // No active fault is present
        (!pcInstance->Status.bits.suspend)          // Power supply is not held in suspend mode
        //&&(pcInstance->Status.bits.cs_calib_complete)  // Current Sensor Calibration complete
        
        )
    {
        pcInstance->Status.bits.GO = false;
        psfbPWM_Resume(pcInstance);
        return(CONVERTER_OPSRET_COMPLETE);
    }
    else
    // Remain in current state until bit-test becomes true
    {
        return(CONVERTER_OPSRET_REPEAT);
    }
    
}

/*******************************************************************************
 * @fn static uint16_t State_RampUp(volatile PSFB_POWER_CONTROLLER_t *pcInstance)
 * @ingroup lib-layer-psfb-state-machine-functions
 * @param	PSFB_POWER_CONTROLLER_s  pointer to PSFB Converter data structure
 * @return  Unsigned Integer (0 = PSFB_OPSRET_REPEAT, 1 = PSFB_OPSRET_COMPLETE,2 = PSFB_OPSRET_REPEAT)
 *
 * @brief 
 * 
 * <b>Description</b> 
 * After a successful state machine reset, the state machine waits in  
 * STANDBY mode until all conditional flag bits are set/cleared allowing  
 * the converter to run. 
 *********************************************************************************/
static uint16_t State_RampUp(volatile POWER_CONTROLLER_t *pcInstance)
{
    uint16_t retval=CONVERTER_OPSRET_ERROR;
    
    // Enable control loops and initialize output voltage ramp parameters
    if(0==pcInstance->VLoop.controller->status.bits.enabled)
    {
        // Initialize the voltage controller for the ramp
        if(0==pcInstance->StartUp.v_ramp.ref_inc_step)
        { pcInstance->StartUp.v_ramp.ref_inc_step=1; }

        pcInstance->StartUp.v_ramp.reference = 0; // Reset Soft-Start Voltage Reference
        pcInstance->VLoop.controller->Ports.ptrControlReference = &pcInstance->StartUp.v_ramp.reference; // Voltage loop is pointing to Soft-Start Reference
                
        pcInstance->VLoop.controller->status.bits.enabled=true;
    }
    else
    { 
        pcInstance->StartUp.v_ramp.reference+=pcInstance->StartUp.v_ramp.ref_inc_step; 
    }
    
    
    // check if ramp is complete
    if (pcInstance->StartUp.v_ramp.reference > pcInstance->SetValues.v_ref)
    {
        // Set reference to the desired level
        pcInstance->StartUp.v_ramp.reference = pcInstance->SetValues.v_ref;

        // Reconnect API reference to controller
        pcInstance->VLoop.controller->Ports.ptrControlReference = &pcInstance->SetValues.v_ref;
        retval = CONVERTER_OPSRET_COMPLETE;

    }
    else
    // remain in this state until ramp is complete
    {
      retval = CONVERTER_OPSRET_REPEAT;
    }
    return(retval);
}

/*******************************************************************************
 * @fn static uint16_t State_Online(volatile PSFB_POWER_CONTROLLER_t *pcInstance)
 * @ingroup lib-layer-psfb-state-machine-functions
 * @param	PSFB_POWER_CONTROLLER_s  pointer to PSFB Converter data structure
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief 
 * 
 * <b>Description</b> 
 * After soft-start and when state POWER_GOOD_DELAY has expired, the converter 
 * enters normal operation.
 * 
 * During normal operation the state machine scans the user reference setting. 
 * Once a change between the user reference setting and the most recent controller 
 * reference has been detected, the state machine will tune the controller 
 * reference to the new user control reference level in incremental steps,
 * applying the same ramp slope as during soft-start.
 * 
 * While ramping the output voltage up or down, the BUSY bit will be set and any 
 * new changes to the reference will be ignored until the ramp up/down is complete.
 *********************************************************************************/
static uint16_t State_Online(volatile POWER_CONTROLLER_t *pcInstance)
{
    uint16_t retval=CONVERTER_OPSRET_ERROR;
    
    // Check for changes in output voltage reference
    int16_t vref_buf = *pcInstance->VLoop.controller->Ports.ptrControlReference;
    
    IEC4bits.CMP2IE = 1;
    
    if(pcInstance->SetValues.v_ref != vref_buf) 
    {
        // Set the BUSY bit indicating a delay/ramp period being executed
        pcInstance->Status.bits.busy = true;

        // New reference value is less than controller reference value => ramp down
        if(pcInstance->SetValues.v_ref < vref_buf)
        {
            // decrement reference until new reference level is reached
            *pcInstance->VLoop.controller->Ports.ptrControlReference -= pcInstance->StartUp.v_ramp.ref_inc_step; // decrement reference
            if(*pcInstance->VLoop.controller->Ports.ptrControlReference < pcInstance->SetValues.v_ref)  // check if ramp is complete
            {
                *pcInstance->VLoop.controller->Ports.ptrControlReference = pcInstance->SetValues.v_ref; // clamp reference level to setting
                pcInstance->Status.bits.busy = false;
            }
        }
        // New reference value is greater than controller reference value => ramp up
        else if(pcInstance->SetValues.v_ref > vref_buf)
        {
            // increment reference until new reference level is reached
            *pcInstance->VLoop.controller->Ports.ptrControlReference += pcInstance->StartUp.v_ramp.ref_inc_step; // increment reference
            if(*pcInstance->VLoop.controller->Ports.ptrControlReference > pcInstance->SetValues.v_ref)  // check if ramp is complete
            {
                *pcInstance->VLoop.controller->Ports.ptrControlReference = pcInstance->SetValues.v_ref; // clamp reference level to setting
                pcInstance->Status.bits.busy = false;
            }
        }
    }
    else
    {
        // Clear the BUSY bit indicating "no state machine activity"
        pcInstance->Status.bits.busy = false;
    }

    // remain in STATE_ONLINE
    retval = CONVERTER_OPSRET_REPEAT;
#ifdef __WITH_PIL__
    if(PilProbes.Start==0)
    {
        // Resets the state machine when PIL simulation is restarted
        pcInstance->StateId.value = (uint32_t)CONVERTER_OPSTATE_INITIALIZE;
    }
#endif

    return(retval);
    
}

/*******************************************************************************
 * @fn static uint16_t State_Error(volatile PSFB_POWER_CONTROLLER_t *pcInstance)
 * @ingroup lib-layer-psfb-state-machine-functions
 * @param	PSFB_POWER_CONTROLLER_s  pointer to PSFB Converter data structure
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief 
 * 
 * <b>Description</b> 
 * This function is a default anchor in case task list index #0 is ever called.
 * This is the equivalent of a switch case "default".
 *********************************************************************************/
static uint16_t State_Error(volatile POWER_CONTROLLER_t *pcInstance)
{
    uint16_t retval=CONVERTER_OPSRET_ERROR;
    
    // If this function is ever called, bring state machine back on track 
    // by resetting it to INITIALIZE
    
    retval = psfbPWM_Suspend(pcInstance);   // Hold PWM output (turning off power)
    pcInstance->Status.bits.busy = false;    // Reset busy bit
    
    converterGPIO_Clear(&pcInstance->Gpio.EN_Bypass);
    converterGPIO_Clear(&pcInstance->Gpio.EN_Inrush);

    if(retval)
        retval = CONVERTER_OPSRET_COMPLETE;
    else
        retval = CONVERTER_OPSRET_ERROR;

    
    return(retval);
}

// ______________________________________
// end of file
