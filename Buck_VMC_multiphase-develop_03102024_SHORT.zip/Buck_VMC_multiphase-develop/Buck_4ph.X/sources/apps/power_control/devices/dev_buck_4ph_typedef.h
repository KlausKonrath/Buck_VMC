/**
 *  (c) 2024 Microchip Technology Inc. and its subsidiaries.
 * 
 *  Subject to your compliance with these terms, you may use Microchip software
 *  and any derivatives exclusively with Microchip products. You're responsible
 *  for complying with 3rd party license terms applicable to your use of 3rd
 *  party software (including open source software) that may accompany Microchip
 *  software.
 *
 *  SOFTWARE IS "AS IS." NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY,
 *  APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,
 *  MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 *  WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP
 *  HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO
 *  THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL
 *  CLAIMS RELATED TO THE SOFTWARE WILL NOT EXCEED AMOUNT OF FEES, IF ANY,
 *  YOU PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 *
 */

/* 
 * @file    dev_buck_4ph_typedef.h
 * @author  M91169
 * @brief   Type definitions for the Phase Shift Full Bridge Converter data object
 * @version 1.0  initial release
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef BUCK_4PH_CONVERTER_TYPE_DEF_H
#define	BUCK_4PH_CONVERTER_TYPE_DEF_H

#include <xc_pral.h> // include processor files - each processor file is guarded.  

#include "config/hal.h"
#include "../drivers/npnz16b.h"



/****************************************************************************************************
 * @ingroup lib-layer-converter-properties-private-data-types
 * @enum    CONVERTER_STATUS_s 
 * @brief   Enumeration of status and control flags
 * @extends POWER_CONTROLLER_s
 *****************************************************************************************************/
/****************************************************************************************************
 * @brief Generic power controller status word
 * 
 * <b>Description:</b>
 * The power controller status/control word contains status (low-byte) and control bits (high-byte). 
 * -# Status Bits:
 *      - ADC_ACTIVE: ADC is active and running (read only)
 *      - PWM_STARTED: PWM is active and running generating ADC triggers (read only)
 *      - POWERSOURCE_DETECTED: A valid power source has been detected allowing the converter to run (read only)
 *      - CS_READ: Current sense feedback ready (read only)
 *      - FORCED_SHUT_DOWN: Control(Status bit for external software components forcing the converter to stay off
 *      - BUSY: Converter is currently going through an internal process (e.g. ramp up/down) (read only)
 * 
 * -# Control Bits
 *      - ENABLE: Enables/Disables the power converter
 *      - AUTORUN: When set, the power converter will automatically start up once all status bits are set accordingly
 *      - GO: Control bit to manually start the power converter if (AUTOSTART=0)
 *  
 *****************************************************************************************************/
struct CONVERTER_STATUS_s     ///<Power Train Data Object
{
    union {
    struct{
        bool ready:1;              ///< Bit #0: status bit, indicating PSFB Converter is initialized and ready to run
        bool adc_active:1;         ///< Bit #1: indicating that ADC has been started and samples are taken
        bool pwm_active:1;         ///< Bit #2: indicating that PWM has been started and ADC triggers are generated
        bool fault_active :1;      ///< Bit #3: Flag bit indicating system is in enforced shut down mode (usually due to a fault condition)
        unsigned :1;               ///< Bit #4:  indicating that a valid power source was detected
        bool cs_calib_complete :1; ///< Bit #5: indicating that current sensor is ready
        unsigned :1;               ///< Bit #6: (reserved)
        bool busy :1;              ///< Bit #7:  Flag bit indicating that the state machine is executing a process (e.g. startup-ramp)

        bool cs_calib_enable :1;   ///< Bit #8:  Control bit indicating if current sense needs calibrations
        unsigned :1;               ///< Bit #9: (reserved)
        unsigned :1;               ///< Bit #10: (reserved)
        unsigned :1;               ///< Bit #11: (reserved)
        bool suspend :1;           ///< Bit #12: Control bit to put the converter in suspend mode (turned off while ENABLE bit is still on)
        bool GO :1;                ///< Bit #13: When set, the GO-bit fires up the power supply
        bool autorun :1;           ///< Bit #14: Control bit determining if converter is starting automatically or on command (using the GO bit)
        bool Enabled :1;           ///< Bit #15: Control bit enabling/disabling the converter
    } __attribute__((packed)) bits;         ///< data structure for single bit addressing operations

	uint16_t value; ///< buffer for 16-bit word read/write operations
    };
    
};
typedef struct CONVERTER_STATUS_s CONVERTER_STATUS_t;

/****************************************************************************************************
 * @ingroup lib-layer-converter-properties-private-data-types
 * @enum CONVERTER_OPSTATES_e
 * @brief  Enumeration of state machine operating states 
 * @extends CONVERTER_STATE_ID_s 
 * @details
 * This enumeration is listing all defined states supported by the power controller state-machine.
 * The state machine handles the initialization of the power controller, stand-by, start up procedure
 * including Power-On-Delay, Ramp-Up and Power Good Delay until it ends up in a continuous operating
 * state. When reference values are changed while running, the state machine will tune into the new
 * reference values using the slew rates defined for the startup phase. 
 *****************************************************************************************************/
enum CONVERTER_OPSTATES_e    // Enumeration of state machine operating states 
{    
    CONVERTER_OPSTATE_ERROR          = 0x0000,  ///< power converter control state #0: in case of an error, state machine will reset to RESET
    CONVERTER_OPSTATE_INITIALIZE     = 0x0001,  ///< power converter control state #1: initialize variables and hijack controller reference
    CONVERTER_OPSTATE_RESET          = 0x0002,  ///< power converter control state #2: Initializing variable but bypassing delays
    CONVERTER_OPSTATE_STANDBY        = 0x0003,  ///< power converter control state #3: power converter control state #2 standing by, ready to launch, waiting for GO (no action)
    CONVERTER_OPSTATE_RAMPUP         = 0x0004,  ///< power converter control state #4: Startup handler sub-state machine
    CONVERTER_OPSTATE_ONLINE         = 0x0005   ///< power converter control state #5: Output in regulation and power is OK (normal continuous operation)
        
};
typedef enum CONVERTER_OPSTATES_e CONVERTER_OPSTATE_t; // Enumeration of state machine operating states 

/****************************************************************************************************
 * @ingroup lib-layer-converter-properties-private-data-types
 * @enum CONVERTER_OPSTATE_RETURNS_e
 * @brief Enumeration of state machine operating state return values
 ****************************************************************************************************/
enum CONVERTER_OPSTATE_RETURNS_e
{  // Enumeration of state machine operating state return values
    
    CONVERTER_OPSRET_ERROR           = 0x0000,  ///< power converter state return #0: internal error occurred
    CONVERTER_OPSRET_COMPLETE        = 0x0001,  ///< power converter state return #1: operation state has completed
    CONVERTER_OPSRET_REPEAT          = 0x0002   ///< power converter state return #2: operation state is in progress and needs to be recalled
        
};
typedef enum CONVERTER_OPSTATE_RETURNS_e CONVERTER_OPSTATE_RETURNS_t; // Enumeration of state machine operating state return values

/****************************************************************************************************
 * @ingroup lib-layer-converter-properties-private-data-types
 * @enum CONVERTER_STATE_ID_s 
 * @brief data structure breaking down State ID into Main-State and Sub-State IDs
 * @extends PSFB_POWER_CONTROLLER_s
 *****************************************************************************************************/
struct CONVERTER_STATE_ID_s 
{
    union {
    struct { 
        CONVERTER_OPSTATE_t opstate_id;   ///< Most recent operating state of main state machine
        //enum PSFB_SUBSTATES_e substate_id; ///< Most recent operating state of active sub state machine
    } bits;
    uint32_t value; ///> full state ID value access to main and sub-state machine state
    };
    
};
typedef struct CONVERTER_STATE_ID_s CONVERTER_STATE_ID_t;

/****************************************************************************************************
 * @ingroup lib-layer-psfb-converter-properties-private-data-types
 * @enum PSFB_STARTUP_PERIOD_HANDLER_s
 * @brief Power converter soft-start settings
 * @extends PSFB_CONVERTER_STARTUP_s
 * @details
 * This data structure is used to set the startup settings such as power on delay, power good delay
 * and ramp up time. It further covers private values like startup counters and reference values
 * for voltage and current, which are used internally by the controller (read only) but are still
 * accessible for external code modules for monitoring, diagnostics and fault handling purposes.
 * 
 *****************************************************************************************************/
struct CONVERTER_STARTUP_PERIOD_HANDLER_s 
{
    uint16_t counter; // Soft-Start Execution Counter (read only)
    uint16_t period;  // Soft-Start Period (POD, RAMP PERIOD, PGD, etc.)
    uint16_t reference; // Internal dummy reference used to increment/decrement controller reference
    uint16_t ref_inc_step; // Size/value of one reference increment/decrement or this period
};
typedef struct CONVERTER_STARTUP_PERIOD_HANDLER_s PSFB_STARTUP_PERIOD_HANDLER_t; ///> Power converter soft-start auxiliary variables

/***************************************************************************************************
 * @ingroup lib-layer-psfb-converter-properties-private-data-types
 * @enum PSFB_STARTUP_DELAY_MONITOR_s
 * @brief  Bulk capacitor charge-up monitor
 * @extends PSFB_STARTUP_DELAY_MONITOR_s
 *****************************************************************************************************/
struct CONVERTER_STARTUP_DELAY_MONITOR_s
{
    uint16_t counter; ///> counter to measure voltage settling time 
    uint16_t period; ///> period in which voltage should not change
    uint16_t filter_mask; ///> Bit-mask for filtered comparison between previous and most recent sample
    uint16_t timeout; ///> Additional timeout counter
    uint16_t timeout_counter; ///> Parallel counter monitoring for a given timeout window
};
typedef struct CONVERTER_STARTUP_DELAY_MONITOR_s PSFB_STARTUP_DELAY_MONITOR_t; ///> Bulk capacitor charge-up monitor
 
/****************************************************************************************************
 * @ingroup lib-layer-converter-properties-private-data-types
 * @enum CONVERTER_STARTUP_s
 * @brief Generic power controller startup settings
 * @details This data structure is used to set the startup settings such as power on delay, power good delay
 * and ramp up time. It further covers private values like startup counters and reference values
 * for voltage and current, which are used internally by the controller (read only) but are still
 * accessible for external code modules for monitoring, diagnostics and fault handling purposes.
 * @extends CONVERTER_POWER_CONTROLLER_s
 *****************************************************************************************************/
struct CONVERTER_STARTUP_s
{
    struct CONVERTER_STARTUP_DELAY_MONITOR_s power_on_delay;
    struct CONVERTER_STARTUP_DELAY_MONITOR_s power_good_delay;
    struct CONVERTER_STARTUP_DELAY_MONITOR_s inrush_delay;
    struct CONVERTER_STARTUP_PERIOD_HANDLER_s i_ramp;
    struct CONVERTER_STARTUP_PERIOD_HANDLER_s v_ramp;
};
typedef struct CONVERTER_STARTUP_s CONVERTER_STARTUP_t; ///> Power converter start-up settings and variables

/****************************************************************************************************
 * @ingroup lib-layer-converter-properties-private-data-types
 * @struct  CONVERTER_DATA_s
 * @brief   Publicly accessible data buffer of most recent runtime data values
 * @extends CONVERTER_POWER_CONTROLLER_s
 *****************************************************************************************************/
struct CONVERTER_DATA_s
{
    uint16_t Vin;                           ///< Converter input voltage
    uint16_t Vin_phys;                      ///< Converter input voltage in [10mV]
    uint16_t V_dcdc;                        ///< Converter dcdc voltage
    uint16_t V_dcdc_phys;                   ///< Converter dcdc voltage in [10mV]
    uint16_t V_motor;                       ///< Converter motor voltage
    uint16_t V_motor_phys;                  ///< Converter motor voltage in [10mV]
    uint16_t V_aux;                         ///< Converter aux voltage
    uint16_t V_aux_phys;                    ///< Converter aux voltage in [10mV]
    uint16_t V_24volt;                      ///< Converter 24V voltage
    uint16_t V_24volt_phys;                 ///< Converter 24V voltage in [10mV]
    uint16_t I_200watt;                     ///< Converter 200W current
    uint16_t I_200watt_phys;                ///< Converter 200W current in [1mA]
    uint16_t Vin_prot;                      ///< Converter before the inrush input voltage
    uint16_t Vin_prot_phys;                 ///< Converter before the inrush input voltage in [10mV]
    uint16_t Vout;                          ///< Converter output voltage
    uint16_t Vout_phys;                     ///< Converter output voltage in [10mV]
    uint16_t Ibuck1;                        ///< Converter buck1 current
    uint16_t Ibuck1_phys;                   ///< Converter buck1 current in [1mA]
    uint16_t Ibuck2;                        ///< Converter buck2 current
    uint16_t Ibuck2_phys;                   ///< Converter buck2 current in [1mA]
    uint16_t Ibuck3;                        ///< Converter buck3 current
    uint16_t Ibuck3_phys;                   ///< Converter buck3 current in [1mA]
    uint16_t Ibuck4;                        ///< Converter buck4 current
    uint16_t Ibuck4_phys;                   ///< Converter buck4 current in [1mA]
};
typedef struct CONVERTER_DATA_s CONVERTER_DATA_t;         ///< PSFB Converter runtime data

/****************************************************************************************************
 * @ingroup lib-layer-psfb-converter-properties-private-data-types
 * @enum PSFB_CONTROL_MODE_e
 * @brief  Enumeration of the power supply mode control
 * @extends PSFB_CONVERTER_SETTINGS_s
 * @details
 * This data structure is used to set the overall settings to allow external software instances 
 * to control the power control object, such as voltage and current references.
 *****************************************************************************************************/
enum PSFB_CONTROL_MODE_e 
{
    PSFB_CONTROL_MODE_VMC = 0,  // Voltage Mode Control
    PSFB_CONTROL_MODE_PCMC = 1, // Peak current mode Control
    PSFB_CONTROL_MODE_ACMC  = 2 // Average Current Mode Control
};
typedef enum PSFB_CONTROL_MODE_e PSFB_CONTROL_MODE_t;

/****************************************************************************************************
 * @ingroup lib-layer-psfb-converter-properties-private-data-types
 * @struct PSFB_CONVERTER_SETTINGS_s
 * @brief Generic power controller control settings
 * @extends PSFB_POWER_CONTROLLER_s
 * @details
 * This data structure is used to set the overall settings to allow external software instances 
 * to control the power control object, such as voltage and current references.
 *****************************************************************************************************/
struct CONVERTER_SETTINGS_s
{
    uint16_t v_ref;                 ///< User reference setting used to control the power converter controller
    uint16_t nominal_duty;          ///< Used to store the output of the voltage loop
    uint16_t nominal_adc_trigger;   ///< Used to store the trigger for ADC channels
};
typedef struct CONVERTER_SETTINGS_s CONVERTER_SETTINGS_t;

/****************************************************************************************************
 * @ingroup lib-layer-psfb-converter-properties-data-types
 * @struct PSFB_NPNZ16_CONTROLLER_s
 * @brief Generic power control loop settings
 * @extends PSFB_POWER_CONTROLLER_s
 * 
 * @details
 * This data structure is used to set the control loop settings such as pointers to controller 
 * objects and its function calls as well as basic user settings such as reference, feedback
 * signal offsets, trigger delays and minimum/maximum output clamping values.
 *  
 *****************************************************************************************************/
struct CONVERTER_NPNZ16_CONTROLLER_s 
{
    // Properties (user settings)
    uint16_t reference;            ///< Control loop reference variable NOT USED 
    uint16_t feedback_offset;      ///< Feedback offset value for calibration or bi-direction feedback signals
    uint16_t trigger_offset;       ///< ADC trigger offset value for trigger fine-tuning
    int16_t  minimum;              ///< output clamping value (minimum)
    uint16_t maximum;              ///< output clamping value (maximum)
	
    // Control Loop Object
    volatile NPNZ16b_t* controller;  ///< pointer to control loop object data structure
	
    // Function pointers
    volatile uint16_t (*ctrl_Initialize)(volatile NPNZ16b_t*); ///< Function pointer to INIT routine
    void (*ctrl_Reset)(volatile NPNZ16b_t*); ///< Function pointer to RESET routine
    void (*ctrl_Update)(volatile NPNZ16b_t*); ///< Function pointer to UPDATE routine
    void (*ctrl_Precharge)(volatile NPNZ16b_t*, volatile int, volatile int); ///< Function pointer to PRECHARGE routine
};
typedef struct CONVERTER_NPNZ16_CONTROLLER_s CONVERTER_NPNZ16_CONTROLLER_t;


/****************************************************************************************************
 * @ingroup lib-layer-converter-properties-private-data-types
 * @struct SWITCH_NODE_SETTINGS_s
 * @brief Generic power converter switch-node specifications
 * @extends POWER_CONTROLLER_s
 * 
 * @details
 * This data structure is used to set the converter switch-node specifications declaring which
 * PWM channel is used as well as its switching frequency, phase-shift, dead times and duty ratio
 * limits.
 * 
 *****************************************************************************************************/
struct SWITCH_NODE_s 
{
    uint16_t pwm_instance;         ///< number of the PWM channel used
    uint16_t gpio_instance;        ///< GPIO instance of the selected PWM generator
    uint16_t gpio_high;            ///< GPIO port pin-number of PWMxH of the selected PWM generator
    uint16_t gpio_low;             ///< GPIO port pin-number of PWMxL of the selected PWM generator
    bool     master_period_enable; ///< Selecting MASTER or Individual period register
    bool     high_resolution_enable; ///< Selecting if PWM module should use high-resolution mode 
    bool     sync_drive;           ///< Selecting if PWM module should run in complementary or single mode 
    uint16_t Period;               ///< Switching period
    uint16_t PhaseShift_TrigA_Init;///< Initial triga when the PWM module is being turned on
    uint16_t dead_time_rising;     ///< Dead time setting at rising edge of a half-bridge drive
    uint16_t dead_time_falling;    ///< Dead time setting at falling edge of a half-bridge drive
    uint16_t trigger_scaler;       ///< PWM triggers for ADC will be generated every n-th cycle
    uint16_t trigger_offset;       ///< PWM triggers for ADC will be offset by n cycles
    uint16_t dac_instance;         ///< Comparator used to turn off the PWM in case of primary current fault
    uint16_t dac_threshold;        ///< Leading-Edge Blanking period
    uint16_t LebPeriod;           ///< Leading-Edge Blanking period
};
typedef struct SWITCH_NODE_s SWITCH_NODE_t; ///< Switching signal timing settings

/*****************************************************************************************************
 * @ingroup lib-layer-psfb-converter-properties-private-data-types
 * @struct PSFB_ADC_INPUT_SCALING_s
 * @brief ADC input signal scaling
 * @extends PSFB_ADC_INPUT_SETTINGS_s
 * 
 ****************************************************************************************************/
//struct PSFB_ADC_INPUT_SCALING_s
//{
//    int16_t factor; ///< Fractional scaling factor (range -1 ... 0.99969)
//    int16_t scaler; ///< Feedback number scaler used for number normalization
//    int16_t offset; ///< Signal offset as signed integer to be subtracted from ADC input
//};
//typedef struct PSFB_ADC_INPUT_SCALING_s PSFB_ADC_INPUT_SCALING_t; ///< ADC input signal scaling = (ADCBUF - <offset>) * <factor> >> 2^<scaler>

/****************************************************************************************************
 * @ingroup lib-layer-psfb-converter-properties-private-data-types
 * @struct PSFB_ADC_INPUT_SETTINGS_s
 * @brief Generic power converter ADC input channel configuration
 * @extends PSFB_POWER_CONTROLLER_s
 * 
 * @details
 * This data structure is used to set the converter feedback specifications declaring which
 * ADC channels are used including the individual AD input configuration such as trigger mode,
 * input mode, result format and value normalization.
 * 
 *****************************************************************************************************/
struct PSFB_ADC_INPUT_s 
{
    bool enabled;                  ///< input channel enable bit
    uint16_t* adc_buffer;          ///< pointer to ADC result buffer
    uint16_t gpio_instance;        ///< GPIO instance of the selected PWM generator
    uint8_t adc_input;             ///< number of the ADC input channel used
    uint8_t adc_core;              ///< number of the ADC core connected to the selected channel
    uint8_t trigger_source;        ///< input channel trigger source
    bool interrupt_enable;         ///< input channel interrupt enable bit
    bool early_interrupt_enable;   ///< input channel early interrupt enable bit
    bool differential_input;       ///< input channel differential mode enable bit
    bool signed_result;            ///< input channel singed result mode enable bit
    bool level_trigger;            ///< input channel level trigger mode enable bit
    //struct PSFB_ADC_INPUT_SCALING_s scaling; ///< normalization scaling settings
};
typedef struct PSFB_ADC_INPUT_s CONVERTER_ADC_INPUT_t; ///< ADC input channel configuration

/****************************************************************************************************
 * @ingroup lib-layer-psfb-converter-properties-private-data-types
 * @struct  PSFB_FEEDBACK_SETTINGS_s
 * @brief   Power converter feedback input channel declarations
 * @extends PSFB_POWER_CONTROLLER_s
 * *************************************************************************************************** */
struct CONVERTER_FEEDBACK_s 
{
    CONVERTER_ADC_INPUT_t ad_vin_prot;                   ///< ADC input sampling protected input voltage
    CONVERTER_ADC_INPUT_t ad_vin;                        ///< ADC input sampling input voltage
    CONVERTER_ADC_INPUT_t ad_v_dcdc;                     ///< ADC input sampling dcdc voltage
    CONVERTER_ADC_INPUT_t ad_v_motor;                    ///< ADC input sampling motor voltage
    CONVERTER_ADC_INPUT_t ad_v_aux;                      ///< ADC input sampling aux voltage
    CONVERTER_ADC_INPUT_t ad_v_24volt;                   ///< ADC input sampling 24V voltage
    CONVERTER_ADC_INPUT_t ad_i_200watt;                  ///< ADC input sampling i_200watt current
    CONVERTER_ADC_INPUT_t ad_vout;                       ///< ADC input sampling output voltage
    CONVERTER_ADC_INPUT_t ad_ibuck1;                     ///< ADC input sampling buck1 current
    CONVERTER_ADC_INPUT_t ad_ibuck2;                     ///< ADC input sampling buck2 current
    CONVERTER_ADC_INPUT_t ad_ibuck3;                     ///< ADC input sampling buck3 current
    CONVERTER_ADC_INPUT_t ad_ibuck4;                     ///< ADC input sampling buck4 current
};
typedef struct CONVERTER_FEEDBACK_s CONVERTER_FEEDBACK_t; ///< PSFB converter feedback declarations

/****************************************************************************************************
 * @ingroup lib-layer-converter-properties-private-data-types
 * @struct CONVERTER_GPIO_INSTANCE_s
 * @brief Generic power converter GPIO specifications
 * @extends CONVERTER_GPIO_SETTINGS_s
 * 
 * @details
 * This data structure is used to set the converter GPIO specifications declaring which
 * if and which additional GPIOs are used by the converter controller, such as POWER_GOOD.
 * 
 *****************************************************************************************************/
struct CONVERTER_GPIO_INSTANCE_s 
{
    bool Enabled;      ///< Specifies, if this IO is used or not
    P33C_GPIO_t IoPin; ///< Assigns a device pin to be controlled by the library
    uint16_t Polarity; ///< Output polarity, where 0=ACTIVE HIGH, 1=ACTIVE_LOW
    uint16_t IoType;   ///< Input/Output definition (0=output (push-pull), 1=input, 2=open-drain (output))
};
typedef struct CONVERTER_GPIO_INSTANCE_s CONVERTER_GPIO_INSTANCE_t; ///< GPIO instance of the converter control GPIO

/****************************************************************************************************
 * @ingroup lib-layer-psfb-converter-properties-private-data-types
 * @struct PSFB_GPIO_SETTINGS_s 
 * @brief Generic power converter GPIO specifications
 * @extends PSFB_POWER_CONTROLLER_s
 *****************************************************************************************************/
struct CONVERTER_GPIO_s 
{
    CONVERTER_GPIO_INSTANCE_t PowerGood_5V_Buck;        ///< Power Good 5V Buck INPUT
    CONVERTER_GPIO_INSTANCE_t PowerGood_FC_Dart_Buck;   ///< Power Good FC Dart Buck INPUT
    CONVERTER_GPIO_INSTANCE_t PowerGood_Aux_Buck;       ///< Power Good AUX Buck INPUT
    CONVERTER_GPIO_INSTANCE_t PowerGood_200Watt;        ///< Power Good 200W INPUT
    CONVERTER_GPIO_INSTANCE_t Variant;                  ///< Variant INPUT
    CONVERTER_GPIO_INSTANCE_t Sync_200Watt;             ///< Sync_200Watt OUTPUT
    CONVERTER_GPIO_INSTANCE_t Dis_U_200Watt;            ///< Dis_U_200Watt OUTPUT
    CONVERTER_GPIO_INSTANCE_t EN_Bypass;                ///< EN_Bypass Output
    CONVERTER_GPIO_INSTANCE_t EN_Inrush;                ///< EN_Inrush Output
    CONVERTER_GPIO_INSTANCE_t EN_DCDC_Inrush;           ///< EN_DCDC_Inrush Output
    CONVERTER_GPIO_INSTANCE_t EN_DCDC_Idealdiode;       ///< EN_DCDC_Idealdiode Output
    CONVERTER_GPIO_INSTANCE_t V_Comparator;             ///< Input Voltage Comparator Input
    
};
typedef struct CONVERTER_GPIO_s CONVERTER_GPIO_t; ///< GPIO instance of the converter control GPIO

/****************************************************************************************************
 * @ingroup lib-layer-converter-properties-public-data-types
 * @struct  CONVERTER_BALANCING_s
 * @brief   Converter current balancing data object
 *****************************************************************************************************/

struct CONVERTER_BALANCING_s
{
    uint16_t*  ptrIBuck1Master;     ///< Pointer to buck1 current used as reference
    uint16_t*  ptrIBuck2Slave;      ///< Pointer to buck2 current
    uint16_t*  ptrIBuck3Slave;      ///< Pointer to buck3 current
    uint16_t*  ptrIBuck4Slave;      ///< Pointer to buck4 current
    
    int16_t Buck2_dc_offset;       ///< Used to store buck2 duty cycel offset for current balancing
    int16_t Buck3_dc_offset;       ///< Used to store buck3 duty cycel offset for current balancing
    int16_t Buck4_dc_offset;       ///< Used to store buck4 duty cycel offset for current balancing
    
    uint32_t IBuck1_iir;           ///< Filtered value of buck1 current
    uint32_t IBuck2_iir;           ///< Filtered value of buck2 current
    uint32_t IBuck3_iir;           ///< Filtered value of buck3 current
    uint32_t IBuck4_iir;           ///< Filtered value of buck4 current
    
    uint16_t Iir_filter_lenght;    /// number of bitshift used to implement the iir filter
    
    int16_t  Minimum_DC_offset;            ///< Minumum duty cycel offset used to balance Buck2,3,4 currents
    int16_t  Maximum_DC_offset;            ///< Maximum duty cycel offset used to balance Buck2,3,4 currents
    uint16_t Minimum_delta_current;        ///< Minimum current difference above which the balancing is activated

};
typedef struct CONVERTER_BALANCING_s CONVERTER_BALANCING_t;


/****************************************************************************************************
 * @ingroup lib-layer-converter-properties-public-data-types
 * @struct  POWER_CONTROLLER_s
 * @brief   Converter data object
 *****************************************************************************************************/
struct POWER_CONTROLLER_s ///< PSFB Converter control & monitoring data structure
{
    CONVERTER_STATUS_t Status;         ///<  Converter operation status bits 
    CONVERTER_STATE_ID_t StateId;                ///< Converter state machine operating state ID
    CONVERTER_STARTUP_t StartUp;       ///< Converter startup timing settings 
    CONVERTER_SETTINGS_t SetValues;    ///< Control field for global access to references
    
    CONVERTER_DATA_t Data;                  ///<  Converter runtime data
    CONVERTER_FEEDBACK_t Feedback;               ///<  Converter feedback settings

    SWITCH_NODE_t SwNode1;             ///< Converter switch node settings
    SWITCH_NODE_t SwNode2;             ///< Converter switch node settings
    SWITCH_NODE_t SwNode3;             ///< Converter switch node settings
    SWITCH_NODE_t SwNode4;             ///< Converter switch node settings
    
    CONVERTER_GPIO_t Gpio;               ///< Converter additional GPIO specification

    CONVERTER_NPNZ16_CONTROLLER_t VLoop; ///< Converter bulk voltage control loop object
    CONVERTER_BALANCING_t   Balancing;  ///<  Converter current balancing control settings
};
typedef struct POWER_CONTROLLER_s POWER_CONTROLLER_t; 



#endif	/* CONVERTER_TYPE_DEF_H */

// ________________________
// end of file
