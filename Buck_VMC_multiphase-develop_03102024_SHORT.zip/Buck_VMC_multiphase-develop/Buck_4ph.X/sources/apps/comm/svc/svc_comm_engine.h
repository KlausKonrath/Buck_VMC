/* 
 * @file    svc_comm_engine.h
 * @author  M91406
 * @brief   Communication protocol driver header file
 * @version 1.0
 */

#ifndef COMM_PROTOCOL_ENGINE_H
#define COMM_PROTOCOL_ENGINE_H

#include "config/hal.h"
#include "common/p33c_plib/uart/IUartHandler.h"
#include "../app_comm_config.h"

/*********************************************************************************
 * @ingroup apps-layer-comm-data-objects
 * @brief   UART Protocol Data Type used for Message tracking and frame parsing
**********************************************************************************/
struct COMM_FRAME_s 
{
    uint8_t  Command;
    uint8_t  DataLen;
    uint8_t  CRC;
    uint8_t  State;
    uint16_t ptrData;
    uint16_t FrameErr;
    uint16_t DataError;
    int (*CallRxCommandParser)(void);
    bool Busy;
    bool Ready;
};
typedef struct COMM_FRAME_s COMM_FRAME_t;

#define COMM_SOF  (uint8_t)0x55 // START OF FRAME
#define COMM_CMD  (uint8_t)0x54 // COMMAND BYTE
#define COMM_DLEN (uint8_t)0x00 // DATA LENGTH
#define COMM_DATA (uint8_t)0x00 // DATA BYTES
#define COMM_CRC  (uint8_t)0x00 // CHECKSUM BYTE
#define COMM_EOM  (uint8_t)0x0D // END OF MESSAGE BYTE
#define COMM_EOF  (uint8_t)0x0A // END OF FRAME BYTE

#define COMM_CRC_SEED   (uint8_t)0xA1 // CRC8 Seed

enum COMM_STATES_e 
{
    COMMSTAT_SOF  = 0, // START OF FRAME
    COMMSTAT_CMD  = 1, // COMMAND BYTE
    COMMSTAT_DLEN = 2, // DATA LENGTH
    COMMSTAT_DATA = 3, // DATA BYTES
    COMMSTAT_CRC  = 4, // CHECKSUM BYTE
    COMMSTAT_EOM  = 5, // END OF MESSAGE BYTE
    COMMSTAT_EOF  = 6  // END OF FRAME BYTE
};
typedef enum COMM_STATES_e COMM_STATES_t;

/* UART data object and related data buffers */
extern UART_t Comm;
extern uint8_t CmdBuffer[];
extern uint16_t rxBufferSize;
extern uint16_t txBufferSize;
extern UART_BUFFER_t TxDataBuffer;
extern UART_BUFFER_t RxDataBuffer;
extern COMM_FRAME_t rxFrame;

/* UART DMA Receive Handler */
extern uint8_t rxBufferDma[][RX_BUFFER_SIZE];
extern uint8_t txBufferDma[][TX_BUFFER_SIZE];

/* Public Function Prototypes */
extern int CommFrameReset(void);
extern int CommDmaReceive(UART_t* comInterface);
extern int CommStageToTransmit(uint8_t* dataArray, uint16_t dataSize);
extern int CommDmaTransmit(UART_t* comInterface);

#endif /* COMM_PROTOCOL_ENGINE_H */
