/*
 * @file    rtos.c
 * @brief   Real time operating system core engine interface layer
 * @author  M91406
 * @date    05/27/2021
 * @version 1.0.6
 */

#include <xc_pral.h> // include processor files - each processor file is guarded.  

#include "config/mcal.h" // include common microcontroller abstraction header file
#include "boot/rtos_boot.h" // include common boot modules header file
#include "core/taskmgr.h" // include private data type definitions
#include "core/execute.h" // include execution engine header file

#include "IExceptions.h" // include exception handler interface header file
#include "IAppTask.h" // include application task interface header file

// Private function prototypes of task list execution functions
extern uint16_t rtos_Execute(void);
extern uint16_t rtos_End(void);

/***********************************************************************************
 * @ingroup os-layer-rtos-functions-public
 * @brief   Initializes essential chip resources
 * @return  unsigned integer (0=failure, 1=success)
 * 
 * @details
 *  The Boot function covers the initialization of essential chip 
 *  resources such as main oscillator, auxiliary oscillator, watchdog timer
 *  and general purpose I/Os (GPIO). All other, design specific peripherals
 *  are initialized in the User Peripheral Initialization or by the respective 
 *  User Task Device Drivers included in the firmware project
 * 
 **********************************************************************************/
uint16_t rtos_Boot(void)
{
    uint16_t retval=1;

    retval &= osFosc_Initialize(); ///< Set up system oscillator for 100 MIPS operation
    retval &= osAclk_Initialize(); ///< Set up Auxiliary PLL for 500 MHz (source clock to PWM module)
    retval &= osGpio_Initialize(); ///< Initialize common device GPIOs
    retval &= osDsp_Initialize();  ///< Initialize the DSP engine for fractional multiplication with saturation
    retval &= Exceptions_SoftTrapsInitialize(false, false, false); // Initialize Soft-Traps configuring DSP events
    
    if(retval) taskManager.Status.bits.BootComplete = 1; // Set Boot Complete flag bit
    
    return(retval);
}

/*********************************************************************************
 * @ingroup os-layer-rtos-functions-public
 * @brief   Application main loop
 * @return  unsigned integer (0=failure, 1=success)
 * 
 * @details
 *  This function replaces the common main()-loop of a C-program, which would 
 *  commonly be placed in file main.c. This function will only be called once 
 *  from main() and remain to be executed on the lowest CPU priority of #0.
 *  Within the main()-loop of this function, the execution of the low-priority 
 *  task sequence is called, triggered by the interrupt-driven, real-time high-
 *  priority task layer function. Thus low-priority layer tasks are always called
 *  at a moment of potentially lowest CPU load, with the highest likelihood of
 *  completing the execution.
 *  
 *  Some low-priority tasks, however, might always take multiple task-manager
 *  cycles to be executed, during which period they will get frequently interrupted
 *  by high-priority tasks. 
 *
 **********************************************************************************/
uint16_t rtos_Run(void)
{
    uint16_t retval = 1;

    // Execute RTS scheduler
    retval &= rtos_Execute();

    // Exit RTOS execution is triggering a CPU reset
    CPU_RESET();    // if the firmware ever ends up here, reset the CPU
    
    return(0);      // Return "false" signaling OS has exited execution
}

/*********************************************************************************
 * @ingroup os-layer-rtos-functions-public
 * @brief   Stops the execution of application tasks
 * @return  unsigned integer (0=failure, 1=success)
 *
 * @details
 *  The RTOS Stop function stops the execution of user tasks by calling 
 *  each tasks declared Stop function.
 * 
 **********************************************************************************/
uint16_t rtos_Stop(void)
{
    uint16_t retval=1;
    
    // Execute function list covering user-task start-up functions
    retval &= rtos_End();
    
    return(retval);
}

/*********************************************************************************
 * @ingroup os-layer-rtos-functions-public
 * @brief   Ends the execution of the main() loop enforcing a CPU reset.
 * @return  unsigned integer (0=failure, 1=success)
 *
 * @details
 *  The RTOS Exit function terminates the execution of the main loop enforcing
 *  a CPU reset during which the target device will return into its factory
 *  default state. No software or hardware state will be preserved.
 * 
 **********************************************************************************/
uint16_t rtos_Exit(void)
{
    uint16_t retval=1;
    
    // Execute function list covering user-task start-up functions
    retval &= rtos_End();
    
    return(retval);
}

// ________________________________
// end of file
