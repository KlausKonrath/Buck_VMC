/*
 * @file    exceptions.c
 * @brief   Real time operating system low-level exception handlers
 * @author  M91406
 * @date    01/12/2022
 * @version 1.0.6
 */

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer types header file
#include <stdbool.h> // include standard boolean types header file

#include "execute.h" // include RTOS execution layer header file
#include "inlines.h" // include exception event call inline function header file

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-variables
 * @brief   Defining support flag for primary and secondary DMA interrupt vectors 
 *********************************************************************************/
#if ((__HAS_DMA__) || (__HAS_DMAV2__))
  #define TRAP_DMA_SUPPORT			true  ///< Device supports DMA
#else
  #define TRAP_DMA_SUPPORT			false ///< Device does not support DMA
#endif

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Public Functions
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup os-layer-exc-functions-public
 * @brief   Configures the software-configurable traps
 * @param   accumulatorA_OverflowTrapEnable   Flag of type Boolean enabling/disabling accumulator A trap at 1.31 overflow
 * @param   accumulatorB_OverflowTrapEnable   Flag of type Boolean enabling/disabling accumulator B trap at 1.31 overflow
 * @param   accumulatorCatastrophicOverflowTrapEnable   Flag of type Boolean enabling/disabling catastrophic accumulator trap at 9.31 overflow
 * 
 * @details
 *  This routine sets the DSP-specific traps for overflow-events of accumulator A and B. 
 * 
 *************************************************************************************************/
uint16_t Exceptions_SoftTrapsInitialize(
            bool accumulatorA_OverflowTrapEnable, 
            bool accumulatorB_OverflowTrapEnable, 
            bool accumulatorCatastrophicOverflowTrapEnable)
{
    _OVATE = accumulatorA_OverflowTrapEnable; // Enable Accumulator A Overflow Trap Enable bit
    _OVBTE = accumulatorB_OverflowTrapEnable; // Enable Accumulator B Overflow Trap Enable bit
    _COVTE = accumulatorCatastrophicOverflowTrapEnable; // Enable Catastrophic Overflow Trap Enable bit
    
    return(1);
}


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// Private Functions
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup os-layer-exc-functions-private
 * @brief   Centralized trap handler routine
 * 
 * @details
 *  This routine is used as centralized trap handler for all traps. Each trap is identified 
 *  and logged by a unique trap ID and all CPU interrupt status bits and CPU interrupt vectors
 *  are captured.
 * 
 *  The captured information is then pushed to the public function @ref (ExceptionHandler).
 *  Users may override this public function to tailor the trap vector response as needed in
 *  user code.
 *
 *************************************************************************************************/
static inline void DefaultCpuException(TRAP_ID_t trapId)
{
    static CPU_EXCEPTION_t cpuEx;
    
    // Capture Trap logger values
    cpuEx.TrapId = trapId; // Capture Trap ID
    cpuEx.TrapCount++; // Capture occurrence 

    // Capture RTOS active task status
    cpuEx.TaskInfo = taskManager.TaskInfo;

    // Capture CPU interrupt status flags
    cpuEx.CpuStatus.RCON.value    = RCON;
    cpuEx.CpuStatus.INTTREG.value = INTTREG;
    cpuEx.CpuStatus.INTCON1.value = INTCON1;
    cpuEx.CpuStatus.INTCON2.value = INTCON2;
    cpuEx.CpuStatus.INTCON3.value = INTCON3;
    cpuEx.CpuStatus.INTCON4.value = INTCON4;
    
    // Hand over captured exception to Exception Handler
    InvokeCpuException(cpuEx);
    
    return;
}

// =================================================================================================
// PRIMARY EXCEPTION VECTOR HANDLERS
// =================================================================================================
/** @ingroup os-layer-exc-functions-private
 *  @{
 */
/**************************************************************************************************
 * @brief basic framework for trap handler routine
 * @details
 *  These routines are used if INTCON2bits.ALTIVT = 1. All trap service routines in this 
 *  file simply ensure that device continuously executes code within the trap service 
 *  routine. 
 *  Users may modify the basic framework provided here to suit to the needs of their 
 *  application. 
 *
 *************************************************************************************************/
void __attribute__((interrupt, no_auto_psv, weak)) _ReservedTrap5(void) {
    DefaultCpuException(TRAP_RESERVED_TRAP_5_ERROR); // Call default trap handler
}

/**************************************************************************************************
 * @brief basic framework for trap handler routine
 * @details
 *  These routines are used if INTCON2bits.ALTIVT = 1. All trap service routines in this file 
 *  simply ensure that device continuously executes code within the trap service routine. 
 *  Users may modify the basic framework provided here to suit to the needs of their application.
 *
 *************************************************************************************************/
void __attribute__((interrupt, no_auto_psv, weak)) _ReservedTrap7(void) {
    DefaultCpuException(TRAP_RESERVED_TRAP_7_ERROR); // Call default trap handler
}

/**************************************************************************************************
 * @brief basic framework for capturing Hard Trap Error
 * @details
 *  These routines are used if INTCON2bits.ALTIVT = 1. All trap service routines in this file 
 *  simply ensure that device continuously executes code within the trap service routine. 
 *  In this function the hard trap error is captured.
 *
 *************************************************************************************************/
void __attribute__((interrupt, no_auto_psv, weak)) _HardTrapError(void) {
    DefaultCpuException(TRAP_HARD_TRAP_ERROR); // Call default trap handler
}

/**************************************************************************************************
 * @brief basic framework for capturing Soft Trap Error
 * @details
 *  These routines are used if INTCON2bits.ALTIVT = 1. All trap service routines in this file 
 *  simply ensure that device continuously executes code within the trap service routine. 
 *  In this function the soft trap error is captured.
 *
 **************************************************************************************************/
void __attribute__((interrupt, no_auto_psv, weak)) _SoftTrapError(void) {
    DefaultCpuException(TRAP_SOFT_TRAP_ERROR);
}

/**************************************************************************************************
 * @brief captures Oscillator failure
 * @details
 *  These routines are used if INTCON2bits.ALTIVT = 1. All trap service routines in this file 
 *  simply ensure that device continuously executes code within the trap service routine. 
 *  Oscillator Failure Trap is captured, when the system clock becomes unstable
 *
 *************************************************************************************************/
void __attribute__((interrupt, no_auto_psv, weak)) _OscillatorFail(void) {
    DefaultCpuException(TRAP_OSCILLATOR_FAIL);
    _OSCFAIL = 0;
}

/**************************************************************************************************
 * @brief captures Address error 
 * @details
 *  These routines are used if INTCON2bits.ALTIVT = 1. All trap service routines in this file 
 *  simply ensure that device continuously executes code within the trap service routine. 
 *  Address Error Trap is captured, when a routine tries to access unknown memory addresses
 *  in RAM or Flash via PSV.
 *
 *************************************************************************************************/
void __attribute__((interrupt, no_auto_psv, weak)) _AddressError(void) {
    DefaultCpuException(TRAP_ADDRESS_ERROR);
    _ADDRERR = 0;
}

/**************************************************************************************************
 * @brief captures Stack error 
 * @details
 *  These routines are used if INTCON2bits.ALTIVT = 1. All trap service routines in this file 
 *  simply ensure that device continuously executes code within the trap service routine. 
 *  Stack Error Trap is captured, when a stack address error occurred.
 *
 *************************************************************************************************/
void __attribute__((interrupt, no_auto_psv, weak)) _StackError(void) {
    DefaultCpuException(TRAP_STACK_ERROR);
    _STKERR = 0;
}

/**************************************************************************************************
 * @brief captures Math error 
 * @details
 *  These routines are used if INTCON2bits.ALTIVT = 1. All trap service routines in this file 
 *  simply ensure that device continuously executes code within the trap service routine. 
 *  Math Error Trap is captured, when a math operation cannot be solved (e.g. division by zero)
 *
 *************************************************************************************************/
void __attribute__((interrupt, no_auto_psv, weak)) _MathError(void) {
    DefaultCpuException(TRAP_MATH_ERROR);
    if(1 == _SFTACERR) _SFTACERR = 0;
    if(1 == _DIV0ERR) _DIV0ERR = 0;
    if(1 == _MATHERR) _MATHERR = 0;
}

/**@}*/ // end of os-layer-exc-functions-private

#if (TRAP_DMA_SUPPORT)
#if defined (_DMACError)
// =================================================================================================
// DMA Error Trap is captured, when an access error of the dual ported RAM occurred
// =================================================================================================

void __attribute__((interrupt, no_auto_psv, weak)) _DMACError(void) {
    DefaultCpuException(TRAP_DMA_ERROR);
}
#endif
#endif

// =================================================================================================
//
// ALTERNATE EXCEPTION VECTOR HANDLERS
//
// =================================================================================================
//
// These routines are used if INTCON2bits.ALTIVT = 1. All trap service routines in this file 
// simply ensure that device continuously executes code within the trap service routine. 
//
// Users may modify the basic framework provided here to suit to the needs of their application.
//
// =================================================================================================
#if (__XC16_VERSION < 1030)

void __attribute__((interrupt, no_auto_psv, weak)) _AltHardTrapError(void) {
    DefaultCpuException(TRAP_ALT_HARD_TRAP_ERROR); // Call default trap handler
}

void __attribute__((interrupt, no_auto_psv, weak)) _AltSoftTrapError(void) {
    DefaultCpuException(TRAP_ALT_SOFT_TRAP_ERROR);
}

void __attribute__((interrupt, no_auto_psv, weak)) _AltOscillatorFail(void) {
    DefaultCpuException(TRAP_ALT_OSCILLATOR_FAIL);
}

void __attribute__((interrupt, no_auto_psv, weak)) _AltAddressError(void) {
    DefaultCpuException(TRAP_ALT_ADDRESS_ERROR);
}

void __attribute__((interrupt, no_auto_psv, weak)) _AltStackError(void) {
    DefaultCpuException(TRAP_ALT_STACK_ERROR);
}

void __attribute__((interrupt, no_auto_psv, weak)) _AltMathError(void) {
    DefaultCpuException(TRAP_ALT_MATH_ERROR);
}

#if (TRAP_DMA_SUPPORT)

void __attribute__((interrupt, no_auto_psv, weak)) _AltDMACError(void) {
    DefaultCpuException(TRAP_ALT_DMA_ERROR);
}
#endif

#endif

// ________________________________
// end of file
