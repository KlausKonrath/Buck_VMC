/*
 * @file    interrupts.c
 * @brief   Real time operating system low-level interrupt exception handlers
 * @author  M91406
 * @date    03/02/2023
 * @version 1.0.6
 */

#include <xc_pral.h> // include device register abstraction header file

#include "interrupts.h" // include interrupt exception type definitions header file
#include "inlines.h" // include exception event call inline function header file

/*********************************************************************************
 * @ingroup os-layer-core-int-functions-public
 * @brief   Default interrupt service routine for initialized and enabled interrupt vectors without interrupt vector destination
 * 
 * @details
 *  Hardware interrupt vectors, which are enabled but don't have a dedicated
 *  interrupt service routine assigned, will be redirected to the default 
 *  interrupt vector. If this vector also doesn't have an assigned service 
 *  routine, the CPU will reset.
 *  
 *  This interrupt vector service routine captures interrupts without assigned
 *  service routine and allows developers to capture and trace the active 
 *  interrupt vector back, which is tripping this default routine.
 *  
 **********************************************************************************/
void __attribute__((__interrupt__, no_auto_psv, weak)) _DefaultInterrupt(void)
{
    uint16_t _i=0;
    volatile uint16_t* _ptr = &IFS0;
    
    // Scan all interrupt flag bit registers for active flag bits
    for (_i=0; _i<P33C_IFS_SFR_COUNT; _i++)
    {
        // Capture value of IFSx register block
        volatile uint16_t* _ptrIfs = _ptr + (uint16_t)_i;
        volatile uint16_t* _ptrIec = _ptr + (uint16_t)(P33C_SFR_BLOCK_OFFSET + _i);
        uint16_t _testValue = (*(_ptrIfs) & *(_ptrIec)); // Filter active interrupt flag bits
        
        // IF any flag bit is set, enter CAPTURE statement
        if (_testValue != 0)
        {
            // The active interrupt vector can be identified by verifying value 
            // of _i representing the IFS register instance, and _testValue identifying
            // the vector source(s) by bit-position as _testValue captures only the 
            // register flag bits of all enabled interrupts. Hence, _testValue only shows 
            // enabled interrupts, which have actually been tripped.
            // 
            // Example: 
            //   _i = 1 pointing to registers IFS1 and IEC1;
            //   _testValue = 0x0010 (=0b0000000000010000), which points to IFS1[4]=External Interrupt #2
            //
            // For troubleshooting, check if every enabled interrupt, which has been triggered 
            // does have some interrupt service routine (ISR) being placed within a project source
            // file.
            
            Nop(); // Place breakpoint to capture IFS/IEC Register Mismatch value
            Nop();
            Nop();
            
            // ToDo: Review this handler call
            //       This implementation calls the handler function for each
            //       mismatch between interrupt vector flag and interrupt
            //       enable flag. Multiple mismatches will result in multiple
            //       handler calls. 
            //       Review, reject, approve and/or improve !!!
            
            IRQ_EXCEPTION_t IrqExceptionLog; // data structure used as buffer for default interrupt vector monitoring 
            IrqExceptionLog.Group = _i;         // Log Interrupt Group
            IrqExceptionLog.Value = _testValue; // Filter mismatching bits
            
            InvokeInterruptException(IrqExceptionLog);
            
        }
        
        // Auto-clear IFS register bits
        *_ptrIfs = 0;
    }
        
}

// ________________________________
// end of file
