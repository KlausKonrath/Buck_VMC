/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/*
 * @file    taskerrors.h
 * @brief   Real time operating system task conflict handlers
 * @author  M91406
 * @date    06/23/2023, 10:49 AM
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef RTOS_TASK_EXECPTION_TYPEDEF_H
#define	RTOS_TASK_EXECPTION_TYPEDEF_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer types header file
#include <stdbool.h> // include standard boolean types header file

#include "execute.h" // include RTOS execution layer header file
#include "../IAppTask.h" // include applicaiton task interface header file

// Public type definitions

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-data-types
 * @brief   Enumeration of known task execution exceptions
 *********************************************************************************/
enum OS_TASKEX_TYPE_e {
    
    OS_TASKEX_UNKNOWN,                          // Unknown task error
    OS_TASKEX_LOW_PRIORITY_TIMEOUT,             // Low priority task queue does not respond anymore
    OS_TASKEX_HIGH_PRIORITY_TIMEOUT,            // High priority task queue does not respond anymore
    OS_TASKEX_HIGH_PRIORITY_QUOTA_VIOLATION,    // High priority task queue overran scheduler base period
    OS_TASKEX_TASK_RET_ERROR                    // A task function returned a failure 
};
typedef enum OS_TASKEX_TYPE_e OS_TASKEX_TYPE_t;

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-data-types
 * @brief   Data object used to capture and store task exception event information
 *********************************************************************************/
struct TASK_EXCEPTION_s
{
    OS_TASKEX_TYPE_t      ExId;     ///< Exception identifier 
    IApplicationTask_t*   TaskInfo; ///< Information about the task which was affected by a collision
};
typedef struct TASK_EXCEPTION_s TASK_EXCEPTION_t; // Global data structure for task collision event capturing

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-functions
 * @brief   Data object used to capture and store task exception event information
 *********************************************************************************/
extern void DefaultTaskException(OS_TASKEX_TYPE_t exception, IApplicationTask_t* task);

#endif	/* RTOS_TASK_EXECPTION_TYPEDEF_H */

// _______________________________
// end of file
