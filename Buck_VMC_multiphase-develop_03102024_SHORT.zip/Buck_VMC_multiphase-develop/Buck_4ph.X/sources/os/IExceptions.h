/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/**
 * @file    IExceptions.h
 * @author  M91406
 * @brief   CPU exceptions interface header file
 * @date    02/07/2022
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef RTOS_EXCEPTIONS_INTERFACE_H
#define	RTOS_EXCEPTIONS_INTERFACE_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer types header file
#include <stdbool.h> // include standard boolean types header file

#include "core/traps.h" // include exception handler header file
#include "core/interrupts.h" // include default interrupt event data object header file
#include "core/taskerrors.h" // include task exceptions event data object header file

/*********************************************************************************
 * @ingroup os-layer-exc-properties-public-variables
 * @brief   Global CPU exception information data object
 *
 * @details
 *  The CpuExceptionLog is the global data object which is used to capture
 *  trap, interrupt and task execution details when a CPU exception event
 *  occurred to support analysis and resolution of the exception event.
 *  This data type is declared as "persistent" allowing to read the 
 *  information after the CPU went through a soft reset.
 *
 **********************************************************************************/
extern __attribute__((__persistent__)) CPU_EXCEPTION_t CpuExceptionLog; 

/*********************************************************************************
 * @ingroup os-layer-exc-properties-public-variables
 * @brief   Global default interrupt vector event information data object
 *
 * @details
 *  The IrqExceptionLog is the global data object which is used to capture
 *  interrupt source and value details when an IRQ exception event
 *  occurred to support analysis and resolution of the exception event.
 *  This data type is declared as "persistent" allowing to read the 
 *  information after the CPU went through a soft reset.
 *
 **********************************************************************************/
extern __attribute__((__persistent__)) IRQ_EXCEPTION_t IrqExceptionLog;

/*********************************************************************************
 * @ingroup os-layer-exc-properties-public-variables
 * @brief   Global task execution exception event information data object
 *
 * @details
 *  The TaskExceptionLog is the global data object which is used to capture
 *  task conflict details when a task conflict exception event occurred 
 *  to support analysis and resolution of the exception event.
 *  This data type is declared as "persistent" allowing to read the 
 *  information after the CPU went through a soft reset.
 *
 **********************************************************************************/
extern __attribute__((__persistent__)) TASK_EXCEPTION_t TaskExceptionLog;


// =================================================================================================
// Expose function call prototypes of exception handlers
// =================================================================================================

/*********************************************************************************
 * @ingroup os-layer-exc-functions-public
 * @brief   Global task conflict exception handler method
 *
 * @details
 *  Task exceptions are detected and invoked by the task scheduler.
 *  Possible root cause of this exception can be:
 *    - Task execution stalled tripping a scheduler timeout event
 *    - Task execution of low-priority queue stopped unexpectedly
 *    - Task execution of high-priority queue stopped unexpectedly
 *    - Task execution of task in cooperative queue overran allowed quota
 *
 **********************************************************************************/
extern void __attribute__((weak)) TaskExceptionHandler(TASK_EXCEPTION_t ex);

/*********************************************************************************
 * @ingroup os-layer-exc-functions-public
 * @brief   Global default interrupt vector exception handler method
 *
 * @details
 *  IRQ exceptions are detected and invoked by the default interrupt vector 
 *  service routine, handled by the RTOS.
 * 
 *  Possible root cause of this exception can be:
 *    - An interrupt has been enabled but no interrupt service routine was assigned/declared
 *  
 **********************************************************************************/
extern void __attribute__ ((weak)) InterruptExceptionHandler(IRQ_EXCEPTION_t ex);

/*********************************************************************************
 * @ingroup os-layer-exc-functions-public
 * @brief   Global CPU exception handler method
 *
 * @details
 *  CPU exceptions are detected and invoked by the default trap handler interrupt
 *  service routines, handled by the RTOS.
 * 
 *  Possible root cause of this exception can be:
 *    - Hard Trap event
 *    - Soft Trap event
 *    - Oscillator Failure event
 *    - Address Error event
 *    - Stack Error event
 *    - Math Error event
 *    - DMA Error event
 *    - DSP Accumulator Overflow event (optional, must be enabled by calling function Exceptions_SoftTrapsInitialize)
 * 
 **********************************************************************************/
extern void __attribute__((weak)) CpuExceptionHandler(CPU_EXCEPTION_t ex);

/*********************************************************************************
 * @ingroup os-layer-exc-functions-public
 * @brief   Configures Soft CPU traps options
 *
 * @details
 *  Soft traps are invoked by DSP accumulator overflow events. These events
 *  are configurable by the end user. As the DSP supports saturation and the
 *  detection of overflow events may or may not be desired.
 *
 **********************************************************************************/
extern uint16_t __attribute__ ((weak)) Exceptions_SoftTrapsInitialize(
            bool accumulatorA_OverflowTrapEnable, 
            bool accumulatorB_OverflowTrapEnable, 
            bool accumulatorCatastrophicOverflowTrapEnable);

#endif	/* RTOS_EXCEPTIONS_INTERFACE_H */

// _______________________________
// end of file
