/*
 * @file    rtos_timer.c
 * @brief   Target device standard timer configuration routines
 * @author  M91406
 * @date    07/08/2019
 * @version 1.0.6
 */

#include <stdint.h> // include standard integer data types
#include <math.h>

#include "common/p33c_pral/xc_pral.h"   // include peripheral register abstraction layer header file
#include "config/hal.h" // include hardware abstraction layer header file
#include "config/os.h" // include RTOS configuration header file
#include "../core/execute.h" // include RTOS execution engine header file

/***********************************************************************************
 * @ingroup os-layer-library-timer-public-functions
 * @brief   Initializes the timer used as time-base for the task scheduler
 * @return  unsigned integer (0=failure, 1=success)
 * 
 * @details
 *  The internal PLL is set up to operate the CPU at maximum speed of 100 MIPS 
 *  (100 MHz instruction cycle). The task scheduler runs on a specific, usually 
 *  fixed time base specified in the state machine section of the microcontroller
 *  abstraction layer (e.g. 100us). 
 * 
 *  This routine initializes a device timer exclusively used for that purpose
 *  which is not shared with other tasks/peripherals to ensure stable, deterministic
 *  behavior of the firmware. The timer does not use interrupts. The scheduler 
 *  task execution period is controlled by polling on the timer overrun bit, allowing
 *  some more relaxed timing while not putting additional burden on the CPU.
 *
 **********************************************************************************/
uint16_t osTimer_Initialize (void)
{
    uint16_t retval=1;
    uint16_t _tmrPeriod=0;
    
    p33c_Timer_PowerOn();                               // Make sure power to peripheral is enabled
    retval = p33c_Timer_SetConfig(tmrConfigDefault);    // Set default configuration for max. performance
    
    //Period = 0.0001 s; Frequency = 100000000 Hz; PR 9999; 
    #ifdef RTOS_6G2_EXEC_PER
    if (taskManager.Status.bits.BootComplete)
    { 
        _tmrPeriod = RTOS_6G2_EXEC_PER; 
        retval &= p33c_Timer_SetPeriod(_tmrPeriod);
    }
    else
    {
        _tmrPeriod = (uint16_t)((float)RTOS_6G2_EXECUTION_PERIOD * pow(10, 6));
        retval &= p33c_Timer_SetTimePeriodUs(_tmrPeriod);
    }
    #else
    #pragma message "no RTOS time base frequency defined; default setting will be used"
    _tmrPeriod = 9999;
    #endif

    retval &= p33c_Timer_IsrInitialize(false, 0);
    
    return(retval);
}
 
/***********************************************************************************
 * @ingroup os-layer-library-timer-public-functions
 * @brief   Enables the timer used as time-base for the task scheduler
 * @param   interruptEnable    Control flag of type boolean enabling or disabling the timer interrupt
 * @param   interruptPriority  Interrupt Service Routine priority level of the timer interrupt (if enabled) between level 0 and 6
 * @return  unsigned integer (0=failure, 1=success)
 * 
 * @details
 *  Once the task scheduler time base has been initialized, this function 
 *  can be used to enable the timer and start the scheduled task execution.
 *
 **********************************************************************************/
uint16_t osTimer_Enable (bool interruptEnable, uint8_t interruptPriority)
{
    uint16_t retval=1;

    retval &= p33c_Timer_IsrInitialize(interruptEnable ,interruptPriority);
    retval &= p33c_Timer_Enable();
    
    return(retval);
}

// ________________________________
// end of file
