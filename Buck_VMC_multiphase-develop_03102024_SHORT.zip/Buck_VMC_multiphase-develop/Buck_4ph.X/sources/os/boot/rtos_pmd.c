/*
 * @file    rtos_pmd.c
 * @brief   Target device Peripheral Module Disable configuration routines
 * @author  M91406
 * @date    07/08/2019
 * @version 1.0.6
 */

#include <stdint.h> // include standard integer data types
#include "common/p33c_pral/xc_pral.h"

/***********************************************************************************
 * @ingroup os-layer-library-pmd-public-functions
 * @brief   Powers down all device peripherals
 * @return  unsigned integer (0=failure, 1=success)
 * 
 * @details
 *  When the device is coming out of RESET, all peripheral modules are powered
 *  and active, ready to be initialized and used. However, each active peripheral
 *  consumes power and accidental writes to any of its specifal function registers
 *  may be a potential source for undesired behavior. Hence, in this application 
 *  all power supply to all peripheral modules are disabled, minimizing the device 
 *  power consumption and preventing potential misbehavior of unused peripheral 
 *  modules.
 *
 * @note
 *  Unpowered peripherals cannot be initialized and reads from/write to the 
 *  respective special function registers will fail until the power supply to 
 *  the peripheral has been enabled. Hence, power to peripheral modules has to
 *  be enabled before any intialization of its register can take place.
 * 
 *  Depending on the peripheral a short delay period may be required for the 
 *  peripheral functions to become available after power up. 
 *
 *  Please refer to the device data sheet for details.
 *
 **********************************************************************************/
uint16_t osPmd_Initialize(void) {
    
    uint16_t retval=1;
    
    // Disable all peripheral modules
    retval &= p33c_Pmd_SetConfig(pmdConfigDisableAll);
    
    return(retval);
}

// _______________________________
// end of file
