/*
    (c) 2023 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
#include <stddef.h> // include standard definition data types

#include "xc_pral.h" // include peripheral register abstraction layer drivers
#include "../IUartHandler.h"

static int plib33c_Uart_RingBufferInitialize(PLIB33C_UART_RINGBUFFER_t * const ringbuf, uint8_t sto[], uint16_t len); 

/*********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @brief   UART send or transmit byte-data buffer
 * @details
 *  UART send or transmit data buffer from which the UART interface is reading new 
 *  data to be transmitted
 **********************************************************************************/
uint8_t __attribute__((far, weak)) plib33cUartSendBufferArr[UART_TX_BUFFER_DEFAULT_SIZE];

/*********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @brief   UART send data buffer size
 * @details
 *  Size of the UART send data buffer in bytes
 **********************************************************************************/
uint16_t __attribute__((weak)) plib33cUartSendBufferArrSize = (sizeof(plib33cUartSendBufferArr)/sizeof(plib33cUartSendBufferArr[0])); 

/*********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @brief   UART receive byte-data buffer
 * @details
 *  UART receive data buffer to which the UART interface is writing to when
 *  new data is received.
 **********************************************************************************/
uint8_t __attribute__((far, weak)) plib33cUartRcvBufferArr[UART_RX_BUFFER_DEFAULT_SIZE];

/*********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @brief   UART receive data buffer size
 * @details
 *  Size of the UART receiver data buffer in bytes
 **********************************************************************************/
uint16_t __attribute__((weak)) plib33cUartRcvBufferArrSize = (sizeof(plib33cUartRcvBufferArr)/sizeof(plib33cUartRcvBufferArr[0])); 

/*********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @brief   Data object that contains the Uart buffer send properties
 * @details Object 'PLIB33C_UART_SEND_BUFFER_t' is the object providing access 
 *          to the Uart send data buffers
 **********************************************************************************/
UART_BUFFER_t plib33cUartSendBuffer[P33C_UART_COUNT];

/*********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @brief   Data object that contains the Uart buffer receive ring buffer
 * @details Object 'PLIB33C_UART_RINGBUFFER_t' is the object providing access 
 *          to the Uart receive data ring buffer
 **********************************************************************************/
PLIB33C_UART_RINGBUFFER_t plib33cReceiveRingBuffer[P33C_UART_COUNT];

/*********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @brief   Data object that contains the data status of the send and receive
 * @details Object 'PLIB33C_DATA_STATUS_t' is the object providing access 
 *          to the Uart data status
 **********************************************************************************/
PLIB33C_DATA_STATUS_t plib33cDataStatus[P33C_UART_COUNT];

/*********************************************************************************
 * @ingroup p33c-plib-uart-properties-private-private
 * @brief   Hardware communication interface object
 * @details Object 'PLIB33C_UART_INTERFACE_t' is the object providing access to low-level interface 
 *          receive and transmit functions as well as related data buffers and 
 *          hardware layer driver API.
 **********************************************************************************/
static UART_t selfPlib33cUartComm[P33C_UART_COUNT];

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Initializes a UART driver communication port with predefined user settings
 * @param   interfaceCommPort Pointer to UART interface object of type UART_INTERFACE_t
 * @return 0 = failure, Initializing UART interface was not successful
 * @return 1 = success, Initializing UART interface was successful
 * @details
 *  This function can be used to initialize a UART data buffer by handing over
 *  a predefined user-UART data buffer object.  
 *
 **********************************************************************************/
int plib33c_Uart_CommPortInitialize(UART_t* uartConfig)
{
    int retval = 1;
    uint16_t index = (uartConfig->CommPort.UartInstance - 1);
    
    selfPlib33cUartComm[index].CommPort.UartInstance = uartConfig->CommPort.UartInstance;
    selfPlib33cUartComm[index].CommPort.TxD.DmaInstance = uartConfig->CommPort.TxD.DmaInstance;
    selfPlib33cUartComm[index].Status.TxDmaEnable = uartConfig->Status.TxDmaEnable;
    
    plib33cDataStatus[index].bits.rxReady = false;
    plib33cDataStatus[index].bits.rxByteReceived = false;
    plib33cDataStatus[index].bits.rxBufferEmpty = true;
    plib33cDataStatus[index].bits.rxBufferOverrun = false;
    plib33cDataStatus[index].bits.txReady = true;
    plib33cDataStatus[index].bits.txDataSent = true;
    
    return(retval);
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Initializes a UART data buffer with predefined user settings
 * @param   uartInstance Instance of the UART port of type unsigned integer (e.g. 1=UART1, 2=UART2, etc.)
 * @param   interfaceSendBuffer  Pointer to UART send buffer object of type PLIB_UART_SEND_BUFFER_t
 * @param   interfaceReceiveBuffer  Pointer to UART receive buffer object of type PLIB_UART_RECEIVE_BUFFER_t
 * @return 0 = failure, Initializing UART data buffer was not successful
 * @return 1 = success, Initializing UART data buffer was successful
 * @details
 *  This function can be used to initialize a UART data buffer by handing over
 *  a predefined user-UART data buffer object.  
 *
 **********************************************************************************/
int plib33c_Uart_DataBufferInitialize(UART_t* uartConfig, UART_BUFFER_t* interfaceSendBuffer, UART_BUFFER_t* interfaceReceiveBuffer)
{
    int retval = 1;
    uint8_t index = (uartConfig->CommPort.UartInstance - 1);
    
    if(interfaceSendBuffer == NULL)
    {
        plib33cUartSendBuffer[index].ptrData = plib33cUartSendBufferArr;   ///< Collected data from the frame parser
        plib33cUartSendBuffer[index].Size = plib33cUartSendBufferArrSize;    ///< Tx buffer data length
    }
    else
    {
        // Initialize interface data buffer
        plib33cUartSendBuffer[index].ptrData = interfaceSendBuffer->ptrData;   ///< Collected data from the frame parser
        plib33cUartSendBuffer[index].Size = interfaceSendBuffer->Size;    ///< Tx buffer data length
    }

    if(interfaceReceiveBuffer == NULL)
    {
        retval &= plib33c_Uart_RingBufferInitialize(&plib33cReceiveRingBuffer[index], 
            plib33cUartRcvBufferArr, plib33cUartRcvBufferArrSize);
    }
    else
    {
        retval &= plib33c_Uart_RingBufferInitialize(&plib33cReceiveRingBuffer[index], 
                    interfaceReceiveBuffer->ptrData, interfaceReceiveBuffer->Size);
    }

    return(retval);
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Acquire and manage the receive byte
 * @param   uartInstance Instance of the UART port of type unsigned integer (e.g. 1=UART1, 2=UART2, etc.)
 * @param   ringbuf Pointer to ring buffer object of type PLIB33C_UART_RINGBUFFER_t
 * @param   bytePointer pointer to the variable byte
 * @return 0 = failure, receive ring buffer is not empty
 * @return 1 = success, receive ring buffer is empty
 *  
 * @details This function gets the receive byte/s until the ring buffer is empty.
 *       When the ring buffer tail is not equal ring buffer head, the byte is transferred 
 *       to the variable byte pointer. 
 * 
 *********************************************************************************/
bool plib33c_Uart_RingBufferGet(uint16_t uartInstance, PLIB33C_UART_RINGBUFFER_t* const ringbuf, uint8_t *bytePointer) 
{
    uint16_t tail = ringbuf->tail;
    
    if (ringbuf->head != tail) 
    { //ring buffer is not empty
        
        *bytePointer = ringbuf->buf[tail];
        ++tail;
        
        if (tail == ringbuf->end) 
        {  tail = 0; }
        
        ringbuf->tail = tail; // update the tail to a *valid* index 
        
        plib33cDataStatus[uartInstance-1].bits.rxBufferEmpty =  false;
        plib33cDataStatus[uartInstance-1].bits.rxByteReceived = true;
        return((bool)!plib33cDataStatus[uartInstance-1].bits.rxBufferEmpty);
    }
    else 
    {
        plib33cDataStatus[uartInstance-1].bits.rxByteReceived = false;
        plib33cDataStatus[uartInstance-1].bits.rxBufferEmpty =  true;
        plib33cDataStatus[uartInstance-1].bits.rxBufferLocked = false;
        return(0);
    }
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   transfer and set the receive byte to the user defined buffer 
 * @param   uartInstanceIndex Instance of the UART port of type unsigned integer (e.g. 1=UART1, 2=UART2, etc.) minus one 
 * @param   ringbuf Pointer to ring buffer object of type PLIB33C_UART_RINGBUFFER_t
 * @param   data  Received Uart byte when Uart only
 * @return 0 = failure, Unsuccessful to transfer the data to the ring buffer
 * @return 1 = success, Successfully transfer the data to the ring buffer
 *  
 * @details This function saves the byte receive when the Uart interrupts. It also
 *     increments the DMA destination address every time a byte is received.
 * 
 * @note    In the event that the ring buffer overflows, the overflow bit is set,
 *     as well as the rxBufferLocked bit is set. In this manner, the user needs to
 *     process all the data on the ring buffer before the ring buffer can be 
 *     used again (rxBufferLocked = false).
 *********************************************************************************/
int plib33c_Uart_RingBufferSet(uint16_t uartInstanceIndex, PLIB33C_UART_RINGBUFFER_t* const ringbuf, uint8_t data) 
{
    int retval = 1;
    uint16_t head = 0;
 
    if(plib33cDataStatus[uartInstanceIndex].bits.rxBufferLocked == false)
    {
        head = ringbuf->head + 1;

        if (head == ringbuf->end) { head = 0; }

        if (head != ringbuf->tail) 
        { // buffer NOT full?
            ringbuf->buf[ringbuf->head] = data; // copy the byte into the buffer 
            ringbuf->head = head; // update the head to a *valid* index 
            plib33cDataStatus[uartInstanceIndex].bits.rxBufferOverrun = false;
        }
        else { plib33cDataStatus[uartInstanceIndex].bits.rxBufferOverrun = true; }
    }
    
   return(retval);  
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   transfer and set the receive byte to the user defined buffer 
 * @param   dmaInstance  Instance of the DMA of type unsigned integer (e.g. 0=DMA0, 1=DMA1, etc.)
 * @param   uartInstanceIndex Instance of the UART port of type unsigned integer (e.g. 1=UART1, 2=UART2, etc.) minus one
 * @param   ringbuf Pointer to ring buffer object of type PLIB33C_UART_RINGBUFFER_t
 * @return 0 = failure, Failure to transfer the data byte to the buffer
 * @return 1 = success, Successfully transfer the data byte to the buffer
 *  
 * @details This function saves the byte receive when the Uart interrupts. It also
 *     increments the DMA destination address everytime a byte is received.
 * 
 * @note    In the event that the ring buffer overflows, the overflow bit is set,
 *     as well as the rxBufferLocked bit is set. In this manner, the user needs to
 *     process all the data on the ring buffer before the ring buffer can be 
 *     used again (rxBufferLocked = false).
 * 
 *********************************************************************************/
int plib33c_Uart_DMARingBufferSet(uint16_t dmaInstance, uint8_t uartInstanceIndex, PLIB33C_UART_RINGBUFFER_t* const ringbuf) 
{
    int retval = 1;
    uint16_t head = 0;
    
    P33C_DMA_INSTANCE_t* dma = p33c_DmaInstance_GetHandle(dmaInstance);

    if(plib33cDataStatus[uartInstanceIndex].bits.rxBufferLocked == false)
    {
        head = ringbuf->head + 1;

        if (head == ringbuf->end) 
            { head = 0; }

        if (head != ringbuf->tail) 
        { // buffer NOT full?
            ringbuf->head = head; // update the head to a *valid* index
            dma->DMADSTx.value =(uint16_t)ringbuf->buf + ringbuf->head;
            plib33cDataStatus[uartInstanceIndex].bits.rxBufferOverrun = false;
        }
        else {
            //head == tail
            plib33cDataStatus[uartInstanceIndex].bits.rxBufferOverrun = true;
            plib33cDataStatus[uartInstanceIndex].bits.rxBufferLocked = true;
        }
    }
    return(retval);  
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Initializes the Uart ring buffer
 * @param   ringbuf Pointer to ring buffer object of type PLIB33C_UART_RINGBUFFER_t
 * @param   buf Ring buffer array that will hold the receive bytes
 * @param   size    Size of the ring buffer array
 * @return 0 = failure, Initialization of ring buffer is not successful
 * @return 1 = success, Initialization of ring buffer is successful
 *  
 * @details This function initializes the ring buffers used by the Uart Receiver.
 * 
 *********************************************************************************/
int plib33c_Uart_RingBufferInitialize(PLIB33C_UART_RINGBUFFER_t* const ringbuf, uint8_t buf[], uint16_t size) 
{
    int retval = 1;

    //initialize ring buffer
    ringbuf->buf  = &buf[0];
    ringbuf->end  = size;
    ringbuf->head = 0;
    ringbuf->tail = 0;
    
    return(retval);
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Redirects the printf to Uart
 * @param   handle Handles the printf state(stdin, stdout, stderr,...)
 * @param   buffer Pointing the location of the character bytes
 * @param   len Length of the printf character
 * @return  len returns the length of the printed character
 *  
 * @details 
 *  The write function is used by the printf. To redirect the printf to Uart
 *  the weak declaration of the write function on the libc library is modified. 
 * 
 * @see
 *  More information in MPLAB XC16 Libraries Reference Guide 
 *  https://www.microchip.com/50001456
 * 
 *********************************************************************************/
int __attribute__((__section__(".libc.write"))) write(int handle, void *buffer, unsigned int len) 
{
    P33C_UART_INSTANCE_t* uart;
    
    switch(handle)
    {
    default: break;
    case 0:  break;
    case 1:  // Handle #1 is reserved for UART 
        //Set pointer to memory address of desired Uart instance
        switch (__C30_UART)
        {
            case 1: uart = p33c_UartInstance_GetHandle(1); break;
            case 2: uart = p33c_UartInstance_GetHandle(2); break;
            case 3: uart = p33c_UartInstance_GetHandle(3); break;
            default: return(len);
        }

        if(!(uart->UxMODE.bits.UARTEN)){
            uart->UxBRG.value = 0;
            uart->UxMODE.bits.UARTEN = 1;
        }

        if(!(uart->UxMODE.bits.UTXEN)){
            uart->UxMODE.bits.UTXEN = 1;
        }
        for (int i = len; i; --i)
        { plib33c_Uart_WriteByte(__C30_UART, *(char*)buffer++); }
                
        break;
   }

    return(len);
} 


// ___________________
// end of file
