/*
    (c) 2023 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
#include <stddef.h> // include standard definition data types

#include "p33c_plib_uart_templates.h"

/*********************************************************************************
 * @ingroup p33c-plib-uart-templates-private
 * @brief   Default UART configuration of one UART instance for standard serial communication without hardware handshake
 *
 * @details
 *   Default configuration of a UART port SFRs with all its registers 
 *   being set for a simple, default UART operation with RX and TX channels 
 *   enabled but without hardware handshake.
 *   Programmers can use this template to quickly set a standard UART port 
 *   up for simple pure RX/TX operation without handshake. If specific, 
 *   additional features are required, these registers must be written after  
 *   this configuration template has been loaded to prevent they are 
 *   accidentally overwritten.
 * 
 * @note
 *   All configuration templates initialize SFRs with ENABLE bits being 
 *   cleared, requiring the user enables the peripheral instance separately.
 * 
 * @note
 *   The UART instance will be configured with RX and TX enabled using the 
 *   high resolution mode with fractional Baud Rate generation. The default 
 *   input clock is FOSC/2 (FP)
 * 
 ********************************************************************************/
const P33C_UART_INSTANCE_t plib33cUartConfigSerialRxTx = {
    
    .UxMODE.value   = 0x00B0,   // UARTEN=0, USIDL=0, WAKE=0, RXBIMD=0, BRKOVR=0, UTXBRK=0, BRGH=1, ABAUD=0, UTXEN=1, URXEN=1, MOD=0
    .UxMODEH.value  = 0x0880,   // SLPEN=0, ACTIVE=0, BCLKMOD=1, BCLKSEL=0, HALFDPLX=0, RUNOVF=1, URXINV=0, STSEL=0, C0EN=0, UTXINV=0, FLO=0
    .UxSTA.value    = 0x0000,   // TXMTIE=0, PERIE=0, ABDOVE=0, CERIE=0, FERIE=0, RXBKIE=0, OERIE=0, TXCIE=0, TRMT=0, PERR=0, ABDOVF=0, CERIF=0, FERR=0, RXBKIF=0, OERR=0, TXCIF=0
    .UxSTAH.value   = 0x0000,   // UTXISEL2=0, UTXISEL1=0, UTXISEL0=0, URXISEL2=0, URXISEL1=0, URXISEL0=0, TXWRE=0, STPMD=0, UTXBE=0, UTXBF=0, RIDLE=0, XON=0, URXBE=0, URXBF=0
    .UxBRG.value    = 0x0000,   // BRG=0
    .UxBRGH.value   = 0x0000,   // BRG[19:16]=0
    .UxRXREG.value  = 0x0000,   // RXREG[7:0]=0
    .UxTXREG.value  = 0x0000,   // TXREG[7:0]=0
    .UxP1.value     = 0x0000,   // P1[7:0]=0
    .UxP2.value     = 0x0000,   // P2[7:0]=0
    .UxP3.value     = 0x0000,   // P3[7:0]=0
    .UxP3H.value    = 0x0000,   // P3[7:0]=0
    .UxTXCHK.value  = 0x0000,   // TXCHK[7:0]=0
    .UxRXCHK.value  = 0x0000,   // RXCHK[7:0]=0
    .UxSCCON.value  = 0x0000,   // TXRPT1=0, TXRPT0=0, CONV=0, T0PD=0, PRTCL=0,
    .UxSCINT.value  = 0x0000,   // RXRPTIF=0, TXRPTIF=0, BTCIF=0, WTCIF=0, GTCIF=0, RXRPTIE=0, TXRPTIE=0, BTCIE=0, WTCIE=0, GTCIE=0,
    .UxINT.value    = 0x0000    // WUIF=0, ABDIF=0, ABDIE=0,

};

/*********************************************************************************
 * @ingroup p33c-plib-uart-templates-private
 * @brief   Default UART configuration of one UART instance for standard serial communication without hardware handshake
 *
 * @details
 *   Default configuration of a DMA SFRs with all its registers 
 *   being set for a simple, default DMA operation with RX channel 
 *   enabled but without hardware handshake.
 *   Programmers can use this template to quickly set a standard DMA 
 *   up for simple pure RX operation without handshake. If specific, 
 *   additional features are required, these registers must be written after  
 *   this configuration template has been loaded to prevent they are 
 *   accidentally overwritten.
 * 
 ********************************************************************************/
const P33C_DMA_INSTANCE_t plib33cDmaInstanceConfigRxD = {

    .DMACHx.bits.CHEN   = 0,    // Disable channel by default to be enabled at the right time
    .DMACHx.bits.NULLW  = 0,    // No dummy write is initiated
    .DMACHx.bits.TRMODE = 0b01, // Transfer Mode Selection: Repeated One-Shot
    .DMACHx.bits.SIZE   = 1,    // Data Size Selection: Byte (8-bit)
    .DMACHx.bits.SAMODE = 0b00, // Source Address Mode Selection: DMASRCn remains unchanged after a transfer completion
    .DMACHx.bits.DAMODE = 0b01, // Destination Address Mode Selection: DMADSTn is incremented based on the SIZE bit after a transfer completion
    .DMACHx.bits.RELOAD = 1,    // Registers are reloaded to their previous values upon the start of the next operation
    .DMACHx.bits.CHREQ  = 0,    // No DMA request is pending

    .DMAINTx.value = 0x0000,    // Clear DMA Channel n Interrupt Control Register
    .DMASRCx.value = 0x0000,    // Clear DMA Channel n Source Address Register
    .DMADSTx.value = 0x0000,    // DMA Channel n Destination Address Register
    .DMACNTx.value = 0x0000     // DMA Channel n Count Register
};

/*********************************************************************************
 * @ingroup p33c-plib-uart-templates-private
 * @brief   Default UART configuration of one UART instance for standard serial communication without hardware handshake
 *
 * @details
 *   Default configuration of a DMA SFRs with all its registers 
 *   being set for a simple, default DMA operation with TX channel 
 *   enabled but without hardware handshake.
 *   Programmers can use this template to quickly set a standard DMA 
 *   up for simple pure TX operation without handshake. If specific, 
 *   additional features are required, these registers must be written after  
 *   this configuration template has been loaded to prevent they are 
 *   accidentally overwritten.
 * 
 ********************************************************************************/
const P33C_DMA_INSTANCE_t plib33cDmaInstanceConfigTxD = {

    .DMACHx.bits.CHEN   = 0,    // Disable channel by default to be enabled at the right time
    .DMACHx.bits.NULLW  = 0,    // No dummy write is initiated
    .DMACHx.bits.TRMODE = 0b00, // Transfer Mode Selection: One-Shot
    .DMACHx.bits.SIZE   = 1,    // Data Size Selection: Byte (8-bit)
    .DMACHx.bits.SAMODE = 0b01, // Source Address Mode Selection: DMASRCn is incremented based on the SIZE bit after a transfer completion
    .DMACHx.bits.DAMODE = 0b00, // Destination Address Mode Selection: DMADSTn remains unchanged after a transfer completion
    .DMACHx.bits.RELOAD = 0,    // Registers are not reloaded to their previous values upon the start of the next operation
    .DMACHx.bits.CHREQ  = 0,    // No DMA request is pending

    .DMAINTx.value = 0x0000,    // Clear DMA Channel n Interrupt Control Register
    .DMASRCx.value = 0x0000,    // Clear DMA Channel n Source Address Register
    .DMADSTx.value = 0x0000,    // DMA Channel n Destination Address Register
    .DMACNTx.value = 0x0000     // DMA Channel n Count Register
};

// ___________________
// end of file
