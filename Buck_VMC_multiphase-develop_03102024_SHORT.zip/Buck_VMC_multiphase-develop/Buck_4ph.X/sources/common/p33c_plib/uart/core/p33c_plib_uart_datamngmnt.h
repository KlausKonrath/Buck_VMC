/*
    (c) 2023 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

#ifndef DRV_UART_DATAMNGMNT_H
#define	DRV_UART_DATAMNGMNT_H

//#include"p33c_plib_uart_handler.h"

/**********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @struct PLIB_UART_RECEIVE_RINGBUFFER_t
 * @brief This data structure holds the receive ring buffer property
 *********************************************************************************/
struct PLIB33C_RING_BUFFER_s{
    uint8_t    *buf; ///< pointer to the start of the ring buffer 
    uint16_t    end;  ///< offset of the end of the ring buffer 
    uint16_t    head; ///< offset to where next byte will be inserted 
    uint16_t    tail; ///< offset of where next byte will be removed 
};
typedef struct PLIB33C_RING_BUFFER_s PLIB33C_UART_RINGBUFFER_t;

/**********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @struct PLIB_UART_RECEIVE_RINGBUFFER_t
 * @brief This data structure holds the status of the data that is being received 
 *     and sent/ transmitted
 *********************************************************************************/
struct PLIB33C_DATA_STATUS_s {
    bool rxReady           : 1;  ///< Bit 0: Rx is ready to receive data
    bool rxByteReceived    : 1;  ///< Bit 1: data has been received, waiting for more bytes to complete the data frame
    bool rxBufferEmpty     : 1;  ///< Bit 2: Receive buffer is empty
    bool rxBufferOverrun   : 1;  ///< Bit 3: RECEIVE buffer full, not able to receive data anymore
    bool rxBufferLocked    : 1;  ///< Bit 4: Lock the rx data buffer
    bool txReady           : 1;  ///< Bit 4: ready for transmission 
    bool txDataSent        : 1;  ///< Bit 5: transmission completed
    unsigned               : 6;  ///< Bit 13-6: (reserved)
    bool Ready             : 1;  ///< Bit 14: READY bit indicating that UART interface is initialized and ready
    bool Enable            : 1;  ///< Bit 15: Enable Debug UART communication

} __attribute__((packed));

union PLIB33C_DATA_STATUS_u 
{
    struct PLIB33C_DATA_STATUS_s bits;  ///< Common debugging UART object status bits
    uint16_t value;    ///< Common debugging UART object status word    
};
typedef union PLIB33C_DATA_STATUS_u PLIB33C_DATA_STATUS_t; ///< Common debugging UART object status

#endif	/* DRV_UART_DATAMNGMNT_H */

// ___________________
// end of file
