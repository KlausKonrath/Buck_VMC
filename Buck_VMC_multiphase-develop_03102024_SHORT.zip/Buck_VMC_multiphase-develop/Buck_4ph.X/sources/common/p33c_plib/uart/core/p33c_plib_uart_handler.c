/*
    (c) 2023 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
#include <stddef.h> // include standard definition data types
#include <stdlib.h> // include standard libraries data type

#include "xc_pral.h" // include peripheral register abstraction layer drivers
#include "p33c_plib_uart_handler.h"
#include "p33c_plib_uart_datamngmnt.h"
#include "p33c_plib_uart_templates.h"
#include "../IUartHandler.h"

#define DEFAULT_TIMEOUT 65000U

#if defined (U8MODE)
volatile uint16_t plib33cUartDmaTrgRx [] = {
    DMATRG_UART1_RX, DMATRG_UART2_RX, DMATRG_UART3_RX, DMATRG_UART4_RX,
    DMATRG_UART5_RX, DMATRG_UART6_RX, DMATRG_UART7_RX, DMATRG_UART8_RX    
};
volatile uint16_t plib33cUartDmaTrgTx [] = {
    DMATRG_UART1_TX, DMATRG_UART2_TX, DMATRG_UART3_TX, DMATRG_UART4_TX,
    DMATRG_UART5_TX, DMATRG_UART6_TX, DMATRG_UART7_TX, DMATRG_UART8_TX    
};
#elif defined (U7MODE)
volatile uint16_t plib33cUartDmaTrgRx [] = {
    DMATRG_UART1_RX, DMATRG_UART2_RX, DMATRG_UART3_RX, DMATRG_UART4_RX,
    DMATRG_UART5_RX, DMATRG_UART6_RX, DMATRG_UART7_RX
};
volatile uint16_t plib33cUartDmaTrgTx [] = {
    DMATRG_UART1_TX, DMATRG_UART2_TX, DMATRG_UART3_TX, DMATRG_UART4_TX,
    DMATRG_UART5_TX, DMATRG_UART6_TX, DMATRG_UART7_TX
};
#elif defined (U6MODE)
volatile uint16_t plib33cUartDmaTrgRx [] = {
    DMATRG_UART1_RX, DMATRG_UART2_RX, DMATRG_UART3_RX, DMATRG_UART4_RX,
    DMATRG_UART5_RX, DMATRG_UART6_RX
};
volatile uint16_t plib33cUartDmaTrgTx [] = {
    DMATRG_UART1_TX, DMATRG_UART2_TX, DMATRG_UART3_TX, DMATRG_UART4_TX,
    DMATRG_UART5_TX, DMATRG_UART6_TX
};
#elif defined (U5MODE)
volatile uint16_t plib33cUartDmaTrgRx [] = {
    DMATRG_UART1_RX, DMATRG_UART2_RX, DMATRG_UART3_RX, DMATRG_UART4_RX,
    DMATRG_UART5_RX 
};
volatile uint16_t plib33cUartDmaTrgTx [] = {
    DMATRG_UART1_TX, DMATRG_UART2_TX, DMATRG_UART3_TX, DMATRG_UART4_TX,
    DMATRG_UART5_TX
};
#elif defined (U4MODE)
volatile uint16_t plib33cUartDmaTrgRx [] = {
    DMATRG_UART1_RX, DMATRG_UART2_RX, DMATRG_UART3_RX, DMATRG_UART4_RX
};
volatile uint16_t plib33cUartDmaTrgTx [] = {
    DMATRG_UART1_TX, DMATRG_UART2_TX, DMATRG_UART3_TX, DMATRG_UART4_TX
};
#elif defined (U3MODE)
volatile uint16_t plib33cUartDmaTrgRx [] = {
    DMATRG_UART1_RX, DMATRG_UART2_RX, DMATRG_UART3_RX
};
volatile uint16_t plib33cUartDmaTrgTx [] = {
    DMATRG_UART1_TX, DMATRG_UART2_TX, DMATRG_UART3_TX
};
#elif defined (U2MODE)
volatile uint16_t plib33cUartDmaTrgRx [] = {
    DMATRG_UART1_RX, DMATRG_UART2_RX
};
volatile uint16_t plib33cUartDmaTrgTx [] = {
    DMATRG_UART1_TX, DMATRG_UART2_TX
};
#elif defined (U1MODE)
volatile uint16_t plib33cUartDmaTrgRx [] = {
    DMATRG_UART1_RX
};
volatile uint16_t plib33cUartDmaTrgTx [] = {
    DMATRG_UART1_TX
};
#endif

#define plib33c_Uart_InterfaceGetDmaTriggerRx(x) (uint16_t)plib33cUartDmaTrgRx[x-1]
#define plib33c_Uart_InterfaceGetDmaTriggerTx(x) (uint16_t)plib33cUartDmaTrgTx[x-1]

extern PLIB33C_DATA_STATUS_t plib33cDataStatus[];

/**********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Sends a byte-array via user-specified UART instance 
 * @param   txDestination:  Pointer to the destination register (e.g. UART Transmit Buffer Register UxTXREG) of type 16-bit unsigned integer
 * @param   txSource:       Pointer to the first member of the byte array to send of type 8-bit unsigned integer
 * @param   dataLength:      Length of the byte-array (bytes to be sent) of type 16-bit unsigned integer
 * @param   txTimeout:      Wait State Timeout threshold of type 16-bit unsigned integer
 * @return  true:           Byte array has been sent successfully
 * @return  false:          Sending byte array has failed
 * 
 * @details
 *   This assembler routine sends an externally declared byte-array via
 *   the specified UART instance. While pipelining data bytes into the 
 *   UART FIFO, the status of the TxD FIFO status is monitored: 
 *   
 *   - The monitor suspends operation while the buffer is full and 
 *     starts to decrement the timeout counter while the transmitter 
 *     FIFO is blocked. The routine remains in this Wait State until
 *     the transmit FIFO buffer becomes available again or the timeout-
 *     counter decrements to zero.
 * 
 *   - When operation is continued after a FIFO Wait State, the timeout-
 *     counter is reset to its user-defined default value where it remains 
 *     until the next FIFO Wait State occurs.
 * 
 *   - When the timeout counter decrements to zero before the transmitter 
 *     FIFO becomes available again, the routine skips the operation and 
 *     exits.
 * 
 *   - When the number of bytes declared by parameter dataLength have been 
 *     moved into the FIFO, the routine exits. 
 * 
 *********************************************************************************/
extern bool plib33c_Uart_SendBufferAsm(uint16_t* txDestination, uint8_t* txSource, uint16_t dataLength, uint16_t txTimeout);

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief  Opens the specified UART port with the specified settings in standard RS232 mode
 * @param uartInstance      Index of UART instance of type unsigned integer
 * @param baud         Baud Rate in signal segments per second of type unsigned integer of the UART instance Baud Rate generator
 * @param dataBits    Data bit length
 * @param parity       Data parity type
 * @param stopBits    Data bit length
 * @param flowControl Flow control option
 * @return 0 = failure, disabling UART port was not successful
 * @return 1 = success, disabling UART port was successful
 * 
 * @details
 *  This function opens a UART interface port with the respective settings 
 *  specified by in the function parameters. No data send and receive function
 *  will be enabled by default.
 *
 **********************************************************************************/
int plib33c_Uart_OpenPort(uint16_t uartInstance, PLIB33C_UART_BAUDRATE_t baud, 
    PLIB33C_UART_DATA_BITS_t dataBits, PLIB33C_UART_PARITY_t parity, 
    PLIB33C_UART_STOP_BITS_t stopBits, PLIB33C_UART_FLOWCONTROL_t flowControl) 
{
    int retval = 1;
    
    // Check port number specified by user
    if ((0 >= uartInstance) || (uartInstance > P33C_UART_COUNT))
    { return(0); }

    // Check baud rate specified by user
    if (baud < UART_BAUDRATE_75 || baud > UART_BAUDRATE_921600)
    { return(0); }
    
    // Update oscillator setting
    retval &= p33c_UpdateSystemFrequencies();

    // Check system oscillator settings
    if (p33c_SystemFrequencies.Fosc == 0)
    { return(0); }
    
    // Capture UART instance SFR block
    P33C_UART_INSTANCE_t* uart = p33c_UartInstance_GetHandle(uartInstance);
    
    // Selecting the data bits
    switch(dataBits) 
    {
        case UART_DATABITS_7:
            uart->UxMODE.bits.MOD = 0b0001; // Enable 7-bit UART mode
            break;
        
        case UART_DATABITS_8:
            
            // Selecting the data parity
            switch(parity) 
            {
                case UART_PARITY_NONE:
                    uart->UxMODE.bits.MOD = 0b0000; // Enable 8-bit UART mode, no parity
                    break;
                case UART_PARITY_ODD:
                    uart->UxMODE.bits.MOD = 0b0010; // Enable 8-bit UART mode, odd parity
                    break;
                case UART_PARITY_EVEN:
                    uart->UxMODE.bits.MOD = 0b0011; // Enable 8-bit UART mode, even parity
                    break;
                default:
                    return(0);
            }
            
            break;
            
        default:
            return(0);
    }

    // Selecting the data bits
    switch(stopBits) 
    {
        case UART_STOPBITS_1:
            uart->UxMODEH.bits.STSEL = 0b00;    // 1 Stop bit sent, 1 checked at receive
            break;
        case UART_STOPBITS_15:
            uart->UxMODEH.bits.STSEL = 0b01;    // 1.5 Stop bits sent, 1.5 checked at receive
            break;
        case UART_STOPBITS_2:
            uart->UxMODEH.bits.STSEL = 0b10;    // 2 Stop bits sent, 2 checked at receive
            break;
        default:
            return(0);
    }
    
    // Selecting the data parity
    switch(flowControl) 
    {
        case UART_FLOWCONTROL_NONE:
            uart->UxMODEH.bits.FLO = 0b00;  // Flow control off
            break;
        case UART_FLOWCONTROL_HARDWARE:
            uart->UxMODEH.bits.FLO = 0b10;  // RTS-DSR (for TX side)/CTS-DTR (for RX side) hardware flow control
            break;
        case UART_FLOWCONTROL_XON_XOFF:
            uart->UxMODEH.bits.FLO = 0b01;  // XON/XOFF software flow control
            break;
        default:
            return(0);
    }

    // Set Baud Rate Generator Divider Mode to Fractional Divider
    if (baud >= UART_BAUDRATE_115200 )
    { uart->UxMODEH.bits.BCLKSEL = 0b10; } // Baud Clock Source Selection: FOSC/2 (=FP)
    else { uart->UxMODEH.bits.BCLKSEL = 0b00; } // Baud Clock Source Selection: FOSC
    uart->UxMODEH.bits.BCLKMOD = 1; // Use fractional baud rate divider mode (highest resolution)
    
    // Calculate baud rate generator divider
    
    retval &= plib33c_Uart_SetBaudrate(uartInstance, baud);

    // Clear pending TX error flags
    uart->UxSTA.bits.TXCIF = 0; // Clear Transmit Collision Interrupt Flag bit
    uart->UxSTAH.bits.TXWRE = 0; // Clear TX Write Transmit Error Status bit

    uart->UxSTA.bits.OERR = 0;      // Clear Receive Buffer Overflow Interrupt Flag bit
    uart->UxSTA.bits.RXBKIF = 0;
    
    // Enable RX, TX and UART port instance
    uart->UxSTAH.bits.UTXBE  = 1;    // Reset TX FIFO
    uart->UxSTAH.bits.URXBE  = 1;    // Reset RX FIFO
    uart->UxMODE.bits.UTXEN  = true; // Enable Transmitter
    uart->UxMODE.bits.URXEN  = true; // Enable Receiver
    uart->UxMODE.bits.UARTEN = true; // Enable UART Instance
    
    retval = (bool)(uart->UxMODE.bits.UARTEN);
    
	return(retval);
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Enables the specified UART port
 * @param   uartInstance Instance of the UART port of type unsigned integer (e.g. 1=UART1, 2=UART2, etc.)
 * @return  0 = failure, enabling UART port was not successful
 * @return  1 = success, enabling UART port was successful
 * 
 * @details
 *     This function enables the UART port. It is expected that RX and/or TX
 *     have been enabled previously as part of the peripheral configuration.
 *     
 * @note:
 *     if RX and TX are not enabled, this function will still enable the 
 *     specified UART instance but will return an error to indicate that 
 *     no communication will be possible.
 * 
 *********************************************************************************/
int plib33c_Uart_Enable(uint16_t uartInstance)
{
    int retval = 1;
    
    // Set pointer to memory address of desired PWM instance
    P33C_UART_INSTANCE_t* uart = p33c_UartInstance_GetHandle(uartInstance);
    
    // Set UART port enable bit (expecting RX and/or TX to be set previously)
    uart->UxMODE.bits.UARTEN = true;
    retval &= (bool)((uart->UxMODE.bits.UARTEN) && 
                    ((uart->UxMODE.bits.UTXEN) || (uart->UxMODE.bits.URXEN)));
    
    return(retval);       
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Disables the specified UART port 
 * @param   uartInstance Instance of the UART port of type unsigned integer (e.g. 1=UART1, 2=UART2, etc.)
 * @return  0 = failure, disabling UART port was not successful
 * @return  1 = success, disabling UART port was successful
 * 
 * @details
 *     This function disables the UART port. All communication will stop immediately.
 * 
 *********************************************************************************/
int plib33c_Uart_Disable(uint16_t uartInstance)
{
    int retval = 1;
    
    // Set pointer to memory address of desired PWM instance
    P33C_UART_INSTANCE_t* uart = p33c_UartInstance_GetHandle(uartInstance);
    
    uint16_t timeout = 0;
    
    while((!uart->UxSTA.bits.TRMT) && (timeout++<DEFAULT_TIMEOUT)); // Wait until last TX buffer shifter activity has seized
    if (timeout >= DEFAULT_TIMEOUT) return(0);                      // Timeout Error
    timeout = 0;                                                    // Clear timeout counter
    
    while((!uart->UxSTAH.bits.UTXBE) && (timeout++<DEFAULT_TIMEOUT)); // Wait until UART signals empty buffer
    if (timeout >= DEFAULT_TIMEOUT) return(0);                      // Timeout Error
    timeout = 0;                                                    // Clear timeout counter
    
    // Set UART port enable bit (allowing RX and/or TX to remain set)
    uart->UxMODE.bits.UARTEN = false;
    retval &= (bool)(!uart->UxMODE.bits.UARTEN);
    
    return(retval);       
}
  
/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief  Sets the Baud Rate of the specified UART instance
 * @param  uartInstance  Index of UART peripheral instance of type unsigned integer
 * @param  baud     Baud Rate in signal segments per second of type unsigned integer of the UART peripheral instance Baud Rate generator
 * @return 0 = failure, setting UART Baud Rate was not successful
 * @return 1 = success, setting UART Baud Rate was successful
 * 
 * @details
 *     This function writes the value specified by 'baud' to the Baud Rate 
 *     register of the specified UART peripheral instance.
 * 
 *********************************************************************************/
int plib33c_Uart_SetBaudrate(uint16_t uartInstance, uint32_t baud)
{
    int retval = 1;

    // Check port number specified by user
    if ((0 >= uartInstance) || (uartInstance > P33C_UART_COUNT))
    { return(0); }
    
    // Capture UART instance SFR block
    P33C_UART_INSTANCE_t* uart = p33c_UartInstance_GetHandle(uartInstance);
    if (NULL == uart) { return(0); } // return error   
    
    // Update oscillator setting
    retval &= p33c_UpdateSystemFrequencies();

    // Check which baud rate option is set
    uint32_t brg = 0;
    switch (uart->UxMODEH.bits.BCLKSEL)
    {
        case 0b00: brg = (uint32_t)(p33c_SystemFrequencies.Fp / baud); break;
        case 0b10: brg = (uint32_t)(p33c_SystemFrequencies.Fosc / baud); break;
        case 0b11: brg = (uint32_t)((p33c_SystemFrequencies.AFvco / 3.0) / baud); break;
        default: return(0);
    }

    // If legacy mode of baud clock generation is selected, divide baud clock setting by x,  
    // where x = 4 or 16 depending on the BRGH bit
    if (false == uart->UxMODEH.bits.BCLKMOD) { 

        if (uart->UxMODE.bits.BRGH) { // If High Speed Baud Rate Clock Divider 4 is selected 
            brg = ((brg >> 2)-1); // divide by 4, subtract 1
        }
        else { // If Low Speed Baud Rate Clock Divider 16 is selected 
            brg = ((brg >> 4)-1); // divide by 16, subtract 1
        }
    }

    // Set UART port Baud Rate divisor bits
    uart->UxBRG.value = (uint16_t)(brg & 0x0000FFFF);
    uart->UxBRGH.value = (uint16_t)((brg & 0x00FF0000) >> 16);
    
    return(retval);
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief  Gets the most recent Baud Rate of the specified UART interface
 * @param  uartInstance Index of UART peripheral instance of type unsigned integer
 * @return Baud Rate in signal segments per second of type unsigned integer of the UART interface Baud Rate generator
 * 
 * @details
 *     This function returns the value of the Baud Rate register of the 
 *     specified UART peripheral instance in [Baud Per Second]
 * 
 *********************************************************************************/
uint32_t plib33c_Uart_GetBaudRate(uint16_t uartInstance)
{
    uint32_t retval=1;
    
    // Check port number specified by user
    if ((0 >= uartInstance) || (uartInstance > P33C_UART_COUNT))
        return(0);
    
    // Capture UART instance SFR block
    P33C_UART_INSTANCE_t* uart = p33c_UartInstance_GetHandle(uartInstance);

    if (uart != NULL) 
    {
        // Update oscillator setting
        retval &= p33c_UpdateSystemFrequencies();

        // Read Baud Rate Register
        uint32_t brg = (uart->UxBRGH.value);
        brg <<= 16;
        brg |= uart->UxBRG.value;

        // IF legacy mode of baud clock generation is selected, divide baud clock setting by x,  
        // where x = 4 or 16 depending on the BRGH bit
        if (!uart->UxMODEH.bits.BCLKMOD) { 

            if (uart->UxMODE.bits.BRGH) { // If High Speed Baud Rate Clock Divider 4 is selected 
                brg = ((brg+1) << 2); // add 1, multiply by 4
            }
            else { // If Low Speed Baud Rate Clock Divider 16 is selected 
                brg = ((brg+1) << 4); // add 1, multiply by 16
            }
        }

        // Check which baud rate option is set
        if (brg > 0) // Uses fractional Baud Rate Generation
        { 
            uint32_t baud = 0;
            switch (uart->UxMODEH.bits.BCLKSEL)
            {
                case 0b00: baud = (uint32_t)(p33c_SystemFrequencies.Fp / brg); break;
                case 0b10: baud = (uint32_t)(p33c_SystemFrequencies.Fosc / brg); break;
                case 0b11: baud = (uint32_t)((p33c_SystemFrequencies.AFvco / 3.0) / brg); break;
                default: return(0);
            }
            retval = baud;
        }
        else {
            retval = 0;
        }

    }
    
    return(retval);       
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Sends a single via an opened UART interface
 * @param   uartInstance Index of UART peripheral instance of type unsigned integer
 * @param   byte    Single data byte to be sent via specified UART interface object
 * @return 0 = failure, setting UART Baud Rate was not successful
 * @return 1 = success, setting UART Baud Rate was successful
 *  
 * @details
 *     This function sends a single byte via the specified UART peripheral 
 *     instance. 
 * 
 *********************************************************************************/
int plib33c_Uart_WriteByte(uint16_t uartInstance, char byte)
{
    int retval = 1;

    // Null-pointer protection
    P33C_UART_INSTANCE_t*  uart = p33c_UartInstance_GetHandle(uartInstance);
    
    if (uart != NULL) 
    {
        while(uart->UxSTAH.bits.UTXBF);
        uart->UxTXREG.bits.TXREG = byte; // write byte to buffer
    }
    else { retval = 0; }

    return(retval);
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Send data buffer via Transmit buffer of selected Uart instance
 * @param   uartInstance Pointer to UART peripheral instance of type unsigned integer
 * @param 	buffer		Pointer to the address of the transmit buffer	
 * @param   dataLength	length of the buffer to be transmitted
 * @return	0	Unsuccessful in sending the data buffer
 * @return  1   Successful in send the data buffer 
 * @details
 *  This function send out the data buffer via transmit buffer of the selected instance.
 *  It calls an assembly code to optimize the transfer of data. 
 *     
 *********************************************************************************/
int plib33c_Uart_SendBuffer(uint16_t uartInstance, uint8_t* buffer, uint16_t dataLength)
{
    int retval = 1;

    // Null-pointer protection
    P33C_UART_INSTANCE_t* uart = p33c_UartInstance_GetHandle(uartInstance);
    
    if (uart != NULL) 
    { 
        // Send data buffer via TxD Buffer of selected UART instance
        uint16_t timeout=1000;
        retval = plib33c_Uart_SendBufferAsm(&uart->UxTXREG.value, buffer, dataLength, timeout);
    }
    else { retval = 0; }

    return(retval);
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Reads a single byte from an opened UART interface 
 * @param   uartInstance Pointer to UART peripheral instance of type unsigned integer
 * @return  Single data byte read from the specified UART interface
 *  
 * @details
 *     This function reads a single byte from the specified UART interface. 
 * 
 *********************************************************************************/
uint8_t plib33c_Uart_ReadByte(uint16_t uartInstance)
{
    int retval = 1;
    P33C_UART_INSTANCE_t* uart;
    
    // Null-pointer protection
    uart = p33c_UartInstance_GetHandle(uartInstance);
    if (uart != NULL) {
        retval = (char)(uart->UxRXREG.bits.RXREG);
    }   
    else { retval = 0; }

    return(retval);
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Initializes a DMA settings for the UART interface
 * @param   port Pointer to UART interface object of type UART_INTERFACE_t
 * @return 0 = failure, Initializing DMA and UART interface was not successful
 * @return 1 = success, Initializing DMA and UART interface was successful
 * @details
 *  This function can be used to initialize a DMA for UART interface by handing over
 *  a predefined user interface object.  
 *
 **********************************************************************************/
int plib33c_Uart_DmaDataTransferInitialize(UART_t* uartConfig) 
{
    int retval = 1;
	
    // Initialize selected UART
    P33C_UART_INSTANCE_t* uart = p33c_UartInstance_GetHandle(uartConfig->CommPort.UartInstance);
    if (uart != NULL)
    {
        uart->UxSTAH.bits.UTXISEL = 0;  // Generate trigger when complete buffer is empty
        uart->UxSTAH.bits.URXISEL = 0;  // Generate trigger receive interrupt when there is 1 word or more in the buffer
    }
    
    // Enable DMA support
    if ((uartConfig->Status.TxDmaEnable))
    {
        // Check DMA module is used, enable if not
        P33C_DMA_MODULE_t* dmac = p33c_DmaModule_GetHandle();
        
        if (dmac != NULL) 
        {
            if (0 == dmac->DMACON.bits.DMAEN) { p33c_DmaModule_SetConfig(dmaModuleConfigClear); }
            dmac->DMACON.bits.DMAEN = true; // Enable DMA controller first
            dmac->DMACON.bits.PRSSEL = true; //Enable DMA Channel Priority Scheme
        }
        else { return(0); }

        // Initialize TxD DMA channel
        if (uartConfig->Status.TxDmaEnable) 
        {
            P33C_DMA_INSTANCE_t* dma = p33c_DmaInstance_GetHandle(uartConfig->CommPort.TxD.DmaInstance);

            if (dma != NULL) 
            {
                retval &= p33c_DmaInstance_SetConfig(uartConfig->CommPort.TxD.DmaInstance, plib33cDmaInstanceConfigTxD);
                dma->DMADSTx.value = (uint16_t)&(uart->UxTXREG); // Set fixed destination address for Transmit channel
                dma->DMAINTx.bits.CHSEL = plib33c_Uart_InterfaceGetDmaTriggerTx(uartConfig->CommPort.UartInstance); // DMA Channel Trigger Selection: UARTx Transmitter
            }
            else { return(0); }
        }
        else { /* do nothing */ }
    }
    
    // Set READY bit indicating successful configuration
    uartConfig->Status.Ready = true;
    
	return(retval);
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Sends complete user buffer via an opened UART interface using DMA
 * @param   port        Pointer to UART interface object of type UART_INTERFACE_t
 * @param   startAddr  Data buffer start address of type unsigned integer
 * @param   length      Length of data buffer to be sent
 * @return 0 = failure, DMA Send Buffer was not successful
 * @return 1 = success, DMA Send Buffer was successful
 *  
 * @details
 *     This function links the DMA port to the UART transmit 
 *
 **********************************************************************************/
int plib33c_Uart_SendBufferDma(UART_t* uartConfig, uint8_t* buffer, uint16_t dataLength)
{
    int retval = 1;
    
    // Exit if part has not been declared
    if (uartConfig == NULL) { return(0); }
    
    // Exit if DMA usage is disabled by user
    if (!uartConfig->Status.TxDmaEnable) { return(0); }
    
    plib33cDataStatus[uartConfig->CommPort.UartInstance].bits.txDataSent = false;
    
    // Capture UART and DMA object addresses
    P33C_UART_INSTANCE_t* uart = p33c_UartInstance_GetHandle(uartConfig->CommPort.UartInstance);
    if (NULL == uart) { return(0); }
    P33C_DMA_INSTANCE_t* dma  = p33c_DmaInstance_GetHandle(uartConfig->CommPort.TxD.DmaInstance);
    if (NULL == dma) { return(0); }
    
    uint16_t timeout=0;

    // Set BUSY bit
    uartConfig->Status.Busy = true;

    // Wait while previous process is ongoing
    while((dma->DMACNTx.value > 0) && (timeout++<DEFAULT_TIMEOUT)); // Wait until DMA has transferred all data to destination
    if (timeout >= DEFAULT_TIMEOUT) return(0);                      // Timeout Error
    timeout = 0;                                                    // Clear timeout counter
    while((!uart->UxSTA.bits.TRMT) && (timeout++<DEFAULT_TIMEOUT)); // Wait until last TX buffer shifter activity has seized
    if (timeout >= DEFAULT_TIMEOUT) return(0);                      // Timeout Error
    timeout = 0;                                                    // Clear timeout counter
    while((!uart->UxSTAH.bits.UTXBE) && (timeout++<DEFAULT_TIMEOUT)); // Wait until UART signals empty buffer
    if (timeout >= DEFAULT_TIMEOUT) return(0);                      // Timeout Error
    timeout = 0;                                                    // Clear timeout counter

    // Wait until the DMA is done 
    while ((dma->DMACHx.bits.CHREQ) && (timeout++<DEFAULT_TIMEOUT)); // Wait until DMA transfer is complete
    if (timeout >= DEFAULT_TIMEOUT) return(0);                      // Timeout Error
    timeout = 0;                                                    // Clear timeout counter

    // Reset TX FIFO
    uart->UxMODE.bits.UTXEN = 0;    // Disable Transmitter
    uart->UxSTAH.bits.UTXBE = 1;    // Reset TX FIFO
    uart->UxMODE.bits.UTXEN = 1;    // Enable Transmitter

    // Clear pending TX error flags
    uart->UxSTA.bits.TXCIF = 0; // Clear Transmit Collision Interrupt Flag bit
    uart->UxSTAH.bits.TXWRE = 0; // Clear TX Write Transmit Error Status bit

    uint16_t startAddr = (uint16_t)buffer; // Convert pointer to start of byte data array to 16-bit memory address pointer
    dma->DMASRCx.value = startAddr; // Set DMA start address pointer
    dma->DMACNTx.value = dataLength; // Set DMA data set length
    dma->DMACHx.bits.CHREQ = 1; // Trigger DMA request by software
    dma->DMACHx.bits.CHEN = true; // DMA Channel Enable: enabled

    uartConfig->Status.Busy = false;   // clear BUSY bit
    
    retval = (dma->DMAINTx.bits.HIGHIF | dma->DMAINTx.bits.LOWIF | dma->DMAINTx.bits.OVRUNIF);
    retval = (bool)(retval==0);
    
    return(retval);
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Checks if the DMA is Done
 * @param   dmaInstance Index of DMA instance of type unsigned integer
 * @return 0 = failure, DMA is not DONE with data processing
 * @return 1 = success, DMA is DONE with data processing
 *  
 * @details This function monitors if the DMA is done processing the data that will
 *     sent out in UART via DMA
 *   
 **********************************************************************************/
bool plib33c_Uart_OperationCompleteDma(uint16_t dmaInstance)
{
    P33C_DMA_INSTANCE_t* dma = p33c_DmaInstance_GetHandle(dmaInstance);
    return(dma->DMAINTx.bits.DONEIF);
}

/*********************************************************************************
 * @fn uint16_t plib33c_Uart_RemapRxPin(uint16_t uartInstance, GPIO_PORT_PIN_t pin)
 * @ingroup p33c-plib-uart-methods-private
 * @brief  Assign uart receive output to a pin
 * @param  uartInstance      Index of UART instance of type unsigned integer
 * @param  pin          Generic device port ID structure data type
 * @return 0 = failure, Receive pin enable was not successful
 * @return 1 = success, Receive pin enable was successful
 * 
 * @details Enables the device pin to be used as Uart Receive pin
 * 
 *********************************************************************************/
int plib33c_Uart_RemapRxPin(UART_t* uartConfig, const P33C_GPIO_t* pin)
{
    int retval = 1;
    
    // Unlock Peripheral Pin Selection Registers
    retval &= p33c_Pps_UnlockIO();
    
    switch(uartConfig->CommPort.UartInstance) 
    {
        case 1:
            retval &= p33c_Pps_MapInput(pin->Properties.RPid, PPSI_U1RX);
            break;

        #if P33C_UART_COUNT > 1
        case 2:
            retval &= p33c_Pps_MapInput(pin->Properties.RPid, PPSI_U2RX);
            break;
        #endif  
        #if P33C_UART_COUNT > 2
        case 3:
            retval &= p33c_Pps_MapInput(pin->Properties.RPid, PPSI_U3RX);
            break;
        #endif
        default:
            return(0);
            break;
    }
    
    // Lock Peripheral Pin Selection Registers
    retval &= p33c_Pps_LockIO();
    
    // Set TRIS registers of RX
    pin->Methods.Init(true, true);
    pin->Methods.SetPullUp(true);
        
    return(retval);
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief  Assign uart transmit output to a pin
 * @param  uartInstance      Index of UART instance of type unsigned integer
 * @param  pin          Generic device port ID structure data type
 * @return 0 = failure, Transmit pin enable was not successful
 * @return 1 = success, Transmit pin enable was successful
 * 
 * @details Enables the device pin to be used as Uart Trasmit pin
 * 
 *********************************************************************************/
int plib33c_Uart_RemapTxPin(UART_t* uartConfig, const P33C_GPIO_t* pin)
{
    int retval = 1;

    // Unlock Peripheral Pin Selection Registers
    retval &= p33c_Pps_UnlockIO();
    
    switch(uartConfig->CommPort.UartInstance) 
    {
        case 1:
            retval &= p33c_Pps_MapOutput(pin->Properties.RPid, PPSO_U1TX);
            break;

        #if P33C_UART_COUNT > 1
        case 2:
            retval &= p33c_Pps_MapOutput(pin->Properties.RPid, PPSO_U2TX);
            break;
        #endif

        #if P33C_UART_COUNT > 2
        case 3:
            retval &= p33c_Pps_MapOutput(pin->Properties.RPid, PPSO_U3TX);
            break;
        #endif    
            
        default:
            return(0);
            break;
    }
    
    // Lock Peripheral Pin Selection Registers
    retval &= p33c_Pps_LockIO();

    // Set TRIS registers of TX
    pin->Methods.Init(false, true);
    pin->Methods.SetPullUp(true);
    
    return(retval);
}

// ___________________
// end of file
