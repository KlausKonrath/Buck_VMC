

#include "I2C.h"
#include <xc.h>
#include "config/apps.h"
#include "./apps/power_control/devices/dev_buck_4ph_typedef.h"   // include  Converter type definitions
#include "./apps/power_control/devices/dev_psfb_converter.h" // include  Converter object header
#include "./apps/power_control/devices/dev_psfb_pconfig.h"
#include "./apps/power_control/drivers/vout_loop_vmc.h"   
#include "./apps/power_control/drivers/vout_loop_agc.h"   

// Define the I2C buffer size
#define I2C_TX_BUFFER_SIZE  40
#define I2C_RX_BUFFER_SIZE   6

// Declare I2C buffers
uint8_t i2c_rx_buffer[I2C_RX_BUFFER_SIZE];
uint8_t i2c_tx_buffer[I2C_TX_BUFFER_SIZE];

uint8_t CommandCode = 0x00U;

/* send message */
bool	st_AddrFlag;
bool	st_DataFlag;
uint16_t CompVoltage = 0x0000U;

/* ********************************************************************************************** */
/* ********************************************************************************************** */
/* ********************************************************************************************** */

/*********************************************************************************
 * @brief   Initializes a given I2C port
 * 
 * @details
 *  This function initializes the specified I2C port along with the DMA. 
 *  The data buffers and handlers were also initialize, as well as the
 *  pins for the I2C RxD and TxD.
 * 
 *********************************************************************************/
void I2C_Initialize(void) 
{
    /* RB8 and RB9 must be digital inputs */
    ANSELBbits.ANSELB8 = 0U;
    ANSELBbits.ANSELB9 = 0U;
    
    /* Enable internal pull-ups for SDA and SCL */
    _CNPUB8 = 1;
    _CNPUB9 = 1;
    
    /* set RB8 and RB9 Port configuration for SDC and SCL */
    SCL_ODC = 1;
    SCL_LAT = 0;    
    SCL_TRIS = 1;
    SDA_ODC = 1;
    SDA_LAT = 1;
    SDA_TRIS = 1;

    // Initialize I2C1 as slave
    I2C1CONLbits.I2CEN = 0;   // Disable I2C1 module
    I2C1CONLbits.I2CSIDL = 0; // Continue operation in Idle mode
    I2C1CONLbits.A10M = 0;    // 7-bit slave address
    I2C1CONLbits.STREN = 1;
    I2C1CONLbits.SCLREL = 0;  // Holds the SCLx clock low
    I2C1CONLbits.DISSLW = 0;  // disables slew rate
    I2C1CONHbits.BOEN = 1;    // Buffer overwrite enable  
    
    I2C1ADD = 0x55;           // Set slave address to 0x55
    I2C1MSK = 0x00;           // No address masking
    
    
    IPC4bits.SI2C1IP = 1;
    IFS1bits.SI2C1IF = 0;
    IEC1bits.SI2C1IE = 1;
    
    I2C1CONLbits.I2CEN = 1;   // Enable I2C1 module
    
    
//    // Initialize DMA for I2C1 RX on Channel 2
//    DMACH2bits.CHEN = 0;        // Disable DMA channel 2
//    DMACH2bits.SIZE = 1;        // 8-bit size transfers
//    DMACH2bits.RELOAD = 0;      // Address and Count Reload = DMASRCn, DMADSTn and DMACNTn are not reloaded on the start of the next operation
//    DMACH2bits.SAMODE = 0b00;   // Source Address Mode Selection, = DMASRCn remains unchanged after a transfer completion
//    DMACH2bits.DAMODE = 0b01;   // Source Address Mode Selection, = DMASRCn is incremented by SIZE after a transfer completion
//    DMACH2bits.TRMODE = 0b01;   // repeated one-shot
//    DMAINT2bits.CHSEL = 0x09;   // SI2C1 Client Event
//    DMACNT2 = 0x02;
//    
//    DMASRC2 = &I2C1RCV;         // Source Address - Read from I2C Buffer
//    DMADST2 = &i2c_rx_buffer;   // Destination Address - write into RAM Buffer
//    
//    /* set DMA2 to low ISR priority */
//    IPC4bits.DMA2IP = 1;
    
    
    // Initialize DMA for I2C1 TX on Channel 3
    DMACH3bits.CHEN = 0;        // Disable DMA channel 3
    DMACH3bits.SIZE = 1;        // 8-bit size transfers
    DMACH3bits.RELOAD = 0;      // Address and Count Reload = DMASRCn, DMADSTn and DMACNTn are not reloaded on the start of the next operation
    DMACH3bits.SAMODE = 0b01;   // Source Address Mode Selection, = DMASRCn remains unchanged after a transfer completion
    DMACH3bits.DAMODE = 0b00;   // Source Address Mode Selection, = DMASRCn is incremented by SIZE after a transfer completion
    DMACH3bits.TRMODE = 0b01;   // repeated one-shot
    DMAINT3bits.CHSEL = 0x09;   // SI2C1 Client Event
    
    DMASRC3 = (uint16_t)&i2c_tx_buffer[2U];   // Source Address - Read from RAM Buffer
    DMADST3 = (uint16_t)&I2C1TRN;         // Destination Address - write on I2C
    
    /* set DMA3 to low ISR priority */
    IPC5bits.DMA3IP = 1;
    

    
//    // Enable DMA Channel 2 interrupt
//    IFS1bits.DMA2IF = 0;       // Clear DMA2 interrupt flag
//    IEC1bits.DMA2IE = 1;       // Enable DMA2 interrupt
    
    // Enable DMA Channel 3 interrupt
    IFS1bits.DMA3IF = 0;       // Clear DMA3 interrupt flag
    IEC1bits.DMA3IE = 1;       // Enable DMA3 interrupt

    // Enable DMA channels
//    DMACH2bits.CHEN = 1;      // Enable DMA Channel 2
//    DMACH3bits.CHEN = 1;      // Enable DMA Channel 3
}

/*********************************************************************************
 * @brief   Handling of RX-Buffer
 * 
 * @details
 *  This function handles received data according desired command code.
 * 
 *********************************************************************************/
void I2C_Handler(void)
{
    uint16_t tmp_calc = 0U;
    uint16_t tmp_crc_received = 0U;
    
    /* check for new command code request */
    switch(i2c_rx_buffer[0U])
    {
        case Cmd_Idle:

            /* no new request - do nothing */

        break;
    
        case Cmd_ComparatorVoltage:
            
            /* check if every byte of message was received */
            if(i2c_rx_buffer[5U] == 1U)
            {
                /* calculate CRC16 of received data */
                tmp_calc = crc16(i2c_rx_buffer, (LengthData_ComparatorVoltage_Resp + 1U));

                /* load received CRC from buffer */
                tmp_crc_received |= (i2c_rx_buffer[4U] << 8U);
                tmp_crc_received |= i2c_rx_buffer[3U];

                /* compare checksum */
                if(tmp_calc == tmp_crc_received)
                {
                    /* clear variable */
                    CompVoltage = 0x0000U;
                    
                    /* checksum correct - load LSB value of comparator voltage */
                    CompVoltage |= (uint16_t)i2c_rx_buffer[1U];
                    
                    /* load MSB value of comparator voltage */
                    CompVoltage |= (uint16_t)(((uint16_t)i2c_rx_buffer[2U]) << 8U);
                    
                    /* check if max. allowed comparator voltage reached */
                    if(CompVoltage > 0x41BEU)
                    {
                        /* do limitation */
                        CompVoltage = 0x41BEU;
                    }
                    else
                    {
                        /* everything inner range - do nothing */
                    }
                    
                    /* calculate PWM Duty Cycle --> y = 2,3767 * x */
                    tmp_calc = (uint16_t)(((uint32_t)((uint32_t)CompVoltage * (uint32_t)2434)) >> 10U);
                    
                    /* check if limitation is necessary */
                    if(tmp_calc > PWM6_DC_100_PERC)
                    {
                        /* do limitation */
                        tmp_calc = PWM6_DC_100_PERC;
                    }
                    else
                    {
                        /* everything is inner range - do nothing */
                    }
                    
                    /* write new desired duty cylce */
                    PG6DC = tmp_calc;
                    
                    /* set duty cycle update flag */
                    PG6STATbits.UPDREQ = 1;

                }
                else
                {
                    /* checksum not correct - do nothing */
                }

                /* clear command code for next request */
                i2c_rx_buffer[0U] = 0U;
                
                /* clear marker for message received completely */
                i2c_rx_buffer[5U] = 0U;
            }
            else
            {
                /* message not completely received */
            }

        break;
        
        case Cmd_ColdRestart:

            /* check if every byte of message was received */
            if(i2c_rx_buffer[4U] == 1U)
            {
                /* calculate CRC16 of received data */
                tmp_calc = crc16(i2c_rx_buffer, (LengthData_ColdRestart_Resp + 1U));

                /* load received CRC from buffer */
                tmp_crc_received |= (i2c_rx_buffer[4U] << 8U);
                tmp_crc_received |= i2c_rx_buffer[3U];

                /* compare checksum */
                if(tmp_calc == tmp_crc_received)
                {
                    /* checksum correct - load value */

    //TODO:    

                }
                else
                {
                    /* checksum not correct - do nothing */
                }

                /* clear command code for next request */
                i2c_rx_buffer[0U] = 0U;
                
                /* clear marker for message received completely */
                i2c_rx_buffer[4U] = 0U;
            }
            else
            {
                /* message not completely received */
            }
            
        break;
        
        default:

            /* wrong call - clear command code for next request */
            i2c_rx_buffer[0U] = 0U;
            
        break;
    }
    
}

// DMA2 Interrupt Service Routine (ISR)
void __attribute__((interrupt, no_auto_psv)) _DMA2Interrupt(void) 
{
    // Clear the DMA interrupt flag
    IFS1bits.DMA2IF = 0;
    
//    DMACH3bits.CHREQ = 1;
    
    // Handle received data
    // (e.g., process i2c_rx_buffer)
}

// DMA3 Interrupt Service Routine (ISR)
void __attribute__((interrupt, no_auto_psv)) _DMA3Interrupt(void)
{   
    /* disable DMA3 */
    DMACH3bits.CHEN = 0;
    
    /* Clear the DMA interrupt flag */
    IFS1bits.DMA3IF = 0;
}

//TODO: wieder l�schen - nur f�r Testzweck!!!
static uint32_t process_dummy_32 = 0x44332211;

void __attribute__ ( ( interrupt, no_auto_psv ) ) _SI2C1Interrupt(void)
{
	static uint8_t cnt_Buff = 0U;
	uint8_t Temp = 0U;
    uint16_t CRC = 0U;

    /* check for write collision */
    if(I2C1STATbits.IWCOL == true)
    {
        /* clear write collision flag*/
        I2C1STATbits.IWCOL = false;
    }
    else
    {
        /* do nothing */
    }
    
    /* check for receive overflow */
    if(I2C1STATbits.I2COV == true)
    {
        /* clear receive overflow flag*/
        I2C1STATbits.I2COV = false;
        
        /* do dummy read */
        Temp = I2C1RCV;  
    }
    else
    {
        /* do nothing */
    }
    
    
	/* check if data transfer is input slave and last byte was device adress and matched */
	if((I2C1STATbits.R_W == 0)&&(I2C1STATbits.D_A == 0))
    {
        /* dummy read */
        Temp = I2C1RCV;

        /* next byte will be address */
        st_AddrFlag = 1;

        st_DataFlag = 0;

        cnt_Buff = 0x00;
    }
	/* check if data transfer is input slave and last byte was data */
	else if((I2C1STATbits.R_W == 0)&&(I2C1STATbits.D_A == 1))
	{
        if(st_AddrFlag)
        {
            /* clear address flag */
            st_AddrFlag = 0U;

            /* next byte is data */
            st_DataFlag = 1U;

            /* read command code from I2C */
            CommandCode = I2C1RCV;

            cnt_Buff = 0x00;
        }
        else if(st_DataFlag)
        {
            /* check for valid command code */
            if(CommandCode == Cmd_ComparatorVoltage)
            {
                /* store data into buffer */
                i2c_rx_buffer[(cnt_Buff + 1U)] = (uint8_t)I2C1RCV;

                /* check for message end */
                if(cnt_Buff < (LengthComplete_ComparatorVoltage_Resp - 2U))
                {
                    /* increment buffer array counter */
                    cnt_Buff++;
                }
                else
                {
                    /* first byte of rx-buffer is Command Code */
                    i2c_rx_buffer[0U] = CommandCode;
                    
                    /* end of message reached - set marker */
                    i2c_rx_buffer[5U] = 0x01U;
                }
            }
            else if(CommandCode == Cmd_ColdRestart)
            {
                /* store data into buffer */
                i2c_rx_buffer[(cnt_Buff + 1U)] = (uint8_t)I2C1RCV;

                /* check for message end */
                if(cnt_Buff < (LengthComplete_ColdRestart_Resp - 2U))
                {
                    /* increment buffer array counter */
                    cnt_Buff++;
                }
                else
                {
                    /* first byte of rx-buffer is Command Code */
                    i2c_rx_buffer[0U] = CommandCode;
                    
                    /* end of message reached - set marker */
                    i2c_rx_buffer[4U] = 0x01U;
                }
            }
            else
            {
                /* no valid command code - do dummy read */
                Temp = I2C1RCV;
            }
            
            /* end of tx */
            st_AddrFlag = 0;
        }
        else
        {
            /* should never be reached - do dummy read  */
            Temp = I2C1RCV;
        }
	}
	else if((I2C1STATbits.R_W == 1)&&(I2C1STATbits.D_A == 0))
	{
		/* dummy read */
        Temp = I2C1RCV;
        
        /* clear flag for data received */
        st_DataFlag = 0;   
        
        /* check command code */
        switch(CommandCode)
        {
            case Cmd_StatusInformation:
            
                /* load first byte in Buffer with Command Code for CRC Calculation */
                i2c_tx_buffer[0U] = Cmd_StatusInformation;
                
                /* load CRC Fault detection value */
//TODO: hier richtigen Fault Detection Wert laden!!!
                i2c_tx_buffer[1U] = 0x00;
                
                /* do CRC16 calculation */
                CRC = crc16(i2c_tx_buffer, (Length_StatusInformation_Resp - 1U));
                
                /* load CRC16 LSB */
                i2c_tx_buffer[2U] = (uint8_t)CRC;
                
                /* load CRC16 MSB */
                i2c_tx_buffer[3U] = (uint8_t)(CRC >> 8U);
                
                /* load counter for sending desired byte length via DMA */
                DMACNT3 = (uint8_t)(Length_StatusInformation_Resp - 1U);
                
            break; 
            
            case Cmd_VersionInformation:
            
                /* load first byte in Buffer with Command Code for CRC Calculation */
                i2c_tx_buffer[0U] = Cmd_VersionInformation;
                
                /* load major software version */
                i2c_tx_buffer[1U] = FIRMWARE_VERSION_MAJOR;
                
                /* load minor software version */
                i2c_tx_buffer[2U] = FIRMWARE_VERSION_MINOR;
                
                /* load patch software version */
                i2c_tx_buffer[3U] = FIRMWARE_VERSION_PATCH;
                
                /* load hardware variant */
                i2c_tx_buffer[4U] = HARDWARE_VARIANT;
                
                /* do CRC16 calculation */
                CRC = crc16(i2c_tx_buffer, (Length_VersionInformation_Resp - 1U));
                
                /* load CRC16 LSB */
                i2c_tx_buffer[5U] = (uint8_t)CRC;
                
                /* load CRC16 MSB */
                i2c_tx_buffer[6U] = (uint8_t)(CRC >> 8U);
                
                /* load counter for sending desired byte length via DMA */
                DMACNT3 = (uint8_t)(Length_VersionInformation_Resp - 1U);
                
            break;
            
            case Cmd_ProcessData:
            
                /* load first byte in Buffer with Command Code for CRC Calculation */
                i2c_tx_buffer[0U] = Cmd_ProcessData;
                
                
                
                /* U-IN-ADC */
                /* load LSB System Supply input voltage */
                i2c_tx_buffer[1U] = (uint8_t)buck_4ph.Data.Vin_phys;
                
                /* load MSB System Supply input voltage */
                i2c_tx_buffer[2U] = (uint8_t)(buck_4ph.Data.Vin_phys >> 8U);
                
                

                /* U-Protected-ADC */
                /* load LSB System Supply voltage after ideal diode */
                i2c_tx_buffer[3U] = (uint8_t)buck_4ph.Data.Vin_prot_phys;
                
                /* load MSB System Supply voltage after ideal diode */
                i2c_tx_buffer[4U] = (uint8_t)(buck_4ph.Data.Vin_prot_phys >> 8U);
                
                

                /* U-DCDC-ADC */
                /* load LSB System Supply voltage after inrush limiter */
                i2c_tx_buffer[5U] = (uint8_t)buck_4ph.Data.V_dcdc_phys;
                
                /* load MSB System Supply voltage after inrush limiter */
                i2c_tx_buffer[6U] = (uint8_t)(buck_4ph.Data.V_dcdc_phys >> 8U);
                
                
                
                /* U-Regel-ADC */
                /* load LSB Internal Supply after 800W buck converter */
                i2c_tx_buffer[7U] = (uint8_t)buck_4ph.Data.Vout_phys;
                
                /* load MSB Internal Supply after 800W buck converter */
                i2c_tx_buffer[8U] = (uint8_t)(buck_4ph.Data.Vout_phys >> 8U);
                
                

                /* U-Motor-ADC */
                /* load LSB Motor Supply voltage */
                i2c_tx_buffer[9U] = (uint8_t)buck_4ph.Data.V_motor_phys;
                
                /* load MSB Motor Supply voltage */
                i2c_tx_buffer[10U] = (uint8_t)(buck_4ph.Data.V_motor_phys >> 8U);
                
                

                /* U-24V-ADC */
                /* load LSB Internal Supply after 24V 200W buck/boost converter */
                i2c_tx_buffer[11U] = (uint8_t)buck_4ph.Data.V_24volt_phys;
                
                /* load MSB Internal Supply after 24V 200W buck/boost converter */
                i2c_tx_buffer[12U] = (uint8_t)(buck_4ph.Data.V_24volt_phys >> 8U);
                
                

                /* U-Aux-ADC */
                /* load LSB Auxiliary supply voltage */
                i2c_tx_buffer[13U] = (uint8_t)buck_4ph.Data.V_aux_phys;
                
                /* load MSB Auxiliary supply voltage */
                i2c_tx_buffer[14U] = (uint8_t)(buck_4ph.Data.V_aux_phys >> 8U);
                
                

                /* I-800W-PH1-ADC */
                /* load LSB Measured current through Phase 1 of 800W buck converter */
                i2c_tx_buffer[15U] = (uint8_t)buck_4ph.Data.Ibuck1_phys;
                
                /* load MSB Measured current through Phase 1 of 800W buck converter */
                i2c_tx_buffer[16U] = (uint8_t)(buck_4ph.Data.Ibuck1_phys >> 8U);
                
                

                /* I-800W-PH2-ADC */
                /* load LSB Measured current through Phase 2 of 800W buck converter */
                i2c_tx_buffer[17U] = (uint8_t)buck_4ph.Data.Ibuck2_phys;
                
                /* load MSB Measured current through Phase 2 of 800W buck converter */
                i2c_tx_buffer[18U] = (uint8_t)(buck_4ph.Data.Ibuck2_phys >> 8U);
                
                

                /* I-800W-PH3-ADC */
                /* load LSB Measured current through Phase 3 of 800W buck converter */
                i2c_tx_buffer[19U] = (uint8_t)buck_4ph.Data.Ibuck3_phys;
                
                /* load MSB Measured current through Phase 3 of 800W buck converter */
                i2c_tx_buffer[20U] = (uint8_t)(buck_4ph.Data.Ibuck3_phys >> 8U);
                
                

                /* I-800W-PH4-ADC */
                /* load LSB Measured current through Phase 4 of 800W buck converter */
                i2c_tx_buffer[21U] = (uint8_t)buck_4ph.Data.Ibuck4_phys;
                
                /* load MSB Measured current through Phase 4 of 800W buck converter */
                i2c_tx_buffer[22U] = (uint8_t)(buck_4ph.Data.Ibuck4_phys >> 8U);
                
                

                /* I-200W-ADC */
                /* load LSB Measured current through 200W buck/boost converter */
                i2c_tx_buffer[23U] = (uint8_t)buck_4ph.Data.I_200watt_phys;
                
                /* load MSB Measured current through 200W buck/boost converter */
                i2c_tx_buffer[24U] = (uint8_t)(buck_4ph.Data.I_200watt_phys >> 8U);
                
                
//TODO: Dummy ersetzen!!!                
                /* InternalSignals */
                /* load LSB Binary control/feedback Signals bitwise encoded */
                i2c_tx_buffer[25U] = (uint8_t)process_dummy_32;
                
                /* load Binary control/feedback Signals bitwise encoded */
                i2c_tx_buffer[26U] = (uint8_t)(process_dummy_32 >> 8U);
                
                /* load Binary control/feedback Signals bitwise encoded */
                i2c_tx_buffer[27U] = (uint8_t)(process_dummy_32 >> 16U);
                
                /* load MSB Binary control/feedback Signals bitwise encoded */
                i2c_tx_buffer[28U] = (uint8_t)(process_dummy_32 >> 24U);
                
                
//TODO: Dummy ersetzen!!!  
                /* Faults */
                /* load LSB Internal Faults/Diagnostic signals bitwise encoded */
                i2c_tx_buffer[29U] = (uint8_t)process_dummy_32;
                
                /* load Internal Faults/Diagnostic signals bitwise encoded */
                i2c_tx_buffer[30U] = (uint8_t)(process_dummy_32 >> 8U);
                
                /* load Internal Faults/Diagnostic signals bitwise encoded */
                i2c_tx_buffer[31U] = (uint8_t)(process_dummy_32 >> 16U);
                
                /* load MSB Internal Faults/Diagnostic signals bitwise encoded */
                i2c_tx_buffer[32U] = (uint8_t)(process_dummy_32 >> 24U);
                
                
//TODO: Dummy ersetzen!!!  
                /* RefreshTick */
                /* load LSB Last refresh millisecond timestamp/tick of internal dsPIC clock */
                i2c_tx_buffer[33U] = (uint8_t)process_dummy_32;
                
                /* load Last refresh millisecond timestamp/tick of internal dsPIC clock */
                i2c_tx_buffer[34U] = (uint8_t)(process_dummy_32 >> 8U);
                
                /* load Last refresh millisecond timestamp/tick of internal dsPIC clock */
                i2c_tx_buffer[35U] = (uint8_t)(process_dummy_32 >> 16U);
                
                /* load MSB Last refresh millisecond timestamp/tick of internal dsPIC clock */
                i2c_tx_buffer[36U] = (uint8_t)(process_dummy_32 >> 24U);
                
                
                
                /* do CRC16 calculation */
                CRC = crc16(i2c_tx_buffer, (Length_ProcessData_Resp - 1U));
                
                /* load CRC16 LSB */
                i2c_tx_buffer[37U] = (uint8_t)CRC;
                
                /* load CRC16 MSB */
                i2c_tx_buffer[38U] = (uint8_t)(CRC >> 8U);
                
                /* load counter for sending desired byte length via DMA */
                DMACNT3 = (uint8_t)(Length_ProcessData_Resp - 1U);
                
            break;
            
            case Cmd_ComparatorVoltage:
            
                /* load first byte in Buffer with Command Code for CRC Calculation */
                i2c_tx_buffer[0U] = Cmd_ComparatorVoltage;
                            
                /* U-COMP-PWM-DAC */
                /* load LSB Comparator reference voltage */
                i2c_tx_buffer[1U] = (uint8_t)CompVoltage;
                
                /* load MSB Comparator reference voltagee */
                i2c_tx_buffer[2U] = (uint8_t)(CompVoltage >> 8U);
                
                
                /* do CRC16 calculation */
                CRC = crc16(i2c_tx_buffer, (Length_CompVoltage_Req - 1U));
                
                /* load CRC16 LSB */
                i2c_tx_buffer[3U] = (uint8_t)CRC;
                
                /* load CRC16 MSB */
                i2c_tx_buffer[4U] = (uint8_t)(CRC >> 8U);
                
                /* load counter for sending desired byte length via DMA */
                DMACNT3 = (uint8_t)(Length_CompVoltage_Req - 1U);
                
            break;
            
            default:
                
                /* wrong call */
                
            break;
        }
        

        /* reload DMA TX-Buffer address */
        DMASRC3 = (uint16_t)&i2c_tx_buffer[2U];
        
        /* send first data Byte manual */
        I2C1TRN = i2c_tx_buffer[1U];
        
        /* enable DMA3 */
        DMACH3bits.CHEN = 1;
	}
    else
    {
        /* do nothing */
    }
    
    /* I2C1 Clock stretch release */
    I2C1CONLbits.SCLREL = 1;
        
    /* clear I2C1 interrupt flag */
    IFS1bits.SI2C1IF = 0;
}
    


#define INITIAL_VALUE 0x5635
#define FINAL_XOR_VALUE 0x0000

// CRC Lookup-Tabelle
static const uint16_t crc16_table[256] = {
    0x0000, 0xAC9A, 0xF5AE, 0x5934, 0x47C6, 0xEB5C, 0xB268, 0x1EF2,
    0x8F8C, 0x2316, 0x7A22, 0xD6B8, 0xC84A, 0x64D0, 0x3DE4, 0x917E,
    0xB382, 0x1F18, 0x462C, 0xEAB6, 0xF444, 0x58DE, 0x01EA, 0xAD70,
    0x3C0E, 0x9094, 0xC9A0, 0x653A, 0x7BC8, 0xD752, 0x8E66, 0x22FC,
    0xCB9E, 0x6704, 0x3E30, 0x92AA, 0x8C58, 0x20C2, 0x79F6, 0xD56C,
    0x4412, 0xE888, 0xB1BC, 0x1D26, 0x03D4, 0xAF4E, 0xF67A, 0x5AE0,
    0x781C, 0xD486, 0x8DB2, 0x2128, 0x3FDA, 0x9340, 0xCA74, 0x66EE,
    0xF790, 0x5B0A, 0x023E, 0xAEA4, 0xB056, 0x1CCC, 0x45F8, 0xE962,
    0x3BA6, 0x973C, 0xCE08, 0x6292, 0x7C60, 0xD0FA, 0x89CE, 0x2554,
    0xB42A, 0x18B0, 0x4184, 0xED1E, 0xF3EC, 0x5F76, 0x0642, 0xAAD8,
    0x8824, 0x24BE, 0x7D8A, 0xD110, 0xCFE2, 0x6378, 0x3A4C, 0x96D6,
    0x07A8, 0xAB32, 0xF206, 0x5E9C, 0x406E, 0xECF4, 0xB5C0, 0x195A,
    0xF038, 0x5CA2, 0x0596, 0xA90C, 0xB7FE, 0x1B64, 0x4250, 0xEECA,
    0x7FB4, 0xD32E, 0x8A1A, 0x2680, 0x3872, 0x94E8, 0xCDDC, 0x6146,
    0x43BA, 0xEF20, 0xB614, 0x1A8E, 0x047C, 0xA8E6, 0xF1D2, 0x5D48,
    0xCC36, 0x60AC, 0x3998, 0x9502, 0x8BF0, 0x276A, 0x7E5E, 0xD2C4,
    0x774C, 0xDBD6, 0x82E2, 0x2E78, 0x308A, 0x9C10, 0xC524, 0x69BE,
    0xF8C0, 0x545A, 0x0D6E, 0xA1F4, 0xBF06, 0x139C, 0x4AA8, 0xE632,
    0xC4CE, 0x6854, 0x3160, 0x9DFA, 0x8308, 0x2F92, 0x76A6, 0xDA3C,
    0x4B42, 0xE7D8, 0xBEEC, 0x1276, 0x0C84, 0xA01E, 0xF92A, 0x55B0,
    0xBCD2, 0x1048, 0x497C, 0xE5E6, 0xFB14, 0x578E, 0x0EBA, 0xA220,
    0x335E, 0x9FC4, 0xC6F0, 0x6A6A, 0x7498, 0xD802, 0x8136, 0x2DAC,
    0x0F50, 0xA3CA, 0xFAFE, 0x5664, 0x4896, 0xE40C, 0xBD38, 0x11A2,
    0x80DC, 0x2C46, 0x7572, 0xD9E8, 0xC71A, 0x6B80, 0x32B4, 0x9E2E,
    0x4CEA, 0xE070, 0xB944, 0x15DE, 0x0B2C, 0xA7B6, 0xFE82, 0x5218,
    0xC366, 0x6FFC, 0x36C8, 0x9A52, 0x84A0, 0x283A, 0x710E, 0xDD94,
    0xFF68, 0x53F2, 0x0AC6, 0xA65C, 0xB8AE, 0x1434, 0x4D00, 0xE19A,
    0x70E4, 0xDC7E, 0x854A, 0x29D0, 0x3722, 0x9BB8, 0xC28C, 0x6E16,
    0x8774, 0x2BEE, 0x72DA, 0xDE40, 0xC0B2, 0x6C28, 0x351C, 0x9986,
    0x08F8, 0xA462, 0xFD56, 0x51CC, 0x4F3E, 0xE3A4, 0xBA90, 0x160A,
    0x34F6, 0x986C, 0xC158, 0x6DC2, 0x7330, 0xDFAA, 0x869E, 0x2A04,
    0xBB7A, 0x17E0, 0x4ED4, 0xE24E, 0xFCBC, 0x5026, 0x0912, 0xA588
};

uint16_t crc16(const uint8_t *data, uint8_t length) 
{
    uint16_t crc = 0x5635; // Initialisierungswert

    for (uint8_t i = 0; i < length; i++) 
    {
        uint8_t table_index = (crc >> 8) ^ data[i];
        crc = (crc << 8) ^ crc16_table[table_index];
    }

    return crc ^ 0x0000; // Kein XOR am Ende
}
// ___________________
// end of file
