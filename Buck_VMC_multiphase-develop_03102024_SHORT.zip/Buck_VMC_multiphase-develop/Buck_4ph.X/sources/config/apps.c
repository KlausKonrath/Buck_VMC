/**
 * @file    apps.c
 * @brief   Application tasks configuration 
 * @author  M91406
 * @date    06/10/2021
 * @version 1.0.3
 */

#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
#include <stddef.h> // include standard definition data types

#include "config/apps.h" // include common application task abstraction layer header file
#include "os/IAppTask.h" // include application task interface object declarations

/****************************************************************************************************
 * @ingroup application-layer-user-tasks-configuration
 * @var     IApplicationTask_t appLed
 * @brief   LED User Task declaration and configuration
 *****************************************************************************************************/
volatile IApplicationTask_t appLed = 
{
    .Functions.Initialize       = &appLED_Initialize,       ///< Pointer to user task INITIALIZATION function
    .Functions.Start            = &appLED_Start,            ///< Pointer to user task INITIALIZATION function
    .Functions.Execute          = &appLED_Execute,          ///< Pointer to user task INITIALIZATION function
    .Functions.Stop             = NULL,                     ///< (no function available)
    .Functions.Dispose          = &appLED_Dispose,          ///< Pointer to user task INITIALIZATION function
    
    .Events.Exception           = NULL,                     ///< Pointer to proprietary exception event handler function
    .Properties.PriorityClass   = APP_CLASS_LOW_PRIORITY,   ///< Application task lass (high- or low-priority)
    .Properties.TimeBase.Period = 1000,                     ///< Task execution period in OS task manager call ticks
    .Properties.TimeBase.Offset = 0,                        ///< Task execution offset in OS task manager call ticks
    
    .Status.Enabled             = true                      ///< Enable this task right after startup
};

/****************************************************************************************************
 * @ingroup application-layer-user-tasks-configuration
 * @var     IApplicationTask_t appPowerSupply
 * @brief   Task configuration of the Power Supply User Task
 *****************************************************************************************************/
volatile IApplicationTask_t appPowerSupply = 
{
    .Functions.Initialize       = &appPowerSupply_Initialize, ///< Pointer to user task INITIALIZATION function
    .Functions.Start            = &appPowerSupply_Start,    ///< Pointer to user task START function
    .Functions.Execute          = &appPowerSupply_Execute,  ///< Pointer to user task EXECUTE function
    .Functions.Stop             = NULL,                     ///< (no function available)
    .Functions.Dispose          = &appPowerSupply_Stop,     ///< Pointer to user task DISPOSE/STOP function

    .Events.Exception           = NULL,                     ///< Pointer to proprietary exception event handler function
    .Properties.PriorityClass   = APP_CLASS_HIGH_PRIORITY,  ///< Application task lass (high- or low-priority)
    .Properties.TimeBase.Period = 0,                        ///< Task execution period in (n-1) OS task manager call ticks 
    .Properties.TimeBase.Offset = 0,                        ///< Task execution offset in (n-1) OS task manager call ticks
    
    .Status.Enabled             = true                      ///< Enable this task right after startup
};

/****************************************************************************************************
 * @ingroup application-layer-user-tasks-configuration
 * @var     IApplicationTask_t appFaultMonitor
 * @brief   Task configuration of the Power Supply User Task
 *****************************************************************************************************/
volatile IApplicationTask_t appFaultMonitor = 
{
    .Functions.Initialize       = &appFaultMonitor_Initialize, ///< Pointer to user task INITIALIZATION function
    .Functions.Start            = &appFaultMonitor_Start,   ///< Pointer to user task START function
    .Functions.Execute          = &appFaultMonitor_Execute, ///< Pointer to user task EXECUTE function
    .Functions.Stop             = NULL,                     ///< (no function available)
    .Functions.Dispose          = &appFaultMonitor_Dispose, ///< Pointer to user task DISPOSE function

    .Events.Exception           = NULL,                     ///< Pointer to proprietary exception event handler function
    .Properties.PriorityClass   = APP_CLASS_HIGH_PRIORITY,  ///< Application task lass (high- or low-priority)
    .Properties.TimeBase.Period = 0,                        ///< Task execution period in (n-1) OS task manager call ticks 
    .Properties.TimeBase.Offset = 0,                        ///< Task execution offset in (n-1) OS task manager call ticks

    .Status.Enabled             = true                      ///< Enable this task right after startup
};

/****************************************************************************************************
 * @ingroup application-layer-user-tasks-configuration
 * @var     IApplicationTask_t appComm
 * @brief   LED User Task declaration and configuration
 *****************************************************************************************************/
volatile IApplicationTask_t appComm = 
{
    .Functions.Initialize       = &appComm_Initialize,      ///< Pointer to user task INITIALIZATION function
    .Functions.Start            = &appComm_Start,           ///< Pointer to user task START function
    .Functions.Execute          = &appComm_Execute,         ///< Pointer to user task EXECUTE function
    .Functions.Stop             = NULL,                     ///< (no function available)
    .Functions.Dispose          = NULL,                     ///< (no function available)
    
    .Events.Exception           = NULL,                     ///< Pointer to proprietary exception event handler function
    
    .Properties.PriorityClass   = APP_CLASS_LOW_PRIORITY,   ///< Application task lass (high- or low-priority)
    .Properties.TimeBase.Period = 100,                      ///< Task execution period in OS task manager call ticks (100 OS Ticks = 10ms)
    .Properties.TimeBase.Offset = 50,                       ///< Task execution offset in OS task manager call ticks
    
    // On , the UART output pins are shared with the ICSP programming port
    // Hence, UART communication is only available when no programmer/debugger is active
    #if __DEBUG
    .Status.Enabled             = true                     ///< Disable this task if firmware is in debug mode
    #else
    .Status.Enabled             = true                      ///< Enable this task right after startup
    #endif
};
/**********************************************************************************/
/* APPLICATION TASK EXECUTION CONFIGURATION                                       */
/**********************************************************************************/


/***********************************************************************************
 * @ingroup application-layer-user-tasks-configuration
 * @var     IApplicationTask_t* AppTaskQueue[]
 * @brief   Function pointer array listing all user-tasks of this application
 * @details
 *  The task list is an array capturing all static tasks of the application. 
 * Each task is an independent, functional entity serving a specific purpose,
 * and is performing a specific function respectively. The order in which tasks
 * are added to this list does not reflect their importance/priority and only
 * serves the purpose of exposing them to the operating system, which will then
 * group and execute them in priority queues.
 * 
 * The specific settings of each task can be configured in their respective
 * settings data structure, where execution period, execution offset and 
 * priority can be defined.
 * 
 **********************************************************************************/

volatile IApplicationTask_t* AppTaskQueue[] =
{
    &appLed,          ///< Application Task #0: LED Task
    &appPowerSupply,  ///< Application Task #1: Power Supply Control Task
    &appFaultMonitor,  ///< Application Task #2: Fault Monitor Task
    &appComm            ///< Application Task #3: UART Communication task
};
volatile uint16_t AppTaskQueue_Size = (sizeof(AppTaskQueue)/sizeof(AppTaskQueue[0])); 

// __________________________
// end of file
