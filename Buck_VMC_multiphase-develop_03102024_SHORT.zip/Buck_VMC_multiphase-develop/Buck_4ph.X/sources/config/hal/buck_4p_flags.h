/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/**
 * @file    buck_4p_flags.h
 * @author  M91406
 * @brief   Macro flags 
 * @version 1.0
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef BUCK_4PH_CONFIGURATION_FLAGS_H
#define	BUCK_4PH_CONFIGURATION_FLAGS_H

/*********************************************************************************
 * @ingroup special-options
 * @def     DIRCTRL_SOFT_SWAP
 * @def     DIRCTRL_HOT_SWAP
 * @see     DEFAULT_DIRCTRL_MODE
 * @brief   Supported converter default conversion direction swapping mode
 ***********************************************************************************/
#define DEFAULT_SOFT_SWAP       0U  ///< Converter swaps conversion mode by going through a supply reset
#define DIRCTRL_HOT_SWAP        1U  ///< Converter swaps conversion mode on-the-fly

/*********************************************************************************
 * @ingroup special-options
 * @def     DEFAULT_OPMODE_BUCK
 * @def     DEFAULT_OPMODE_BOOST
 * @def     DEFAULT_OPMODE_AUTO
 * @see     DEFAULT_OPERATING_MODE
 * @brief   Supported converter default startup operating modes
 ***********************************************************************************/
#define DEFAULT_OPMODE_BUCK     0U  ///< Converter starts in step-down mode (buck) by default
#define DEFAULT_OPMODE_BOOST    1U  ///< Converter starts in step-up mode (boost) by default
//#define DEFAULT_OPMODE_AUTO     2U   // Converter automatically detects which mode to use at startup     // ToDo: implement auto-startup mode selection


/*********************************************************************************
 * @ingroup special-options
 * @def     TRIGGER_MODE_NONE
 * @def     TRIGGER_MODE_PWM
 * @def     TRIGGER_MODE_ADC
 * @brief   Control interrupt trigger selection flags
 ***********************************************************************************/
#define TRIGGER_MODE_NONE       0U  ///< Control loop is not called
#define TRIGGER_MODE_PWM        1U  ///< Control loop is called in PWM interrupt
#define TRIGGER_MODE_ADC        2U  ///< Control loop is called in ADC interrupt
#define TRIGGER_MODE_TIMER      3U  ///< Control loop is called in Timer interrupt

#endif	/* ADP1051_240_EVALZ_CONFIGURATION_FLAGS_H */

// ________________________
// end if file
