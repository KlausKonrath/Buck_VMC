
#ifdef __NO_PIL__
    #ifdef __WITH_PIL__
    #error "conflicting compile options detected. Please select __NO_PIL__ when running the software on a real hardware or __WITH_PIL__ when running the project in a guidided PLECS simulation."
    #endif
#endif

#ifdef __WITH_PIL__

#include "pil_main.h"
#include "pil/uart1.h"
#include "apps/fault_handler/drivers/IFaultHandler.h"
#include "apps/fault_handler/app_fault_monitor.h"
#include "apps/power_control/app_power_control.h" //"devices/dev_psfb_converter.h"

// Common PIL data objects
PilProbes_t PilProbes;
PIL_Handle_t PilHandle;
PIL_Obj_t PilObj;

// Private variables used in this source file
static float t1_int=0; // timer interval counter required by tate PIL_CLBK_START_TIMERS

/*********************************************************************************
 * @brief   PIL UART Communication 
 * @details
 *  This function performs the UART operations through which data is exchanged
 *  with the PLECS simulation. It is called by function PilCallback(). 
 **********************************************************************************/
void PollUart(PIL_Handle_t aHandle)
{    
    while(!U1STAHbits.URXBE)                    
    {
        // while data is available in receive buffer
        PIL_RA_serialIn(aHandle, U1RXREG);
        //U1TXREG = U1RXREG;
    }
    if(!U1STAHbits.UTXBF)
    {
        // transmit buffer empty
        int16_t ch;
        if(PIL_RA_serialOut(aHandle, &ch))
        { U1TXREG = ch; }
    }
    
    TP23.Methods.Clear();
    
    if(U1STAbits.OERR)
    {
        TP23.Methods.Set();
        U1STAbits.OERR = 0;    // clear RX buffer overrun error
    }
}

/*********************************************************************************
 * @brief   PIL Implementation State Machine
 * @details
 *  This function is the state machine managing exchange of input and output
 *  data with the PLECS simulation. It is called by function PIL_BEGIN_INT_CALL().
 **********************************************************************************/
void PilCallback(PIL_Handle_t aPilHandle, PIL_CtrlCallbackReq_t aCallbackReq)
{
	switch(aCallbackReq)
	{
		//1
        case  PIL_CLBK_ENTER_NORMAL_OPERATION_REQ:
			// enabling the hardware actuation (if desired by user)

			PIL_inhibitPilSimulation(aPilHandle);
            // enable actuation
			return;

		//2
        case PIL_CLBK_LEAVE_NORMAL_OPERATION_REQ:
			// stopping the hardware actuation or invoking a transfer to a safe system state
			// disable actuation

            PIL_allowPilSimulation(aPilHandle);
            
			return;
        //3
		case PIL_CLBK_INITIALIZE_SIMULATION:

            appPowerSupply_Start();
            Nop();
            return;
        //4
        case PIL_CLBK_PREINIT_SIMULATION:

            return;
        //5    
		case PIL_CLBK_TERMINATE_SIMULATION:
            //Termination Request
			PilInitCalibrations();
            
            // Re Enable operating system execution after the simulation is stopped
            T1CONbits.TON = 1;
		    break;
        //6
		case PIL_CLBK_STOP_TIMERS:
        {
            T1CONbits.TON = 0;
            TMR1=0;
            PG1CONLbits.ON = 0;   // Disabling the PWM timer
            
            return;
        }
        //7 During PLECS simulation 7 -> 6 states are called at every PIL_BEGIN_INT_CALL() REMEMBER to set the sample time into the PIL block properties in PLECS
        case PIL_CLBK_START_TIMERS:
        {
            // start relevant timers
            PG1CONLbits.ON = 1;   // Enabling the PWM timer. It needs to be enabled before turning on T1 to avoid calling the converter state machine with PWM disabled
            t1_int+=(1.0/SWITCHING_FREQUENCY);
            if(t1_int>=RTOS_6G2_EXECUTION_PERIOD)
            {
                t1_int-=RTOS_6G2_EXECUTION_PERIOD;
                TMR1=PR1-1;
                T1CONbits.TON = 1;
            }
        }
   }
}

/*********************************************************************************
 * @brief   Initializes the Processor-In-Loop Background Service
 * @details
 *  This function initializes the required PIL data objects and related 
 *  callback functions to allow the MCU to send and receive input and output
 *  data with the PLECS simulation.
 **********************************************************************************/
void PilInitialize(void)
{
    // Initialize PIL framework
    PilHandle = PIL_init(&PilObj, sizeof(PilObj));
    PIL_setGuid(PilHandle, PIL_GUID_PTR);
    PIL_setCtrlCallback(PilHandle, (PIL_CtrlCallbackPtr_t)PilCallback);
    PIL_setSerialComCallback(PilHandle, (PIL_CommCallbackPtr_t)PollUart);
    
    #ifdef SCOPE_BUF_SIZE
        PIL_setAndConfigScopeBuffer(PilHandle, (uint16_t *)&ScopeBuffer, SCOPE_BUF_SIZE, SCOPE_MAX_TRACE_WIDTH_IN_WORDS);
    #endif
    
    PIL_requestReadyMode(PilHandle);

    // TODO verify how to manage current fault using PCI when running PIL
    fltobj_Buck_OCP.Status.bits.Enabled=false; 
}

#endif // __WITH_PIL__

// ________________________
// end of file
