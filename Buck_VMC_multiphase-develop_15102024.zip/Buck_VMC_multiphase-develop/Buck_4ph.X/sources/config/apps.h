/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * @file   apps.h
 * @author M91406
 * @brief global defines of this application
 * Revision history: 
 * v1.0 initial version
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef APPLICATION_GLOBALS_HEADER_H
#define	APPLICATION_GLOBALS_HEADER_H

#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
#include <stddef.h> // include standard definition data types

/*********************************************************************************
 * @ingroup application-tasks
 * @{
 * @brief   Registers all main tasks of the application by including their main header files
 * @details
 *  The following list of includes is required to register individual tasks 
 *  to become visible for the task manager of the operating system. Once the
 *  main header file of a task has been included, respective API functions 
 *  can be added to the appropriate task execution lists in file 'apps.c'
 **********************************************************************************/
#include "apps/power_control/app_power_control.h"
#include "apps/fault_handler/app_fault_monitor.h"
#include "apps/led/app_led.h"
#include "apps/comm/app_comm.h"

/** @} */ // end of group application-tasks

/*********************************************************************************
 * @ingroup application-version-macro
 * @def     FIRMWARE_VERSION
 * @brief   3x 8-bit wide, Integer encoded firmware version number
 * @details
 *  This macro returns the most recent firmware version as integer encoded 
 *  value of format 
 * 
 *      [MAJOR][MINOR][REVISION]
 * 
 *  with 
 *    - MAJOR
 *    - MINOR
 *    - PATCH
 *  
 *  Version 1.2.23 will be encoded as 01.02.23
 *  The largest firmware version number supported is 99.99.99.
 * 
 *  Firmware modules can use this integer encoded firmware version to conditional
 *  select code sections depending on the availability of firmware version-specific
 *  features or limitations.
 **********************************************************************************/
#define FIRMWARE_VERSION_MAJOR (uint8_t) 0x01
#define FIRMWARE_VERSION_MINOR (uint8_t) 0x01
#define FIRMWARE_VERSION_PATCH (uint8_t) 0x00


#define HW_VARIANT_2_PHASE      (uint8_t) 0x00
#define HW_VARIANT_4_PHASE      (uint8_t) 0x01

#define HARDWARE_VARIANT       HW_VARIANT_4_PHASE




#endif	/* APPLICATION_GLOBALS_HEADER_H */

