/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * @file   dppic33c_mcal.h
 * @author M91406
 * @brief  DPSK3 Hardware Descriptor header file
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef DSPIC33C_MCU_ABSTRACTION_DESCRIPTOR_H
#define	DSPIC33C_MCU_ABSTRACTION_DESCRIPTOR_H

#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
#include <stddef.h> // include standard definition data types
#include <math.h> // include standard math functions library

/**************************************************************************************************
 * @ingroup device-abstraction-settings
 * @{
 * @brief Fundamental microcontroller device settings
 * 
 * @details
 * This section is used to define device specific parameters like ADC reference and
 * resolution, main execution clock frequency and peripheral time base settings. 
 * All parameters are defined using physical quantities. 
 * 
 **************************************************************************************************/
#define EXTOSC_FREQUENCY        (float)8000000.0    ///< External Oscillator frequency in [Hz]
#define FRCC_FREQUENCY          (float)8000000.0    ///< Internal FRC Oscillator frequency in [Hz]
#define USE_EXTERNAL_CLOCK      false               ///< flag to be set by user if an external crystal whould be used

#define CPU_FREQUENCY           (float)100000000.0  ///< CPU frequency in [Hz]
#define AUX_FREQUENCY           (float)500000000.0  ///< Auxiliary PLL frequency in [Hz]

/*********************************************************************************
 * @ingroup device-abstraction-settings
 * @def     FOSC_FREQUENCY
 * @brief   Macro selecting the main clock frequency value based on user selection of oscillator type
 * @details
 *  This macro selects the main clock frequency value based on user selection 
 *  of the oscillator type. 
 **********************************************************************************/
#if (USE_EXTERNAL_CLOCK == true)
  #define FOSC_FREQUENCY        EXTOSC_FREQUENCY    ///< Main Oscillator frequency in [Hz]
#else
  #define FOSC_FREQUENCY        FRCC_FREQUENCY      ///< Main Oscillator frequency in [Hz]
#endif 

// ADC Reference and Resolution Settings    
#define ADC_REFERENCE           (float)3.300 ///< ADC reference voltage in [V]
#define ADC_RESOLUTION          (float)12.00 ///< ADC resolution in [bit]

// ADC Reference and Resolution Settings    
#define DAC_REFERENCE           (float)3.300 ///< DAC reference voltage in [V] (usually AVDD)
#define DAC_RESOLUTION          (float)12.00 ///< DAC resolution in [bit] DA02 taken from data sheet

#define DAC_MINIMUM             (float)0.165 ///< DAC minimum output voltage in [V]
#define DAC_MAXIMUM             (float)3.135 ///< DAC maximum output voltage in [V]
#define DAC_TRANSITION_TIME     (float)340.0e-9 ///< PDM DAC ramp generator transition time setting DA09 from data sheet in [s]
#define DAC_STEADY_STATE_TIME   (float)550.0e-9 ///< PDM DAC ramp generator steady-stte time setting DA10 from data sheet in [s]
#define DAC_LEADING_EDGE_PERIOD (float)120.0e-9 ///< DACx Leading-Edge Blanking in [s]

// PWM/ADC Clock Settings   
#define PWM_CLOCK_HIGH_RESOLUTION   true ///< Enables/disables the PWM generator high resolution mode of 250 ps versus 2 ns

#if (PWM_CLOCK_HIGH_RESOLUTION)
#define PWM_CLOCK_FREQUENCY     (float)4.0e+9 ///< PWM Clock Frequency in [Hz]
#else
#define PWM_CLOCK_FREQUENCY     (float)500.0e+6 ///< PWM Clock Frequency in [Hz]
#endif

#define AUX_PLL_CLOCK           (float)(1.0 / AUX_FREQUENCY)

/** @} */ // end of group device-abstraction-settings

/**
 * @ingroup device-abstraction-macros
 * @{
 * @brief Conversion macros of fundamental microcontroller device settings
 * 
 * @details
 * This section is used to convert device specific parameters like ADC reference and
 * resolution, main execution clock frequency and peripheral time base settings, declared 
 * in physical quantities, into binary (integer) numbers to be written to variables and SFRs.
 */

#define CPU_TCY             (float)(1.0 / CPU_FREQUENCY) ///< Instruction period
#define ADC_VALUE_MAX       (uint16_t)((0x0001 << (uint16_t)ADC_RESOLUTION) - 1.0) // DO NOT CHANGE
#define DAC_VALUE_MAX       (uint16_t)((0x0001 << (uint16_t)ADC_RESOLUTION) - 1.0) // DO NOT CHANGE
#define ADC_GRANULARITY     (float)(ADC_REFERENCE / (float)(ADC_VALUE_MAX + 1)) ///< ADC granularity in [V/tick]
#define DAC_GRANULARITY     (float)(DAC_REFERENCE / (float)(DAC_VALUE_MAX + 1)) ///< DAC granularity in [V/tick]
#define PWM_CLOCK_PERIOD    (float)(1.0 / PWM_CLOCK_FREQUENCY) ///< PWM Clock Period in [sec]
#define DAC_CLOCK_PERIOD    (float)(2.0 / AUX_FREQUENCY) ///< DAC Clock Period in [sec]

#define DAC_MIN             (uint16_t)(DAC_MINIMUM / DAC_GRANULARITY) ///< Integer value of minimum DAC reference  
#define DAC_MAX             (uint16_t)(DAC_MAXIMUM / DAC_GRANULARITY) ///< Integer value of maximum DAC reference 
#define DAC_TMODTIME        (uint16_t)((DAC_TRANSITION_TIME / AUX_PLL_CLOCK) / 2.0) ///< Integer value of transition time period based on most recent auxiliary clock settings
#define DAC_SSTIME          (uint16_t)((DAC_STEADY_STATE_TIME / AUX_PLL_CLOCK) / 2.0) ///< Integer value of Steady-State time period based on most recent auxiliary clock settings
#define DAC_TMCB            (uint16_t)((DAC_LEADING_EDGE_PERIOD / AUX_PLL_CLOCK) / 2.0) ///< Integer value of Steady-State time period based on most recent auxiliary clock settings

/** @} */ // end of group device-abstraction-macros

#endif // end of DSPIC33C_MCU_ABSTRACTION_DESCRIPTOR_H
