/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/**
 * @file    os.h
 * @brief   RTOS configuration API header file
 * @author  M91406
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef OPERATING_SYSTEM_API_HEADER_H
#define	OPERATING_SYSTEM_API_HEADER_H

#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
#include <stddef.h> // include standard definition data types

// OPERATING SYSTEM HEADER FILES
#include "./mcal/dspic33c_mcal.h" // include dsPIC33C microcontroller abstraction layer header file
#include "os/IRtos6G2.h" // include RTOS 6G2 header file

/**************************************************************************************************
 * @ingroup rtos-settings
 * @def     RTOS_6G2_EXECUTION_PERIOD
 * @brief   Main RTOS execution step period
 **************************************************************************************************/
#define RTOS_6G2_EXECUTION_PERIOD   (float)100.0e-6 ///< Main State Machine function call period in [sec]

/**************************************************************************************************
 * @ingroup rtos-settings
 * @def     RTOS_6G2_EXEC_PER_TIMEOUT
 * @brief   Timeout detection threshold of unresponsive high-priority queue 
 **************************************************************************************************/
#define RTOS_6G2_EXEC_PER_TIMEOUT   65000   ///< Timeout detection threshold of OS-Timer interrupt timeout event

/**************************************************************************************************
 * @ingroup rtos-settings
 * @def     RTOS_6G2_EXEC_LPQ_TIMEOUT
 * @brief   Timeout detection threshold of unresponsive low-priority queue 
 **************************************************************************************************/
#define RTOS_6G2_EXEC_LPQ_TIMEOUT   65000   ///< Timeout detection threshold of low-priority queue timeout event

// RTOS execution options

/*********************************************************************************
 * @ingroup rtos-settings
 * @def     RTOS_6G2_QUEUE_EXCEPTION_ENABLE
 * @brief   Enables/disables task queue exception events
 * @details
 *  When RTOS_6G2_QUEUE_EXCEPTION_ENABLE is TRUE, task queue exception events 
 *  will be invoked when task queue execution time quota violations by the 
 *  operating system.
 * 
 *  When RTOS_6G2_QUEUE_EXCEPTION_ENABLE is FALSE, no task exceptions will be 
 *  invoked and no task queue time quota violations will be indicated or 
 *  handled. 
**********************************************************************************/
#ifdef __WITH_PIL__
#define RTOS_6G2_QUEUE_EXCEPTION_ENABLE false
#else
#define RTOS_6G2_QUEUE_EXCEPTION_ENABLE true
#endif

/*********************************************************************************
 * @ingroup rtos-settings
 * @def     RTOS_6G2_CAPTURE_STATISTICS
 * @brief   Enables/disables task execution time statistics tracking
 * @details
 *  When RTOS_6G2_CAPTURE_STATISTICS is TRUE, task execution time is measured 
 *  across the task top-level function call. Task execution time execution 
 *  includes:
 * 
 *  - Last execution time measured in CPU cycles (auto update)
 *  - Maximum execution time measured in CPU cycles (cleared in software)
 *  - Average execution time measured in CPU cycles (auto update)
 * 
 *  When RTOS_6G2_CAPTURE_STATISTICS is FALSE, the task execution time neither
 *  monitored nor any statistics are captured. 
 * 
 * @note
 *  The results of the task execution time statistics are captured by the operating 
 *  system but no automated actions are taken despite the values of the result. 
 *  If task stalling protection is required, an independent fault handler must be 
 *  integrated in user software.
**********************************************************************************/
#define RTOS_6G2_CAPTURE_STATISTICS false

/*********************************************************************************
 * @ingroup rtos-settings
 * @def     RTOS_6G2_CAPTURE_CPU_LOAD
 * @brief   Enables/disables CPU load tracking
 * @details
 *  When RTOS_6G2_CAPTURE_CPU_LOAD is TRUE, CPU load is measured on lowest CPU 
 *  priority level by counting free CPU cycles between task queue execution 
 *  intervals. The result is stored in the CPU load data field of the task manager 
 *  data structure as fractional number between 0 and 1 reflecting the CPU load
 *  as value between 0% and 100%.
 * 
 *  When RTOS_6G2_CAPTURE_CPU_LOAD is FALSE, the CPU load calculation is bypassed.
 * 
 * @note
 *  The result of the CPU load measurement is only captured by the operating 
 *  system but no actions are taken despite the determined load level. 
 *  If CPU overload protection is required, an independent fault handler must be 
 *  integrated in user software.
 **********************************************************************************/
#define RTOS_6G2_CAPTURE_CPU_LOAD   false   

/*********************************************************************************
 * @ingroup rtos-settings
 * @def     RTOS_6G2_CAPTURE_PROFILE
 * @brief   Enables/disables task execution time statistics tracking
 * @details
 *  When RTOS_6G2_CAPTURE_STATISTICS is TRUE, task execution time is measured 
 *  across the task top-level function call. Task execution time execution 
 *  includes:
 * 
 *  - Last execution time measured in CPU cycles (auto update)
 *  - Maximum execution time measured in CPU cycles (cleared in software)
 *  - Average execution time measured in CPU cycles (auto update)
 * 
 *  When RTOS_6G2_CAPTURE_STATISTICS is FALSE, the task execution time neither
 *  monitored nor any statistics are captured. 
 * 
 * @note
 *  The results of the task execution time statistics are captured by the operating 
 *  system but no automated actions are taken despite the values of the result. 
 *  If task stalling protection is required, an independent fault handler must be 
 *  integrated in user software.
**********************************************************************************/
#define RTOS_6G2_CAPTURE_PROFILE    false

// ================================================================================
// PLEASE NOTE: 
// Runtime task profiling data logging array is only available in debugging mode
#if (RTOS_6G2_CAPTURE_PROFILE == true)
#if __DEBUG
#define TASK_PROFILE_ARR_SIZE   255
extern uint16_t ptrTaskProfileArray;
extern uint16_t arrTaskProfile[TASK_PROFILE_ARR_SIZE];
extern uint32_t arrTaskTime[TASK_PROFILE_ARR_SIZE];
extern uint16_t arrCpuLoad[TASK_PROFILE_ARR_SIZE];
#endif
#endif
// ================================================================================


/**
 * @addtogroup rtos-settings
 * @{
 * 
 * @details
 *  This section includes the global task execution scheduler peripheral assignments.
 *  The main task scheduler time base requires a timer interrupt to separate high-priority
 *  from low-priority task execution. The high priority task timer interrupt is configured here.
 */

#define _OsTimerInterrupt      _T1Interrupt ///< Interrupt serivce routine label 
#define _OSTIMER_IP            _T1IP        ///< Interrupt priority register
#define _OSTIMER_IE            _T1IE        ///< Interrupt enable bit
#define _OSTIMER_IF            _T1IF        ///< Interrupt flag bit
#define _OSTIMER_PER           PR1          ///< Timer period register
#define _OSTIMER_TMRCAP        TMR1         ///< Timer period counter register

#define _OSTIMER_ALTWREG_ENABLE true        ///< if = true, selects a free alternate working register set for fast context switching
#define _OSTIMER_PRIORITY       4           ///< Interrupt priority (1 ... 7, default = 2)

/** @} */ // end of group rtos-settings ~~~~~~~~~~

/**
 * @ingroup rtos-macros
 * @brief   Global task execution scheduler conversion macros
 * 
 * @details
 *  Conversion macros are used to convert user settings defined in physical quantities into 
 *  binary (integer) numbers, which will be written to registers and variables and/or used 
 *  in calculations throughout the firmware.
 */

#define RTOS_6G2_EXEC_PER (uint16_t)((CPU_FREQUENCY * RTOS_6G2_EXECUTION_PERIOD)-1) ///< Operating System Timer execution period

#endif	/* End of OPERATING_SYSTEM_API_HEADER_H */

// _________________________
// end of file
