#ifndef __SPECIAL_FUNCTION_LAYER_VOUT_LOOP_AGC_H__
#define __SPECIAL_FUNCTION_LAYER_VOUT_LOOP_AGC_H__

#include <xc.h>                                   // include processor files - each processor file is guarded
#include <dsp.h>                                  // include DSP data types (e.g. fractional)
#include <stdint.h>                               // include standard integer number data types
#include <stdbool.h>                              // include standard boolean data types (true/false)

#include "npnz16b.h"                              // include NPNZ library header file

/*********************************************************************************
 * @fn void vout_loop_AGCFactorUpdate(volatile struct NPNZ16b_s* controller)
 * @ingroup special-function-layer-npnz16-functions
 * @brief Prototype of the Assembler feedback control loop routine helping to call the vout_loop_AGCFactorUpdate from C-code
 * @param controller: Pointer to NPNZ16b data object of type struct NPNZ16b_s*
 *
 * @details
 * This function is the loop gain modulation that calculates a Q15 coefficients 
 * used to scale the gain of the controller in order to keep the closed loop
 * transfer function constant vs the input voltage variation
 ********************************************************************************/

extern void vout_loop_AGCFactorUpdate(            
        volatile struct NPNZ16b_s* controller     // Pointer to NPNZ16b data object
    );

#endif