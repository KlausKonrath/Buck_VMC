#ifndef __SPECIAL_FUNCTION_LAYER_VOUT_LOOP_PWM_UPD_H__
#define __SPECIAL_FUNCTION_LAYER_VOUT_LOOP_PWM_UPD_H__

#include <xc.h>                                   // include processor files - each processor file is guarded
#include <dsp.h>                                  // include DSP data types (e.g. fractional)
#include <stdint.h>                               // include standard integer number data types
#include <stdbool.h>                              // include standard boolean data types (true/false)

#include "npnz16b.h"                              // include NPNZ library header file

/*********************************************************************************
 * @fn void pwm_register_update(volatile struct NPNZ16b_s* controller)
 * @ingroup special-function-layer-npnz16-functions
 * @brief Prototype of the Assembler feedback control loop routine helping to call the pwm_register_update from C-code
 * @param controller: Pointer to NPNZ16b data object of type struct NPNZ16b_s*
 *
 * @details
 * This function updates the PWM duty cycle registers and trigger B register for the 4 phases
 ********************************************************************************/

extern void pwm_register_update(            
        volatile struct NPNZ16b_s* controller     // Pointer to NPNZ16b data object
    );

#endif