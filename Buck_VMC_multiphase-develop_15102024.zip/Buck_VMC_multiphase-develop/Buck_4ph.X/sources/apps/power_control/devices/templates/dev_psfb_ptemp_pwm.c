/* 
 * @file   dev_psfb_ptemp_pwm.c
 * @author M91406
 * @brief
 * Revision history: 
 */

#include <xc_pral.h> // include peripheral register abstraction layer drivers
#include "dev_psfb_ptemp_pwm.h"
/****************************************************************************************************
 * @ingroup lib-layer-psfb-ptemplate-properties-variables
 * @var psfbPwmModuleConfig
 * @brief PWM module default configuration
 *****************************************************************************************************/
volatile P33C_PWM_INSTANCE_t pgConfigPWM = {
        .PGxCONL.value = REG_PGxCONL, // PGxCONL: PWM GENERATOR x CONTROL REGISTER LOW
        .PGxCONH.value = REG_PGxCONH, // PGxCONH: PWM GENERATOR x CONTROL REGISTER HIGH
        .PGxSTAT.value = 0x0000, // PGxSTAT: PWM GENERATOR x STATUS REGISTER
        .PGxIOCONL.value = REG_PGxIOCONL, // PGxIOCONL: PWM GENERATOR x I/O CONTROL REGISTER LOW
        .PGxIOCONH.value = REG_PGxIOCONH, // PGxIOCONL: PWM GENERATOR x I/O CONTROL REGISTER HIGH
        .PGxEVTL.value = REG_PGxEVTL, // PGxEVTL: PWM GENERATOR x EVENT REGISTER LOW
        .PGxEVTH.value = REG_PGxEVTH, // PGxEVTH: PWM GENERATOR x EVENT REGISTER HIGH
        .PGxFPCIL.value = REG_PGxFPCIL, // PGxFPCIL: PWM GENERATOR x FAULT PCI REGISTER LOW
        .PGxFPCIH.value = REG_PGxFPCIH, // PGxFPCIL: PWM GENERATOR x FAULT PCI REGISTER HIGH
        .PGxCLPCIL.value = REG_PGxCLPCIL, // PGxLCPCIL: PWM GENERATOR x CURRENT LIMIT PCI REGISTER LOW
        .PGxCLPCIH.value = REG_PGxCLPCIH, // PGxLCPCIL: PWM GENERATOR x CURRENT LIMIT PCI REGISTER HIGH
        .PGxFFPCIL.value = REG_PGxFFPCIL, // PGxFFPCIL: PWM GENERATOR x FEED FORWARD PCI REGISTER LOW
        .PGxFFPCIH.value = REG_PGxFFPCIH, // PGxFFPCIL: PWM GENERATOR x FEED FORWARD PCI REGISTER HIGH
        .PGxSPCIL.value = REG_PGxSPCIL, // PGxSPCIL: PWM GENERATOR x SOFTWARE PCI REGISTER LOW
        .PGxSPCIH.value = REG_PGxSPCIH, // PGxSPCIL: PWM GENERATOR x SOFTWARE PCI REGISTER HIGH
        .PGxLEBL.value = REG_PGxLEBL, // PGxLEBL: PWM GENERATOR x LEADING-EDGE BLANKING REGISTER LOW
        .PGxLEBH.value = REG_PGxLEBH, // PGxLEBL: PWM GENERATOR x LEADING-EDGE BLANKING REGISTER HIGH
        .PGxPHASE.value = 0x0000, // PGxPHASE=0
        .PGxDC.value = 0x0000, // PGxDC=0
        .PGxDCA.value = 0x0000, // PGxDCA=0
        .PGxPER.value = 0x0000, // PGxPER=0
        .PGxTRIGA.value = 0x0000, // PGxTRIGA=0
        .PGxTRIGB.value = 0x0000, // PGxTRIGB=0
        .PGxTRIGC.value = 0x0000, // PGxTRIGC=0
        .PGxDTL.value = 0x0000, // DTL=0
        .PGxDTH.value = 0x0000, // DTH=0
        .PGxCAP.value = 0x0000 // CAP=0
    };
/****************************************************************************************************
 * @ingroup lib-layer-psfb-ptemplate-properties-variables
 * @var psfbPwmModuleConfig
 * @brief PWM generator default configuration
 *****************************************************************************************************/
// PWM module default configuration
volatile P33C_PWM_MODULE_t PwmModuleConfig = 
{
        .PCLKCON.value = REG_PCLKCON,  // PCLKCON: PWM CLOCK CONTROL REGISTER
        .FSCL.value = 0x0000,          // FSCL: FREQUENCY SCALE REGISTER
        .FSMINPER.value = 0x0000,      // FSMINPER: FREQUENCY SCALING MINIMUM PERIOD REGISTER
        .MPHASE.value = 0x0000,        // MPHASE: MASTER PHASE REGISTER
        .MDC.value = 0x0000,           // MDC: MASTER DUTY CYCLE REGISTER
        .MPER.value = 0x0000,          // MPER: MASTER PERIOD REGISTER
        .LFSR.value = 0x0000,          // LFSR: LINEAR FEEDBACK SHIFT REGISTER
        .CMBTRIGL.value = REG_CMBTRIGL, // CMBTRIGL: COMBINATIONAL TRIGGER REGISTER LOW
        .CMBTRIGH.value = REG_CMBTRIGH, // CMBTRIGH: COMBINATIONAL TRIGGER REGISTER HIGH
        .LOGCON_A.value = REG_LOGCONA,  // LOGCONA: COMBINATORIAL PWM LOGIC CONTROL REGISTER A
        .LOGCON_B.value = REG_LOGCONB,  // LOGCONB: COMBINATORIAL PWM LOGIC CONTROL REGISTER B
        .LOGCON_C.value = REG_LOGCONC,  // LOGCONC: COMBINATORIAL PWM LOGIC CONTROL REGISTER C
        .LOGCON_D.value = REG_LOGCOND,  // LOGCOND: COMBINATORIAL PWM LOGIC CONTROL REGISTER D
        .LOGCON_E.value = REG_LOGCONE,  // LOGCONE: COMBINATORIAL PWM LOGIC CONTROL REGISTER E
        .LOGCON_F.value = REG_LOGCONF,  // LOGCONF: COMBINATORIAL PWM LOGIC CONTROL REGISTER F
        .PWMEVT_A.value = REG_PWMEVTA,  // PWMEVTA: PWM EVENT OUTPUT CONTROL REGISTER A
        .PWMEVT_B.value = REG_PWMEVTB,  // PWMEVTB: PWM EVENT OUTPUT CONTROL REGISTER B
        .PWMEVT_C.value = REG_PWMEVTC,  // PWMEVTC: PWM EVENT OUTPUT CONTROL REGISTER C
        .PWMEVT_D.value = REG_PWMEVTD,  // PWMEVTD: PWM EVENT OUTPUT CONTROL REGISTER D
        .PWMEVT_E.value = REG_PWMEVTE,  // PWMEVTE: PWM EVENT OUTPUT CONTROL REGISTER E
        .PWMEVT_F.value = REG_PWMEVTF   // PWMEVTF: PWM EVENT OUTPUT CONTROL REGISTER F
    };

