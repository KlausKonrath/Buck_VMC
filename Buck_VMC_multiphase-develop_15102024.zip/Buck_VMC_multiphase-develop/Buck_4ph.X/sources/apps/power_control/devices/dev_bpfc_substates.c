/*
 * File:   dev_bpfc_substates.c
 * Author: M91406
 *
 * Created on October 9, 2020, 9:16 AM
 */

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types

#include "./dev_bpfc_pconfig.h" // include PSFB Converter
#include "./dev_bpfc_typedef.h" // include PSFB Converter data object declarations
#include "./../../vac_monitor/app_vac_monitor.h"

#ifdef __WITH_PIL__
#include "./../lib_pil/pil.h"
#include "../PIL/main.h"

extern PilProbes_t PilProbes;
extern PIL_Handle_t PilHandle;
#endif

// Private function prototypes of sub-state functions
volatile uint16_t __attribute__((always_inline)) Substate_VbulkMonitor(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance);
volatile uint16_t __attribute__((always_inline)) SubState_RelayEnable(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance);
volatile uint16_t __attribute__((always_inline)) SubState_PowerOnDelay(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance);
volatile uint16_t __attribute__((always_inline)) SubState_PrepareVRampUp(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance);
volatile uint16_t __attribute__((always_inline)) SubState_VRampUpStart(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance);
volatile uint16_t __attribute__((always_inline)) SubState_VRampUp(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance);
volatile uint16_t __attribute__((always_inline)) SubState_PowerGoodDelay(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance);
volatile uint16_t __attribute__((always_inline)) Substate_RelayTuning(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance);

volatile uint16_t (*BpfcConverterRampUpSubStateMachine[])(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance) = {

    Substate_VbulkMonitor,      ///< State #1:  Monitor bulk capacitor voltage
    SubState_RelayEnable,       ///< State #2:  Turn on bypass-relay
    SubState_PowerOnDelay,      ///< State #3:  Wait programmed number of state machine ticks until startup is triggered
    SubState_PrepareVRampUp,    ///< State #4:  Determine ramp up condition, pre-charge controllers and program PWM/Peripherals
    SubState_VRampUpStart,      ///< State #5:  Wait for the next zero-crossing to occur before output voltage ramp-up is allowed
    SubState_VRampUp,           ///< State #6:  Output voltage ramp up
    SubState_PowerGoodDelay,    ///< State #7:  Wait until power good delay has expired and optionally set a GPIO
    Substate_RelayTuning        ///< State #8:  Tune the duty cycle of the relay pwm
    
};
volatile uint16_t BpfcRampUpSubStateList_size = (sizeof(BpfcConverterRampUpSubStateMachine)/sizeof(BpfcConverterRampUpSubStateMachine[0])); 

/*******************************************************************************
 * @fn volatile uint16_t SubState_PowerOnDelay(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance)
 * @ingroup lib-layer-bpfc-state-machine-functions
 * @param	BPFC_POWER_CONTROLLER_s  pointer to PSFB Converter data structure
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief 
 * 
 * <b>Description</b> 
 * After the converter has been cleared to get started, the power-on 
 * delay counter until the defined power-on delay period has expired.  
 *********************************************************************************/
volatile uint16_t Substate_VbulkMonitor(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance)
{
    volatile uint16_t _vbulk=0;
    volatile uint16_t _vin=0;

    // Set BUSY bit until process is complete
    bpfcInstance->status.bits.busy = true;
    
    // Capture input peak value and vbulk
    _vbulk = bpfcInstance->vbulkMonitor.vbulk_average;
    _vin = vac_monitor.LineInfo.vacPeak - TP_VIN_VBLK_DELTA_RELAY_ON;

    // Compare input peak value and vbulk
    if (_vin > _vbulk)
        bpfcInstance->startup.bulk_monitor.counter = 0; // Reset counter if voltage is not tuned in yet

    // Monitor settled voltage for the given period of time
    if (bpfcInstance->startup.bulk_monitor.counter++ >= 
        bpfcInstance->startup.bulk_monitor.period)
    {
        return(BPFC_OPSRET_COMPLETE);
    }
    // In case of a timeout, reset state machine and try again
    if (bpfcInstance->startup.bulk_monitor.timeout_counter++ > 
        bpfcInstance->startup.bulk_monitor.timeout)
    {
        return (BPFC_OPSRET_ERROR);
    }

    // Recall this sub-state
    return(BPFC_OPSRET_REPEAT);
         
}

/*******************************************************************************
 * @fn volatile uint16_t SubState_RelayEnable(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance)
 * @ingroup lib-layer-bpfc-state-machine-functions
 * @param	BPFC_POWER_CONTROLLER_s  pointer to PSFB Converter data structure
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief 
 * 
 * <b>Description</b> 
 * After the POWER ON DELAY has expired, the bypass relay can be closed. 
 * 
 * *********************************************************************************/
volatile uint16_t SubState_RelayEnable(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance){
    
    // Set BUSY bit until process is complete
    bpfcInstance->status.bits.busy = true;
 
    if(bpfcInstance->zcd_settings->Status.bits.zeroFlag)
    {
        // Turn on inrush-current bypass relay
        bpfcRelay_On(bpfcInstance); 
#ifdef __WITH_PIL__       
        PilProbes.INRUSH=1;
#endif

        return (BPFC_OPSRET_COMPLETE);
    }
    else
    {
        return(BPFC_OPSRET_REPEAT);
    }
}


/*******************************************************************************
 * @fn volatile uint16_t State_PowerOnDelay(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance)
 * @ingroup lib-layer-bpfc-state-machine-functions
 * @param	BPFC_POWER_CONTROLLER_s  pointer to PSFB Converter data structure
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief 
 * 
 * <b>Description</b> 
 * After the converter has been cleared to get started, the power-on 
 * delay counter until the defined power-on delay period has expired. 
 * *********************************************************************************/
volatile uint16_t SubState_PowerOnDelay(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance)
{
    // Set BUSY bit until process is complete
    bpfcInstance->status.bits.busy = true;
    
    // Monitor settled voltage for the given period of time
    if (bpfcInstance->startup.power_on_delay.counter++ >= 
        bpfcInstance->startup.power_on_delay.period)
    {
        return(BPFC_OPSRET_COMPLETE);
    }   
    
    // Recall this sub-state
    return(BPFC_OPSRET_REPEAT);
    
}

/*******************************************************************************
 * @fn volatile uint16_t SubState_PrepareVRampUp(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance)
 * @ingroup lib-layer-bpfc-state-machine-functions
 * @param	BPFC_POWER_CONTROLLER_s  pointer to PSFB Converter data structure
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief 
 * 
 * <b>Description</b> 
 * After the POWER ON DELAY has expired, the ramp up starting point is determined  
 * by measuring the input and output voltage and calculates the ideal duty ratio 
 * of the PWM. This value is then programmed into the PWM module duty cycle register 
 * and is also used to pre-charge the control loop output history. In addition the 
 * measured output voltage also set as reference to ensure the loop starts without 
 * jerks and jumps.
 * 
 * When voltage mode control is enabled, the voltage loop control history is 
 * charged, when average current mode control is enabled, the current loop control 
 * history is charged.
 *********************************************************************************/
volatile uint16_t SubState_PrepareVRampUp(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance)
{
    volatile uint16_t _i=0,_delta_ramp;
    volatile uint32_t _vout=0, _vin=0, _start_dc=0;

    // Set BUSY bit until process is complete
    bpfcInstance->status.bits.busy = true;
    
    // Hijack voltage loop controller reference
    bpfcInstance->startup.v_ramp.reference = 0; // Reset Soft-Start Voltage Reference
    //bpfcInstance->startup.i_ramp.reference = 0; // Carlo no ramp on current is needed Reset Soft-Start Current Reference
    bpfcInstance->v_loop.controller->Ports.ptrControlReference = 
        &bpfcInstance->startup.v_ramp.reference; // Voltage loop is pointing to Soft-Start Reference

    // Pre-charge reference
    // Never start above the pre-biased output voltage.
    // Always start at or slightly below the pre-biased output voltage
    bpfcInstance->startup.v_ramp.reference = bpfcInstance->vbulkMonitor.vbulk_average;

    // In average current mode, set current reference limit to max startup current level
    if (bpfcInstance->set_values.control_mode == BPFC_CONTROL_MODE_ACMC) 
    {   // Disable all current control loops and reset control loop histories
        //bpfcInstance->v_loop.maximum = IPFC_ISNS_OCL; //Carlo bpfcInstance->set_values.i_ref;
        bpfcInstance->v_loop.controller->Limits.MaxOutput = bpfcInstance->v_loop.maximum;
    }
    _delta_ramp=bpfcInstance->v_loop.reference - bpfcInstance->startup.v_ramp.reference;
    bpfcInstance->startup.v_ramp.interval =  __builtin_divud(bpfcInstance->startup.v_ramp.duration,_delta_ramp);
    if(bpfcInstance->startup.v_ramp.interval==0)
    {
        return(BPFC_OPSRET_ERROR);
    }
    bpfcInstance->startup.v_ramp.counter=0;
    
    bpfcInstance->startup.v_ramp.reference = bpfcInstance->vbulkMonitor.vbulk_average;
    // Pre-charge PWM and control loop history 
    if(((bpfcInstance->data.v_in - bpfcInstance->feedback.ad_vin.scaling.offset) > 0) &&
       ((bpfcInstance->vbulkMonitor.vbulk_average - bpfcInstance->feedback.ad_vout.scaling.offset) > 0) )
    {
        _vout = __builtin_muluu(
            (bpfcInstance->vbulkMonitor.vbulk_average - bpfcInstance->feedback.ad_vout.scaling.offset), 
            bpfcInstance->feedback.ad_vout.scaling.factor);
        _vout >>= (16 - bpfcInstance->feedback.ad_vout.scaling.scaler);

        _vin = __builtin_muluu(
            (bpfcInstance->data.v_in - bpfcInstance->feedback.ad_vin.scaling.offset), 
            bpfcInstance->feedback.ad_vin.scaling.factor);
        _vin >>= (16 - bpfcInstance->feedback.ad_vin.scaling.scaler);

        // Protect against negative duty cycle results
        if (_vout < _vin) _vout = _vin;
        
        // CALCULATE BOOST PFC CONVERTER STARTUP DUTY RATIO 
        // DC = (VOUT-VIN) / VOUT, where DC = D * PERIOD
        
        _start_dc = __builtin_muluu((_vout-_vin), bpfcInstance->sw_node[0].period);
        _start_dc = __builtin_divud(_start_dc, (uint16_t)_vout);
    }
    else
    // If there is no input voltage or no output voltage, start with minimum duty ratio
    {
        for (_i=0; _i<bpfcInstance->set_values.no_of_phases; _i++) {
            _start_dc = (uint16_t)bpfcInstance->sw_node[_i].duty_ratio_min;
        }
    }

    return(BPFC_OPSRET_COMPLETE);
    
}

/*******************************************************************************
 * @fn volatile uint16_t SubState_VRampUpStart(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance)
 * @ingroup lib-layer-bpfc-state-machine-functions
 * @param	BPFC_POWER_CONTROLLER_s  pointer to PSFB Converter data structure
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief   Waits for the next zero crossing of AC input voltage before output is allowed to ramp up
 * 
 * @details
 * 
 *********************************************************************************/
volatile uint16_t SubState_VRampUpStart(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance)
{
    volatile uint16_t retval=0;

    if (!bpfcInstance->zcd_settings->Status.bits.zeroFlag && !bpfcInstance->zcd_settings->Status.bits.dcMode)
    { 
        return(BPFC_OPSRET_REPEAT); } // Repeat this function until either the zero-cross flag or the dcMode flag is set
    else
    { 
        return(BPFC_OPSRET_COMPLETE); 
    } // At zero-crossing, move on to next state
  
    return (retval);
}

/*******************************************************************************
 * @fn volatile uint16_t SubState_VRampUp(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance)
 * @ingroup lib-layer-bpfc-state-machine-functions
 * @param	BPFC_POWER_CONTROLLER_s  pointer to PSFB Converter data structure
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief 
 * 
 * <b>Description</b> 
 * This is the essential step in which the output voltage is ramped up by 
 * incrementing the outer control loop reference. In voltage mode the output  
 * voltage will ramp up to the nominal regulation point. 
 * In average current mode the inner loop will limit the voltage as soon as the 
 * current reference limit is hit and the output is switched to constant current 
 * mode.
 *********************************************************************************/
volatile uint16_t SubState_VRampUp(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance)
{
    volatile uint16_t retval=0;
    volatile uint16_t _i=0;

    // Set BUSY bit until process is complete
    bpfcInstance->status.bits.busy = true;
    
    // ensure control loop is enabled
    if(!bpfcInstance->v_loop.controller->status.bits.enabled) {

        // Enable all PWM channels
        //retval &= bpfcPWM_Resume(bpfcInstance);  // Carlo Enable PWM outputs // ToDo: Does this really work? No further PWM OFF-protection?

        // Always enable voltage loop controller
        bpfcInstance->v_loop.controller->status.bits.enabled = true; 

        if (bpfcInstance->set_values.control_mode == BPFC_CONTROL_MODE_PRCM)
        {
            // enable all phase current loop controllers
            for (_i=0; _i<bpfcInstance->set_values.no_of_phases; _i++) {
                bpfcInstance->prcm_i_loop[_i].controller->Status.bits.enabled = true; 
            }
        }

    }
    
    bpfcInstance->startup.v_ramp.counter+=(uint16_t) IPFC_VRAMP_RESOLUTION; 
    //PilProbes.DEBUG3=0;
    while(bpfcInstance->startup.v_ramp.counter>=bpfcInstance->startup.v_ramp.interval)
    {
        bpfcInstance->startup.v_ramp.counter-=bpfcInstance->startup.v_ramp.interval;
        // increment reference
        bpfcInstance->startup.v_ramp.reference++;
        //PilProbes.DEBUG3=1;
    }
    
        

    // check if ramp is complete
    if (bpfcInstance->startup.v_ramp.reference > bpfcInstance->v_loop.reference)
    {
        // Set reference to the desired level
        bpfcInstance->startup.v_ramp.reference = bpfcInstance->v_loop.reference;

        // Reconnect API reference to controller
        bpfcInstance->v_loop.controller->Ports.ptrControlReference = &bpfcInstance->v_loop.reference;

       retval = BPFC_OPSRET_COMPLETE;

    }
    else
    // remain in this state until ramp is complete
    {
      retval = BPFC_OPSRET_REPEAT;
    }
    return(retval);
}

/*******************************************************************************
 * @fn volatile uint16_t SubState_PowerGoodDelay(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance)
 * @ingroup lib-layer-bpfc-state-machine-functions
 * @param	BPFC_POWER_CONTROLLER_s  pointer to PSFB Converter data structure
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief 
 * 
 * <b>Description</b> 
 * In this phase of the soft-start procedure a counter is incremented until the 
 * power good delay has expired before the soft-start process is marked as COMPLETED
 *********************************************************************************/
volatile uint16_t SubState_PowerGoodDelay(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance)
{
    volatile uint16_t _source=0;
    volatile uint16_t _compare=0;

    // Set BUSY bit until process is complete
    bpfcInstance->status.bits.busy = true;
    
    // Capture compare value
    _source = (bpfcInstance->vbulkMonitor.vbulk_average);
  //  _compare = (bpfcInstance->startup.power_good_delay.pre_sample & bpfcInstance->startup.power_good_delay.filter_mask); 
    _compare = (bpfcInstance->v_loop.reference - 424 );
    // Compare the previous sample with the most recent ones
    
    _compare=_source-1;
    if (_source < _compare)
        bpfcInstance->startup.power_good_delay.counter = 0; // Reset counter if voltage is not tuned in yet
    
    // Monitor settled voltage for the given period of time
    if (bpfcInstance->startup.power_good_delay.counter++ >= 
        bpfcInstance->startup.power_good_delay.period)
        //return (BPFC_STATE_PREPARE_V_RAMP);
    {
        return(BPFC_OPSRET_COMPLETE);
      // return(BPFC_STATE_ONLINE);
    }
    
    // In case of a timeout, reset state machine and try again
    if (bpfcInstance->startup.power_good_delay.timeout_counter++ > 
        bpfcInstance->startup.power_good_delay.timeout)
    {
        return ( BPFC_OPSRET_ERROR);
    }

    // Recall this sub-state
    return( BPFC_OPSRET_REPEAT  );

    
}

/*******************************************************************************
 * @fn volatile uint16_t bpfcRelayTuningEnable(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance)
 * @ingroup lib-layer-bpfc-state-machine-functions
 * @param	BPFC_POWER_CONTROLLER_s  pointer to PSFB Converter data structure
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief 
 * 
 * @details 
 * After a successful soft-start and when state POWER_GOOD_DELAY has expired, 
 * the control signal to the bypass relay can be modulated to reduce its power
 * consumption by driving the relay with a low-frequency PWM signal.
 * 
 * This feature is optional and needs to be configured and enabled in 
 * proprietary user code. 
 * 
 * If disabled, this state is bypassed and the converter is calling the 
 * following state,
 * 
 * *********************************************************************************/

volatile uint16_t Substate_RelayTuning(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance) 
{
    // Set BUSY bit until process is complete
    bpfcInstance->status.bits.busy = true;
    
    // IF this option is disabled, exit here
    if (!bpfcInstance->relaySettings.tune_enable) {
        // boostRelay_On(bpfcInstance);
       return ( BPFC_OPSRET_COMPLETE  );
    }
   
    
    if (
        (bpfcInstance->relaySettings.relay_counter < (bpfcInstance->relaySettings.relay_init_counter)) && 
        (!bpfcInstance->relaySettings.init_flag)) 
    {
        bpfcInstance->relaySettings.relay_counter++;
    } 
    else if (
        (bpfcInstance->relaySettings.relay_counter == (bpfcInstance->relaySettings.relay_init_counter)) && 
        (!bpfcInstance->relaySettings.init_flag)) 
    {
        bpfcInstance->relaySettings.init_flag = 1;
        bpfcInstance->relaySettings.relay_counter = 0;
        bpfc_RelayDutyDecrement(bpfcInstance, bpfcInstance->relaySettings.decrement_period_count);

        bpfcInstance->relaySettings.duty_ratio_init = 
            (bpfcInstance->relaySettings.duty_ratio_init - bpfcInstance->relaySettings.duty_ratio_scaler);
       // boostCCP_RelayAssociate(bpfcInstance);
    }
    else if (
        (++bpfcInstance->relaySettings.relay_counter >= bpfcInstance->relaySettings.relay_step_counter) && 
        (bpfcInstance->relaySettings.duty_ratio_init != bpfcInstance->relaySettings.duty_ratio_final) &&
        (bpfcInstance->relaySettings.init_flag) ) 
    {
        bpfcInstance->relaySettings.duty_ratio_init = 
            (bpfcInstance->relaySettings.duty_ratio_init - bpfcInstance->relaySettings.duty_ratio_scaler);
        bpfc_RelayDutyDecrement(bpfcInstance, bpfcInstance->relaySettings.decrement_period_count);
        bpfcInstance->relaySettings.relay_counter = 0;
    } 
    else if ( bpfcInstance->relaySettings.duty_ratio_init == bpfcInstance->relaySettings.duty_ratio_final) 
    {
        return(BPFC_OPSRET_COMPLETE)  ; 
    }
    
    return(BPFC_OPSRET_REPEAT );

}

// end of file
