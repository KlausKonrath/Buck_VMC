/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   dev_bpfc_substates.h
 * Author: M91406
 * Comments: 
 * Revision history: 
 */

#ifndef BPFC_CONVERTER_OPERATION_SUBSTATES_H
#define	BPFC_CONVERTER_OPERATION_SUBSTATES_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
/***********************************************************************************
 * @ingroup lib-layer-bpfc-state-machine-properties-variables
 * @var volatile uint16_t (*BpfcConverterRampUpSubStateMachine[])(volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance);
 * @brief   Function pointer array of bpfc converter startup sub-states
 * @details
 * The function pointer list BpfcConverterRampUpSubStateMachine[] is providing 
 * access to a list of state functions. Each function mapped into this array 
 * as function pointer represents a self-contained, independent sub-state. 
 * The main state machine will call functions from this list in order of their
 * index within the array, starting from '0'. While this list is executed, the 
 * calling main state is transparent by passing through the return value of the 
 * most recent sub-state. Once all sub-states have been executed, the calling main 
 * state will return the COMPLETE flag, allowing the main state machine to move on.
 * 
 * Each function needs to be called by handing over a parameter of type
 * 
 * - struct BPFC_CONVERTER_s 
 * 
 * Each function returns of type unsigned integer:
 * 
 * - 0 = BPFC_OPSRET_ERROR
 * - 1 = BPFC_OPSRET_COMPLETE
 * - 2 = BPFC_OPSRET_REPEAT
 * 
 **********************************************************************************/
// PSFB converter state machine function pointer array
extern volatile uint16_t (*BpfcConverterRampUpSubStateMachine[])
            (volatile struct BPFC_POWER_CONTROLLER_s *bpfcInstance); ///< BPFC converter state machine function pointer array



#endif	/* BPFC_CONVERTER_OPERATION_SUBSTATES_H */

// end of file
