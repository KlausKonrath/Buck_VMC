/**
 * @file    app_led.c
 * @brief   Fault monitor application layer source file
 * @author  M91406
 * @date    03/12/2020
 * @version 1.0.3
 */

#include "config/apps.h" // include common application task abstraction layer header file
#include "config/hal.h" // include hardware abstraction layer header file

// PRIVATE VARIABLE DELARATIONS
static uint16_t tgl_cnt = 0;  // local counter of LED toggle loops
static uint16_t pre_state = 0; // copy of LED toggle mode status used to detect changes

#define TON_INTERVAL_STANDBY     1  // LED on-time interval of 1 x 100 ms = 100 ms
#define TGL_INTERVAL_STANDBY    10  // LED toggle interval of 10 x 100 ms = 900 ms

#define TON_INTERVAL             5  // LED on-time interval of 5 x 100 ms = 500 ms
#define TGL_INTERVAL            10  // LED toggle interval of 5 x 100 ms = 400 ms

#define TON_INTERVAL_ERR         1  // LED on-time interval of 1 x 100 ms = 100 ms
#define TGL_INTERVAL_ERR         2  // LED toggle interval of 1 x 100 ms = 100 ms

DEBUGGING_LED_t debugLed;

/*********************************************************************************
 * @ingroup apps-layer-led-debug-functions-public
 * @brief   Initializes the LED driving GPIO
 * @return  unsigned integer (0=failure, 1=success)
 *
 * @details
 *  This routine configures the driving GPIO as output and sets the initial
 *  toggle interval of the debugging LED.
 *
 **********************************************************************************/
uint16_t appLED_Initialize(void) 
{
    uint16_t retval = 1;
    
//    if(debugLed.Period == 0)
//        debugLed.Period = TGL_INTERVAL_STANDBY;
//    
//    if(debugLed.OnTime == 0)
//        debugLed.OnTime = TGL_INTERVAL_STANDBY;
//    
//    debugLed.ioPin = &DBGLED;
//    debugLed.ioPin->Methods.Init(0, 0);

    return(retval);
}

/*********************************************************************************
 * @ingroup apps-layer-led-debug-functions-public
 * @brief   Executes the debugging LED driver
 * @return  unsigned integer (0=failure, 1=success)
 *
 * @details
 *  This routine executes the debugging LED driver controlling the toggling 
 *  interval of the debugging LED.
 *
 **********************************************************************************/
uint16_t appLED_Execute(void) 
{
    uint16_t retval = 1;

//    // Exit early if debugging LED is disabled
//    if (!debugLed.Status.bits.enabled)
//        return(1);
//
//    // Change LED toggle frequency when power supply is in fault state
//    if (buck_4ph.Status.bits.fault_active)
//    {
//        debugLed.OnTime = TON_INTERVAL_ERR;
//        debugLed.Period = TGL_INTERVAL_ERR;
//    }
//    // Change LED toggle frequency when power supply is in normal operation
//    else if (buck_4ph.Status.bits.ready)
//    {
//        debugLed.OnTime = TON_INTERVAL;
//        debugLed.Period = TGL_INTERVAL;
//    }
//    // Change LED toggle frequency when power supply is in standby
//    else
//    {
//        debugLed.OnTime = TON_INTERVAL_STANDBY;
//        debugLed.Period = TGL_INTERVAL_STANDBY;
//    }
//    
//    // Clear counter when state has changed
//    if (pre_state != buck_4ph.Status.value)
//        tgl_cnt = 1;
//    // increment counter if not
//    
//    pre_state = buck_4ph.Status.value;
//    
//	// Toggle LED, refresh LCD and reset toggle counter
//    if (++tgl_cnt > debugLed.Period) // Count n loops until LED toggle interval is exceeded
//    { tgl_cnt = 1; } 
//
//	if (tgl_cnt <= debugLed.OnTime) // Count n loops until LED on-time is exceeded
//    { debugLed.ioPin->Methods.Set(); }
//    else // Count n loops until LED toggle interval is exceeded
//    { debugLed.ioPin->Methods.Clear(); }
//
//    // Capture LED I/O pin status
//    debugLed.Status.bits.on = (bool)(debugLed.ioPin->Methods.Get() == DBGLED_ON);
    
    return(retval);
}

/*********************************************************************************
 * @ingroup apps-layer-led-debug-functions-public
 * @brief   Enables the periodic refresh of the debugging LED status
 * @return  unsigned integer (0=failure, 1=success)
 *
 * @details
 *  This routine is used to allow function 'appLED_Execute' to periodically 
 *  refresh the debugging LED status.
 *
 **********************************************************************************/
uint16_t appLED_Start(void) 
{
    uint16_t retval = 1;
    
//    debugLed.Status.bits.enabled = false;
//    retval &= (uint16_t)(debugLed.Status.bits.enabled);

    return(retval);
}

/*********************************************************************************
 * @ingroup apps-layer-led-debug-functions-public
 * @brief   Frees the resources of the debugging LED driver
 * @return  unsigned integer (0=failure, 1=success)
 *
 * @details
 *  This routine is used to end the debugging LED driver task and frees
 *  its resources.
 *
 **********************************************************************************/
uint16_t appLED_Dispose(void) 
{
    uint16_t retval = 1;
    
//    debugLed.Period = 0;
//    debugLed.ioPin->Methods.Dispose();

    return(retval);
}

// end of file
