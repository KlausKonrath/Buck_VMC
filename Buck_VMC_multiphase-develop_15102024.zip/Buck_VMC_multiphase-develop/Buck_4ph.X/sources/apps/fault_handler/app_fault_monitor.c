/* 
 * @file   app_fault_monitor.c
 * @author M91406
 * @brief  Fault monitor application layer source file
 * Revision history: 
 */

#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
#include <stddef.h> // include standard definition data types

#include "config/hal.h" // include hardware abstraction layer header file
#include "config/apps.h" // include application layer abstraction layer header file

#include "./drivers/IFaultHandler.h"

// User fault object declarations
extern volatile FAULT_OBJECT_t* FaultObjectList[];
extern volatile uint16_t FaultObjectList_size;

/*********************************************************************************
 * @fn     uint16_t appFaultMonitor_Execute(void)  
 * @ingroup app-layer-fault-handler-functions-public
 * @brief  Application wide fault object monitoring routine
 * @return 0=failure 
 * @return 1=success
 * 
 * @details
 *   In this function all user-defined fault objects are monitored for 
 *   threshold violations. While fault responses are triggered by each 
 *   fault object individually, system recovery from a fault condition is 
 *   only allowed when all fault conditions have been cleared. Hence, 
 *   individual fault status bits are combined into a common fault bit, 
 *   which needs to be cleared to allow the power supply to start-up again.
 * 
 *********************************************************************************/

uint16_t appFaultMonitor_Execute(void) 
{
    uint16_t retval=1;
    
        
    // Scan all declared fault objects
    drv_FaultHandler_ScanObjects(FaultObjectList, FaultObjectList_size);
    
    // Push global fault state to buck converter device driver status
    buck_4ph.Status.bits.fault_active = FaultMonitor.Status.bits.FaultStatus;
    
    // If power supply controller passes POWER GOOD and reaches state ONLINE,
    // reset restart cycle counter
    if (buck_4ph.StateId.bits.opstate_id == CONVERTER_OPSTATE_ONLINE)
        FaultMonitor.FaultRecoveryCounter = 0;
#ifdef __WITH_PIL__
    //PilProbes.DEBUG1=FaultMonitor.Status.bits.FaultStatus;
#endif
    
    return (retval);
}

/*********************************************************************************
 * @fn     uint16_t appFaultMonitor_Initialize(void)
 * @ingroup app-layer-fault-handler-functions-public
 * @brief  Initialization of user-defined fault objects
 * @return 0=failure 
 * @return 1=success
 * 
 * @details
 * This function initializes the fault monitor data object user settings
 * and the CPU soft traps. All user defined fault objetcs are pre-initialized
 * in app_fault_config.c and do not need further initialization.
 *********************************************************************************/

uint16_t appFaultMonitor_Initialize(void) 
{
    uint16_t retval=1;
    
        
    // Initialize fault monitor recovery parameters
    FaultMonitor.FaultRecovery = &appPowerSupply_Resume;
    FaultMonitor.FaultLatchCount = FAULT_RESTART_CYCLES;
    FaultMonitor.FaultRecoveryCounter = 0;
    
    return(retval);
}

/*********************************************************************************
 * @fn     uint16_t appFaultMonitor_Start(void) 
 * @ingroup app-layer-fault-handler-functions-public
 * @brief  Function starting all pre-configured fault checks
 * @return 0=failure 
 * @return 1=success
 * 
 * @details
 *   This function is used to set the fault status of all fault objects 
 *   to ACTIVE, enforcing the system monitor to clear them one-by-one as 
 *   default startup self-test procedure. Once cleared, the respective 
 *   recovery procedures will turn on the respective user-tasks being
 *   kept on-hold while faults have been active.
 * 
 *   Users can set the initial state of each fault object in accordance
 *   to their inclusion in the self-test period at firmware startup.
 * 
 *********************************************************************************/

uint16_t appFaultMonitor_Start(void) 
{
    fltobj_Buck_OVP.Status.bits.FaultStatus = true; // Clear Output Over Voltage Protection fault
    fltobj_Buck_OVP.Status.bits.FaultActive = true; // Clear Output Over Voltage Protection fault condition indicator
    fltobj_Buck_OVP.Status.bits.Enabled = true; // Disable Output Over Voltage Protection object 
    fltobj_Buck_OVP.Counter=0;
    
    fltobj_Buck_RegErr.Status.bits.FaultStatus = false; // Clear Regulation Error fault
    fltobj_Buck_RegErr.Status.bits.FaultActive = false; // Clear Regulation Error fault condition indicator
    fltobj_Buck_RegErr.Status.bits.Enabled = false; // Disable Regulation Error object (will be enabled by power supply state machine)
    fltobj_Buck_RegErr.Counter=0;
//    fltobj_PsfbVbulkOk.Status.bits.FaultStatus = false; // Clear Grid AC VOltage Synchronization fault
//    fltobj_PsfbVbulkOk.Status.bits.FaultActive = false; // Clear Grid AC VOltage Synchronization fault condition indicator
//    fltobj_PsfbVbulkOk.Status.bits.Enabled = true; // Disable Grid AC VOltage Synchronization fault object 
    
    return(1);
}

/*********************************************************************************
 * @fn     uint16_t appFaultMonitor_Dispose(void) 
 * @ingroup app-layer-fault-handler-functions-public
 * @brief  Function clearing all fault object settings
 * @return 0=failure 
 * @return 1=success
 * 
 * @details
 *   This function is used to clear all fault objects settings. Once cleared,
 *   the fault objects are detached from memory addresses and cannot be used
 *   for fault monitoring anymore until they have been re-initialized.
 * 
 *********************************************************************************/

uint16_t appFaultMonitor_Dispose(void) {
    
    // Clear all user defined fault objects
    drv_FaultHandler_Dispose(FaultObjectList, FaultObjectList_size);
    
    return(1);
}

// end of file
