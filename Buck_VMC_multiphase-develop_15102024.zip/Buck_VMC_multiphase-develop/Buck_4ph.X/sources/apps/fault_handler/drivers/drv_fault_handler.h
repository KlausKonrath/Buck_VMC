/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * @file    drv_fault_handler.h
 * @author  M91406
 * @brief   Global, generic fault handler header file
 * @version 1.0
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef FAULT_HANDLER_H
#define	FAULT_HANDLER_H

#include <stdint.h> // include standard integer types 
#include <stdbool.h> // include standard boolean types  
#include <stddef.h> // include standard definitions  

/**
 * @ingroup lib-layer-fault-properties-public-data-types
 * @{
 */
/***********************************************************************************
 * @enum FLT_COMPARE_TYPE_e
 * @brief This data structure is comprised of fault comparison types
 * @extends FLT_OBJECT_STATUS_s
 *********************************************************************************/
enum FLT_COMPARE_TYPE_e {
    
	FLTCMP_NONE				= 0, ///<  No comparison type has been defined (fault object will be ignored)
	FLTCMP_GREATER_THAN		= 1, ///<  Check for condition: SOURCE > trip level
	FLTCMP_LESS_THAN		= 2, ///<  Check for condition: SOURCE < trip level
	FLTCMP_IS_EQUAL			= 3, ///<  Check for condition: SOURCE = trip level
	FLTCMP_IS_NOT_EQUAL		= 4, ///<  Check for condition: SOURCE != trip level
	FLTCMP_BETWEEN			= 5, ///<  Check for condition: (reset_level < SOURCE) && (SOURCE < trip_level)
	FLTCMP_OUTSIDE			= 6  ///<  Check for condition: (SOURCE < reset_level) || (trip_level < SOURCE)
        
}; ///< Fault handler compare type enumeration
typedef enum FLT_COMPARE_TYPE_e FLT_COMPARE_TYPE_t; ///< Fault handler compare type enumeration data type

/**********************************************************************************
 * @struct FLT_OBJECT_STATUS_s
 * @brief This data structure defines the fault object status
 * @extends FAULT_OBJECT_s
 *********************************************************************************/
struct FLT_OBJECT_STATUS_s {

    bool FaultStatus : 1;               ///< Bit 0: Flag bit indicating if FAULT has been tripped
	bool FaultActive : 1;               ///< Bit 1: Flag bit indicating if fault condition has been detected but FAULT has not been tripped yet
	unsigned : 6;                       ///< Bit <7:2>: (reserved)
	FLT_COMPARE_TYPE_t CompareType: 3;	///< Bit <10:8>: Fault check comparison type control bits
	unsigned : 4;                       ///< Bit 14: (reserved)
	bool Enabled : 1;                   ///< Bit 15: Control bit enabling/disabling monitoring of the fault object
        
}__attribute__((packed)); // Fault object status bit field for single bit access

/**********************************************************************************
 * @union FLT_OBJECT_STATUS_u
 * @brief This data structure defines the fault object status
 * @extends FAULT_OBJECT_s
 *********************************************************************************/
union FLT_OBJECT_STATUS_u
{
    struct FLT_OBJECT_STATUS_s bits; // Fault object status bit-field
    uint16_t value;		// Fault object status word  
};
typedef union FLT_OBJECT_STATUS_u FLT_OBJECT_STATUS_t; ///< Fault object status data type

/**********************************************************************************
 * @struct FLT_COMPARE_OBJECT_s
 * @brief This data structure defines the data object which will be monitored by the fault handler
 * @extends FAULT_OBJECT_s
 *********************************************************************************/
struct FLT_COMPARE_OBJECT_s {
    
    uint16_t* ptrObject;   ///< Pointer to register or variable which should be monitored 
    uint16_t bitMask;      ///< Bit mask will be &-ed with source as value (use 0xFFFF for full value comparison)
    
}; ///< Fault compare object
typedef struct FLT_COMPARE_OBJECT_s FLT_COMPARE_OBJECT_t; ///< Fault compare object data type

/**********************************************************************************
 * @struct  FLT_EVENT_RESPONSE_s
 * @brief   This data structure defines the fault monitor event response object
 * @extends FAULT_OBJECT_s
 *********************************************************************************/
struct FLT_EVENT_RESPONSE_s {
    
    uint16_t compareThreshold;             ///< Signal level at which the fault condition will be detected
    uint16_t eventThreshold;               ///< Bit mask will be &-ed with source as value (use 0xFFFF for full value comparison)
    uint16_t (*ptrResponseFunction)(void); ///< pointer to a user-defined function called when a defined fault monitoring event is detected
    
}; ///< Fault monitor event response object
typedef struct FLT_EVENT_RESPONSE_s FLT_EVENT_RESPONSE_t;	///< Fault monitor event response object data type

/**********************************************************************************
 * @struct  FAULT_MONITOR_STATUS_s
 * @brief   This data structure defines the data object holding status information of the fault handler
 * @extends FAULT_OBJECT_s
 *********************************************************************************/
struct FAULT_MONITOR_STATUS_s {
    union {
        struct {
        bool FaultStatus : 1;  ///< Bit 0: Flag bit indicating if a FAULT condition has been tripped
        bool FaultLatch : 1;   ///< Bit 1: Flag bit indicating if a latched FAULT condition has been enforced
		unsigned : 14;         ///< Bit <15:2>: (reserved)
	} __attribute__((packed)) bits;     ///< Fault monitor status bit field for single bit access  
	uint16_t value;            ///< Fault monitor status word  
    };
};
typedef struct FAULT_MONITOR_STATUS_s FAULT_MONITOR_STATUS_t;

/**********************************************************************************
 * @struct FAULT_MONITOR_s
 * @brief  Common fault monitor settings
 *********************************************************************************/
struct FAULT_MONITOR_s {
    FAULT_MONITOR_STATUS_t Status;     ///< Status word of the fault monitor
    uint16_t FaultStatusList;          ///< Status word encoding individual fault object states in order of their list index
    uint16_t FaultRecoveryCounter;     ///< Most recent number of fault recovery attempts
    uint16_t FaultLatchCount;          ///< Number of fault recovery attempts after which the system gets locked in a latched fault state
    uint16_t (*FaultRecovery)(void);   ///< Function pointer to the common fault recovery function
};
typedef struct FAULT_MONITOR_s FAULT_MONITOR_t;


/** @} */ // end of group



#endif	/* FAULT_HANDLER_H */

