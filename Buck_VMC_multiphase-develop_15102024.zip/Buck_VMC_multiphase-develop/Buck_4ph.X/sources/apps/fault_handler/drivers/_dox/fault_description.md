fault monitor {#fault-monitor-description}
=====================

The fault handler is an independent firmware task, based on a fault monitor library, which is used to define certain so-called Fault Objects. A 'Fault Object' represents a value of a special function register or global user variable, which will monitored and validated by the Fault Monitor Library. The Library supports different comparisons for validation, such as 

- Greater Than
- Less Than
- Equal
- Not Equal
- Within Range
- Out Of Range

Fault Monitor source values are either compared against a user-defined constant (static threshold), or another variable (dynamic threshold). THe Fault Monitor further supports two thresholds, one defining the Fault Trip Level and a second Fault Recovery Level. Depending on the type of comparison selected, the range between both thresholds is either interpreted as hysteresis or range. (see **Fault Handler Library** for details)

The fundamental mechanism of detecting fault conditions and creating trip and recovery responses is based on a simple, adjustable detection filter, which does not influence the monitored value but delays the response of the software. Depending on the type of value monitored, the firmware may need to react sooner or later while the fault detection sensitivity needs to be adjusted accordingly to prevent the power supply from unintended shut downs.

The delay filter counts successive threshold violations, comparing the most recent counter value against an absolute, user-defined maximum. When one sample of the monitored value does *not* violate the given threshold, the counter is reset and starts incrementing from zero at the next threshold detection. When the monitored value remains violating the given threshold until the counter reaches or exceeds the defined maximum counter value, the power supply shut down event is triggered, turning off PWM outputs and control loops and resetting the state machine, waiting for the fault condition to disappear. 

<p>
  <center>
    \image html fault_trip.png width=540 
  </center>
</p>
<p><center><i>Fault Detection</i></center></p>

Recovering from a fault condition uses the same mechanism, but provides its individual set of parameters. Thus, fault trip responses can be adjusted to be aggressive while recovery events can be further delayed to prevent the end-product from falling into an undesired, high frequency shut-down/restart cycle.

<p>
  <center>
    \image html fault_recovery.png width=540 
  </center>
</p>
<p><center><i>Fault Recovery</i></center></p>

#### The most recent firmware version supports the following fault objects:

- **Under Voltage Lock Out (UVLO)**
  When the input voltage drops below the specified minimum voltage, the power supply is shut down, waiting for the input voltage to recover. If the power has been cut, the power supply will remain off until all capacitors are discharged and the microcontroller (MCU) shuts down. The PWM inputs of teh FET driver are pulled low until that point. The MCU drops out at voltages below 2.9V, which is below the UVLO level of teh FET driver. Hence, the gate drive signals remain pulled to off-state continuously without the chance to accidentally turn on.
<br>
- **Over Voltage Lock Out (UVLO)**
  When the input voltage exceeds the specified absolute maximum value, the power supply is shut down. waiting for the input voltage to drop back into the specified range. Auxiliary power supply, feedback voltage dividers and the power FETs support input voltages of up to 20V above the specified maximum to allow proper tracking of the input voltage even under fault conditions.
<br>
- **Regulation Error (RegErr)**
  This fault object continuously monitors the deviation between output voltage and control reference. With a small deviation and a time delay, which allows normal voltage drops and overshoots during load transients, this fault object is the last line of defense. Any fault condition which cannot be detected by the other fault objects, such as internal short circuits, oscillating feedback loops or failing components, will inevitably result in larger deviations of the output voltage from the given reference and will lead to a protective shut down of the power supply.
<br>

#### Optional fault objects:

- **Over Current Protection (OCP)** *(optional)*
  The over current protection requires a very fast response in comparison to voltage monitors. Hence, two successive threshold violations are enough to trip an over current fault condition, shutting down the power supply. As an over current fault condition disappears instantly when the power supply has been shut down, the recovery delay needs to be significantly expended to result in a decent fault response behavior of the end-product.
<br>
- **Over Temperature Warning (OTW)** *(optional)*
  The over temperature warning is commonly triggered when the board or system temperature exceeds a threshold value, which is still within the safe operating area but is higher than under commonly expected conditions. The warning allows state machines to take counter measures (e.g. power derating, partial load drop) if possible helping to reduce power losses. In systems where active counter measures are not an option, communication with the load could prevent fatal system failures. However, any measures taken are highly application dependent and have to be implemented as proprietary user functions.
<br>
- **Over Temperature Protection (OTP)** *(optional)*
  The over temperature protection is triggered when the board or system temperature exceeds a absolute maximum threshold value, at which the system has to be shut down to prevent permanent damage. It is recommended to include a wide hysteresis to allow the board to cool down significantly before initiating a restart attempt to prevent the power converter from ending up in a frequent shut-down/restart cycle.
<br>

---
© 2022, Microchip Technology Inc.