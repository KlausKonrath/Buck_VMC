/* 
 * File:   app_comm_config.h
 * Author: M91406
 *
 * Created on February 27, 2024, 9:19 AM
 */

#ifndef APPLICATION_LAYER_COMM_PROTOCOL_H
#define	APPLICATION_LAYER_COMM_PROTOCOL_H

#include "common/p33c_plib/uart/IUartHandler.h"
#include "svc/svc_comm_engine.h"

/*********************************************************************************
 * @ingroup apps-layer-comm-data-objects
 * @brief   User-defined Status Data Frame to be sent periodically
**********************************************************************************/

union FrmData16b_u {
struct {
    uint8_t low;
    uint8_t high;
}byte;
uint16_t value;       
};
typedef union FrmData16b_u FrmData16b_t;

struct STATUS_FRAME_s {
    uint16_t HighVoltage;       // Voltage present at high voltage port 
    uint16_t LowVoltage;        // Voltage present at low voltage port 
    uint16_t InductorCurrent;   // Inductor current present in single phase
    uint16_t AverageCurrent;    // Total average current present in all phases
    uint16_t Temperature;       // Board temperature
    uint16_t Status;            // Converter status information
    uint16_t StateId;           // ID if converter state machine
};
typedef struct STATUS_FRAME_s STATUS_FRAME_t;

/* **************************************** */
/* Common UART protocol function prototypes */
/* **************************************** */

/* **************************************** */
/* BECOM Commands                           */
/* **************************************** */
#define CMD_REQ_GET_VALUE           (uint8_t)0x10                               // request command for get desired values
#define CMD_RESP_GET_VALUE          (uint8_t)0x11                               // response command for get desired values
#define CMD_GET_VALUE_DATA_LENGTH   (uint8_t)30U                                // length of data bytes in response frame
#define CMD_GET_VALUE_FRAME_LENGTH  (uint8_t)35U                                // length of response frame

#define CMD_REQ_GET_FIRMWARE            (uint8_t)0x20                           // request command for get desired values
#define CMD_RESP_GET_FIRMWARE           (uint8_t)0x21                           // response command for get desired values
#define CMD_GET_FIRMWARE_DATA_LENGTH    (uint8_t)4U                             // length of data bytes in response frame
#define CMD_GET_FIRMWARE_FRAME_LENGTH   (uint8_t)9U                             // length of response frame


#define CMD_REQ_SET_COMP_VOLTAGE           (uint8_t)0x30                        // request command for get desired values
#define CMD_RESP_SET_COMP_VOLTAGE          (uint8_t)0x31                        // response command for get desired values
#define CMD_SET_COMP_VOLTAGE_DATA_LENGTH   (uint8_t)1U                          // length of data bytes in response frame
#define CMD_SET_COMP_VOLTAGE_FRAME_LENGTH  (uint8_t)6U                          // length of response frame


#define CMD_RESP_ERROR              (uint8_t)0xFF                               // response command for get desired values
#define CMD_ERROR_DATA_LENGTH       (uint8_t)1U                                 // length of data bytes in response frame
#define CMD_ERROR_FRAME_LENGTH      (uint8_t)6U                                 // length of response frame

/* **************************************** */
/* Common User Commands                     */
/* **************************************** */

#define COMMCMD_STATUS      (uint8_t)0x54           // Command 'T'       
#define COMMCMD_GET_STATUS  (uint8_t)0x74           // Command 't'       // Periodic Status Message
extern int CommGetStatusFrame(COMM_FRAME_t* frame); // Get Periodic Transmission State of power supply status message

#define COMMCMD_SET_LVREF   (uint8_t)0x41           // Command 'A'
#define COMMCMD_GET_LVREF   (uint8_t)0x61           // Command 'a'
extern int CommSetLvReference(COMM_FRAME_t* frame); // Set LV Reference
extern int CommGetLvReference(COMM_FRAME_t* frame); // Get LV Reference

#define COMMCMD_SET_HVREF   (uint8_t)0x42           // Command 'B'
#define COMMCMD_GET_HVREF   (uint8_t)0x62           // Command 'b'
extern int CommSetHvReference(COMM_FRAME_t* frame); // Set HV Reference
extern int CommGetHvReference(COMM_FRAME_t* frame); // Get HV Reference

#define COMMCMD_SET_DILIM   (uint8_t)0x43           // Command 'C'
#define COMMCMD_GET_DILIM   (uint8_t)0x63           // Command 'c'
extern int CommSetCurrentLimit(COMM_FRAME_t* frame); // Set Step-Down Current Limit
extern int CommGetCurrentLimit(COMM_FRAME_t* frame); // Get Step-Down Current Limit

#define COMMCMD_SET_UILIM   (uint8_t)0x44           // Command 'D'
#define COMMCMD_GET_UILIM   (uint8_t)0x64           // Command 'd'
extern int CommSetAltCurrentLimit(COMM_FRAME_t* frame); // Set Step-Up Current Limit
extern int CommGetAltCurrentLimit(COMM_FRAME_t* frame); // Get Step-Up Current Limit

#define COMMCMD_SET_PWREN   (uint8_t)0x45           // Command 'E'
#define COMMCMD_GET_PWREN   (uint8_t)0x65           // Command 'e'
extern int CommSetPowerSupplyEnable(COMM_FRAME_t* frame); // Set Power Supply Enable State
extern int CommGetPowerSupplyEnable(COMM_FRAME_t* frame); // Get Power Supply Enable State

#define COMMCMD_SET_PWRSWP  (uint8_t)0x53           // Command 'S'
#define COMMCMD_GET_PWRSWP  (uint8_t)0x73           // Command 's'
extern int CommSetConversionSwap(COMM_FRAME_t* frame);  // Trigger power supply conversion mode swap
extern int CommGetConversionSwap(COMM_FRAME_t* frame);  // Get power supply conversion mode and swap settings


#define COMMCMD_SET_RAWDAT (uint8_t)0x59            // Command 'Y'
#define COMMCMD_GET_RAWDAT (uint8_t)0x79            // Command 'y'
extern int CommSetRawDataFrameEnable(COMM_FRAME_t* frame); // Set data format of periodic state frame contents
extern int CommGetRawDataFrameEnable(COMM_FRAME_t* frame); // Get data format of periodic state frame contents

#define COMMCMD_SET_STFEN  (uint8_t)0x5A            // Command 'Z'
#define COMMCMD_GET_STFEN  (uint8_t)0x7A            // Command 'z'
extern int CommSetStatusFrameEnable(COMM_FRAME_t* frame); // Set continuous periodic state frame transmission
extern int CommGetStatusFrameEnable(COMM_FRAME_t* frame); // Get state frame (if periodic transmission is off)

/* ******************************************************* */
/* Special Commands for Development and Bench-Testing Only */
/* ******************************************************* */

#define COMMCMD_SET_OLPEN   (uint8_t)0x4F           // Command 'O'
#define COMMCMD_GET_OLPEN   (uint8_t)0x6F           // Command 'o'
extern int CommSetOpenLoopEnable(COMM_FRAME_t* fram); // Command 'O'
extern int CommGetOpenLoopEnable(COMM_FRAME_t* fram); // Command 'O'

#define COMMCMD_SET_PDC     (uint8_t)0x46           // Command 'F'
#define COMMCMD_GET_PDC     (uint8_t)0x66           // Command 'f'
extern int CommSetDutyCycle(COMM_FRAME_t* frame);   // Set PWM Duty Cycle Value
extern int CommGetDutyCycle(COMM_FRAME_t* frame);   // Get PWM Duty Cycle Value

#endif	/* APPLICATION_LAYER_COMM_PROTOCOL_H */

