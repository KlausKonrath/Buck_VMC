/* 
 * @file    app_comm_functions.h
 * @author  M91406
 * @date    March 12, 2024
 */

#ifndef APP_COMM_CONFIG_H
#define	APP_COMM_CONFIG_H

// Buffer size declarations
#define RX_BUFFER_COUNT  2U
#define RX_BUFFER_SIZE   64U

#define TX_BUFFER_COUNT  2U
#define TX_BUFFER_SIZE   64U



#endif	/* APP_COMM_CONFIG_H */

