/* 
 * @file    svc_comm_engine.c
 * @author  M91406
 * @brief   Communication protocol driver
 * @version 1.0
 */

#include <xc_pral.h>
#include "svc_comm_engine.h"
#include "apps\comm\app_comm_protocol.h"
#include "config/apps.h"
#include "./apps/power_control/devices/dev_buck_4ph_typedef.h"   // include  Converter type definitions
#include "./apps/power_control/devices/dev_psfb_converter.h" // include  Converter object header
#include "./apps/power_control/devices/dev_psfb_pconfig.h"
#include "./apps/power_control/drivers/vout_loop_vmc.h"   
#include "./apps/power_control/drivers/vout_loop_agc.h"  

// Declare UART data object defining the interface to use for communication
static int CommReceiveDataStream(uint8_t* dataArray, uint16_t dataSize);

/* UART Debug response statemachine */
static void CommResponseStateMachine(void);

// RxD Frame Tracker Data Object
COMM_FRAME_t rxFrame;
bool dataProcessing = false;
bool dataTransmission = false;

extern uint16_t CompVoltage;

/*********************************************************************************
 * @ingroup apps-layer-comm-functions-public
 * @brief   UART Receive Frame Reset Routine 
**********************************************************************************/
int CommFrameReset(void)
{
    rxFrame.Command = 0;
    rxFrame.DataLen = 0;
    rxFrame.ptrData = 0;
    rxFrame.State = 0;
    rxFrame.Ready = false; 
    rxFrame.Busy = false;
    
    for (int i=0; i<RxDataBuffer.Size; i++)
    { CmdBuffer[i] = 0; }
    
    return(1);
}

/*********************************************************************************
 * @ingroup apps-layer-comm-functions-public
 * @brief   UART Read Data from DMA Buffer
**********************************************************************************/
int CommDmaReceive(UART_t* comInterface)
{
    int retval = 1;
    static int receiveCounter=0;
    static bool ppPtr=0;
    static int receiveWait=0;

    // Capture DMA channel instance used by application
    P33C_DMA_INSTANCE_t* dma = p33c_DmaInstance_GetHandle(comInterface->CommPort.RxD.DmaInstance);
    
    // Guarding condition 
    if (0 == dma->DMAINTx.bits.DONEIF) { return(retval); }
    if (true == dataProcessing) { return(retval); }
    
    // Only ready data from DMA buffer when no more data has been received
    uint16_t dmaPtr = dma->DMADSTx.value; // Capture recent receive DMA memory address
    if (receiveCounter != dmaPtr)   // Check if address has changed since last time
    { receiveCounter = dmaPtr; receiveWait = 0; return(retval); }
    if (++receiveWait < 3) { return(retval); }
    
    // Check if there is data to read
    int dlen = dmaPtr - (uint16_t)(&rxBufferDma[ppPtr][0]);
    if (dlen == 0) { receiveCounter = dmaPtr; return(retval); }

    bool ppPtrX = ppPtr; // Capture most recent DMA buffer pointer
    ppPtr = !ppPtr; // switch to other DMA buffer
    dma->DMADSTx.value = (uint16_t)(&rxBufferDma[ppPtr][0]); // Set DMA to other buffer 
    dma->DMAINTx.bits.DONEIF = 0; // Clear DMA DONE flag bit

    dataProcessing = true;

    // RX buffer is rxBufferDma[ppPtrX][0]
    // Call data processing here
    retval &= CommReceiveDataStream((uint8_t*)&rxBufferDma[ppPtrX][0], dlen);

    receiveWait = 0;
    receiveCounter = 0;
    dataProcessing = false;
    
    /* check if valid frame was received */
    if(retval == 1)
    {
        /* check rx-Frame ready flag */
        if(rxFrame.Ready == true)
        {
            /* call response-statemachine */
            CommResponseStateMachine();
            
            /* clear rx-Frame ready flag */
            rxFrame.Ready = false;
        }
        else
        {
            /* rx-Frame not ready - do nothing */
        }
    }
    else
    {
        /* no frame or no valid frame received - do nothing */
    }
    
    return(retval);
}

static int CommProcessData(uint8_t dataByte)
{
    int retval = 1;
    
    if ((COMMSTAT_SOF==rxFrame.State) && (COMM_SOF!=dataByte)) 
    {
        retval = 0;
        return(retval);
    }
    bool doReset = false;

    // Do not receive new commands until previous command has been processed
    if ((false == rxFrame.Ready) && (false == doReset))
    {
        rxFrame.Busy = true;

        switch (rxFrame.State) 
        { 
            case COMMSTAT_SOF: // SOF byte received

                if (COMM_SOF == dataByte)
                {
                    rxFrame.ptrData = 0;
                    rxFrame.State = COMMSTAT_CMD; 
                    rxFrame.CRC = COMM_CRC_SEED;
                }
                else { doReset = true; }

                break;

            case COMMSTAT_CMD: // command byte received

                rxFrame.Command = dataByte;
                rxFrame.State = COMMSTAT_DLEN; 
                rxFrame.CRC ^= dataByte;

                break;

            case COMMSTAT_DLEN: // data length byte received

                rxFrame.DataLen = dataByte;
                rxFrame.State = ((rxFrame.DataLen != 0) ? COMMSTAT_DATA : COMMSTAT_EOM); 
                rxFrame.ptrData = 0;
                rxFrame.CRC ^= dataByte;

                break;

            case COMMSTAT_DATA: // receiving data content 

                if (rxFrame.ptrData < rxFrame.DataLen)
                { 
                    CmdBuffer[rxFrame.ptrData] = dataByte; 
                }
                
                rxFrame.CRC ^= dataByte;

                if (++rxFrame.ptrData >= rxFrame.DataLen)
                { 
                    rxFrame.State = COMMSTAT_EOM; // BYPASSING CRC BYTE
                }

                break;

            case COMMSTAT_CRC: // checksum byte received

                if (rxFrame.CRC == dataByte) 
                {
                    rxFrame.State = COMMSTAT_DATA; 
                    rxFrame.ptrData = 0;
                }
                else { doReset = true; }
                break;

            case COMMSTAT_EOM: // end of message byte received

                if (COMM_EOM == dataByte)
                {
                    rxFrame.State = COMMSTAT_EOF; 
                    rxFrame.ptrData = 0;
                }
                else { doReset = true; }
                break;

            case COMMSTAT_EOF: // end of frame byte received

                if (COMM_EOF == dataByte)
                {
                    rxFrame.State = COMMSTAT_SOF;
                    rxFrame.Ready = true; 
                    rxFrame.Busy = false;
                }
                else { doReset = true; }

                break;

            default: // Frame format error
                doReset = true; 
                break;
        }

    }

    // Reset frame in case of a frame error
    if (true == doReset)
    {
        rxFrame.FrameErr++;
        retval &= CommFrameReset();
        
        retval = 0;
    }
    
    return(retval);
    
}

static int CommReceiveDataStream(uint8_t* dataArray, uint16_t dataSize)
{
    int retval = 1;
    
    for (int i=0; i<dataSize; i++)
    {
        uint8_t rxByte = *dataArray;
        *dataArray = 0x00;

        retval &= CommProcessData(rxByte);

        if ((rxFrame.Ready) && (rxFrame.CallRxCommandParser != NULL))
        { 
            Nop();
            Nop();
            Nop();

            retval &= rxFrame.CallRxCommandParser(); 
        }
        else if (false == retval) { break; }

        dataArray++;
    }
    
    return(retval);
    }

static void CommResponseStateMachine(void)
{
    uint8_t response_array[35U];
    uint8_t frame_length = 0x00U;
    uint16_t tmp_calc = 0x0000U;
    uint32_t tmp_Data = 0;
 
    /* check command byte of request message */
    switch (rxFrame.Command)
    {
        case CMD_REQ_GET_VALUE:
               
            response_array[0U] = COMM_SOF;                                      // set Start Of Frame
            response_array[1U] = CMD_RESP_GET_VALUE;                            // set Command
            response_array[2U] = CMD_GET_VALUE_DATA_LENGTH;                     // set length of data bytes
            
            /* DATA - START */
            response_array[3U] = (uint8_t)buck_4ph.Data.Vin_phys;               // U-IN-ADC LSB
            response_array[4U] = (uint8_t)(buck_4ph.Data.Vin_phys >> 8U);       // U-IN-ADC MSB
            
            response_array[5U] = (uint8_t)buck_4ph.Data.Vin_prot_phys;          // U-IN-PROT-ADC LSB
            response_array[6U] = (uint8_t)(buck_4ph.Data.Vin_prot_phys >> 8U);  // U-IN-PROT-ADC MSB
            
            response_array[7U] = (uint8_t)buck_4ph.Data.V_dcdc_phys;            // U-DCDC-ADC LSB
            response_array[8U] = (uint8_t)(buck_4ph.Data.V_dcdc_phys >> 8U);    // U-DCDC-ADC MSB
            
            response_array[9U] = (uint8_t)buck_4ph.Data.Vout_phys;              // U-REGLER-ADC LSB
            response_array[10U] = (uint8_t)(buck_4ph.Data.Vout_phys >> 8U);     // U-REGLER-ADC MSB
            
            response_array[11U] = (uint8_t)buck_4ph.Data.V_motor_phys;          // U-MOTOR-ADC LSB
            response_array[12U] = (uint8_t)(buck_4ph.Data.V_motor_phys >> 8U);  // U-MOTOR-ADC MSB
            
            response_array[13U] = (uint8_t)buck_4ph.Data.V_24volt_phys;         // U-24V-ADC LSB
            response_array[14U] = (uint8_t)(buck_4ph.Data.V_24volt_phys >> 8U); // U-24V-ADC MSB
            
            response_array[15U] = (uint8_t)buck_4ph.Data.V_aux_phys;            // U-AUX-ADC LSB
            response_array[16U] = (uint8_t)(buck_4ph.Data.V_aux_phys >> 8U);    // U-AUX-ADC MSB
            
            response_array[17U] = (uint8_t)buck_4ph.Data.Ibuck1_phys;           // I-800W-PH1-ADC LSB
            response_array[18U] = (uint8_t)(buck_4ph.Data.Ibuck1_phys >> 8U);   // I-800W-PH1-ADC MSB
            
            response_array[19U] = (uint8_t)buck_4ph.Data.Ibuck2_phys;           // I-800W-PH2-ADC LSB
            response_array[20U] = (uint8_t)(buck_4ph.Data.Ibuck2_phys >> 8U);   // I-800W-PH2-ADC MSB
            
            response_array[21U] = (uint8_t)buck_4ph.Data.Ibuck3_phys;           // I-800W-PH3-ADC LSB
            response_array[22U] = (uint8_t)(buck_4ph.Data.Ibuck3_phys >> 8U);   // I-800W-PH3-ADC MSB
            
            response_array[23U] = (uint8_t)buck_4ph.Data.Ibuck4_phys;           // I-800W-PH4-ADC LSB
            response_array[24U] = (uint8_t)(buck_4ph.Data.Ibuck4_phys >> 8U);   // I-800W-PH4-ADC MSB
            
            response_array[25U] = (uint8_t)buck_4ph.Data.I_200watt_phys;        // I-200W-ADC LSB
            response_array[26U] = (uint8_t)(buck_4ph.Data.I_200watt_phys >> 8U);// I-200W-ADC MSB
            
            response_array[27U] = (uint8_t)CompVoltage;                         // Comparator Voltage LSB
            response_array[28U] = (uint8_t)(CompVoltage >> 8U);                 // Comparator Voltage MSB
            
            
            /*  ---------------
                InternalSignals 
                ---------------  */

            /* clear temporary variable */
            tmp_Data = 0U;

            /* load U-Comp */
            tmp_Data |= converterGPIO_GetPinState(&buck_4ph.Gpio.V_Comparator);

            /* load EN_DCDC_IdealDiode */
            tmp_Data |= (converterGPIO_GetPinState(&buck_4ph.Gpio.EN_DCDC_Idealdiode) << 1U);

            /* load EN_DCDC_Inrush */
            tmp_Data |= (converterGPIO_GetPinState(&buck_4ph.Gpio.EN_DCDC_Inrush) << 2U);

            /* load EN_Inrush */
            tmp_Data |= (converterGPIO_GetPinState(&buck_4ph.Gpio.EN_Inrush) << 3U);

            /* load EN_Bypass */
            tmp_Data |= (converterGPIO_GetPinState(&buck_4ph.Gpio.EN_Bypass) << 4U);

            /* load PowerGood_Aux_Buck */
            tmp_Data |= (converterGPIO_GetPinState(&buck_4ph.Gpio.PowerGood_Aux_Buck) << 5U);

            /* load PowerGood_5V_Buck */
            tmp_Data |= (converterGPIO_GetPinState(&buck_4ph.Gpio.PowerGood_5V_Buck) << 6U);

            /* load Dis_U_200Watt */
            tmp_Data |= (converterGPIO_GetPinState(&buck_4ph.Gpio.Dis_U_200Watt) << 7U);

            /* load U_CTRL_PWM_DAC */
//TODO: was soll zur�ckgegeben werden???                tmp_Data |= (??) << 8U);

            /* load PowerGood_200Watt */
            tmp_Data |= (converterGPIO_GetPinState(&buck_4ph.Gpio.PowerGood_200Watt) << 9U);

            /* load PowerGood_FC_Dart_Buck */
            tmp_Data |= (converterGPIO_GetPinState(&buck_4ph.Gpio.PowerGood_FC_Dart_Buck) << 10U);



            /* load LSB Binary control/feedback Signals bitwise encoded */
            response_array[29U] = (uint8_t)tmp_Data;

            /* load Binary control/feedback Signals bitwise encoded */
            response_array[30U] = (uint8_t)(tmp_Data >> 8U);

            /* load Binary control/feedback Signals bitwise encoded */
            response_array[31U] = (uint8_t)(tmp_Data >> 16U);

            /* load MSB Binary control/feedback Signals bitwise encoded */
            response_array[32U] = (uint8_t)(tmp_Data >> 24U);
                
            /* DATA - END */
            
            response_array[33U] = COMM_EOM;                     // set End Of Message
            response_array[34U] = COMM_EOF;                     // set End Of Frame
            
            /* set length of response frame */
            frame_length = CMD_GET_VALUE_FRAME_LENGTH;
          
        break;
        
        case CMD_REQ_GET_FIRMWARE:
               
            response_array[0U] = COMM_SOF;                                      // set Start Of Frame
            response_array[1U] = CMD_RESP_GET_FIRMWARE;                         // set Command
            response_array[2U] = CMD_GET_FIRMWARE_DATA_LENGTH;                  // set length of data bytes
            
            /* DATA - START */
            response_array[3U] = FIRMWARE_VERSION_MAJOR;                        // load major software version
            response_array[4U] = FIRMWARE_VERSION_MINOR;                        // load minor software version
            response_array[5U] = FIRMWARE_VERSION_PATCH;                        // load patch software version
            
            response_array[6U] = HARDWARE_VARIANT;                              // load hardware variant
            
            /* DATA - END */
            
            response_array[7U] = COMM_EOM;                                      // set End Of Message
            response_array[8U] = COMM_EOF;                                      // set End Of Frame
            
            /* set length of response frame */
            frame_length = CMD_GET_FIRMWARE_FRAME_LENGTH;
          
        break;

		case CMD_REQ_SET_COMP_VOLTAGE:
            
            /* prepare positive response */
            response_array[0U] = COMM_SOF;                                      // set Start Of Frame
            response_array[1U] = CMD_RESP_SET_COMP_VOLTAGE;                     // set Command
            response_array[2U] = CMD_SET_COMP_VOLTAGE_DATA_LENGTH;              // set length of data bytes
            response_array[3U] = 0x01;                                          // data byte
            response_array[4U] = COMM_EOM;                                      // set End Of Message
            response_array[5U] = COMM_EOF;                                      // set End Of Frame
            
            /* set length of response frame */
            frame_length = CMD_SET_COMP_VOLTAGE_FRAME_LENGTH;
            
            /* clear variable */
            CompVoltage = 0x0000U;

            /* load LSB value of comparator voltage */
            CompVoltage |= (uint16_t)CmdBuffer[0];

            /* load MSB value of comparator voltage */
            CompVoltage |= (uint16_t)(((uint16_t)CmdBuffer[1]) << 8U);

            /* check if max. allowed comparator voltage reached */
            if(CompVoltage > 0x41BEU)
            {
                /* do limitation */
                CompVoltage = 0x41BEU;
            }
            else
            {
                /* everything inner range - do nothing */
            }

            /* calculate PWM Duty Cycle --> y = 2,3767 * x */
            tmp_calc = (uint16_t)(((uint32_t)((uint32_t)((uint32_t)CompVoltage + (uint32_t)50) * (uint32_t)2434)) >> 10U);

            /* check if limitation is necessary */
            if(tmp_calc > PWM6_DC_100_PERC)
            {
                /* do limitation */
                tmp_calc = PWM6_DC_100_PERC;
            }
            else
            {
                /* everything is inner range - do nothing */
            }

            /* write new desired duty cylce */
            PG6DC = tmp_calc;
            
            /* set duty cycle update flag */
            PG6STATbits.UPDREQ = 1;
          
        break;

        default:
          
            /* wrong call - set default error message */
            response_array[0U] = COMM_SOF;                      // set Start Of Frame
            response_array[1U] = CMD_RESP_ERROR;                // set Error Command
            response_array[2U] = CMD_ERROR_DATA_LENGTH;         // set length of data bytes
            response_array[3U] = 0xFF;                          // Error data byte
            response_array[4U] = COMM_EOM;                      // set End Of Message
            response_array[5U] = COMM_EOF;                      // set End Of Frame
            
            /* set length of response frame */
            frame_length = CMD_ERROR_FRAME_LENGTH;
        
        break;
    
    }
    
    /* load desired TX message*/
    CommStageToTransmit(&response_array, frame_length);
}

/*********************************************************************************
 * @ingroup apps-layer-comm-functions-public
 * @brief   Puts messages into the transmit buffer
**********************************************************************************/
int CommStageToTransmit(uint8_t* dataArray, uint16_t dataSize)
{
    int retval = 1;
    
    // Guarding condition
    if (0 == dataSize) { return(retval); }
    if (NULL == dataArray) { return(retval); }
    
    for (int i=0; i<dataSize; i++)
    {
        if (TxDataBuffer.ArrayPointer >= txBufferSize) { retval = 0; break; }
        txBufferDma[TxDataBuffer.BufferPointer][TxDataBuffer.ArrayPointer++] = (*dataArray++);
    }
    
    TxDataBuffer.Ready = true;
    
    return(retval);
}


int CommDmaTransmit(UART_t* comInterface)
{
    int retval = 1;

    // Guarding condition 
    if (false == TxDataBuffer.Ready) { return(retval); }
    
    // Capture most recent buffer pointers
    int dlen = TxDataBuffer.ArrayPointer;   // Capture most recent DMA buffer index pointer
    int bufP = TxDataBuffer.BufferPointer;  // Capture most recent DMA buffer pointer
    if (0 == dlen) { return(retval); }      // Exit if there is no data to be sent

    // Set ping-pong buffer to next buffer
    if (++TxDataBuffer.BufferPointer >= TX_BUFFER_COUNT) // switch to next DMA buffer
    { TxDataBuffer.BufferPointer = 0; } // Manage overrun
    TxDataBuffer.ArrayPointer = 0; // Reset array index pointer
    TxDataBuffer.ptrData = (uint8_t*)&txBufferDma[TxDataBuffer.BufferPointer][0]; // Set pointer to most recent data buffer
    TxDataBuffer.Ready = false;
    
    // Initiate DMA data transfer 
    retval &= plib33c_Uart_SendBufferDma(comInterface, (uint8_t*)&txBufferDma[bufP][0], (uint16_t)dlen);
    
    if (0 == retval)
    {
        Nop();
        Nop();
        Nop();
        TxDataBuffer.Ready = true;
    }
    
    
    return(retval);
}

void __attribute__((__interrupt__, no_auto_psv)) VCP_RxInterrupt(void)
{
    Nop();
    Nop();
    Nop();
    
    //CommReceiveFrame(&Comm); // Call RECEIVE Routine
    VCP_Rx_IF = 0; // Clear Interrupt Flag Bit
}

void __attribute__((__interrupt__, no_auto_psv)) VcpErrInterrupt(void)
{
    Nop(); // Place Breakpoint here
    Nop();
    Nop();

    P33C_UART_INSTANCE_t* uart = p33c_UartInstance_GetHandle(Comm.CommPort.UartInstance);
    uart->UxSTA.value = 0;
    VCP_ErrIF = 0; // Clear Interrupt Flag Bit
}

// ______________________________________
// end of file
