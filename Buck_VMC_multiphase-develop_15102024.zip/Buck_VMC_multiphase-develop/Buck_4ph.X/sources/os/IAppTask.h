/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/**
 * @file    IAppTask.h
 * @author  M91406
 * @brief   Interface declaration of the Application Task Data Object
 * @date    02/07/2022
 * @details
 *   Revision history: 
 *    02/07/2022 | 1.0.0 | M91406 | Initial version
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef RTOS_TASK_DECLARATION_INTERFACE_H
#define	RTOS_TASK_DECLARATION_INTERFACE_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types

#include "core/apptask.h" // include application task data object definitions

/***********************************************************************************
 * @ingroup os-layer-rtos-properties-public-data-types
 * @brief Application task interface object
 * @details
 *  The application task object is wrapped around a user task added to the project
 * as building block and is managed by the task scheduler of the operating system.
 *
 **********************************************************************************/
struct IApplicationTask_s {
    
	APPTASK_STATUS_t     Status;        ///< Status word of the application task object (single 16-bit data field)
    APPTASK_TASKLINK_t   Functions;     ///< List of function pointers to main API application task functions
    APPTASK_TASKEVENTS_t Events;        ///< List of function pointers to built-in task event handlers
    APPTASK_PROPERTIES_t Properties;    ///< Task properties and settings
    APPTASK_STATISTICS_t Statistics;    ///< Application task execution time statistics information
        
}; ///<  Application task interface data structure
typedef struct IApplicationTask_s IApplicationTask_t; ///< Application Task Data Object data type


#endif	/* RTOS_TASK_DECLARATION_INTERFACE_H */

