/*
 * @file    boot.c
 * @brief   Target device boot routines
 * @author  M91406
 * @date    06/18/2021
 * @version 1.0.6
 */

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
#include <stddef.h> // include standard definition data types

/* INCLUDE DEFAULT SYSTEM COMPONENT INITIALIZATION MODULES */
#include "rtos_dsp.h"
#include "rtos_fosc.h"
#include "rtos_gpio.h"
#include "rtos_pmd.h"

#ifndef OS_EXECUTION_INTERFACE_HEADER_H
#define	OS_EXECUTION_INTERFACE_HEADER_H


#endif /* OS_EXECUTION_INTERFACE_HEADER_H */
