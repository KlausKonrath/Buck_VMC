/*
 * @file    rtos_fosc.c
 * @brief   Target device oscillator configuration routines
 * @author  M91406
 * @date    07/08/2019
 * @version 1.0.3
 */

#include <stdint.h> // include standard integer data types
#include "common/p33c_pral/xc_pral.h"

#define TIMEOUT_LIMIT   5000U   // timeout counter maximum

/***********************************************************************************
 * @ingroup os-layer-library-fosc-public-functions
 * @brief   System oscillator initialization
 * @return  unsigned integer (0=failure, 1=success)
 * 
 * @details
 * This function initializes the internal 8 MHz RC oscillator as the main
 * oscillator and initializes the PLL to operate the CPU at maximum performance 
 * of 100 MHz instruction cycle.
 * 
 **********************************************************************************/
uint16_t osFosc_Initialize(void) 
{
    uint16_t retval=1;
    
    retval = p33c_Osc_SetConfig(oscDefaultConfigFrc);
    
    return(retval);

}

/***********************************************************************************
 * @ingroup os-layer-library-fosc-public-functions
 * @brief   Initializes the auxiliary clock of the device
 * @return  unsigned integer (0=failure, 1=success)
 * 
 * @details
 * This function initializes the auxiliary PLL for operating ADC and PWM module
 * at maximum performance at an input clock of 500 MHz. Each peripheral module
 * may use additional frequency scalers and multipliers to further convert this
 * frequency.
 *
 **********************************************************************************/
uint16_t osAclk_Initialize(void) {

    uint16_t retval=1;

    retval &= p33c_Aclk_SetConfig(aclkDefaultConfigApll500);

    return(retval);
}

// _______________________________
// end of file

