/*
 * @file    rtos_dsp.c
 * @brief   Target device Digital Signal Processor (DSP) core configuration routines
 * @author  M91406
 * @date    10/16/2018
 * @version 1.0.6
 */

#include <stdint.h> // include standard integer data types
#include "common/p33c_pral/xc_pral.h"

static const P33C_DSP_CONFIG_t osDspDefaultConfig;

/***********************************************************************************
 * @ingroup os-layer-library-dsp-public-functions 
 * @brief   Digital Signal Processor initialization
 * @return  unsigned integer (0=failure, 1=success)
 * 
 * @details
 *   This routine initializes the default configuration of the 
 *   DSP core for performing SMPS control loop libraries.
 *   If any other section of the firmware needs to use the DSP 
 *   with different settings, this code module would have to 
 *   make sure the core configuration is reset to these defaults
 *   when the SMPS control library is executed.
 *  
 * @note: 
 *   The configuration of the control library allows to add its own 
 *   core configuration save & restore cycle in the control code.
 *   Please enable this function in the control loop configuration
 *   if conflicts between different DSP configurations cannot be 
 *   resolved differently within the firmware.
 *   This routine initializes the default configuration of the 
 *   DSP core for performing SMPS control loop libraries.
 *   If any other section of the firmware needs to use the DSP 
 *   with different settings, this code module would have to 
 *   make sure the core configuration is reset to these defaults
 *   when the SMPS control library is executed.
 *  
 *   The configuration of the control library allows to add its own 
 *   core configuration save & restore cycle in the control code.
 *   Please enable this function in the control loop configuration
 *   if conflicts between different DSP configurations cannot be 
 *   resolved differently within the firmware.
 *    
 **********************************************************************************/
uint16_t osDsp_Initialize(void) { return(p33c_Dsp_SetConfig(osDspDefaultConfig)); }

/****************************************************************************************************
 * @ingroup os-layer-library-dsp-private-functions 
 * @brief   Default Configuration of the Digital Signal Processor
 * 
 * @details
 *  Sets the default core configuration for fixed-point arithmetic required
 *  for processing power supply real-time feedback loop compensation filters.
 * 
 *  Uninitialized Register Bits:
 * 
 * .CORCON.bits.DL = CORCON_DL_0;              // (read only)
 * .CORCON.bits.EDT = CORCON_EDT_RUN;          // control bit => do not set during configuration
 * .CORCON.bits.SFA = CORCON_SFA_ACTIVE;       // (read only)
 * .CORCON.bits.IPL3 = CORCON_IPL3_STAT_LT7;   // (read only)
 *
 *************************************************************************************************** */
static const __attribute__((space(auto_psv)))  P33C_DSP_CONFIG_t osDspDefaultConfig = {
    
    .CORCON.bits.ACCSAT = CORCON_ACCSAT_131,    // Accumulator Saturation Mode Selection: 9.31 saturation (super saturation)
    .CORCON.bits.IF     = CORCON_IF_FRACTIONAL, // Integer or Fractional Multiplier Mode Selection: Fractional mode is enabled for DSP multiply
    .CORCON.bits.RND    = CORCON_RND_UNBIASED,  // Rounding Mode Selection: Unbiased (convergent) rounding is enabled
    .CORCON.bits.SATA   = CORCON_SATA_ON,       // ACCA Saturation Enable: Accumulator A saturation is enabled
    .CORCON.bits.SATB   = CORCON_SATB_ON,       // ACCB Saturation Enable: Accumulator B saturation is enabled
    .CORCON.bits.SATDW  = CORCON_SATDW_ON,      // Data Space Write from DSP Engine Saturation Enable: Data Space write saturation is enabled
    .CORCON.bits.US     = CORCON_US_SIGNED,     // DSP Multiply Unsigned/Signed Control: DSP engine multiplies are signed
    .CORCON.bits.VAR    = CORCON_VAR_FIXED      // Variable Exception Processing Latency Control: Fixed exception processing is enabled
    
};

// ________________________________
// end of file
