/*
 * @file    rtos_gpio.c
 * @brief   Target device General Purpose Input/Output (GPIO) configuration routines
 * @author  M91406
 * @date    07/08/2019
 * @version 1.0.6
 */


#include <stdint.h> // include standard integer data types
#include "common/p33c_pral/xc_pral.h"

/***********************************************************************************
 * @ingroup os-layer-library-gpio-public-functions
 * @brief   Resets the device input/output pins to digital inputs
 * @return  unsigned integer (0=failure, 1=success)
 * 
 * @details
 *  When the device is coming out of RESET, all device pins are configured as
 *  inputs and all analog functions will be enabled. Enabled analog functions
 *  are a potential source for conflicts and are therefore turned off by default
 *  during device startup to allow all peripheral configuration drivers to start
 *  from a defined default state.
 *
 **********************************************************************************/
uint16_t osGpio_Initialize(void) {
    
    uint16_t retval=1;
    
    // Forcing all GPIOs into initial default state
    for (uint16_t _i=0; _i<p33c_PortInstances;_i++)
    {
        retval &= p33c_PortInstance_SetConfig(_i, portConfigClear);
    }
    
    return(retval);
}

// ________________________________
// end of file
