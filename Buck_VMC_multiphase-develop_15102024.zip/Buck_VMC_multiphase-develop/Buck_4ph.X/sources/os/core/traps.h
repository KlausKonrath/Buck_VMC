/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */
/*
 * @file    exceptions.h
 * @author  M91406
 * @brief   Exception handler header file
 * @date    01/12/2022
 */

#ifndef RTOS_CPU_EXECPTION_TYPEDEF_H
#define RTOS_CPU_EXECPTION_TYPEDEF_H

// Device header file
#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer types header file
#include <stdbool.h> // include standard boolean types header file

#include "execute.h" // include RTOS execution layer header file

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-data-types
 * @brief   defining trap-ID for primary and secondary vectors 
 * @extends TRAP_LOGGER_s
 *********************************************************************************/
enum TRAP_ID_e
{
	TRAP_OSCILLATOR_FAIL		= 0x0001,	///< Trap ID for primary exception vector
	TRAP_ADDRESS_ERROR			= 0x0002,	///< Trap ID for primary exception vector
	TRAP_STACK_ERROR			= 0x0004,	///< Trap ID for primary exception vector
	TRAP_MATH_ERROR				= 0x0008,	///< Trap ID for primary exception vector
	TRAP_DMA_ERROR				= 0x0010,	///< Trap ID for primary exception vector

    TRAP_SOFT_TRAP_ERROR        = 0x0020,   ///< Trap ID for generic soft trap exception vector
    TRAP_HARD_TRAP_ERROR        = 0x0040,   ///< Trap ID for generic hard trap exception vector
    TRAP_RESERVED_TRAP_5_ERROR  = 0x0080,   ///< Trap ID for generic exception vector
    TRAP_RESERVED_TRAP_7_ERROR  = 0x0080,   ///< Trap ID for generic exception vector

	TRAP_ALT_OSCILLATOR_FAIL	= 0x0100,	///< Trap ID for alternate exception vector
	TRAP_ALT_ADDRESS_ERROR		= 0x0200,	///< Trap ID for alternate exception vector
	TRAP_ALT_STACK_ERROR		= 0x0400,	///< Trap ID for alternate exception vector
	TRAP_ALT_MATH_ERROR			= 0x0800,	///< Trap ID for alternate exception vector
	TRAP_ALT_DMA_ERROR			= 0x1000,	///< Trap ID for alternate exception vector

    TRAP_ALT_SOFT_TRAP_ERROR    = 0x2000,   ///< Trap ID for alternate generic soft trap exception vector
    TRAP_ALT_HARD_TRAP_ERROR    = 0x4000,   ///< Trap ID for alternate generic hard trap exception vector
        
	TRAP_RESET_MSK				= 0x7F1F	///< Bit Mask to filter used bits only
};
typedef enum TRAP_ID_e TRAP_ID_t;

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-data-types
 * @brief   CPU interrupt status and control register #1
 * @extends TRAP_LOGGER_s
 *********************************************************************************/
struct CPU_INTCON1_s
{
    union {
        struct tagINTCON1BITS bits; ///< CPU interrupt status and control register #1 bit field
    	uint16_t value;    ///< CPU interrupt status and control register #1 value
    };
}; ///< CPU Interrupt Status and Control Register #1
typedef struct CPU_INTCON1_s CPU_INTCON1_t; ///< CPU Interrupt Status and Control Register #1 data type

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-data-types
 * @brief   CPU interrupt status and control register #2
 * @extends TRAP_LOGGER_s
 *********************************************************************************/
struct CPU_INTCON2_s
{
    union {
        struct tagINTCON2BITS bits; ///< CPU interrupt status and control register #2 bit field
        uint16_t value;    ///< CPU interrupt status and control register #2 value
    };
}; ///< CPU Interrupt Status and Control Register #2
typedef struct CPU_INTCON2_s CPU_INTCON2_t; ///< CPU Interrupt Status and Control Register #2 data type

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-data-types
 * @brief   CPU interrupt status and control register #3
 * @extends TRAP_LOGGER_s
 *********************************************************************************/
struct CPU_INTCON3_s
{
    union {
        struct tagINTCON3BITS bits; ///< CPU interrupt status and control register #3 bit field
        uint16_t value;    ///< CPU interrupt status and control register #3 value
    };
}; ///< CPU Interrupt Status and Control Register #3
typedef struct CPU_INTCON3_s CPU_INTCON3_t; ///< CPU Interrupt Status and Control Register #3 data type

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-data-types
 * @brief   CPU interrupt status and control register #4
 * @extends TRAP_LOGGER_s
 *********************************************************************************/
struct CPU_INTCON4_s
{
    union {
        struct tagINTCON4BITS bits; ///< CPU interrupt status and control register #4 bit field
        uint16_t value;    ///< CPU interrupt status and control register #4 value
    };
}; ///< CPU Interrupt Status and Control Register #4
typedef struct CPU_INTCON4_s CPU_INTCON4_t; ///< CPU Interrupt Status and Control Register #4 data type

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-data-types
 * @brief   CPU reset status and control register 
 * @extends TRAP_LOGGER_s
 *********************************************************************************/
struct CPU_RCON_s
{
    union { 
        struct tagRCONBITS bits;    ///< CPU reset status and control register bit field
        uint16_t value;    ///< CPU reset status and control register value
    };
}; ///< CPU Reset Status and Control Register 
typedef struct CPU_RCON_s CPU_RCON_t; ///< CPU Reset Status and Control Register data type

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-data-types
 * @brief   CPU interrupt status and control register 
 * @extends TRAP_LOGGER_s
 *********************************************************************************/
struct CPU_INTTREG_s
{
    union { 
        struct tagINTTREGBITS bits; ///< CPU interrupt status and control register bit field
        uint16_t value;    ///< CPU interrupt status and control register value
    };
}; ///< CPU Interrupt Status and Control Register 
typedef struct CPU_INTTREG_s CPU_INTTREG_t; ///< CPU Interrupt Status and Control Register data type

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-data-types
 * @brief   Group of CPU interrupt status and control registers
 * @extends TRAP_LOGGER_s
 *********************************************************************************/
struct CPU_STAT_INFO_s
{
    CPU_RCON_t    RCON;    ///< Copy of CPU reset control register
    CPU_INTTREG_t INTTREG; ///< Copy of CPU interrupt status and control register
    CPU_INTCON1_t INTCON1; ///< Copy of CPU interrupt status and control register #1
    CPU_INTCON2_t INTCON2; ///< Copy of CPU interrupt status and control register #2
    CPU_INTCON3_t INTCON3; ///< Copy of CPU interrupt status and control register #3
    CPU_INTCON4_t INTCON4; ///< Copy of CPU interrupt status and control register #4
};
typedef struct CPU_STAT_INFO_s CPU_STAT_INFO_t;

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-data-types
 * @brief   Data structure for RCON status capturing
 * @extends TRAP_LOGGER_s
 *********************************************************************************/
struct EXCEPTIONLOG_STATUS_s 
{
    // Control bits
    bool CpuResetTrigger : 1;      // Bit 0: Control bit to trigger software-enforced CPU reset
    unsigned : 1;                  // Bit 1: (reserved)
    unsigned : 1;                  // Bit 2: (reserved)
    unsigned : 1;                  // Bit 3: (reserved)
    unsigned : 1;                  // Bit 4: (reserved)
    unsigned : 1;                  // Bit 5: (reserved)
    unsigned : 1;                  // Bit 6: (reserved)
    unsigned : 1;                  // Bit 7: (reserved)

    // Status bits
    bool SwReset : 1;              // Bit 8:  Flag indicating CPU was reset by software (read only)
    unsigned : 1;                  // Bit 9:  (reserved)
    unsigned : 1;                  // Bit 10: (reserved)
    unsigned : 1;                  // Bit 11: (reserved)
    unsigned : 1;                  // Bit 12: (reserved)
    unsigned : 1;                  // Bit 13: (reserved)
    unsigned : 1;                  // Bit 14: (reserved)
    unsigned : 1;                  // Bit 15: (reserved)
    
}__attribute__((packed)) ;

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-data-types
 * @brief   Exception Log Status
 *********************************************************************************/
union EXCEPTIONLOG_STATUS_u 
{
    struct EXCEPTIONLOG_STATUS_s bits;  ///< Exception Log Status bit-field
    uint16_t value;                     ///< 16-bit wide value
};
typedef union EXCEPTIONLOG_STATUS_u EXCEPTIONLOG_STATUS_t;

// =================================================================================================
//	GLOBAL DATA STRUCTURE - TRAP LOGGER OBJECT
// =================================================================================================

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-data-types
 * @brief   Global data structure for capturing CPU exceptions
 *********************************************************************************/
struct CPU_EXCEPTION_s 
{
    EXCEPTIONLOG_STATUS_t  Status;     ///< Status word of the Trap Logger object
	TRAP_ID_t              TrapId;     ///< Trap-ID of the captured incident
    uint16_t               ResetCount; ///< Counter of CPU RESET events (read/write)
	uint16_t               TrapCount;  ///< Counter tracking the number of occurrences
    CPU_STAT_INFO_t        CpuStatus;  ///< Complete list of CPU interrupt status and control flags
    OS_TASKMGR_TASKINFO_t  TaskInfo;   ///< Information of last task executed
};
typedef struct CPU_EXCEPTION_s CPU_EXCEPTION_t; // Global data structure for CPU interrupt event capturing

#endif /* RTOS_CPU_EXECPTION_TYPEDEF_H */
  
// end of file
