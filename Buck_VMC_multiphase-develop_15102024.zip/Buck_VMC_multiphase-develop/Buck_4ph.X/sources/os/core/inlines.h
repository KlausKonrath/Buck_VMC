/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * @file    inlines.h
 * @author  M91406
 * @brief   Private scheduler functions to be inlined in source code.
 * @date    06/23/2023, 12:35 PM
 */

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer types header file
#include <stdbool.h> // include standard boolean types header file

#include "execute.h" // include RTOS execution layer header file
#include "taskerrors.h" // include task exceptions event data object header file

#include "../IExceptions.h" // include common exception handler interface header file

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef RTOS_PRIVATE_INLINE_FUNCTIONS_H
#define	RTOS_PRIVATE_INLINE_FUNCTIONS_H

/*********************************************************************************
 * @ingroup operating-system-functions-private
 * @brief   Invokes a task conflict exception interrupt
 * @param   ex: Exception information data object of type TASK_EXCEPTION_t
 * 
 * @details
 *  This function is called by the task exception handler, which captures 
 *  the most recent status of the task manager information available at the
 *  time the exception event occurred.
 *
 **********************************************************************************/
static inline void InvokeTaskException(TASK_EXCEPTION_t ex) { TaskExceptionHandler(ex); }

/*********************************************************************************
 * @ingroup operating-system-functions-private
 * @brief   Invokes a default interrupt exception event
 * @param   ex: Exception information data object of type IRQ_EXCEPTION_t
 * 
 * @details
 *  This function is called by the interrupt exception handler, which captures 
 *  the most recent status of the interrupt controller information available at 
 *  the time the exception event occurred.
 *
 **********************************************************************************/
static inline void InvokeInterruptException(IRQ_EXCEPTION_t ex) { InterruptExceptionHandler(ex);  }

/*********************************************************************************
 * @ingroup operating-system-functions-private
 * @brief   Invokes the default CPU exception (Trap) event
 * @param   ex: Exception information data object of type IRQ_EXCEPTION_t
 * 
 * @details
 *  This function is called by the CPU exception handler, which captures 
 *  the most recent CPU status and task execution information available 
 *  at the time the exception event occurred.
 *
 **********************************************************************************/
static inline void InvokeCpuException(CPU_EXCEPTION_t ex) { CpuExceptionHandler(ex); }

#endif	/* RTOS_PRIVATE_INLINE_FUNCTIONS_H */

// _______________________________
// end of file
