/*
 * @file    execute.c
 * @brief   Real time operating system core engine routines
 * @author  M91406
 * @date    05/27/2021
 * @version 1.0.6
 */

#include <xc_pral.h> // include processor files - each processor file is guarded.  

#include "config/os.h" // include operating system user configuration header file
#include "config/mcal.h" // include common microcontroller abstraction header file
#include "taskmgr.h" // include private data type defiitions
#include "taskerrors.h" // include task exception handler header file
#include "inlines.h" // include RTOS execution inline functions header file

#include "../boot/rtos_timer.h" // include RTOS timer module driver header file

#ifdef __WITH_PIL__
#include "pil/pil.h"
extern PIL_Handle_t PilHandle;
#endif

/*********************************************************************************
 * @ingroup os-layer-core-exe-properties-public-data-types-objects
 * @brief   The task manager object provides a global scope to task list execution status
 * @details
 *  The task manager data object is internally used to track the application 
 *  task execution and provides the real-time operating system time base 
 *  counter. 
 *
 **********************************************************************************/
OS_TASK_MANAGER_t taskManager;

/***********************************************************************************
 * @ingroup os-layer-core-exe-properties-public-data-types-task-queue-declarations
 * @brief   Enumeration of top-level application task function call types
 *
 * @details
 *  Application tasks can assign user functions to certain RTOS executing queues.
 *  The RTOS manages the execution of types:
 * 
 *   - Initialize:  Function called after CPU Boot initializing all application tasks and their data objects
 *   - Start:       Function called after initialization of application tasks and their data objects
 *   - Execute:     Function called application tasks got initialized and started. 
 *                  This function will be continuously called in accordance with 
 *                  the user declaration of task execution period and time-shift 
 *   - Stop:        Function called to suspend the execution of an application tasks
 *   - Dispose:     Function called when an application task is ended
 * 
 ***********************************************************************************/
enum TASK_QUEUE_TYPE_e {
    
    QUEUE_INITIALIZE = 0,   ///< Initialization function execution queue
	QUEUE_START = 1,        ///< Start sequence function execution queue
	QUEUE_EXECUTE = 2,      ///< High-/Low-priority function execution queue
	QUEUE_STOP = 3,         ///< Stop sequence function execution queue
	QUEUE_DISPOSE = 4       ///< Dispose sequence function execution queue
        
}; ///< 
typedef enum TASK_QUEUE_TYPE_e TASK_QUEUE_TYPE_t; ///< Task execution queue types enumeration

/***********************************************************************************
 * @ingroup os-layer-core-exe-properties-public-data-types-task-queue-declarations
 * @brief   Enumeration of task types for selective execution of task queue members
 *
 * @details
 *  Selective task queue member execution differentiates between the following types:
 * 
 *   - ALL:     Executes all tasks in the task queue in the give order of 0 to n.
 *   - LP:      Executes all low-priority tasks in the task queue in the give order from 0 to n.
 *   - HP:      Executes all high-priority tasks in the task queue in the give order from 0 to n.
 * 
 ***********************************************************************************/
enum TASK_QUEUE_EXECUTE_OPTION_e {
    
    QUEUE_EXEC_NONE = 0,    ///< Does not execue any function of the active queue
	QUEUE_EXEC_LP = 1,      ///< Only executes low priority tasks
	QUEUE_EXEC_HP = 2,      ///< Only executes high priority tasks
    QUEUE_EXEC_ENABLED = 3, ///< Only executes tasks, which are enabled in the active queue
	QUEUE_EXEC_ALL = 4      ///< Execute all tasks listed in the active queue
        
}; ///< Enumeration of application task execution classes
typedef enum TASK_QUEUE_EXECUTE_OPTION_e TASK_QUEUE_EXECUTE_OPTION_t; ///< Enumeration of application task execution classes data type

// Application Layer Task Queue (externally defined in apps.c)
extern IApplicationTask_t* AppTaskQueue[];
extern const uint16_t AppTaskQueue_Size; 

// Private function prototypes of task list execution functions
static uint16_t rtos_Initialize(void);
static uint16_t rtos_Start(void);
static uint16_t rtos_Stop(void);
static uint16_t rtos_TaskExecCounter_Update(void);
static uint16_t rtos_TaskExecCounter_Reset(void);

static uint16_t rtos_Queue_Execute(
    TASK_QUEUE_TYPE_t type, 
    TASK_QUEUE_EXECUTE_OPTION_t priority);

#if (RTOS_6G2_CAPTURE_STATISTICS) // Optional variables
static uint32_t rtos_TaskExecTime_Update(uint16_t tStart, uint16_t tStop, uint16_t tLoops);
#endif

/********************************************************************************* 
 * @ingroup operating-system-properties-private-variables
 * @{
 * @details Private high-/low-priority code profiling auxiliary variables
 *********************************************************************************/
static volatile bool LowPriorityWait = true; 
static volatile uint16_t LowPriorityTickCount = 0;
#if (RTOS_6G2_CAPTURE_CPU_LOAD == true)
static uint16_t lpMainLoopCycleCount = 10;
#endif
/** @} */ // end of operating-system-properties-private-variables ~~~~~~~~~~~~~~

// Debugging array for task execution profile tracking
#if (RTOS_6G2_CAPTURE_PROFILE == true)
  #if __DEBUG
    uint16_t ptrTaskProfileArray = 0;
    uint16_t arrTaskProfile[TASK_PROFILE_ARR_SIZE];
    #if (RTOS_6G2_CAPTURE_STATISTICS == true)
    uint32_t arrTaskTime[TASK_PROFILE_ARR_SIZE];
    #endif
    #if (RTOS_6G2_CAPTURE_CPU_LOAD == true)
    uint16_t arrCpuLoad[TASK_PROFILE_ARR_SIZE];
    #endif
  #endif
#endif

/*********************************************************************************
 * @ingroup os-layer-core-exe-functions-public
 * @brief   Application main loop
 * @return  unsigned integer (0=failure, 1=success)
 * 
 * @details
 *  This function replaces the common main()-loop of a C-program, which would 
 *  commonly be placed in file main.c. This function will only be called once 
 *  from main() and never return.
 * 
 *  Within the main()-loop of this function, the execution of the low-priority 
 *  task sequence is called, triggered by the interrupt-driven, real-time high-
 *  priority task layer function. Thus low-priority layer tasks are always called
 *  at a moment of potentially lowest CPU load, with the highest likelihood of
 *  completing the execution.
 * 
 *  Some low-priority tasks, however, might always take multiple task-manager
 *  cycles to be executed, during which period they will get frequently interrupted
 *  by high-priority tasks. 
 *
 **********************************************************************************/
uint16_t rtos_Execute(void)
{
    uint16_t retval = 1;

    // Initialize User Tasks and OS Timer
    retval &= rtos_Initialize();
    
    // Launch RTOS scheduler
    retval &= rtos_Start();
    
    // Main program execution
    while (!taskManager.Status.bits.Disable) 
    {
        // After all code has been executed, reset counters to capture "free" CPU cycles
        LowPriorityWait = true;     // Set Low-Priority Queue Wait
        LowPriorityTickCount = 0;   // Clear Low Priority Timer Tick Counter
        volatile uint16_t timeout = 0;       // Clear timeout counter

        // wait while low-priority wait semaphore is set or a 'go' timeout occurs
        while ((LowPriorityWait == true) && (timeout++ < RTOS_6G2_EXEC_PER_TIMEOUT));   // Wait until semaphore is cleared

        // Check for high-priority task queue timeout events
        // => Throw task scheduler exception if high-priority task stopped responding
        #if (RTOS_6G2_QUEUE_EXCEPTION_ENABLE == true)
        if (timeout >= RTOS_6G2_EXEC_PER_TIMEOUT) 
        { DefaultTaskException(OS_TASKEX_HIGH_PRIORITY_TIMEOUT, NULL); }
        #endif
        
        // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        // Execute non-time critical, low-priority task queue

        taskManager.Timebase.Counter = 0;
        retval &= rtos_Queue_Execute(QUEUE_EXECUTE, QUEUE_EXEC_LP);

        #ifdef __WITH_PIL__
        PIL_backgroundCall(PilHandle);
        #endif
        // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #if (RTOS_6G2_CAPTURE_CPU_LOAD == true)

        if (LowPriorityTickCount > 1)
            taskManager.CpuLoad.CpuLoad = 0x7FFF;  // If timer overran more than once, set CPU load to 100%
        else
        {
            uint16_t _tmrcap = _OSTIMER_PER;   // Add full timer period
            uint16_t _tickcount = (uint16_t)(__builtin_muluu(timeout, lpMainLoopCycleCount));
            _tmrcap -= _tickcount;
            _tmrcap = (_tmrcap < _OSTIMER_PER ? _tmrcap : (_OSTIMER_PER-1));
            taskManager.CpuLoad.CpuLoad = (uint16_t)(__builtin_divf(_tmrcap, _OSTIMER_PER));
        }
        
        #endif
    }

    rtos_Stop();    // Call all declared user STOP functions trying to get system into a safe state
    CPU_RESET();    // if the firmware ever ends up here, reset the CPU
    
    return(0);      // Return "false" signaling OS has exited execution
}

/*********************************************************************************
 * @ingroup os-layer-core-exe-functions-public
 * @brief   Ends the execution of the main() loop enforcing a CPU reset.
 * @return  unsigned integer (0=failure, 1=success)
 *
 * @details
 *  This function is calling the STOP sequence of all managed tasks and set
 *  the EXIT control bit of the task manager, terminating the main()-loop
 *  triggering a CPU reset. No data will be preserved by the RTOS. At CPU
 *  reset the target device will be reset into default factory state. After
 *  the CPU reset the firmware will automatically restart.
 *
 **********************************************************************************/
uint16_t rtos_End(void)
{
    uint16_t retval=1;
    
    // ToDo: System is not brought into a safe state before CPU reset is 
    //       invoked. Adding/call the STOP-sequence resulted in stalling
    //       condition. Analyze potential STOP procedure floor and ensure 
    //       safe state before CPU reset.
    
    // Set Scheduler Disable bit exits the continuous main() loop 
    // execution enforcing a CPU reset.
    taskManager.Status.bits.Disable = true;
   
    return(retval);
}

/*********************************************************************************
 * @ingroup os-layer-core-exe-functions-private
 * @brief   Initializes the task manager object and user-task execution lists
 * @return  unsigned integer (0=failure, 1=success)
 *
 * @details
 *  This function will enumerate all tasks registered by the user in app.c 
 *  and call their specified initialization functions. This function will be 
 *  called automatically when function rtos_Execute is called from user code.
 *  No further steps have to be taken in user code to initialize the RTOS or
 *  user tasks.
 *
 **********************************************************************************/
static uint16_t rtos_Initialize(void)
{
    uint16_t retval=1;
    uint16_t _id=0;
    
    // Initialize task data object
    for (uint16_t i=0; i<AppTaskQueue_Size; i++)
    {
        _id = AppTaskQueue[i]->Properties.PriorityClass;
        _id <<= 8;
        _id |= i;

        AppTaskQueue[i]->Properties.TaskID = _id;
        AppTaskQueue[i]->Properties.ReturnValue = 0;
        AppTaskQueue[i]->Status.Busy = false;
        AppTaskQueue[i]->Statistics.AvgTime = 0;
        AppTaskQueue[i]->Statistics.ExecTime = 0;
        AppTaskQueue[i]->Statistics.MaxTime = 0;
        AppTaskQueue[i]->Properties.TimeBase.Counter = 0;
    }
    
    // Configure Operating System Timer
    retval &= osTimer_Initialize();

    // Reset task manager status word
    taskManager.Status.bits.HpTimeout = 0;
    taskManager.Status.bits.LpTimeout = 0;
    taskManager.Status.bits.LpActive = 0;
    taskManager.Status.bits.HpActive = 0;
    taskManager.Status.bits.Disable = 0;
    taskManager.Status.bits.Suspend = 0;
    // => DO NOT SET OR CLEAR Boot Complete flag bit
    
    // Enabling/disabling statistics tracking
    taskManager.Status.bits.Statistics = (int)RTOS_6G2_CAPTURE_STATISTICS;
    
    return(retval);
}

/*********************************************************************************
 * @ingroup os-layer-core-exe-functions-private
 * @brief   Starts the execution of the main() loop
 * @return  unsigned integer (0=failure, 1=success)
 *
 * @details
 *  This function will call the all specified START functions of all tasks 
 *  registered by the user in app.c directly after the execution of the task 
 *  initialization sequence. This function will be called automatically 
 *  when function rtos_Execute is called from user code. No further steps have 
 *  to be taken in user code to initialize the RTOS or user tasks.
 *
 **********************************************************************************/
static uint16_t rtos_Start(void)
{
    uint16_t retval=1;
    
    // Start Operating System Timer without interrupts (no high priority execution)
    retval &= osTimer_Enable(false, 0);

    // Execute function list covering user-task initialization functions
    retval &= rtos_Queue_Execute(QUEUE_INITIALIZE, QUEUE_EXEC_ALL);

    // Execute function list covering user-task start-up functions
    retval &= rtos_Queue_Execute(QUEUE_START, QUEUE_EXEC_ENABLED);

    // Reset all task counters
    retval &= rtos_TaskExecCounter_Reset();

    // Start Operating System Timer with interrupts (starts high priority task execution)
    retval &= osTimer_Enable(true, _OSTIMER_PRIORITY);
   
    return(retval);
}

/*********************************************************************************
 * @ingroup os-layer-core-exe-functions-private
 * @brief   Stops the execution of the main() loop
 * @return  unsigned integer (0=failure, 1=success)
 *
 * @details
 *  This function will call all specified STOP functions of all tasks 
 *  registered by the user in app.c in one, successive sequence. 
 * 
 **********************************************************************************/
static uint16_t rtos_Stop(void)
{
    uint16_t retval=1;
    
    // Execute function list covering user-task stop functions
    retval &= rtos_Queue_Execute(QUEUE_STOP, QUEUE_EXEC_ALL);
    
    // Reset all task counters
    retval &= rtos_TaskExecCounter_Reset();

    return(retval);
}

/**********************************************************************************
 * @ingroup os-layer-core-exe-functions-private
 * @brief   High priority, interrupt-driven task sequence execution
 * 
 * @details
 *  This interrupt is used to call the high priority task sequence at a fixed
 *  repetition frequency (default of 10 kHz/100 us period). All tasks listed
 *  in the high priority task list will get executed one after another. The total
 *  execution time of the sequence therefore has to fit in the given repetition 
 *  period to ensure reliable real-time resolution of each task of the sequence.
 * 
 * @note
 *  If option _OSTIMER_ALTWREG_ENABLE is enabled, an alternate working register 
 *  set must be assigned to the interrupt priority set by _OSTIMER_PRIORITY
 *  for the _OsTimerInterrupt interrupt service routine as shown in the following
 *  code example:
 *  
 *  @code {.c}
 *   #pragma config CTXT1 = IPL3
 *  @endcode
 * 
 * @see 
 *  - @ref _OSTIMER_ALTWREG_ENABLE 
 *  - @ref _OSTIMER_PRIORITY
 * 
 **********************************************************************************/
#if (_OSTIMER_ALTWREG_ENABLE == true)
#define STR(x)   #x
#define XSTR(x)  STR(x)
#define MSG(x)   STR(x)
#pragma message  MSG(Info: RTOS Timer expects alternate working registers to be assigned to priority level XSTR(_OSTIMER_PRIORITY))
void __attribute__((__interrupt__, context, no_auto_psv)) _OsTimerInterrupt(void)
#else
#pragma message "Info: RTOS Timer ignores alternate working registers."
void __attribute__((__interrupt__, no_auto_psv)) _OsTimerInterrupt(void)
#endif
{
	uint16_t retval=1;

    // Increment execution period counter
    taskManager.Timebase.Counter++;             // Increment task manager OS time-base counter
    LowPriorityTickCount++;                     // Increment the low-priority task timer tick counter
    _OSTIMER_IF = 0;                            // Clear the interrupt flag bit
    
    // Check for low-priority task queue timeout events
    // => Throw task scheduler exception if low priority task stopped responding
    #if (RTOS_6G2_QUEUE_EXCEPTION_ENABLE == true)
    if (taskManager.Timebase.Counter > RTOS_6G2_EXEC_LPQ_TIMEOUT) 
    { DefaultTaskException(OS_TASKEX_LOW_PRIORITY_TIMEOUT, NULL); }
    #endif
    
    // Update task execution counter
    // => Increment all task execution time-base counters
    retval &= rtos_TaskExecCounter_Update();  

    // Execute high priority task queue
    retval &= rtos_Queue_Execute(QUEUE_EXECUTE, QUEUE_EXEC_HP); // execute the high priority task queue

    // Check for high-priority task queue time quota violation event
    #if (RTOS_6G2_QUEUE_EXCEPTION_ENABLE == true)
    if (1 == _OSTIMER_IF) 
    { DefaultTaskException(OS_TASKEX_HIGH_PRIORITY_QUOTA_VIOLATION, NULL); }
    #endif

    // Clear low-priority semaphore allowing to execute low-priority tasks
    LowPriorityWait = false;    // Clear WAIT trigger allowing execution of low priority tasks
    _OSTIMER_IF = 0;            // Clear the interrupt flag bit in case timer has overflown
}

/**********************************************************************************
 * @ingroup os-layer-core-exe-functions-private
 * @brief   Low priority task sequence executed after the high priority task sequence execution is complete
 * @return  unsigned integer (0=failure, 1=success)
 * 
 * @details
 *  This function executes different task lists of which some are time 
 *  critical while others are insensitive to execution time jitter. Each
 *  task list handed into this function will be executed from task #0 to
 *  task #n in ascending order. Hence, tasks with a lower list index will
 *  encounter less task execution jitter than others with a higher list
 *  index.
 * 
 *  This function can also be interrupted by the high-priority execution 
 *  call, in which case the high-priority task will be executed before the 
 *  previously started low-priority task sequence has completed. 
 * 
 * ********************************************************************************/
static uint16_t rtos_Queue_Execute(TASK_QUEUE_TYPE_t type, TASK_QUEUE_EXECUTE_OPTION_t priority)
{
    bool     _exec=false; // Flag indicating if task is due to be executed
    uint16_t retval=1; // common return variable
    
    // --------------------------------------------------
        
    // Track if all execution layers are executed
    if (priority == QUEUE_EXEC_HP) taskManager.Status.bits.HpActive = true;
    if (priority == QUEUE_EXEC_LP) taskManager.Status.bits.LpActive = true;
    
    // Roll through queue executing due tasks
    for (uint16_t i=0; i<AppTaskQueue_Size; i++) 
    {
        // Check if task is due to be executed
        switch (priority)
        { 
            case QUEUE_EXEC_NONE:    _exec = false; break;
            case QUEUE_EXEC_ALL:     _exec = true; break;
            case QUEUE_EXEC_ENABLED: _exec  = AppTaskQueue[i]->Status.Enabled; break;
            default:
                if (AppTaskQueue[i]->Status.Enabled)
                {
                    if ((int)AppTaskQueue[i]->Properties.PriorityClass == (int)priority)
                    { _exec = (bool)(AppTaskQueue[i]->Properties.TimeBase.Counter <= 0); }
                    else
                    { _exec = false; } // Clear EXECUTE flag
                }
                else { _exec = false; } // Clear EXECUTE flag
                break;
        }

        // Execute task
        if (_exec)
        {
            // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            // Select task function to be executed
            uint16_t (*fcall)(void);
            switch (type)
            {
                case QUEUE_INITIALIZE:  fcall = AppTaskQueue[i]->Functions.Initialize; break;
                case QUEUE_START:       fcall = AppTaskQueue[i]->Functions.Start;      break;
                case QUEUE_EXECUTE:     fcall = AppTaskQueue[i]->Functions.Execute;    break;
                case QUEUE_STOP:        fcall = AppTaskQueue[i]->Functions.Stop;       break;
                case QUEUE_DISPOSE:     fcall = AppTaskQueue[i]->Functions.Dispose;    break;
                default: fcall = NULL; _exec = false; break;
            }
            // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

            // If function pointer is not NULL, call task function
            if (fcall != NULL) 
            { 
                #if (RTOS_6G2_CAPTURE_STATISTICS == true) // Optional variables 
                // Capture most recent timer value
                uint32_t _texec=0;
                uint16_t _tstop=0;
                uint16_t _tstart = _OSTIMER_TMRCAP;
                uint32_t _tloops = taskManager.Timebase.Counter;
                #endif

                // Set up application task counter for next execution
                AppTaskQueue[i]->Properties.TimeBase.Counter += AppTaskQueue[i]->Properties.TimeBase.Period;

                taskManager.TaskInfo.QueueType = type;
                taskManager.TaskInfo.QueueMode = priority;
                taskManager.TaskInfo.TaskId = AppTaskQueue[i]->Properties.TaskID;
                
                // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                // Call Task Function
                // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                AppTaskQueue[i]->Status.Busy = true;    // Set BUSY status
                uint16_t rtv = fcall();                 // Call task function, capturing individual result
                retval &= rtv;                          // accumulate function call results
                AppTaskQueue[i]->Status.Busy = false;   // Clear BUSY status
                // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                AppTaskQueue[i]->Properties.ReturnValue = rtv;     // log last, individual function result

                #if (RTOS_6G2_QUEUE_EXCEPTION_ENABLE == true)
                if( rtv == 0) { DefaultTaskException(OS_TASKEX_TASK_RET_ERROR, AppTaskQueue[i]); }
                #endif 
                
                // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

                #if (RTOS_6G2_CAPTURE_STATISTICS == true)

                    if(taskManager.Status.bits.Statistics)
                    {
                        _tstop = _OSTIMER_TMRCAP;     // Capture most recent timer value
                        _tloops = (taskManager.Timebase.Counter - _tloops);
                        _texec = rtos_TaskExecTime_Update(_tstart, _tstop, _tloops);
                        AppTaskQueue[i]->Statistics.ExecTime = _texec;
                        if (_texec > AppTaskQueue[i]->Statistics.MaxTime)
                            AppTaskQueue[i]->Statistics.MaxTime = _texec;
                        AppTaskQueue[i]->Statistics.AvgTime += _texec;
                        AppTaskQueue[i]->Statistics.AvgTime >>= 1;
                    } 

                    #if (RTOS_6G2_CAPTURE_PROFILE == true)

                        #if __DEBUG

                        // In debug mode with statistics enabled, capture task execution time
                        arrTaskProfile[ptrTaskProfileArray] = taskManager.TaskInfo.TaskId;

                        #if (RTOS_6G2_CAPTURE_STATISTICS == true)
                        arrTaskTime[ptrTaskProfileArray] = (AppTaskQueue[i]->Statistics.ExecTime);
                        #endif

                        #if (RTOS_6G2_CAPTURE_CPU_LOAD == true)
                        arrCpuLoad[ptrTaskProfileArray] = taskManager.CpuLoad.CpuLoad;
                        #endif

                        if (ptrTaskProfileArray++ >= TASK_PROFILE_ARR_SIZE) 
                        {
                            Nop(); // In debug mode, place break point here
                            Nop();
                            Nop();
                            ptrTaskProfileArray = 0;
                        }

                        #endif
                    #endif
                #endif
            }
        }    
    }
    
    // Return result (0=failure, 1=success)
    return(retval);
}

/*********************************************************************************
 * @ingroup os-layer-core-exe-functions-private
 * @brief   Updates the primary scheduling time base
 * @return  unsigned integer (0=failure, 1=success)
 *
 * @details
 *  This function increments the counters of the primary task scheduler time base
 *  as well as the individual execution period counters of each managed task 
 *  registered by the user in file apps.c. The timer counter tick rate is defined
 *  by the macro RTOS_6G2_EXEC_PER (default = 100 us).
 * 
 * @see RTOS_6G2_EXECUTION_PERIOD, RTOS_6G2_EXEC_PER
 *
 **********************************************************************************/
static uint16_t rtos_TaskExecCounter_Update(void)
{
    uint16_t retval=1;

    // Capture most recent time base counter to prevent drift across tasks
    uint16_t _tstep = taskManager.Timebase.Counter;  
    
    // Decrement all task execution counters
    for (uint16_t i=0; i<AppTaskQueue_Size; i++) 
    { AppTaskQueue[i]->Properties.TimeBase.Counter -= _tstep; }

    // Reset common time base counter
    taskManager.Timebase.Counter = 0;   // Clear the task scheduler tick counter
    _OSTIMER_IF = 0;                    // Clear Timer interrupt flag bit

    return(retval);
}

/*********************************************************************************
 * @ingroup os-layer-core-exe-functions-private
 * @brief   Resets the main task manager time base counter
 * @return  unsigned integer (0=failure, 1=success)
 * 
 * @details
 *  The task scheduler uses one common execution tick counter to track and
 *  schedule all managed tasks in the task list. This function resets the 
 *  main time base counter and all subsequent task counters back to their
 *  initial start condition.
 *
 **********************************************************************************/
static uint16_t rtos_TaskExecCounter_Reset(void)
{
    uint16_t retval=1;

    // Increment all task execution counters
    for (uint16_t i=0; i<AppTaskQueue_Size; i++) {
        AppTaskQueue[i]->Properties.TimeBase.Counter = 0;
        AppTaskQueue[i]->Properties.TimeBase.Counter += AppTaskQueue[i]->Properties.TimeBase.Offset;
        AppTaskQueue[i]->Properties.TimeBase.Counter += AppTaskQueue[i]->Properties.TimeBase.Period;
        AppTaskQueue[i]->Properties.TimeBase.Counter ++;
    } 
    
    taskManager.Timebase.Counter = 0;   // Clear the task scheduler tick counter
    _OSTIMER_TMRCAP = 0;                // Clear timer counter register
    _OSTIMER_IF = 0;                    // Clear Timer interrupt flag bit

    return(retval);
}

/*********************************************************************************
 * @ingroup os-layer-core-exe-functions-private
 * @brief   Updates the task execution time base
 * @return  unsigned integer (0=failure, 1=success)
 * 
 * @details
 *  If configuration flag RTOS_6G2_CAPTURE_STATISTICS = true, the queue 
 *  execution engine captures timing data before and after a task function
 *  call. This function converts captured data into a total execution period
 *  of the task and returns the result.
 *
 **********************************************************************************/
#if (RTOS_6G2_CAPTURE_STATISTICS) // Optional variables 
static uint32_t rtos_TaskExecTime_Update(uint16_t tStart, uint16_t tStop, uint16_t tLoops)
{
    uint32_t tExec=0;
    
    // Capture execution statistics
    // Calculate effective execution time of low priority task sequence
    switch(tLoops) 
    {
        case 0: // Timer has not overflown during task list execution
            tExec = (uint32_t)(tStop - tStart);
            break;

        case 1: // Timer has overflown once during task list execution
            tExec = (uint32_t)(RTOS_6G2_EXEC_PER - tStart);
            tExec += (uint32_t)tStop;
            break;

        default: // Timer has overflown multiple times during task list execution
            tExec = __builtin_muluu(tLoops, RTOS_6G2_EXEC_PER);
            tExec -= (uint32_t)(RTOS_6G2_EXEC_PER - tStart);
            tExec += (uint32_t)tStop;
            break;
    }

    return(tExec);
}
#endif

// ________________________________
// end of file
