/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/**
 * @file    execute.h
 * @author  M91406
 * @brief   RTOS execution engine header file 
 * @date    01/12/2022
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef RTOS_EXECUTION_TYPEDEF_H
#define	RTOS_EXECUTION_TYPEDEF_H

#include "taskmgr.h" // include task manager type definition header file

///**********************************************************************************
// * @ingroup os-layer-core-exe-properties-public-data-types
// * @brief   Provides information for executed task, fault event and operating mode ID of task manager 
// * @extends TRAP_LOGGER_s
// *********************************************************************************/
//struct TASK_INFO_s 
//{
//    uint16_t TaskId;   ///< Task ID of last executed task
//    uint16_t QueueType; ///< Execution queue ID of the most recently executed task
//};
//typedef struct TASK_INFO_s TASK_INFO_t;

// Expose access to RTOS taskManager object
extern OS_TASK_MANAGER_t taskManager;

#endif	/* RTOS_EXECUTION_TYPEDEF_H */

