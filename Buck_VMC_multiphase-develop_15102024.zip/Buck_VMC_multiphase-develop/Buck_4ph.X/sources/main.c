/**
 * @file    main.c
 * @author  M91406
 * @date    10/01/2020 
 */

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
#include <dsp.h> // include standard DSP data types

#include "config/mcal.h" // Include microcontroller abstraction layer
#include "config/hal.h" // Include hardware abstraction layer
#include "config/apps.h" // Include application abstraction layer
#include "config/os.h" // Include operating system configuration header file

#include "config/usercfg.h" // Include header file of user peripheral configuration module

/*********************************************************************************
 * @ingroup firmware-flow
 * @fn      int main(void)
 * @brief   Main application function
 * @return  signed integer int
 * 
 * @details
 *  This is the main application function executed after the device comes
 *  out of RESET. After the fundamental device configuration and initialization
 *  of all required peripherals and software components, the function enters
 *  the endless main() loop where the device will remain executing the 
 *  application.
 *
 * @code{.c}
 * 
 * @endcode
 *
 **********************************************************************************/
/*
 * PWM1 H/L is the PWM for buck 1
 * PWM1 TRIBB is used to sample Vin, Vin_prod, Vout and buck1 current IBUCK1
 * PWM1 generates the SOC for PWM2 using TRIGA in order to generate the phase shift
 * 
 * 
 * PWM2 H/L is the PWM for buck 2
 * PWM2 TRIBB is used to sample buck2 current IBUCK2
 * PWM2 generates the SOC for PWM3 using TRIGA in order to generate the phase shift
 * 
 
 * PWM3 H/L is the PWM for buck 3
 * PWM3 TRIBB is used to sample buck3 current IBUCK3
 * PWM3 generates the SOC for PWM4 using TRIGA in order to generate the phase shift
 * 
 * 
 * PWM4 H/L is the PWM for buck 4
 * PWM4 TRIBB is used to sample buck4 current IBUCK4

 * 
 
 Analog signals:
 * 
 * Input voltage before the inrush U-Protected: 3k/150k AN18
 * Input voltage U-DCDC: 3k/150k AN9
 * Output voltage U-Regel: 3.3k/47k AN17
 * 
 * Buck1 current: I-800W-PH1-ADC gain 0.3 (3mohm * 100) AN0
 * Buck2 current: I-800W-PH2-ADC gain 0.3 (3mohm * 100) AN5
 * Buck3 current: I-800W-PH3-ADC gain 0.3 (3mohm * 100) AN1
 * Buck4 current: I-800W-PH4-ADC gain 0.3 (3mohm * 100) AN6
 * 
 * Writing PG1DC (master PWM) will trigger the update for all PWM registers
 * 
 * Max current detector: CMP2A (overcurrent protection)
 * 
 * 
 Digital signals
 * 
 * EN_DCDC_Idealdiode   RB4
 * EN_DCDC_INRUSH       RD15
 * EN_INRUSH            RD14
 * EN_BYPASS            RD12
 
 TODO verificare inizializzazione comparatore e PCI
 * 
 * Aggiungere software per incrementare duty ad anello aperto per HW_TEST
 * Verificare configurazione DAC/CMP. 
 * PCI fault, OK CMP1 latched qualifier !LEB OK
 * collegare PCI Fault a fault
 * Verificare LEB PWM OK enabled on all edges OK
 * Verificare che PCI diversi da falut siano disattivi
 * 
 * Introdurre compensatore per balancing. Con 160V oscilla
 * Introdurre AGC. OK
 * Aggiungere hook per aggiornare tutte le fasi prima di quella master OK
 * 
 * Inrush management OK

 */

int main(void) {

    uint16_t retval=1;    
    
    // Fundamental device initialization
    retval &= rtos_Boot();  // Set up system oscillator for 100 MIPS operation
                            // Set up Auxiliary PLL for 500 MHz (source clock to PWM module, ADC and Comparator)
                            // Set up DSP for control loop execution
                            // Initialize common device GPIOs
    
    // Load user defined, static peripheral configurations
    retval &= sysUserPeriperhals_Initialize();
    
    // Load user defined services, which are not part of the scheduled task list
    retval &= sysUserServices_Initialize();    
    
    // Main program execution
    retval &= rtos_Run();
    
    // When the OS is exited, a CPU RESET will be triggered
    // This section of the code should never be reached.
    Nop();
    CPU_RESET();

    return (0);
}

// ________________________
// end of file

