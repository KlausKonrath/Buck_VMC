# dsPIC33C Data Function Library {#powerlibrary}

<span id="startDoc"> </span> <!-- start tag for internal references -->

## Class

PowerSmart™ Firmware Framework Component

## Summary

Set of independent data-driven functions repeatedly required in many applications.

## Table Of Contents

<div id="TOC">
<ul>
<li><a href="#intro">Introduction</a></li>
<li><a href="#lib-use">Library Usage Guidelines</a></li>
<li><a href="#api-guide">API Quick-Start Guide</a></li>
<li><a href="#api-objects">API Public Data Object</a></li>
<li><a href="#state-machine">Data Functions Library</a></li>
<li><a href="#history">History</a></li>
</ul>
</div>

<span id="intro"> </span>

## Introduction

### Description

### Tool Support

<a href="#startDoc">back</a>

<span id="lib-use"> </span>

### Library Usage Guidance

This code library repository must be included in an independent directory within the target project. Changes to any of the files of this repository in the target project environment can be pushed back to this library repository from where these changes can be distributed to one, more or all target projects this library has been used in. The upgrade of library files in a particular target project needs to be performed individually, allowing to individually manage the device driver version used.

#### Adding Subtree Repository

##### Step 1 - Adding Subtree Repository to Target Project

###### a) Using Sourcetree Application

Open *Sourcetree* Application

- Open menu *Repository* → *Repository Settings*
- Click *Add* to open the Add Repository dialog

Inside the Repository dialog

- Enter *Remote Name* `subrepo-p33c-flib`
- Enter clone URL/path https://bitbucket.microchip.com/scm/mcu16asmpsl/p33c-function-libraries.git
- Under *Optional extended integration* → *Remote Account* select your user account
- Click *OK* to close the dialog

###### b) Using Git Bash

Open Git Bash at root of target project repository and use the following command for adding the new subtree remote:

- `$ git remote add subrepo-p33c-flib https://bitbucket.microchip.com/scm/mcu16asmpsl/p33c-function-libraries.git`

##### Step 2) Cloning Subtree Repository

Further using Git Bash use the `subtree add` command to clone the contents of this code library into the target project

- `$ git subtree add --prefix=<code_library_target> subrepo-p33c-flib main --squash`

with `<code_library_target>` = path to sub-folder within the target project directory structure this code library should be cloned to (e.g. my_project.X/sources/power_control/devices).

#### 3) Pulling latest version from Library Repository

When a new version of this code library is available, you can pull it by using the `subtree pull` command in the Git Bash:

`$ git subtree pull --prefix=<code_library_target> subtree-p33c-flib main --squash`

with `<code_library_target>` = path to sub-folder within the target project directory structure this code library has been cloned to (e.g. my_project.X/sources/fault_handler/drivers).

#### 4) Pushing new version back to Library Repository

When changes have been made to files of this code library, the new version can be pushed back to the library repository by using the `subtree push` command in the Git Bash:

`$ git subtree push --prefix=<code_library_target> subtree-p33c-flib feature/version-update --squash`

with `<code_library_target>` = path to sub-folder within the target project directory structure this code library has been cloned to (e.g. my_project.X/sources/fault_handler/drivers).

<span style="color:red">
    <u><b>Note:</b></u><br>
    Pushing directly to the library project 'main' or 'develop' branches may be prohibited. 
    Hence, <i><u><b>changes can only be pushed to feature branches</b></u></i>. A Pull Request is required to review and merge changes to 'develop'. Once changes have been approved and merged int 'develop', they may be merged into branch 'main' and thus released as new version through another pull request. This new version of 'main' can be tagged with a new version number and pulled into target projects.
</span>

<br>&nbsp;

<a href="#startDoc">back</a>

<span id="api-guide"> </span>

### API Quick-Start Guide

#### API Public Functions



<a href="#startDoc">back</a>

---

<span id="history"> </span>

##### History:

- 05/03/2021 v1.0 (M91406) Initial release

---
© 2023, Microchip Technology Inc.
