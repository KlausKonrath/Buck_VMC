/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/**
 * @file    moving_average.h
 * @brief   Assembler routine function calls and data types declarations of generic moving average calculation
 * @author  M91406
 * @date    04/21/22
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef P33C_LIB_MOVING_AVERAGE_H
#define	P33C_LIB_MOVING_AVERAGE_H

#include <stdlib.h>

/***********************************************************************************
 * @ingroup lib-layer-p33c-functions-public-moving-average
 * @struct  AVG_TMPDAT_s
 * @extends AVERAGE_DATA_SOURCE_s
 * @brief   Temporary data buffer for managing moving average value
 * @details
 *  ADD_DETAILED_DESCRIPTION
 **********************************************************************************/
struct MAVG_TMPDAT_s {

    uint16_t tmpEdsPage;        ///< EDS page in which buffer array is located
    uint16_t tmpPtr;            ///< most recent array index pointer
    uint16_t tmpSamDepth;       ///< Number of data points included in average calculation
    int32_t  tmpAvgSum;         ///< Running sum of data values across data array
};

typedef struct MAVG_TMPDAT_s MAVG_TMPDAT_t; ///< internal runtime data buffer. Do not use

/***********************************************************************************
 * @ingroup lib-layer-p33c-functions-public-moving-average
 * @struct  AVERAGE_DATA_SOURCE_s
 * @brief   Moving average data object
 * @details
 *  This data object holds all user configurations and results of the moving
 * average across a user-specified data array. 
 **********************************************************************************/
struct P33C_MOVING_AVERAGE_s {

    int16_t*  ptrSource;        ///< Pointer to data source register or variable
    int16_t*  ptrArray;         ///< Pointer to user defined data array
    uint16_t  ArraySize;        ///< Size of user defined data array
    int16_t   LowerInputLimit;  ///< Minimum input value limit 
    int16_t   UpperInputLimit;  ///< Maximum input value limit 
    int16_t   Average;          ///< Running average value tracked across user array
    
    MAVG_TMPDAT_t tmp;          ///< !!! DO NOT USE !!! \n internal runtime data buffer.
    
} __attribute__((aligned));

typedef struct P33C_MOVING_AVERAGE_s P33C_MOVING_AVERAGE_t;


/*********************************************************************************
 * @ingroup lib-layer-p33c-functions-public-moving-average
 * @brief   Initializes a Moving Average data object of type P33C_MOVING_AVERAGE_t
 * @param   Pointer to Moving Average data object of type AVERAGE_DATA_SOURCE_t
 * @return  unsigned integer (0=failure, 1=success)
 * 
 * @details
 *  This function initializes a Moving Average data object. The data object
 *  must be declared in user code and pointers and input limits must be set
 *  before calling this function.
 *
 * <p><b>Example:</b></p>
 * @code{.c}
 *  
 *    // Create new Moving Average data objects
 *    int16_t bufferArray[32];            // buffer array of the moving average library
 *    P33C_MOVING_AVERAGE_t mavgObject;   // data object of the moving average library
 * 
 *    // Configure Moving Average data objects
 *    mavgObject.ptrSource = &ADCBUF4;
 *    mavgObject.ptrArray = &bufferArray[0];
 *    mavgObject.ArraySize = (sizeof(bufferArray)/sizeof(bufferArray[0]));
 *    mavgObject.LowerInputLimit = 0;
 *    mavgObject.UpperInputLimit = 2500;
 *    
 *    // Call filter module initialization
 *    p33c_LibMavg_Initialize(&mavgObject);
 * 
 * @endcode
 *
 **********************************************************************************/
static __attribute__((used)) uint16_t p33c_MovingAverage_Initialize(P33C_MOVING_AVERAGE_t* dataSource) 
{
    uint16_t retval=1;
    
    // Guarding conditions
    if (dataSource->ptrSource == NULL) return(0);
    if (dataSource->ptrArray == NULL) return(0);
    if (dataSource->ArraySize == 0) return(0);
    
    // Clear data buffer
    dataSource->tmp.tmpPtr = 0;         // REset array pointer
    dataSource->tmp.tmpAvgSum = 0;      // clear average sum
    dataSource->tmp.tmpSamDepth = 0;    // clear sample depth tracker
    
    // Clear output data buffer
    dataSource->Average = 0;
    
    return(retval);
}

/*********************************************************************************
 * @ingroup lib-layer-p33c-functions-public-moving-average
 * @brief   Updates the Moving Average data object
 * @param   Moving average data array object of type P33C_MOVING_AVERAGE_t
 * @return  Returns the most recent average calculation result
 * @details
 *  When this function is called, the library pulls a new sample from 
 *  the declared source memory address, adds its value to the averaging
 *  data buffer array and calculates the new average result and places 
 *  it in the average result buffer. 
 * 
 *  If the array is clear or not filled yet, the average result is
 *  calculated across the available data only when a new sample is added.
 *  
 *  If the array is full, each new sample overrides the oldest, causing 
 *  the average to continuously roll with every new sample added. 
 * 
 * <p><b>Example:</b></p>
 * @code{.c}
 * 
 *    int16_t myAverage;
 * 
 *    // Add data sample to Moving Average and update filter result
 *    p33c_MovingAverage_Update(&mavgObject);
 * 
 *    // Read most recent result buffer
 *    myAverage = mavgObject.Average;
 * 
 * @endcode
 * 
 **********************************************************************************/
extern int16_t p33c_MovingAverage_Update(P33C_MOVING_AVERAGE_t* dataSource);

/*********************************************************************************
 * @ingroup lib-layer-p33c-functions-public-moving-average
 * @brief   Updates the Moving Average data object
 * @param   Moving average data array object of type P33C_MOVING_AVERAGE_t
 * @details
 *  When this function is called, the library clears the temporary 
 *  runtime data and most recent average output buffer. It is recommended
 *  to call this function every time when data sampling is interrupted.
 **********************************************************************************/
extern void p33c_MovingAverage_Clear(P33C_MOVING_AVERAGE_t* dataSource);


#endif	/* P33C_LIB_MOVING_AVERAGE_H */

// ____________________
// end of file
