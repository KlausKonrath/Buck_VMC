/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * @file    IUartHandler.h
 * @author  M15690
 * @brief   Global UART device driver interface header file
 * @version 1.0
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef UART_HANDLER_INTERFACE_H
#define	UART_HANDLER_INTERFACE_H

#include <xc_pral.h>    // include processor abstraction header files 
#include <libpic30.h>   // include pic30 library for printf redirect

#include "core/p33c_plib_uart_handler.h"
#include "core/p33c_plib_uart_templates.h"
#include "core/p33c_plib_uart_datamngmnt.h"
#include "core/p33c_plib_uart_data_capture.h"


/**********************************************************************************
 * @ingroup p33c-plib-uart-properties
 * @struct UART_BUFFER_s
 * @brief This data structure defines a pointer to a user data buffer and its size.
 * @details
 *   Data buffers are used to send data to and receive data from the UART port.
 *   Users may define one or more data buffers to build and prepare data content
 *   to be sent or capture incoming data in one or more data buffers.
 * 
 *   The following code example shows how to define a user data buffer of 
 *   16 bytes and initialize the data buffer data type to assign the user
 *   defined data array.
 * 
 * @code {.c} 
 * 
 *  int8_t* myDataArray[16];
 *  uint16_t myDataArray_size = (sizeof(myDataArray) / sizeof(myDataArray[0]));
 * 
 *  UART_BUFFER_t myDataBuffer = 
 *  {
 *      .ptrData = (uint8_t*)&myDataArray,
 *      .Size = myDataArray_size
 *  };
 * 
 * @endcode
 *********************************************************************************/
struct UART_BUFFER_s
{
    uint8_t* ptrData;       ///< Pointer to a user-defined data buffer array start address
    uint16_t ArrayPointer;  ///< Array index pointer to the next free byte within the array
    uint16_t BufferPointer; ///< Buffer pointer to the active data array
    uint16_t Size;          ///< Size of the user-defined data buffer buffer
    bool Ready;             ///< Buffer Ready Flag indicating that data is ready to be processed
}; // Transmit/Send data object  
typedef struct UART_BUFFER_s UART_BUFFER_t; ///< Transmit/Send object data type  

/**********************************************************************************
 * @ingroup p33c-plib-uart-methods
 * @brief This function can be used as a data type converter of any type of array to 8bit data. 
 *********************************************************************************/
#define converterTo8bitArrayElementCount(x) (sizeof (x) / sizeof (uint8_t))

/*********************************************************************************
 * @ingroup p33c-plib-uart-properties
 * @{
 * 
 * @details
 *  The receive/transmit buffer default declarations are included here.
 *  This UART driver provides built-in receive and transmit data buffers. The macros 
 *  PLIB33C_UART_RX_BUFFER_DEFAULT_SIZE and PLIB33C_UART_TX_BUFFER_DEFAULT_SIZE
 *  define their default size. Should the declaration be overwritten by user 
 *  declarations, variables plibUartRcvBufferArrSize and plibUartSendBufferArrSize 
 *  can be used to derive the real size of these buffer byte arrays.
 * 
 * @note
 *  The receive and transmit buffers are defined in file plib_uart_datamngmnt.c using the
 *  'weak' attribute to allow users to override the buffer array declarations 
 *  with another declaration of the same name in user code.
 *  By doing so, users can declare a new array size and thus adapt the buffer
 *  size to their individual application requirements.
 **********************************************************************************/
#define UART_RX_BUFFER_DEFAULT_SIZE     64  ///< UART receiver buffer default size
#define UART_TX_BUFFER_DEFAULT_SIZE     64  ///< UART transmitter buffer default size

extern uint8_t  plib33cUartRcvBufferArr[];
extern uint16_t plib33cUartRcvBufferArrSize;

extern uint8_t  plib33cUartSendBufferArr[];
extern uint16_t plib33cUartSendBufferArrSize;

/** @} */ // end of p33c-plib-uart-properties ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

/**********************************************************************************
 * @ingroup p33c-plib-uart-properties
 * @brief   UART Driver Receive Ring Buffer
 * @details
 *  This uart driver allows the user to access the ring buffer of the 
 *  receiver in case the received data needs to be manage in a particular use case.
 *  When using plib33cReceiveRingBuffer[], the index of the variable should be 
 *  the instance of a uart minus 1. The user can access the receiver's buffer
 *  pointer, size of the buffer and the tail and head of the incoming data. This
 *  is an example of how to use this variable. 
 * @code{.c}    
 *   plib33cReceiveRingBuffer[uartInstance-1].head 
 * @endcode
 *********************************************************************************/
extern PLIB33C_UART_RINGBUFFER_t plib33cReceiveRingBuffer[];

/**********************************************************************************
 * @ingroup p33c-plib-uart-properties
 * @brief Size of the character string for the uartPrintf
 *********************************************************************************/
#define TEMPSTR_PRINT_UART_SIZE 64

/**********************************************************************************
 * @ingroup p33c-plib-uart-properties
 * @brief This define redirects the sprintf to Uart via DMA
 *********************************************************************************/
#define dmaprintf(uartConfig,...) \
    do{ \
        char cnt;\
        char __print_utils_string[TEMPSTR_PRINT_UART_SIZE]; \
        cnt = sprintf(__print_utils_string, __VA_ARGS__); \
        plib33c_Uart_SendBufferDma(uartConfig, (uint8_t*)(__print_utils_string), cnt); \
    } while(0)

/**********************************************************************************
 * Public Functions
 *********************************************************************************/

extern int plib33c_Uart_U1RxInterruptHandler(void);
extern int plib33c_Uart_U2RxInterruptHandler(void);
extern int plib33c_Uart_U3RxInterruptHandler(void);
extern int plib33c_Uart_U4RxInterruptHandler(void);
extern int plib33c_Uart_U5RxInterruptHandler(void);
extern int plib33c_Uart_U6RxInterruptHandler(void);
extern int plib33c_Uart_U7RxInterruptHandler(void);
extern int plib33c_Uart_U8RxInterruptHandler(void);

extern int plib33c_Uart_Initialize(UART_t* uartConfig, UART_BUFFER_t* interfaceSendBuffer, UART_BUFFER_t* interfaceReceiveBuffer); 
extern int plib33c_Uart_Start(UART_t* uartConfig); 
extern int plib33c_Uart_SendData(UART_t* uartConfig, uint8_t* ptrData, uint16_t dataLength);
extern uint8_t plib33c_Uart_ReceiveData(UART_t* uartConfig);
extern int plib33c_Uart_Close(UART_t* uartConfig);

#endif	/* IUARTHANDLER_H */

// _____________________
// end of file 
