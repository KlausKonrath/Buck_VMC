/*
    (c) 2023 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

#ifndef PLIB_UART_HANDLER_H
#define	PLIB_UART_HANDLER_H

#include <xc_pral.h>
#include "p33c_plib_uart_typedef.h"

extern volatile uint16_t plib33cUartDmaTrgRx[];
extern volatile uint16_t plib33cUartDmaTrgTx[];

/**********************************************************************************
 * Public Functions
 *********************************************************************************/
extern int plib33c_Uart_OpenPort(uint16_t uartInstance, PLIB33C_UART_BAUDRATE_t baud, 
            PLIB33C_UART_DATA_BITS_t dataBits, PLIB33C_UART_PARITY_t parity, 
            PLIB33C_UART_STOP_BITS_t stopBits, PLIB33C_UART_FLOWCONTROL_t flowControl);

extern int plib33c_Uart_SendBufferDma(UART_t* uartConfig, uint8_t* buffer, uint16_t dataLength);
extern int plib33c_Uart_RemapRxPin(UART_t* uartConfig, const P33C_GPIO_t* pin);
extern int plib33c_Uart_RemapTxPin(UART_t* uartConfig, const P33C_GPIO_t* pin);

extern int plib33c_Uart_Enable(uint16_t uartInstance);
extern int plib33c_Uart_Disable(uint16_t uartInstance);
extern int plib33c_Uart_SetBaudrate(uint16_t uartInstance, uint32_t baud);
extern uint32_t plib33c_Uart_GetBaudRate(uint16_t uartInstance);
extern int plib33c_Uart_WriteByte(uint16_t uartInstance, char byte);
extern uint8_t  plib33c_Uart_ReadByte(uint16_t uartInstance);
extern int plib33c_Uart_SendBuffer(uint16_t uartInstance, uint8_t* buffer, uint16_t dataLength);


#endif	/* PLIB_UART_HANDLER_H */

// ___________________
// end of file
