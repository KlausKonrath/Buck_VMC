# dsPIC33C Peripheral Special Function Register Abstraction Layer (PRAL) {#p33c-pral-intro}

## Class

<table style="border: 0px; border-collapse: collapse">
<tr>
<td> <img src="images/psmod.png" width="72"> 
</td>
<td>
- SMPS Firmware Framework Component<br>
- SMPS Firmware Framework Device Interface Layer
</td>
</tr>
</table>

## Summary

Special Function Register Abstraction Declarations and Low-Level Functions reading from and writing to peripheral register sets.

## Dependencies

This firmware framework module is at the lowest architectural level without dependencies on other firmware framework modules. Peripheral abstraction requires devices of product families dsPIC33CK and dsPIC33CH.

---

## Description

### Code Structure

The Peripheral Register Abstraction Layer (PRAL) Library is used to provide abstracted (virtualized) versions of Special Function Register (SFR) sets of target device peripherals.

<center><img src="images/pral-reg-abstraction.png" width="900"></center>

SFRs abstraction is achieved by encapsulating all related and available peripheral registers in a larger data structure, which inherits each single peripheral register from the main target device header file. These registers are aligned in order of their physical appearance in memory, including reserved and non-implemented sections. This allows mapping of abstracted data structures to specific memory addresses at runtime.

In addition to the abstracted register data object, each Peripheral Module Special Function Register Abstraction Module provides standardized functions to read from and write to a peripheral unit and its instances using direct and indirect addressing.

These interfaces serve, among others, three major use-cases:

- **Definition of pre-defined configuration templates** being selectively loaded at runtime. This allows the creation and application of peripheral configuration templates, which can be written to specific instances of a peripheral only known at runtime, easing the replication and migration of peripheral configurations across peripheral instances, devices and applications.
<br>

- **Read, verify, copy & paste configuration contents** of and across peripherals and their instances eases the management of multiple peripheral instances sharing the same configuration. Functional safety applications benefit from fast, register-level read and compare functions verifying correct chip configuration.
<br>

- **Mapable, instance-agnostic runtime access** to all register settings of a peripheral unit provides a mechanism for writing generic device drivers utilizing peripheral functions without direct association to specific peripheral instances. This mechanism is vital to support easy code migration across devices and applications and are the very basis of the chip resource management capabilities of generic device drivers.

### Application

Peripheral Special Function Register Abstraction Layer Drivers (PRAL) are used to provide a simple and direct way of accessing peripheral instances which are not known at compile time. These drivers provide an abstracted version of the dedicated register set of a peripheral unit in form of a data structure. Pointer based handlers are used to assign a generic data structure to a dedicated register set in user code which will get resolved at runtime. When code optimization is used with compiler version XC-DSC 3.00 or higher, the majority of handles may get resolved by the linker, removing handle resolution instructions at runtime.

The API of these drivers provide simple low level access functions

- **GetHandle(uint16_t Instance)**
  Returns the memory address of the first register of the register set of a dedicated peripheral unit (instance or module). Mapping a user-defined peripheral register abstraction data structure to this memory address allows direct access to each peripheral SFR and subsequently to its register bits. The peripheral registers are inherited from the first instance of the peripheral from the XC16/XC-DSC device header file of the recently selected device making sure all supported register bits are properly represented.  
<br>

- **GetConfig(uint16_t Instance)**
  Returns a peripheral register abstraction data structure loaded with the recent register settings of the given peripheral unit (instance or module). This function can be used to read and verify register contents or copy & paste configurations across register instances.  
<br>

- **SetConfig(uint16_t Instance, P33C_xxx_t Config)**
  Writes an initialized peripheral register abstraction data structure to a given peripheral unit (instance or module). This allows quick loading of peripheral configuration templates from user-defined, pre-initialized peripheral SFR abstraction data structure objects.  
<br>

- **Enable(uint16_t Instance), Disable(uint16_t Instance)**
  Enables the peripheral unit (instance or module). Most peripherals with Enable/Disable capabilities are enabled by setting a single register bit without considering further dependencies. Some peripherals, however, require a specific enable sequence to be executed or involve handling/verification of external chip resource dependencies before the peripheral becomes fully functional. This includes unlocking/locking of protected registers or waiting for READY bits to be set, and reversing the enable process in case errors occurred during the process. Enable functions always return True or False indicating if the peripheral unit got successfully enabled or not.
<br>

- **PowerOn(uint16_t Instance), PowerOff(uint16_t Instance)**
  dsPIC33C devices incorporate a Peripheral Module Disable (PMD) control unit, which allows cutting of the power supply to the respective sub-circuit of a peripheral unit (instance or module). Disabling unused peripheral units may help to reduce power consumption and prevents non-deterministic behavior in case an unused peripheral is accidentally enabled or is kept in some active standby state until enabled. When a peripheral is powered off, no read/write operations will take affect. After RESET, all PMD bits are cleared, hence, all peripheral units are active by default.

## Usage Examples

The following code examples for the high-speed PWM driver show how the fundamental functions described above are used.

### a) GetHandle(uint16_t Instance) Example {#p33c-pral-intro-example-a}

This example declares a generic PWM generator register pointer object which gets assigned to the dedicated PWM generator #3. After the assignment the generic data structure object is used to directly read from/write to the SFRs of the dedicated high-speed PWM generator.
These read/write operations are equivalent to hard-coded register manipulation instructions but are now mappable to any PWM generator available without having to change/refactor user code.

```c
    #include <xc_pral.h>

    (...)

    // Capture memory address of PWM generator #3 register set
    P33C_PWM_INSTANCE_t* pg = p33c_PwmInstance_GetHandle(3);

    // Capture SFR memory address of PWM generator #3
    // Access PWM generator #3 configuration registers
    pg->PGxCONL.bits.CLKSEL = 1; // Use clock input selected by MCLKSEL[1:0] (see PCLKCON[1:0])
    pg->PGxCONL.bits.MODSEL = 0; // Use Independent Edge PWM mode
    pg->PGxCONL.bits.HREN = 1; // Enable High Resolution Mode for PWM generator #3 
    pg->PGxIOCONH.bits.PMOD = 1; // PWM generator #3 outputs operate in Independent mode
    pg->PGxPER.value = 8000; // Set the PWM Period to 500 kHz (high-resolution)
    pg->PGxDC.value = 2000; // Set duty cycle to 25%
    pg->PGxCONL.bits.ON = 1; // enabling PWM generator #3

```

### b) GetConfig(uint16_t Instance) Example {#p33c-pral-intro-example-b}

This example declares a generic PWM generator register object which is used to read most recent settings from the special function registers of a given high-speed PWM generator instance.

```c
    #include <xc_pral.h>

    (...)

    // Read complete SFR register set of PWM generator #3 into 
    // abstracted data object 'pg'
    P33C_PWM_INSTANCE_t pg = p33c_PwmInstance_GetConfig(3);

```

### c) SetConfig(uint16_t Instance) Example {#p33c-pral-intro-example-c}

This example declares a generic PWM generator register object which is then used to write a user-defined, generic high-speed PWM generator register settings to the special function registers of a given high-speed PWM generator instance.

```c
    #include <xc_pral.h>

    (...)

    // Create abstracted PWM generator data object
    P33C_PWM_INSTANCE_t pg;

    // Initialize abstracted PWM configuration
    pg.PGxCONL.bits.MODSEL = 0b000; // PWM time-base counter mode selection = Independent Edge PWM mode
    pg.PGxCONL.bits.CLKSEL = 0b01; // Clock selection = MCLKSEL[1:0] control bits
    pg.PGxCONL.bits.HREN = 1 // Enable high resolution mode

    // Write configuration to PWM generator #3 configuration registers
    p33c_PwmInstance_SetConfig(3, pg);

```

### d) Using Templates {#p33c-pral-intro-example-c}

This example declares a pre-initialized, generic PWM generator register object. All register configurations are declared here and will be stored as constant in flash memory as part of the program. At runtime, function SetConfig() is used to load the template into a given PWM generator instance.

```c
    #include <xc_pral.h>

    (...)

    // Create abstracted PWM generator data object in user code and 
    // initialize it with desired user configuration.
    // Attribute space(auto_psv) asks the compiler to place this 
    // configuration template in flash memory, from where it can be 
    // loaded via Program Space Visibility (PSV) virtual memory.
    const __attribute__((space(auto_psv))) P33C_PWM_INSTANCE_t pgConfigComplementary = 
    {
        .PGxCONL.value = 0x0088,    // ON=0, TRGCNT=0b000, HREN=1, CLKSEL=b01, MODSEL=0b000
        .PGxCONH.value = 0x0000,    // MDCSEL=0, MPERSEL=0, MPHSEL=0, MSTEN=0, UPDMOD=0b000, TRGMOD=0, SOCS=0b0000
        .PGxSTAT.value = 0x0000,    // SEVT=0, FLTEVT=0, CLEVT=0, FFEVT=0, SACT=0, FLTACT=0, CLACT=0, FFACT=0, TRSET=0, TRCLR=0, CAP=0, UPDATE=0, UPDREQ=0, STEER=0, CAHALF=0, TRIG=0
        .PGxIOCONL.value = 0x3000,  // CLMOD=0, SWAP=0, OVRENH=1, OVRENL=1, OVRDAT=0, OSYNC=0b00, FLTDAT=0, CLDAT=0, FFDAT=0, DBDAT=0
        .PGxIOCONH.value = 0x0000,  // CAPSRC=0b000, DTCMPSEL=0, PMOD=0b00, PENH=0, PENL=0, POLH=0, POLL=0
        .PGxEVTL.value = 0x0000,    // ADTR1PS=0b00000, ADTR1EN3=0, ADTR1EN2=0, ADTR1EN1=0, UPDTRG=0b00, PGTRGSEL=0b000
        .PGxEVTH.value = 0x0000,    // FLTIEN=0, CLIEN=0, FFIEN=0, SIEN=0, IEVTSEL=0b00, ADTR2EN3=0, ADTR2EN2=0, ADTR2EN1=0, ADTR1OFS=0b00000
        .PGxFPCIL.value = 0x0000,   // TSYNCDIS=0, TERM=0b000, AQPS=0, AQSS=0b000, SWTERM=0, PSYNC=0, PPS=0, PSS=0b00000
        .PGxFPCIH.value = 0x0000,   // BPEN=0, BPSEL=0b000, ACP0b000, SWPCI=0, SWPCIM=0b00, LATMOD=0, TQPS=0, TQSS=0b000
        .PGxCLPCIL.value = 0x0000,  // TSYNCDIS=0, TERM=0b000, AQPS=0, AQSS=0b000, SWTERM=0, PSYNC=0, PPS=0, PSS=0b00000
        .PGxCLPCIH.value = 0x0000,  // BPEN=0, BPSEL=0b000, ACP0b000, SWPCI=0, SWPCIM=0b00, LATMOD=0, TQPS=0, TQSS=0b000
        .PGxFFPCIL.value = 0x0000,  // TSYNCDIS=0, TERM=0b000, AQPS=0, AQSS=0b000, SWTERM=0, PSYNC=0, PPS=0, PSS=0b00000
        .PGxFFPCIH.value = 0x0000,  // BPEN=0, BPSEL=0b000, ACP0b000, SWPCI=0, SWPCIM=0b00, LATMOD=0, TQPS=0, TQSS=0b000
        .PGxSPCIL.value = 0x0000,   // TSYNCDIS=0, TERM=0b000, AQPS=0, AQSS=0b000, SWTERM=0, PSYNC=0, PPS=0, PSS=0b00000
        .PGxSPCIH.value = 0x0000,   // BPEN=0, BPSEL=0b000, ACP0b000, SWPCI=0, SWPCIM=0b00, LATMOD=0, TQPS=0, TQSS=0b000
        .PGxLEBL.value = 0x0000,    // LEB=0
        .PGxLEBH.value = 0x0000,    // PWMPCI=0b000, PHR=0, PHF=0, PLR=0, PLF=0, 
        .PGxPHASE.value = 0x0000,   // PGxPHASE=0
        .PGxDC.value = 0x0000,      // PGxDC=0
        .PGxDCA.value = 0x0000,     // PGxDCA=0
        .PGxPER.value = 0x0000,     // PGxPER=0
        .PGxTRIGA.value = 0x0000,   // PGxTRIGA=0
        .PGxTRIGB.value = 0x0000,   // PGxTRIGB=0
        .PGxTRIGC.value = 0x0000,   // PGxTRIGC=0
        .PGxDTL.value = 0x0000,     // DTL=0
        .PGxDTH.value = 0x0000,     // DTH=0
        .PGxCAP.value = 0x0000      // CAP=0
    };
    
    (...)

    // Initialize PWM Generator 3 and 4 as independent complementary PWMs
    void PwmInit()
    {
        // Write configuration to PWM generator #3 configuration registers
        p33c_PwmInstance_SetConfig(3, pgConfigComplementary);
        // Write configuration to PWM generator #4 configuration registers
        p33c_PwmInstance_SetConfig(4, pgConfigComplementary);
    }

```

## Required Tools

- (none)

## Additional Resources

- (none)

---

&copy; 2023, Microchip Technology Inc. All rights reserved.