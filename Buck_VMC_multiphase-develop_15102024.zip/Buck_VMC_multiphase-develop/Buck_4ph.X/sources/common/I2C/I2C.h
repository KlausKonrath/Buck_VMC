/*
    (c) 2023 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

#ifndef I2C_H
#define	I2C_H

#include <xc_pral.h>

////////////////////////////////////////////////////////////////////////////////
// This parameter sets the TRIS register of I/O used for SCL signal.
// VERIFY THAT IN YOUR APPLICATION THE SCL PIN IS CONFIGURED AS
// A DIGITAL INPUT IN ANSELx REGISTER.
#define SCL_TRIS   _TRISB8
////////////////////////////////////////////////////////////////////////////////
// This parameter sets the ODC register of I/O used for SCL signal.
#define SCL_ODC    _ODCB8
////////////////////////////////////////////////////////////////////////////////
// This parameter sets the LAT register of I/O used for SCL signal.
#define SCL_LAT    _LATB8    
////////////////////////////////////////////////////////////////////////////////
// This parameter sets the PORT register of I/O used for SCL signal.
#define SCL_PORT   _RB8            

////////////////////////////////////////////////////////////////////////////////
// This parameter sets the TRIS register of I/O used for SDA signal.
// VERIFY THAT IN YOUR APPLICATION THE SCL PIN IS CONFIGURED AS
// A DIGITAL INPUT IN ANSELx REGISTER.
#define SDA_TRIS   _TRISB9
////////////////////////////////////////////////////////////////////////////////
// This parameter sets the ODC register of I/O used for SDA signal.
#define SDA_ODC    _ODCB9
////////////////////////////////////////////////////////////////////////////////
// This parameter sets the LAT register of I/O used for SDA signal.
#define SDA_LAT    _LATB9    
////////////////////////////////////////////////////////////////////////////////
// This parameter sets the PORT register of I/O used for SDA signal.
#define SDA_PORT   _RB9


/**********************************************************************************
 * I2C Command Codes
 *********************************************************************************/
#define Cmd_Idle                0x00U
#define Cmd_StatusInformation   0x01U
#define Cmd_VersionInformation  0x02U
#define Cmd_ProcessData         0x03U
#define Cmd_ComparatorVoltage   0x04U
#define Cmd_ColdRestart         0x05U
#define Cmd_Bootloader          0x06U


/**********************************************************************************
 * I2C Command - response lenght
 *********************************************************************************/
#define Length_StatusInformation_Resp           0x03U
#define Length_VersionInformation_Resp          0x06U
#define Length_ProcessData_Resp                 0x26U
#define LengthData_ComparatorVoltage_Resp       0x02U
#define LengthComplete_ComparatorVoltage_Resp   0x05U
#define Length_CompVoltage_Req                  0x04U
#define LengthData_ColdRestart_Resp             0x01U
#define LengthComplete_ColdRestart_Resp         0x04U
#define Length_Bootloader_Resp                  0x01U

/**********************************************************************************
 * Public Functions
 *********************************************************************************/
void I2C_Initialize(void);
void I2C_Handler(void);
uint16_t crc16(const uint8_t *data, uint8_t length);

#endif	/* PLIB_UART_HANDLER_H */

// ___________________
// end of file
