![image](images/microchip.png)

---

# dsPIC33C Phase-Shifted Full Bridge Firmware


<p>
<center>
<a target="_blank" href="https://www.digikey.de/en/products/detail/analog-devices-inc/ADP1051-240-EVALZ/4376319" rel="nofollow">
<img src="images/ADP1051-240-EVALZ-2.jpg" alt="ADP1051-240-EVALZ Reference Design">
</a><br>
<a target="_blank" href="https://www.microchip.com/DM330017-3" rel="nofollow">
ADP1051-240-EVALZ Reference Design
</a>
</center>
</p>

---

## Summary

Average Current Mode Control (ACMC) example of an isolated Phase-Shifted Full Bridge (PSFB) DC-to-DC converter using the dsPIC33CK family of devices.

## Description

This code example demonstrates an average current mode control example using dsPIC33CK Digital Signal Controllers. The firmware supports a compile switch allowing to switch between operating the Analog Devices ADP1051-240-EVALZ 240W 48/12V 240W Phase-Shifted Full Bridge (PSFB) Converter Reference Design or running the firmware in a PLECS simulated environment using the Processor-In-The-Loop (PIL) simulation method.

## Hardware Requirements

- Analog Devices ADP1051-240-EVALZ 240W 48/12V PSFB Converter Reference Design
  - [ADP1051-240-EVALZ User Guide](https://www.analog.com/media/en/technical-documentation/user-guides/ADP1051-240-EVALZ_ADP1050DC1-EVALZ_UG-664.pdf)
  - [Buy Now on Digikey (Part-No. ADP1051-240-EVALZ-ND)](https://www.digikey.de/de/products/detail/analog-devices-inc/ADP1051-240-EVALZ/4376319?utm_adgroup=Analog%20Devices%2C%20Inc.&utm_source=google&utm_medium=cpc&utm_campaign=Dynamic%20Search_DE_Suppliers&utm_term=&productid=&utm_content=Analog%20Devices%2C%20Inc.&utm_id=go_cmp-1692565868_adg-76752629175_ad-668161653550_dsa-471259476160_dev-c_ext-_prd-_sig-CjwKCAiAu9yqBhBmEiwAHTx5pz-ao2d6tEGRedCTIB17988mp8Rd7qgGq_xu74azzgfefovUNjfIuxoCppYQAvD_BwE&gad_source=1&gclid=CjwKCAiAu9yqBhBmEiwAHTx5pz-ao2d6tEGRedCTIB17988mp8Rd7qgGq_xu74azzgfefovUNjfIuxoCppYQAvD_BwE)
- ADP1050-to-dsPIC33CK DP PIM Interposer Card, (Microchip Proprietary, no Part-No., available on request)
- Supported Processor Plug-In Modules:
  - dsPIC33CK256MP506 Digital Power Plug-In Module (DP PIM)
    - [Product Website](https://www.microchip.com/ma330048)
    - [Buy Now on Microchip Direct (Part.-No. MA330048)](https://www.microchipdirect.com/product/MA330048)
  - dsPIC33CK512MP606 Digital Power Plug-In Module (DP PIM)
    - Product Website (coming soon)
    - [Buy Now on Microchip Direct (Part.-No. EV12Y79A)](https://www.microchipdirect.com/product/EV12Y79A)

### Optional Hardware for PLECS PIL Simulation

- dsPIC33&reg; Digital Power Development Board
  - [Product Website](https://www.microchip.com/DM330029)
  - [Buy Now on Microchip Direct (Part.-No. DM330029)](https://www.microchipdirect.com/product/DM330029)

## Software Requirements

- [MPLAB&reg; X IDE v6.15](https://www.microchip.com/mplabx-ide-windows-installer)
- [MPLAB&reg; XC16 Compiler v2.10](https://www.microchip.com/mplabxc16windows)
- [MPLAB&reg; PowerSmart&trade; Development Suite v1.0](https://www.microchip.com/powersmart)
- PIL Simulation:
  - [PLEXIM PLECS v4.7.5](https://www.plexim.com/download) (requires 3rd Partxy License issued by PLEXIM)

## Documentation

### dsPIC33C&reg; Digital Signal Controller Data Sheets

- dsPIC33CK256MP508 (Sagitta) Family of Devices
  - [dsPIC33CK256MP508 Family Data Sheet](https://www.microchip.com/70005349)
  - [dsPIC33CK256MP508 Family Silicon Errata and Data Sheet Clarification](https://www.microchip.com/80000796)

- dsPIC33CK512MP608 (Sagitta+) Family of Devices
  - [dsPIC33CK512MP608 Family Data Sheet](https://www.microchip.com/70005452)
  - [dsPIC33CK512MP608 Family Silicon Errata and Data Sheet Clarification](https://www.microchip.com/80000966)

### dsPIC33C&reg; Plug-In-Modules

- [dsPIC33CK256MP506 Digital Power Plug-In Module User Guide](https://www.microchip.com/50002819)
- dsPIC33CK512MP606 Digital Power Plug-In Module User Guide (coming soon)
- [dsPIC33&reg; Digital Power Development Board (optional)](https://www.microchip.com/50002814)

---

&copy; 2023, Microchip Technology Inc.
