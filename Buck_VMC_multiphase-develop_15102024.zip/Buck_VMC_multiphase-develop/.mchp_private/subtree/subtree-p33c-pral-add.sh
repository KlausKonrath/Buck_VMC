#!/bin/sh
echo $SSH_AUTH_SOCK
cd ../../
git remote add subrepo-p33c-pral https://bitbucket.microchip.com/scm/mcu16asmpsl/p33c-peripheral-register-interface-layer.git
git subtree add --prefix="ADI_PSFB.X/sources/common/p33c_pral" subrepo-p33c-pral prelim --squash 
echo Press Enter to exit
read
