#!/bin/sh
echo $SSH_AUTH_SOCK
cd ../../
echo Pulling changes from subtree 'subrepo-os' branch 'prelim' into recently checked out working branch...
git subtree pull --prefix="ADI_PSFB.X/sources/os" subrepo-os prelim --squash 
echo Pull complete
echo
echo Press Enter to exit
read
