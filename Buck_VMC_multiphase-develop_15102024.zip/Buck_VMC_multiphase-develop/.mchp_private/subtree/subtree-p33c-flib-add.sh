#!/bin/sh
echo $SSH_AUTH_SOCK
cd ../../
echo Adding subtree repository 'subrepo-p33c-flib' to project repository...
git remote add subrepo-p33c-flib https://bitbucket.microchip.com/scm/mcu16asmpsl/p33c-function-libraries.git
echo Adding subtree repository complete
echo 
echo Downloading subtree contents into project repository...
git subtree add --prefix="ADI_PSFB.X/sources/common/p33c_flib" subrepo-p33c-flib prelim --squash 
echo Download source files complete
echo
echo Press Enter to exit
read
