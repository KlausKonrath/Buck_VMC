#!/bin/sh
echo $SSH_AUTH_SOCK
cd ../../
echo Pulling changes from subtree 'subrepo-p33c-flib' branch 'prelim' into recently checked out working branch...
git subtree pull --prefix="ADI_PSFB.X/sources/common/p33c_flib" subrepo-p33c-flib prelim --squash 
echo Pull complete
echo
echo Press Enter to exit
read
