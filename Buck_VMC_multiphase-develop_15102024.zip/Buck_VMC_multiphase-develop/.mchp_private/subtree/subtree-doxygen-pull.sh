#!/bin/sh
echo $SSH_AUTH_SOCK
cd ../../
#echo Splitting Subtree subrepo-doxygen into working branch subrepo-buck-update...
#git subtree split --prefix="ADI_PSFB.X/sources/power_control/devices" --annotate='(split)' --branch 'subrepo-doxygen-update'

#echo Switch to branch subrepo-doxygen-update...
#git checkout subrepo-doxygen-update
#git gitk subrepo-doxygen-update
#$ git push "https://bitbucket.microchip.com/scm/mcu16asmpsl/subrepo-doxygen-templates.git" subrepo-doxygen:version-update

git subtree pull --prefix=".mchp_private/doxygen" subrepo-doxygen prelim --squash
echo Press Enter to exit
read
