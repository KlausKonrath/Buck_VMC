#!/bin/sh
echo $SSH_AUTH_SOCK
cd ../../
git remote add subrepo-doxygen https://bitbucket.microchip.com/scm/mcu16asmpsl/subrepo-doxygen-templates.git
git subtree add --prefix=".mchp_private/doxygen" subrepo-doxygen prelim --squash
echo Press Enter to exit
read
