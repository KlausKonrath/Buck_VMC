#!/bin/sh
#echo $SSH_AUTH_SOCK
#cd ../../
#echo Splitting Subtree subrepo-uart into working branch version-update...
#git subtree split --prefix="ADI_PSFB.X/sources/app_uart/drivers" --annotate='(split)' --branch 'version-update'

#echo Switch to branch version-update...
#git checkout version-update
#git gitk version-update
#$ git push "https://bitbucket.microchip.com/scm/mcu16asmpsl/p33c-device-driver-library.git" subrepo-p33c-plib:version-update

#git subtree pull --prefix="ADI_PSFB.X/sources/common/p33c_plib" subrepo-p33c-plib develop --no-squash 
#echo Press Enter to exit
#read

#!/bin/sh
echo $SSH_AUTH_SOCK
cd ../../
echo Pulling changes from subtree 'subrepo-p33c-plib' branch 'prelim' into recently checked out working branch...
git subtree pull --prefix="ADI_PSFB.X/sources/common/p33c_plib" subrepo-p33c-plib prelim --squash 
echo Pull complete
echo
echo Press Enter to exit
read