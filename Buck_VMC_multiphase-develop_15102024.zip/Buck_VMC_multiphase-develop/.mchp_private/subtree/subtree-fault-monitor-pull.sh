#!/bin/sh
echo $SSH_AUTH_SOCK
cd ../../
git subtree pull --prefix="ADI_PSFB.X/sources/apps/fault_monitor/svc" subrepo-fault prelim --squash
echo Press Enter to exit
read

