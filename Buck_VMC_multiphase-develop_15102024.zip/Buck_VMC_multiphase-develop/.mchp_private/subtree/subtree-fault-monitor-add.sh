#!/bin/sh
echo $SSH_AUTH_SOCK
cd ../../
git remote add subrepo-fault https://bitbucket.microchip.com/scm/mcu16asmpsl/subrepo-fault-monitor.git
git subtree add --prefix="ADI_PSFB.X/sources/apps/fault_monitor/svc" subrepo-fault prelim --squash
echo Press Enter to exit
read

