#!/bin/sh
echo $SSH_AUTH_SOCK
cd ../../
git subtree pull --prefix="ADI_PSFB.X/sources/common/p33c_pral" subrepo-p33c-pral prelim --squash 
echo Press Enter to exit
read
