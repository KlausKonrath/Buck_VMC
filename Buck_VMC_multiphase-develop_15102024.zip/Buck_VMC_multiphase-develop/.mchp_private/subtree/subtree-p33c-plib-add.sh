#!/bin/sh
echo $SSH_AUTH_SOCK
cd ../../
git remote add subrepo-p33c-plib https://bitbucket.microchip.com/scm/mcu16asmpsl/p33c-device-driver-library.git
git subtree add --prefix="ADI_PSFB.X/sources/common/p33c_plib" subrepo-p33c-plib prelim --squash
echo Press Enter to exit
read
