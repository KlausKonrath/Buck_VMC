# dspic33c-power-psfb-adi, v0.3.0

## Summary

This release introduces a linear Droop control implementation of output voltage over load current. The output voltage slew rate is defined in the hardware abstraction layer header file nnn_config.h using the following settings:

- DROOP_IAVG_ARRAY_SIZE = 64: Averaging filter data buffer size (equals number of samples within moving averaging window)
- DROOP_NORM_SHIFT = 3: Q15 number normalization bit-shift for the input source number format
- DROOP_VOLTAGE_SLOPE = 0.030 V/A: Voltage drop over load in [V/A]
- DROOP_MINIMUM_CURRENT = 1.000 A: Minimum output current required before Droop control is enabled

The Droop controller responds to the moving average result of the output current. If DROOP_IAVG_ARRAY_SIZE is shorter, the Droop control becomes more agile, if DROOP_IAVG_ARRAY_SIZE is longer, it becomes more stable.

DROOP_NORM_SHIFT is an internal value required to maximize the number precision and minimize deviations. Teh moving average filter used in this project is fed by ADC samples with a total bit-width of 12 bit. The averaged result is provided in the same number format. Hence, the Droop controller shifts this 12-bit number up to Q15 for the slope calculation. During this up- and down-scaling some LSBs are lost. A future improvement could be to rescale the moving average filter output directly to Q15.

DROOP_VOLTAGE_SLOPE is the definition of the Droop ratio over load, defined in V/A.
Droop usually defines

- a positive offset related to the nominal output voltage at no load
- a cross-over of Droop voltage and nominal output voltage at 50% load
- a negative offset related to the nominal output voltage between 50% and 100% load

However, this implementation only defines a negative slope, which is set relative to the given nominal output voltage.
Hence, to adjust the Droop voltage ramp to cross nominal output voltage at 50% requires to increase the setting of the nominal output voltage accordingly.

DROOP_MINIMUM_CURRENT defines a minimum current at which Droop control is applied. This often helps to stabilize multiple power supplies at no load conditions to remain and maintain a stable bus voltage. It is recommended to set DROOP_MINIMUM_CURRENT at a level where the magnitude current feedback is reliable and robustly greater than the noise floor (including offsets and tolerances).

**Please note**:
DROOP_MINIMUM_CURRENT is subtracted from the Droop input current value. Hence, this offset must be considered when setting up the Droop ramp across load.

## Changelog

- Added moving average filter library to project
- Added moving average filter data object to power supply control module
- Added new power supply runtime data member Iavg (serves as target for moving average filter)
- Added Droop controller to power supply state machine
- Added Droop voltage reference control interface to voltage loop controller Assembly library
- Added Droop control to state machine states RampUp and Online. Droop is continuously active when outer voltage loop is closed.
- Recovered online reference ramp adjustment in state machine state ONLINE. If reference voltage is changed externally, state machine injects a ramp transition from the original setting the the new reference.
- Removed obsolete voltage mode controller
- Overall code cleanup (no functional change)

- Bugfix:
  - Added output current shunt amplifier circuit providing/creating output current data
  - Enabled output current probe interface in PLECS, now injecting data to the firmware

---

# dspic33c-power-psfb-adi, v0.2.2

## Summary

In this release the code generation conflicts preventing MPLAB X from building new data content for the PIL communication with PLECS have been resolved and operation has been verified with Analog Devices ADP1051-240-EVALZ 240W 48/12V PSFB Converter Reference Design. This firmware version supports dsPIC33CK256MP506 (Sagitta) and dsPIC33CK512MP606 (Sagitta+) family of devices.

## Changelog

- Fixed pre-build step command line switches used to call PILPREPTOOL.exe generating PilProbe declarations and symbols in pil_symbols_p.c and pil_symbols_c.c
- Modified build batch file buildsteps.bat to produce more meaningful output in the output window
- Moved PIL related files into single sub-directory sources/pil
- Introduced new sysUserServices_Initialize() function to separate and isolate PIL functions from rest of firmware
- Reviewed and flattened header include paths resolving conflicts with pilpreptool.exe preprocessor build step
- Resolved naming conflict between SPI peripheral register declaration in main device header file and peripheral register abstraction layer data structure members causing pilpreptool.exe to fail
- Fixed pin assignment in dsPIC33CK256MP506 DP PIM header file (affecting operating with real hardware only)
- Changed value of Over Current Protection level from 6A to 15A, causing simulation to fail during startup
- Modified left- and right-leg current balancing of primary full bridge solving minor control instability (affecting operating with real hardware only)
- Cleaned up code from obsolete debugging instructions and comments
- Cleaned up code format and reviewed comments

---

# dspic33c-power-psfb-adi, Hotfix v0.2.1

## Summary

This hotfix solves the following issues with launching a dsPIC33CK512MP606 PIL simulation

- Wrong ADC interrupt assignment in device header file of dsPIC33CK512MP606 DP PIM
- Disabled task queue execution traps when PIL simulation is running (WITH_PIL only)
- Resolved address trap triggered when clearing control loop histories

---

# dspic33c-power-psfb-adi, release v0.2.0

## Summary

This code example demonstrates an average current mode control example using dsPIC33CK Digital Signal Controllers. The firmware supports a compile switch allowing to switch between operating the Analog Devices ADP1051-240-EVALZ 240W 48/12V 240W Phase-Shifted Full Bridge (PSFB) Converter Reference Design or running the firmware in a PLECS simulated environment using the Processor-In-The-Loop (PIL) simulation method.

## Hardware Requirements

- Analog Devices ADP1051-240-EVALZ 240W 48/12V PSFB Converter Reference Design, (Part-No. Digikey ADP1051-240-EVALZ-ND)
- ADP1050-to-dsPIC33CK DP PIM Interposer Card, (Microchip Proprietary, no Part-No.)

## Release Highlights

- Upgraded RTOS 6G2 to version 2.0.67
- Updated Peripheral Register Abstraction Layer library to version 2.0.17
- Added device support for dsPIC33CK512MP608 (Sagitta+) family of devices
- Updated PLECS PIL support files

**Supported Processor Plug-In Modules:**

- dsPIC33CK256MP506 Digital Power Plug-In Module (DP PIM), (Part.-No. MA330048)
- dsPIC33CK512MP606 Digital Power Plug-In Module (DP PIM), (Part.-No. EV12Y79A) (newly added)

## Known Issues

- PIL Simulation and ADI PSFB board operation still in review
- Upgrade of PowerSmart&trade; Firmware Framework is in progress:
  - Updated components:
    - Task Scheduler (RTOS 6G2)
    - Peripheral Register Abstraction Layer (P33C PRAL)
    - Hardware Abstraction Layer (HAL)
    - Configuration layer header files
  - Legacy Components
    - Power supply control state machine library
    - Feedback loop generation uses PowerSmart&trade; DCLD API v1.0
      - Support of dsPIC33C Sagitta+ devices requires manual modification of variable attributes
    - Fault handler library

## Compiler Settings

This project contains multiple PLAB&reg; X Project Configurations to quickly switch between different devices and PIL support options via the Configuration Selection Drop-Down Menu in MPLAB&reg; X IDE. Please take the following requirements into consideration when any of these configurations are modified.

- Optimization Level #0 is not supported and will result in memory allocation errors.
    Always use code optimization level #1 or higher.
- Default code optimization has been set to level #2 as best performance/code size tradeoff.
    Optimization level #2 is the highest optimization level supported by the free XC16 C-Compiler license
- PIL support requires the declaration of 2048 byte of HEAP space, while __NO_PIL__ configurations do not.
- Garbage collection (option Remove Unused Setions) must be turned off with PIL support enabled
- Required Common Macros in each MPLAB&reg; X Project Configuration
  - DP PIM Hardware Selection: __P33CK256MP506_DPPIM__ or __P33CK512MP606_DPPIM__
  - Power Board Selection: __ADP1051_240_EVALZ_
  - PIL Support Selection: __WITH_PIL__ or __NO_PIL__
- Required Path Declarations in each PLAB&reg; X Project Configuration
  - Common Include Directories:
    - sources/common/p33c_pral
  - C Include Directories:
    - sources
  - ASM Include Directories:
    - sources

---

# dspic33c-power-psfb-adi, release v0.1.0

## Release Highlights

Initial release for the ADP1051-240-EVALZ 240W Phase-Shifted Full Bridge Converter Reference Design with dsPIC33CK DP-PIM running in average current mode control with PLECS Processor-In-The-Loop (PIL) simulation support.

## Hardware Requirements

- Analog Devices ADP1051-240-EVALZ 240W 48/12V PSFB Converter Reference Design, (Part-No. Digikey ADP1051-240-EVALZ-ND)
- ADP1050-to-dsPIC33CK DP PIM Interposer Card, (Microchip Proprietary, no Part-No.)
- dsPIC33CK256MP506 Digital Power Plug-In Module (DP PIM), (Part.-No. MA330048)

## Features

This code example demonstrates an average current mode control example using dsPIC33CK Digital Signal Controllers. The firmware supports a compile switch allowing to switch between operating the ADP1051-240-EVALZ 240W 48/12V PSFB reference design or running the firmware in a PLECS simulated environment using the Processor-In-The-Loop (PIL) simulation method

## Known Issues

- PowerSmart Firmware Framework version 1.4. 52 is outdated (07/2022) and requires to be updated to latest version 2.0.67
- PIL Simulation and ADI PSFB board operation still in review.

---

&copy; 2023, Microchip Technology Inc.