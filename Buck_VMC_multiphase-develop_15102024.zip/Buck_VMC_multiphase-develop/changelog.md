# dspic33c-power-psfb-adi, v0.2.2

## Summary

In this release the code generation conflicts preventing MPLAB X from building new data content for the PIL communication with PLECS have been resolved and operation has been verified with Analog Devices ADP1051-240-EVALZ 240W 48/12V PSFB Converter Reference Design. This firmware version supports dsPIC33CK256MP506 (Sagitta) and dsPIC33CK512MP606 (Sagitta+) family of devices.

## Changelog

- Fixed pre-build step command line switches used to call PILPREPTOOL.exe generating PilProbe declarations and symbols in pil_symbols_p.c and pil_symbols_c.c
- Modified build batch file buildsteps.bat to produce more meaningful output in the output window
- Moved PIL related files into single sub-directory sources/pil
- Introduced new sysUserServices_Initialize() function to separate and isolate PIL functions from rest of firmware
- Reviewed and flattened header include paths resolving conflicts with pilpreptool.exe preprocessor build step
- Resolved naming conflict between SPI peripheral register declaration in main device header file and peripheral register abstraction layer data structure members causing pilpreptool.exe to fail
- Fixed pin assignment in dsPIC33CK256MP506 DP PIM header file (affecting operating with real hardware only)
- Changed value of Over Current Protection level from 6A to 15A, causing simulation to fail during startup
- Modified left- and right-leg current balancing of primary full bridge solving minor control instability (affecting operating with real hardware only)
- Cleaned up code from obsolete debugging instructions and comments
- Cleaned up code format and reviewed comments

---

&copy; 2023, Microchip Technology Inc.
