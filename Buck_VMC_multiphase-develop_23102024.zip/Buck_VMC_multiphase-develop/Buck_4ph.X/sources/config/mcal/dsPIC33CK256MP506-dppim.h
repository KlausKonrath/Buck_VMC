/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */
/* 
 * @file    dspic33ck256mp506-dppim.h
 * @author  M91406
 * @brief   Digital Power Processor Plug-In Module Hardware Abstraction Layer Header File
 * @date    12/12/23
 * @version 1.0.7
 */


// This is a guard condition so that contents of this file are not included
// more than once. 
#ifndef P33CK_MA330048_R30_H
#define P33CK_MA330048_R30_H

#ifndef __MA330048_R30__
    #define __MA330048_R30__
#endif

#include <xc_pral.h> // include processor register abstraction extension header file

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// MCU Pin Assignment Macros
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

// ON-BOARD FEATURE SIGNAL POLARITY

#define DBGLED_ON               1U          ///< pin state when debugging LED is on  (1=HIGH, 0=LOW)
#define DBGLED_OFF              0U          ///< pin state when debugging LED is on  (1=HIGH, 0=LOW)

// INTERNAL ON-BOARD FUNCTIONS/FEATURES PIN MAPPING

#define BEC21                   PIN_RD12    ///< EN-Bypass pin
#define DBGLED                  PIN_RC12    ///< Debug LED
#define BEC08                   PIN_RD15    ///< EN-DCDC-Inrush
#define DBGDAC                  PIN_RA3     ///< DAC Output pin for debugging and loop measurement
#define VINJECT                 PIN_RD10    ///< Voltage Injection Test Pin
#define VCP_RX                  PIN_RD4     ///< USB-2-UART Converter Receiver Signal 
#define VCP_TX                  PIN_RD3     ///< USB-2-UART Converter Transceiver Signal
#define I2C2_SDA                PIN_RB5     ///< I2C Data Signal
#define I2C2_SCL                PIN_RB6     ///< I2C Clock Signal

// CARD EDGE CONNECTOR PIN MAPPING

#define CEC01                   PIN_AVSS    ///< Tied to Analog Ground GND_A (fixed, do not change)
#define CEC02                   PIN_AVSS    ///< Tied to Analog Ground GND_A (fixed, do not change)
#define CEC03                   PIN_RA3     ///< AN3/CMP1C/DACOUT1  => Shared ADC Core
#define CEC04                   PIN_RC3     ///< AN15/CMP2A/RP51    => Shared ADC Core
#define CEC05                   PIN_RB8     ///< AN10/RP40/PGD1     => Shared ADC Core
#define CEC06                   PIN_RB2     ///< AN1/AN7/ANA0/CMP1D/CMP2D/CMP3D/RP34 => Dedicated ADC Core 1
#define CEC07                   PIN_NC      ///< (not connected)
#define CEC08                   PIN_RA4     ///< AN4/CMP3B          => Shared ADC Core
#define CEC09                   PIN_RC6     ///< AN17/ANN1/RP54     => Shared ADC Core
#define CEC10                   PIN_RB7     ///< AN2/CMP3A/RP39     => Shared ADC Core
#define CEC11                   PIN_RA1     ///< ANA1               => Dedicated ADC Core 1
#define CEC12                   PIN_RA0     ///< AN0/CMP1A          => Dedicated ADC Core 0
#define CEC13                   PIN_RD11    ///< AN19/CMP2C/RP75    => Shared ADC Core
#define CEC14                   PIN_RC7     ///< AN16/RP55          => Shared ADC Core
#define CEC15                   PIN_RD10    ///< AN18/CMP3C/RP74    => Shared ADC Core
#define CEC16                   PIN_RC0     ///< AN12/ANN0/RP48     => Shared ADC Core
#define CEC17                   PIN_RC2     ///< AN14/CMP2B/RP50    => Shared ADC Core
#define CEC18                   PIN_RC1     ///< AN13/CMP1B/RP49    => Shared ADC Core
#define CEC19                   PIN_RA2     ///< AN9                => Shared ADC Core
#define CEC20                   PIN_RB1     ///< AN6/RP33           => Shared ADC Core
// --------
#define CEC21                   PIN_NONE    ///< (connector gap)
#define CEC22                   PIN_NONE    ///< (connector gap)
// --------
#define CEC23                   PIN_RB9     ///< RP41/AN11/PGC1     => Shared ADC Core
#define CEC24                   PIN_RC8     ///< RP56/ASDA1
#define CEC25                   PIN_RC10    ///< RP58/PWM7H
#define CEC26                   PIN_RD14    ///< RP78
#define CEC27                   PIN_RC11    ///< RP59/PWM7L
#define CEC28                   PIN_RD9     ///< RP73
#define CEC29                   PIN_NC      ///< (not connected)
#define CEC30                   PIN_NC      ///< (not connected)
#define CEC31                   PIN_RC14    ///< RP62/PWM6H
#define CEC32                   PIN_RC9     ///< RP57/ASCL1
#define CEC33                   PIN_RC15    ///< RP63/PWM6L
#define CEC34                   PIN_RD5     ///< RP69
#define CEC35                   PIN_RC4     ///< RP52/PWM5H/ASDA2
#define CEC36                   PIN_RD6     ///< RP70
#define CEC37                   PIN_RB10    ///< RP42/PWM3H
#define CEC38                   PIN_RC5     ///< RP53/PWM5L/ASCL2
#define CEC39                   PIN_RD2     ///< RP66
#define CEC40                   PIN_RB13    ///< RP45/PWM2L
#define CEC41                   PIN_RB11    ///< RP43/PWM3L
#define CEC42                   PIN_RB12    ///< RP44/PWM2H
#define CEC43                   PIN_RD1     ///< RP65/PWM4H
#define CEC44                   PIN_RD0     ///< RP64/PWM4L
#define CEC45                   PIN_RB14    ///< RP46/PWM1H
#define CEC46                   PIN_RC12    ///< RP60/PWM8HF
#define CEC47                   PIN_RB15    ///< RP47/PWM1L
#define CEC48                   PIN_RC13    ///< RP61/PWM8L
#define CEC49                   PIN_MCLR    ///< MCU Reset Pin (MCLR)
#define CEC50                   PIN_RD7     ///< RP71
#define CEC51                   PIN_RB4     ///< RP36/PGC2
#define CEC52                   PIN_RD8     ///< RP72
#define CEC53                   PIN_RB6     ///< RP38/SCL2/PGC3
#define CEC54                   PIN_RD13    ///< RP77/ANN2
#define CEC55                   PIN_RB5     ///< RP37/SDA2/PGD3
#define CEC56                   PIN_RB3     ///< RP35/AN8/PGD2      => Shared ADC Core
#define CEC57                   PIN_5V      ///< Tied to VDD_EXT (5V DC) (fixed, do not change)
#define CEC58                   PIN_VSS     ///< Tied to Digital Ground GND_D (fixed, do not change)
#define CEC59                   PIN_5V      ///< Tied to VDD_EXT (5V DC) (fixed, do not change)
#define CEC60                   PIN_VSS     ///< Tied to Digital Ground GND_D (fixed, do not change)
#define BEC28                   PIN_RB0

// -----------------------------
// Analog Input Interrupt Macros

#define CEC03_ADCANxInterrupt   _ADCAN3Interrupt ///< Interrupt service routine label
#define CEC03_ADCANxIF          _ADCAN3IF   ///< Interrupt flag bit
#define CEC03_ADCANxIE          _ADCAN3IE   ///< Interrupt enable bit
#define CEC03_ADCANxIP          _ADCAN3IP   ///< Interrupt priority bit
#define CEC03_ADCBUF            ADCBUF3     ///< ADC input buffer register

#define CEC04_ADCANxInterrupt   _ADCAN15Interrupt ///< Interrupt service routine label
#define CEC04_ADCANxIF          _ADCAN15IF  ///< Interrupt flag bit
#define CEC04_ADCANxIE          _ADCAN15IE  ///< Interrupt enable bit
#define CEC04_ADCANxIP          _ADCAN15IP  ///< Interrupt priority bit
#define CEC04_ADCBUF            ADCBUF15    ///< ADC input buffer register

#define CEC05_ADCANxInterrupt   _ADCAN10Interrupt ///< Interrupt service routine label
#define CEC05_ADCANxIF          _ADCAN10IF  ///< Interrupt flag bit
#define CEC05_ADCANxIE          _ADCAN10IE  ///< Interrupt enable bit
#define CEC05_ADCANxIP          _ADCAN10IP  ///< Interrupt priority bit
#define CEC05_ADCBUF            ADCBUF10    ///< ADC input buffer register

#define CEC06_ADCANxInterrupt   _ADCAN1Interrupt ///< Interrupt service routine label
#define CEC06_ADCANxIF          _ADCAN1IF   ///< Interrupt flag bit
#define CEC06_ADCANxIE          _ADCAN1IE   ///< Interrupt enable bit
#define CEC06_ADCANxIP          _ADCAN1IP   ///< Interrupt priority bit
#define CEC06_ADCBUF            ADCBUF1     ///< ADC input buffer register

#define CEC08_ADCANxInterrupt   _ADCAN4Interrupt ///< Interrupt service routine label
#define CEC08_ADCANxIF          _ADCAN4IF   ///< Interrupt flag bit
#define CEC08_ADCANxIE          _ADCAN4IE   ///< Interrupt enable bit
#define CEC08_ADCANxIP          _ADCAN4IP   ///< Interrupt priority bit
#define CEC08_ADCBUF            ADCBUF4     ///< ADC input buffer register

#define BEC28_ADCANxInterrupt   _ADCAN5Interrupt ///< Interrupt service routine label
#define BEC28_ADCANxIF          _ADCAN5IF   ///< Interrupt flag bit
#define BEC28_ADCANxIE          _ADCAN5IE   ///< Interrupt enable bit
#define BEC28_ADCANxIP          _ADCAN5IP   ///< Interrupt priority bit
#define BEC28_ADCBUF            ADCBUF5     ///< ADC input buffer register

#define CEC09_ADCANxInterrupt   _ADCAN17Interrupt ///< Interrupt service routine label
#define CEC09_ADCANxIF          _ADCAN17IF  ///< Interrupt flag bit
#define CEC09_ADCANxIE          _ADCAN17IE  ///< Interrupt enable bit
#define CEC09_ADCANxIP          _ADCAN17IP  ///< Interrupt priority bit
#define CEC09_ADCBUF            ADCBUF17    ///< ADC input buffer register

#define CEC10_ADCANxInterrupt   _ADCAN2Interrupt ///< Interrupt service routine label
#define CEC10_ADCANxIF          _ADCAN2IF   ///< Interrupt flag bit
#define CEC10_ADCANxIE          _ADCAN2IE   ///< Interrupt enable bit
#define CEC10_ADCANxIP          _ADCAN2IP   ///< Interrupt priority bit
#define CEC10_ADCBUF            ADCBUF2     ///< ADC input buffer register

#define CEC11_ADCANxInterrupt   _ADCAN1Interrupt ///< Interrupt service routine label
#define CEC11_ADCANxIF          _ADCAN1IF   ///< Interrupt flag bit
#define CEC11_ADCANxIE          _ADCAN1IE   ///< Interrupt enable bit
#define CEC11_ADCANxIP          _ADCAN1IP   ///< Interrupt priority bit
#define CEC11_ADCBUF            ADCBUF1     ///< ADC input buffer register

#define CEC12_ADCANxInterrupt   _ADCAN0Interrupt ///< Interrupt service routine label
#define CEC12_ADCANxIF          _ADCAN0IF   ///< Interrupt flag bit
#define CEC12_ADCANxIE          _ADCAN0IE   ///< Interrupt enable bit
#define CEC12_ADCANxIP          _ADCAN0IP   ///< Interrupt priority bit
#define CEC12_ADCBUF            ADCBUF0     ///< ADC input buffer register

#define CEC13_ADCANxInterrupt   _ADCAN19Interrupt ///< Interrupt service routine label
#define CEC13_ADCANxIF          _ADCAN19IF  ///< Interrupt flag bit
#define CEC13_ADCANxIE          _ADCAN19IE  ///< Interrupt enable bit
#define CEC13_ADCANxIP          _ADCAN19IP  ///< Interrupt priority bit
#define CEC13_ADCBUF            ADCBUF19    ///< ADC input buffer register

#define CEC14_ADCANxInterrupt   _ADCAN16Interrupt ///< Interrupt service routine label
#define CEC14_ADCANxIF          _ADCAN16IF  ///< Interrupt flag bit
#define CEC14_ADCANxIE          _ADCAN16IE  ///< Interrupt enable bit
#define CEC14_ADCANxIP          _ADCAN16IP  ///< Interrupt priority bit
#define CEC14_ADCBUF            ADCBUF16    ///< ADC input buffer register

#define CEC15_ADCANxInterrupt   _ADCAN18Interrupt ///< Interrupt service routine label
#define CEC15_ADCANxIF          _ADCAN18IF  ///< Interrupt flag bit
#define CEC15_ADCANxIE          _ADCAN18IE  ///< Interrupt enable bit
#define CEC15_ADCANxIP          _ADCAN18IP  ///< Interrupt priority bit
#define CEC15_ADCBUF            ADCBUF18    ///< ADC input buffer register

#define CEC16_ADCANxInterrupt   _ADCAN12Interrupt ///< Interrupt service routine label
#define CEC16_ADCANxIF          _ADCAN12IF  ///< Interrupt flag bit
#define CEC16_ADCANxIE          _ADCAN12IE  ///< Interrupt enable bit
#define CEC16_ADCANxIP          _ADCAN12IP  ///< Interrupt priority bit
#define CEC16_ADCBUF            ADCBUF12    ///< ADC input buffer register

#define CEC17_ADCANxInterrupt   _ADCAN14Interrupt ///< Interrupt service routine label
#define CEC17_ADCANxIF          _ADCAN14IF  ///< Interrupt flag bit
#define CEC17_ADCANxIE          _ADCAN14IE  ///< Interrupt enable bit
#define CEC17_ADCANxIP          _ADCAN14IP  ///< Interrupt priority bit
#define CEC17_ADCBUF            ADCBUF14    ///< ADC input buffer register

#define CEC18_ADCANxInterrupt   _ADCAN13Interrupt ///< Interrupt service routine label
#define CEC18_ADCANxIF          _ADCAN13IF  ///< Interrupt flag bit
#define CEC18_ADCANxIE          _ADCAN13IE  ///< Interrupt enable bit
#define CEC18_ADCANxIP          _ADCAN13IP  ///< Interrupt priority bit
#define CEC18_ADCBUF            ADCBUF13    ///< ADC input buffer register

#define CEC19_ADCANxInterrupt   _ADCAN9Interrupt ///< Interrupt service routine label
#define CEC19_ADCANxIF          _ADCAN9IF   ///< Interrupt flag bit
#define CEC19_ADCANxIE          _ADCAN9IE   ///< Interrupt enable bit
#define CEC19_ADCANxIP          _ADCAN9IP   ///< Interrupt priority bit
#define CEC19_ADCBUF            ADCBUF9     ///< ADC input buffer register

#define CEC20_ADCANxInterrupt   _ADCAN6Interrupt ///< Interrupt service routine label
#define CEC20_ADCANxIF          _ADCAN6IF   ///< Interrupt flag bit
#define CEC20_ADCANxIE          _ADCAN6IE   ///< Interrupt enable bit
#define CEC20_ADCANxIP          _ADCAN6IP   ///< Interrupt priority bit
#define CEC20_ADCBUF            ADCBUF6     ///< ADC input buffer register

#define CEC23_ADCANxInterrupt   _ADCAN11Interrupt ///< Interrupt service routine label
#define CEC23_ADCANxIF          _ADCAN11IF  ///< Interrupt flag bit
#define CEC23_ADCANxIE          _ADCAN11IE  ///< Interrupt enable bit
#define CEC23_ADCANxIP          _ADCAN11IP  ///< Interrupt priority bit
#define CEC23_ADCBUF            ADCBUF11    ///< ADC input buffer register

#define CEC56_ADCANxInterrupt   _ADCAN8Interrupt ///< Interrupt service routine label
#define CEC56_ADCANxIF          _ADCAN8IF   ///< Interrupt flag bit
#define CEC56_ADCANxIE          _ADCAN8IE   ///< Interrupt enable bit
#define CEC56_ADCANxIP          _ADCAN8IP   ///< Interrupt priority bit
#define CEC56_ADCBUF            ADCBUF8     ///< ADC input buffer register

// -----------------------------
// PWM Output Interrupt Macros

#define CEC25_PWMxInterrupt     _PWM7Interrupt ///< Interrupt service routine label
#define CEC25_PWMxIF            _PWM7IF     ///< Interrupt flag bit
#define CEC25_PWMxIE            _PWM7IE     ///< Interrupt enable bit
#define CEC25_PWMxIP            _PWM7IP     ///< Interrupt priority bit

#define CEC27_PWMxInterrupt     _PWM7Interrupt ///< Interrupt service routine label
#define CEC27_PWMxIF            _PWM7IF     ///< Interrupt flag bit
#define CEC27_PWMxIE            _PWM7IE     ///< Interrupt enable bit
#define CEC27_PWMxIP            _PWM7IP     ///< Interrupt priority bit

#define CEC31_PWMxInterrupt     _PWM6Interrupt ///< Interrupt service routine label
#define CEC31_PWMxIF            _PWM6IF     ///< Interrupt flag bit
#define CEC31_PWMxIE            _PWM6IE     ///< Interrupt enable bit
#define CEC31_PWMxIP            _PWM6IP     ///< Interrupt priority bit

#define CEC33_PWMxInterrupt     _PWM6Interrupt ///< Interrupt service routine label
#define CEC33_PWMxIF            _PWM6IF     ///< Interrupt flag bit
#define CEC33_PWMxIE            _PWM6IE     ///< Interrupt enable bit
#define CEC33_PWMxIP            _PWM6IP     ///< Interrupt priority bit

#define CEC35_PWMxInterrupt     _PWM5Interrupt ///< Interrupt service routine label
#define CEC35_PWMxIF            _PWM5IF     ///< Interrupt flag bit
#define CEC35_PWMxIE            _PWM5IE     ///< Interrupt enable bit
#define CEC35_PWMxIP            _PWM5IP     ///< Interrupt priority bit

#define CEC37_PWMxInterrupt     _PWM3Interrupt ///< Interrupt service routine label
#define CEC37_PWMxIF            _PWM3IF     ///< Interrupt flag bit
#define CEC37_PWMxIE            _PWM3IE     ///< Interrupt enable bit
#define CEC37_PWMxIP            _PWM3IP     ///< Interrupt priority bit

#define CEC38_PWMxInterrupt     _PWM5Interrupt ///< Interrupt service routine label
#define CEC38_PWMxIF            _PWM5IF     ///< Interrupt flag bit
#define CEC38_PWMxIE            _PWM5IE     ///< Interrupt enable bit
#define CEC38_PWMxIP            _PWM5IP     ///< Interrupt priority bit

#define CEC40_PWMxInterrupt     _PWM2Interrupt ///< Interrupt service routine label
#define CEC40_PWMxIF            _PWM2IF     ///< Interrupt flag bit
#define CEC40_PWMxIE            _PWM2IE     ///< Interrupt enable bit
#define CEC40_PWMxIP            _PWM2IP     ///< Interrupt priority bit

#define CEC41_PWMxInterrupt     _PWM3Interrupt ///< Interrupt service routine label
#define CEC41_PWMxIF            _PWM3IF     ///< Interrupt flag bit
#define CEC41_PWMxIE            _PWM3IE     ///< Interrupt enable bit
#define CEC41_PWMxIP            _PWM3IP     ///< Interrupt priority bit

#define CEC42_PWMxInterrupt     _PWM2Interrupt ///< Interrupt service routine label
#define CEC42_PWMxIF            _PWM2IF     ///< Interrupt flag bit
#define CEC42_PWMxIE            _PWM2IE     ///< Interrupt enable bit
#define CEC42_PWMxIP            _PWM2IP     ///< Interrupt priority bit

#define CEC43_PWMxInterrupt     _PWM4Interrupt ///< Interrupt service routine label
#define CEC43_PWMxIF            _PWM4IF     ///< Interrupt flag bit
#define CEC43_PWMxIE            _PWM4IE     ///< Interrupt enable bit
#define CEC43_PWMxIP            _PWM4IP     ///< Interrupt priority bit

#define CEC44_PWMxInterrupt     _PWM4Interrupt ///< Interrupt service routine label
#define CEC44_PWMxIF            _PWM4IF     ///< Interrupt flag bit
#define CEC44_PWMxIE            _PWM4IE     ///< Interrupt enable bit
#define CEC44_PWMxIP            _PWM4IP     ///< Interrupt priority bit

#define CEC45_PWMxInterrupt     _PWM1Interrupt ///< Interrupt service routine label
#define CEC45_PWMxIF            _PWM1IF     ///< Interrupt flag bit
#define CEC45_PWMxIE            _PWM1IE     ///< Interrupt enable bit
#define CEC45_PWMxIP            _PWM1IP     ///< Interrupt priority bit

#define CEC46_PWMxInterrupt     _PWM8Interrupt ///< Interrupt service routine label
#define CEC46_PWMxIF            _PWM8IF     ///< Interrupt flag bit
#define CEC46_PWMxIE            _PWM8IE     ///< Interrupt enable bit
#define CEC46_PWMxIP            _PWM8IP     ///< Interrupt priority bit

#define CEC47_PWMxInterrupt     _PWM1Interrupt ///< Interrupt service routine label
#define CEC47_PWMxIF            _PWM1IF     ///< Interrupt flag bit
#define CEC47_PWMxIE            _PWM1IE     ///< Interrupt enable bit
#define CEC47_PWMxIP            _PWM1IP     ///< Interrupt priority bit

#define CEC48_PWMxInterrupt     _PWM8Interrupt ///< Interrupt service routine label
#define CEC48_PWMxIF            _PWM8IF     ///< Interrupt flag bit
#define CEC48_PWMxIE            _PWM8IE     ///< Interrupt enable bit
#define CEC48_PWMxIP            _PWM8IP     ///< Interrupt priority bit


#endif  /* MA330048_R30 */
// ___________________
// end of file

