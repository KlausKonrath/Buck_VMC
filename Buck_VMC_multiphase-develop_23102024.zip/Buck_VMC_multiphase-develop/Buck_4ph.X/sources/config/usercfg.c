/*
 * @file   system_initialize.c
 * @author M91406
 *
 * Created on November 12, 2020, 10:33 AM
 */

#include "hal.h"
#include "mcal.h"
#include "usercfg.h"

#ifdef __WITH_PIL__
#include "pil/pil_main.h"
#include "pil/uart1.h"
#endif

/***********************************************************************************
 * @ingroup system-user-peripherals-initialization
 * @brief  Initializes static, application-specific chip resources
 * @return unsigned integer (0=failure, 1=success)
 * 
 * @details
 * The Digital Power Starter Kit 3 supports Test Points allowing users to observe
 * the DAC output of the dsPIC33C device as well as digital status signals of 
 * internal software processes. Using these features requires the configuration 
 * of further on-chip resources. These configurations are static and not related 
 * to any other task or function of the application and therefore need to be added 
 * manually. 
 * 
 * For this kind of Special Features, the startup procedure offers the following 
 * default function call allowing to place proprietary user code for individual
 * device configurations beyond the default setup. 
 * 
 **********************************************************************************/
volatile uint16_t sysUserPeriperhals_Initialize(void) {

    volatile uint16_t retval=1;

    #ifdef __WITH_PIL__
    UART1_Initialize();
    #endif

    // For test only
    
//     RP71 - RD7
//    PWMEVTAbits.EVTAOEN=1;
//    PWMEVTAbits.EVTASEL=0b1000; // ADCTRIG1
//    PWMEVTAbits.EVTAPGS=0; //PWM1
    
    #ifndef __WITH_PIL__    
//    TRISDbits.TRISD7=0; // TEST_1
    
//    // RP63 - RC15
//    PWMEVTBbits.EVTBOEN=1;
//    PWMEVTBbits.EVTBSEL=0b0101; // PCI fault active
//    PWMEVTBbits.EVTBPGS=0; //PWM2
//    
//    TRISCbits.TRISC15=0; // TEST_2
//    
//    __builtin_write_RPCON(0x0000); // unlock PPS
//    RPOR19bits.RP71R = 36;    //PWMEVTA
//    RPOR15bits.RP63R = 37;    //PWMEVTB
//    __builtin_write_RPCON(0x0800); // lock PPS
    #endif   
    
//    // Initialize test pins
//    TP23.Methods.Init(0, 0); // Used for debug only
//    TP24.Methods.Init(0,0); // Used for debug only
    
    
	return(retval);

}

/*********************************************************************************
 * @ingroup system-user-services-initialization
 * @brief   Initializes user service tasks, which are not part of scheduled task queue
 * @return  unsigned integer (0=failure, 1=success)
 * @details
 *  User Services are background services which are not part of the regular
 *  task queue executed and managed by the task scheduler, such as debugging,
 *  simulation, software validation or diagnostics tasks.
 *  
 *  This function will be called by function main() after CPU Boot and function 
 *  sysUserPeripherals_Initialize(). Hence, if user services require their own,
 *  dedicated peripherals, such as communication interfaces, it is recommended
 *  to initialize them in function sysUserPeripherals_Initialize() before calling
 *  initializing user services.
 *
 **********************************************************************************/
volatile uint16_t sysUserServices_Initialize(void) {
    
    #ifdef __WITH_PIL__
    PilInitialize();
    #endif // __WITH_PIL__
    
    return(1);
    
}

// ________________________
// end of file
