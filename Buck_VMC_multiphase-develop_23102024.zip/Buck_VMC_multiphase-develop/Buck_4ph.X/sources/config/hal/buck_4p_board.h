/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * @file    buck_4p_board.h
 * @author  M91169
 * @brief   Buck 4 phases  Hardware Descriptor header file
 * @version 1.0
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef BUCK_4PH_BOARD_H
#define	BUCK_4PH_BOARD_H

#include <xc_pral.h> // include device peripheral register abstraction layer
#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
#include <stddef.h> // include standard definition data types
#include <math.h> // include standard math functions library

#include "config/hal.h" // include rest of hardware abstraction layer header files

/***************************************************************************************************
 * @ingroup circuit-gpio-mcal
 * @{
 * @brief Global abstraction labels of special circuit signal device pin assignments
 * 
 * @details
 * This section is used to define labels of hardware specific signals, which are directly 
 * assigned to specific device pins. These labels will be used throughout the code and remain
 * unchanged even if this firmware is migrated to another device or pin-out changes between
 * hardware revisions.
 * 
 **************************************************************************************************/


#define EN_BYPASS           BEC21   //Output
#define EN_INRUSH           CEC26   //Output
#define EN_DCDC_INRUSH      BEC08   //Output
#define EN_DCDC_IDEAL_DIODE CEC51   //Output
#define DIS_U_200WATT       CEC54   //Output
#define PGOOD_5V_BUCK       CEC39   //Input
#define PGOOD_FC_DART_BUCK  CEC25   //Input
#define PGOOD_AUX_BUCK      CEC50   //Input
#define PGOOD_200WATT       CEC28   //Input
#define SYNC_200WATT        CEC27   //Output
#define VARIANT             CEC52   //Input
#define V_COMP              CEC31   //Input





/** @} */ // end of group circuit-gpio-mcal

/**************************************************************************************************
 * @ingroup circuit-peripheral-mcal
 * @{
 * @brief User-declaration of global defines for PWM signal generator settings
 * 
 * @details
 * This section defines fundamental PWM settings required for the interleaved buck converter
 * of the EPC9137 48V-to-12V rail power module development board. These settings are determined 
 * by hardware and defined using physical quantities. Pre-compiler macros are used to convert 
 * physical values into binary (integer) numbers to be written to Special Function Registers (SFR).
 * 
 **************************************************************************************************/

#define ISENSE_REF_DAC_INSTANCE         REF_DAC_INSTANCE ///< Digital-To-Analog Converter instance used to generate current sense amplifier reference voltage
#define ISENSE_REF_BUFFER_OPA_INSTANCE  REF_BUFFER_OPA_INSTANCE ///< Operational amplifier instance used to generate current sense amplifier reference voltage

/** @} */ // end of group circuit-peripheral-mcal

/**************************************************************************************************
 * @ingroup pwm-mcal-phase
 * @brief PWM peripheral output pins, control signals and register assignments of converter phase #1
 * 
 * @details
 * Each converter phase uses a simple half-bridge to commutate the switch node of the non-isolated,
 * bidirectional step down converter. The signal source therefore only requires a single PWM 
 * generator instance to be configured in fixed frequency, complementary mode with dead times. 
 * Additional PWM peripheral features are used by the firmware to respond to interrupts, trigger 
 * ADC conversions, control device output pins during startup and fault responses and to change 
 * timing settings on the fly. 
 * 
 * Please review the device data sheet for details about register names and settings.
 **************************************************************************************************/

/** 
 * @ingroup pwm-mcal-phase1
 * @{ 
 * @brief   PWM peripheral output pins, control signals and register assignments of converter phase #1
 * @note    Please review the device data sheet for details about register names and settings.
 */

// PWM Phase #1 Configuration

#define PWM1H                   CEC45           ///< Card Edge Connector pin of Device Port Pin of Primary PWM 1 High-Output
#define PWM1L                   CEC47           ///< Card Edge Connector pin of Device Port Pin of Primary PWM 1 Low-Output
#define PWM1_OUTPUT_SWAP        false           ///< PWM H/L outputs of channel are used "as is" (no swap)

#define PWM1_Interrupt          CEC45_PWMxInterrupt  ///< Interrupt Service Routine Label of PG1
#define PWM1_IP                 CEC45_PWMxIP    ///< Interrupt vector priority register
#define PWM1_IF                 CEC45_PWMxIF    ///< Interrupt vector flag bit register bit
#define PWM1_IE                 CEC45_PWMxIE    ///< Interrupt vector enable bit register bit

// -----

#define PWM2H                   CEC42           ///< Card Edge Connector pin of Device Port Pin of Priamry PWM 2 High-Output
#define PWM2L                   CEC40           ///< Card Edge Connector pin of Device Port Pin of Priamry PWM 2 Low-Output
#define PWM2_OUTPUT_SWAP        false           ///< PWM H/L outputs of channel are used "as is" (no swap)

#define PWM2_Interrupt          CEC42_PWMxInterrupt  ///< Interrupt Service Routine Label of PG1
#define PWM2_IP                 CEC42_PWMxIP    ///< Interrupt vector priority register
#define PWM2_IF                 CEC42_PWMxIF    ///< Interrupt vector flag bit register bit
#define PWM2_IE                 CEC42_PWMxIE    ///< Interrupt vector enable bit register bit

// -----

#define PWM3H                   CEC37           ///< Card Edge Connector pin of Device Port Pin of Secondary PWM 1 High-Output
#define PWM3L                   CEC41           ///< Card Edge Connector pin of Device Port Pin of Secondary PWM 1 Low-Output
#define PWM3_OUTPUT_SWAP        false           ///< PWM H/L outputs of channel are used "as is" (no swap)

#define PWM3_Interrupt          CEC37_PWMxInterrupt  ///< Interrupt Service Routine Label of PG1
#define PWM3_IP                 CEC37_PWMxIP    ///< Interrupt vector priority register
#define PWM3_IF                 CEC37_PWMxIF    ///< Interrupt vector flag bit register bit
#define PWM3_IE                 CEC37_PWMxIE    ///< Interrupt vector enable bit register bit

// -----

#define PWM4H                   CEC43           ///< Card Edge Connector pin of Device Port Pin of Secondary PWM 2 High-Output
#define PWM4L                   CEC44           ///< Card Edge Connector pin of Device Port Pin of Secondary PWM 2 Low-Output
#define PWM4_OUTPUT_SWAP        false           ///< PWM H/L outputs of channel are used "as is" (no swap)

#define PWM4_Interrupt          CEC43_PWMxInterrupt  ///< Interrupt Service Routine Label of PG1
#define PWM4_IP                 CEC43_PWMxIP    ///< Interrupt vector priority register
#define PWM4_IF                 CEC43_PWMxIF    ///< Interrupt vector flag bit register bit
#define PWM4_IE                 CEC43_PWMxIE    ///< Interrupt vector enable bit register bit


/** @} */ // end of group pwm-mcal-phase1 ~~~~~~~~~~~~~~~~~


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
/** 
 * @ingroup input-voltage-feedback-mcal
 * @{ 
 * @brief ADC input assignments of input voltage feedback signals
 * 
 * @details
 * In this section the ADC input channels, related ADC result buffers, trigger
 * sources and interrupt vectors are defined. These settings allow the fast 
 * re-assignment of feedback signals in case of hardware changes.
 */

// Peripheral Assignments
#define VIN                     CEC16                   ///< Card Edge Connector pin this signal is connected to

#define VIN_DIV_R1              (float) 150.0            ///< Upper voltage divider resistor in kOhm
#define VIN_DIV_R2              (float) 3.0           ///< Lower voltage divider resistor in kOhm
#define VIN_FEEDBACK_OFFSET     (float) 0.000           ///< Physical, static signal offset in [V]
#define VIN_ADC_TRG_DELAY       (float) 94.0e-9          ///< Trigger delay in [sec]

// Data Acquisition Settings
#define VIN_ADCANxInterrupt     CEC16_ADCANxInterrupt   ///< ADC interrupt service routine function call of the low voltage port feedback channel
#define VIN_ADCANxIF            CEC16_ADCANxIF          ///< ADC interrupt flag bit of the low voltage port feedback channel
#define VIN_ADCANxIE            CEC16_ADCANxIE          ///< ADC interrupt enable bit of the low voltage port feedback channel
#define VIN_ADCANxIP            CEC16_ADCANxIP          ///< ADC interrupt priority bits of the low voltage port feedback channel
#define VIN_ADCBUF              CEC16_ADCBUF            ///< ADC result buffer register of this input
#define VIN_ADCTRIG             PWM1H.Objects.PG->PGxTRIGB.value ///< Register used for trigger placement
#define VIN_TRGSRC              (uint8_t)ADCAN_TRGSRC_PWM1_TRG1  ///< PWM generator ADC Trigger 1 or 2 via PGxTRIGx
//#define VIN_ADCCORE             CEC16.Properties.ADCORE ///< ADC Core this ADC input is tied to
#define VIN_ADCDIFF             false                   ///< true = differential input, false = single-ended input
#define VIN_ADCSIGN             false                   ///< true = sample result is signed, false = sample result is unsigned
#define VIN_LVLTRG              false                   ///< true= sampling is level-triggered, false = sampling is edge-triggered
#define VIN_POLARITY            0                       ///< 0 = signal polarity is positive, 1 = signal polarity is negative 

// V_DCDC
#define V_DCDC                     CEC19                               ///< Card Edge Connector pin this signal is connected to

#define V_DCDC_DIV_R1              (float) 150.0                       ///< Upper voltage divider resistor in kOhm
#define V_DCDC_DIV_R2              (float) 3.0                         ///< Lower voltage divider resistor in kOhm
#define V_DCDC_FEEDBACK_OFFSET     (float) 0.000                       ///< Physical, static signal offset in [V]
#define V_DCDC_ADC_TRG_DELAY       (float) 94.0e-9                     ///< Trigger delay in [sec]

// Data Acquisition Settings
#define V_DCDC_ADCANxInterrupt     CEC19_ADCANxInterrupt               ///< ADC interrupt service routine function call of the low voltage port feedback channel
#define V_DCDC_ADCANxIF            CEC19_ADCANxIF                      ///< ADC interrupt flag bit of the low voltage port feedback channel
#define V_DCDC_ADCANxIE            CEC19_ADCANxIE                      ///< ADC interrupt enable bit of the low voltage port feedback channel
#define V_DCDC_ADCANxIP            CEC19_ADCANxIP                      ///< ADC interrupt priority bits of the low voltage port feedback channel
#define V_DCDC_ADCBUF              CEC19_ADCBUF                        ///< ADC result buffer register of this input
#define V_DCDC_ADCTRIG             PWM1H.Objects.PG->PGxTRIGB.value    ///< Register used for trigger placement
#define V_DCDC_TRGSRC              (uint8_t)ADCAN_TRGSRC_PWM1_TRG1     ///< PWM generator ADC Trigger 1 or 2 via PGxTRIGx
//#define V_DCDC_ADCCORE             CEC19.Properties.ADCORE           ///< ADC Core this ADC input is tied to
#define V_DCDC_ADCDIFF             false                               ///< true = differential input, false = single-ended input
#define V_DCDC_ADCSIGN             false                               ///< true = sample result is signed, false = sample result is unsigned
#define V_DCDC_LVLTRG              false                               ///< true= sampling is level-triggered, false = sampling is edge-triggered
#define V_DCDC_POLARITY            0                                   ///< 0 = signal polarity is positive, 1 = signal polarity is negative 


// V_MOTOR
#define V_MOTOR                     CEC13                               ///< Card Edge Connector pin this signal is connected to

#define V_MOTOR_DIV_R1              (float) 47.0                       ///< Upper voltage divider resistor in kOhm
#define V_MOTOR_DIV_R2              (float) 3.3                         ///< Lower voltage divider resistor in kOhm
#define V_MOTOR_FEEDBACK_OFFSET     (float) 0.000                       ///< Physical, static signal offset in [V]
#define V_MOTOR_ADC_TRG_DELAY       (float) 94.0e-9                     ///< Trigger delay in [sec]

// Data Acquisition Settings
#define V_MOTOR_ADCANxInterrupt     CEC13_ADCANxInterrupt               ///< ADC interrupt service routine function call of the low voltage port feedback channel
#define V_MOTOR_ADCANxIF            CEC13_ADCANxIF                      ///< ADC interrupt flag bit of the low voltage port feedback channel
#define V_MOTOR_ADCANxIE            CEC13_ADCANxIE                      ///< ADC interrupt enable bit of the low voltage port feedback channel
#define V_MOTOR_ADCANxIP            CEC13_ADCANxIP                      ///< ADC interrupt priority bits of the low voltage port feedback channel
#define V_MOTOR_ADCBUF              CEC13_ADCBUF                        ///< ADC result buffer register of this input
#define V_MOTOR_ADCTRIG             PWM1H.Objects.PG->PGxTRIGB.value    ///< Register used for trigger placement
#define V_MOTOR_TRGSRC              (uint8_t)ADCAN_TRGSRC_PWM1_TRG1     ///< PWM generator ADC Trigger 1 or 2 via PGxTRIGx
//#define V_MOTOR_ADCCORE             CEC13.Properties.ADCORE           ///< ADC Core this ADC input is tied to
#define V_MOTOR_ADCDIFF             false                               ///< true = differential input, false = single-ended input
#define V_MOTOR_ADCSIGN             false                               ///< true = sample result is signed, false = sample result is unsigned
#define V_MOTOR_LVLTRG              false                               ///< true= sampling is level-triggered, false = sampling is edge-triggered
#define V_MOTOR_POLARITY            0                                   ///< 0 = signal polarity is positive, 1 = signal polarity is negative 


// V_AUX
#define V_AUX                       CEC14                             ///< Card Edge Connector pin this signal is connected to

#define V_AUX_DIV_R1              (float) 10.0                        ///< Upper voltage divider resistor in kOhm
#define V_AUX_DIV_R2              (float) 3.3                         ///< Lower voltage divider resistor in kOhm
#define V_AUX_FEEDBACK_OFFSET     (float) 0.000                       ///< Physical, static signal offset in [V]
#define V_AUX_ADC_TRG_DELAY       (float) 94.0e-9                     ///< Trigger delay in [sec]

// Data Acquisition Settings
#define V_AUX_ADCANxInterrupt     CEC14_ADCANxInterrupt               ///< ADC interrupt service routine function call of the low voltage port feedback channel
#define V_AUX_ADCANxIF            CEC14_ADCANxIF                      ///< ADC interrupt flag bit of the low voltage port feedback channel
#define V_AUX_ADCANxIE            CEC14_ADCANxIE                      ///< ADC interrupt enable bit of the low voltage port feedback channel
#define V_AUX_ADCANxIP            CEC14_ADCANxIP                      ///< ADC interrupt priority bits of the low voltage port feedback channel
#define V_AUX_ADCBUF              CEC14_ADCBUF                        ///< ADC result buffer register of this input
#define V_AUX_ADCTRIG             PWM1H.Objects.PG->PGxTRIGB.value    ///< Register used for trigger placement
#define V_AUX_TRGSRC              (uint8_t)ADCAN_TRGSRC_PWM1_TRG1     ///< PWM generator ADC Trigger 1 or 2 via PGxTRIGx
//#define V_AUX_ADCCORE             CEC14.Properties.ADCORE           ///< ADC Core this ADC input is tied to
#define V_AUX_ADCDIFF             false                               ///< true = differential input, false = single-ended input
#define V_AUX_ADCSIGN             false                               ///< true = sample result is signed, false = sample result is unsigned
#define V_AUX_LVLTRG              false                               ///< true= sampling is level-triggered, false = sampling is edge-triggered
#define V_AUX_POLARITY            0                                   ///< 0 = signal polarity is positive, 1 = signal polarity is negative 



// V_24VOLT
#define V_24VOLT                      CEC56                             ///< Card Edge Connector pin this signal is connected to

#define V_24VOLT_DIV_R1              (float) 100.0                       ///< Upper voltage divider resistor in kOhm
#define V_24VOLT_DIV_R2              (float) 14.3                        ///< Lower voltage divider resistor in kOhm
#define V_24VOLT_FEEDBACK_OFFSET     (float) 0.000                       ///< Physical, static signal offset in [V]
#define V_24VOLT_ADC_TRG_DELAY       (float) 94.0e-9                     ///< Trigger delay in [sec]

// Data Acquisition Settings
#define V_24VOLT_ADCANxInterrupt     CEC56_ADCANxInterrupt               ///< ADC interrupt service routine function call of the low voltage port feedback channel
#define V_24VOLT_ADCANxIF            CEC56_ADCANxIF                      ///< ADC interrupt flag bit of the low voltage port feedback channel
#define V_24VOLT_ADCANxIE            CEC56_ADCANxIE                      ///< ADC interrupt enable bit of the low voltage port feedback channel
#define V_24VOLT_ADCANxIP            CEC56_ADCANxIP                      ///< ADC interrupt priority bits of the low voltage port feedback channel
#define V_24VOLT_ADCBUF              CEC56_ADCBUF                        ///< ADC result buffer register of this input
#define V_24VOLT_ADCTRIG             PWM1H.Objects.PG->PGxTRIGB.value    ///< Register used for trigger placement
#define V_24VOLT_TRGSRC              (uint8_t)ADCAN_TRGSRC_PWM1_TRG1     ///< PWM generator ADC Trigger 1 or 2 via PGxTRIGx
//#define V_24VOLT_ADCCORE             CEC56.Properties.ADCORE           ///< ADC Core this ADC input is tied to
#define V_24VOLT_ADCDIFF             false                               ///< true = differential input, false = single-ended input
#define V_24VOLT_ADCSIGN             false                               ///< true = sample result is signed, false = sample result is unsigned
#define V_24VOLT_LVLTRG              false                               ///< true= sampling is level-triggered, false = sampling is edge-triggered
#define V_24VOLT_POLARITY            0                                   ///< 0 = signal polarity is positive, 1 = signal polarity is negative 


// I-200W
#define I_200WATT                    CEC10                             ///< Card Edge Connector pin this signal is connected to

#define I_200WATT_DIV_R1              (float) 100.0                       ///< Upper voltage divider resistor in kOhm
#define I_200WATT_DIV_R2              (float) 14.3                        ///< Lower voltage divider resistor in kOhm
#define I_200WATT_FEEDBACK_OFFSET     (float) 0.000                       ///< Physical, static signal offset in [V]
#define I_200WATT_ADC_TRG_DELAY       (float) 94.0e-9                     ///< Trigger delay in [sec]

// Data Acquisition Settings
#define I_200WATT_ADCANxInterrupt     CEC10_ADCANxInterrupt               ///< ADC interrupt service routine function call of the low voltage port feedback channel
#define I_200WATT_ADCANxIF            CEC10_ADCANxIF                      ///< ADC interrupt flag bit of the low voltage port feedback channel
#define I_200WATT_ADCANxIE            CEC10_ADCANxIE                      ///< ADC interrupt enable bit of the low voltage port feedback channel
#define I_200WATT_ADCANxIP            CEC10_ADCANxIP                      ///< ADC interrupt priority bits of the low voltage port feedback channel
#define I_200WATT_ADCBUF              CEC10_ADCBUF                        ///< ADC result buffer register of this input
#define I_200WATT_ADCTRIG             PWM1H.Objects.PG->PGxTRIGB.value    ///< Register used for trigger placement
#define I_200WATT_TRGSRC              (uint8_t)ADCAN_TRGSRC_PWM1_TRG1     ///< PWM generator ADC Trigger 1 or 2 via PGxTRIGx
//#define I_200WATT_ADCCORE             CEC10.Properties.ADCORE           ///< ADC Core this ADC input is tied to
#define I_200WATT_ADCDIFF             false                               ///< true = differential input, false = single-ended input
#define I_200WATT_ADCSIGN             false                               ///< true = sample result is signed, false = sample result is unsigned
#define I_200WATT_LVLTRG              false                               ///< true= sampling is level-triggered, false = sampling is edge-triggered
#define I_200WATT_POLARITY            0                                   ///< 0 = signal polarity is positive, 1 = signal polarity is negative 




#define VIN_PROT                CEC15                   ///< Card Edge Connector pin this signal is connected to

#define VIN_PROT_DIV_R1              (float) 150.0            ///< Upper voltage divider resistor in kOhm
#define VIN_PROT_DIV_R2              (float) 3.0           ///< Lower voltage divider resistor in kOhm
#define VIN_PROT_FEEDBACK_OFFSET     (float) 0.000           ///< Physical, static signal offset in [V]
#define VIN_PROT_ADC_TRG_DELAY       (float) 94.0e-9          ///< Trigger delay in [sec]

// Data Acquisition Settings
#define VIN_PROT_ADCANxInterrupt    CEC15_ADCANxInterrupt   ///< ADC interrupt service routine function call of the low voltage port feedback channel
#define VIN_PROT_ADCANxIF           CEC15_ADCANxIF          ///< ADC interrupt flag bit of the low voltage port feedback channel
#define VIN_PROT_ADCANxIE           CEC15_ADCANxIE          ///< ADC interrupt enable bit of the low voltage port feedback channel
#define VIN_PROT_ADCANxIP           CEC15_ADCANxIP          ///< ADC interrupt priority bits of the low voltage port feedback channel
#define VIN_PROT_ADCBUF             CEC15_ADCBUF            ///< ADC result buffer register of this input
#define VIN_PROT_ADCTRIG            PWM1H.Objects.PG->PGxTRIGB.value ///< Register used for trigger placement
#define VIN_PROT_TRGSRC             (uint8_t)ADCAN_TRGSRC_PWM1_TRG1  ///< PWM generator ADC Trigger 1 or 2 via PGxTRIGx
//#define VIN_ADCCORE               CEC15.Properties.ADCORE ///< ADC Core this ADC input is tied to
#define VIN_PROT_ADCDIFF            false                   ///< true = differential input, false = single-ended input
#define VIN_PROT_ADCSIGN            false                   ///< true = sample result is signed, false = sample result is unsigned
#define VIN_PROT_LVLTRG             false                   ///< true= sampling is level-triggered, false = sampling is edge-triggered
#define VIN_PROT_POLARITY           0                       ///< 0 = signal polarity is positive, 1 = signal polarity is negative 

/** @} */ // end of group input-voltage-feedback-mcal ~~~~~~~~~~~~~~~~~~~~~~~~~


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
/** 
 * @ingroup output-voltage-feedback-mcal
 * @{ 
 * @brief ADC input assignments of output voltage feedback signals
 * 
 * @details
 * In this section the ADC input channels, related ADC result buffers, trigger
 * sources and interrupt vectors are defined. These settings allow the fast 
 * re-assignment of feedback signals in case of hardware changes.
 */

// U-Regel-ADC
#define VOUT                     CEC09                   ///< Card Edge Connector pin this signal is connected to

#define VOUT_DIV_R1              (float) 47.0            ///< Upper voltage divider resistor in kOhm
#define VOUT_DIV_R2              (float) 3.3           ///< Lower voltage divider resistor in kOhm
#define VOUT_FEEDBACK_OFFSET     (float) 0.000           ///< Physical, static signal offset in [V]
#define VOUT_ADC_TRG_DELAY       (float) 94.0e-9          ///< Trigger delay in [sec]

// Data Acquisition Settings
#define VOUT_ADCANxInterrupt     CEC09_ADCANxInterrupt   ///< ADC interrupt service routine function call of the low voltage port feedback channel
#define VOUT_ADCANxIF            CEC09_ADCANxIF          ///< ADC interrupt flag bit of the low voltage port feedback channel
#define VOUT_ADCANxIE            CEC09_ADCANxIE          ///< ADC interrupt enable bit of the low voltage port feedback channel
#define VOUT_ADCANxIP            CEC09_ADCANxIP          ///< ADC interrupt priority bits of the low voltage port feedback channel
#define VOUT_ADCBUF              CEC09_ADCBUF            ///< ADC result buffer register of this input
#define VOUT_ADCTRIG             PWM1H.Objects.PG->PGxTRIGB.value ///< Register used for trigger placement
#define VOUT_TRGSRC              (uint8_t)ADCAN_TRGSRC_PWM1_TRG1  ///< PWM generator ADC Trigger 1 or 2 via PGxTRIGx
//#define VOUT_ADCCORE             CEC09.Properties.ADCORE ///< ADC Core this ADC input is tied to
#define VOUT_ADCDIFF             false                   ///< true = differential input, false = single-ended input
#define VOUT_ADCSIGN             false                   ///< true = sample result is signed, false = sample result is unsigned
#define VOUT_LVLTRG              false                   ///< true= sampling is level-triggered, false = sampling is edge-triggered
#define VOUT_POLARITY            0                       ///< 0 = signal polarity is positive, 1 = signal polarity is negative 

/** @} */ // end of group output-voltage-feedback-mcal ~~~~~~~~~~~~~~~~~~~~~~~~~

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
/** 
 * @ingroup phase-current-feedback-mcal
 * @{ 
 * @brief ADC input assignments of phase current feedback signals
 * 
 * @details
 * In this section the ADC input channels, related ADC result buffers, trigger
 * sources and interrupt vectors are defined. These settings allow the fast 
 * re-assignments of feedback signals in case of hardware changes.
 */

#define ISNS_GAIN               (float) 100             ///> Current mplifier gain
#define ISNS_RESISTOR           (float) 0.002           ///> buck Current sense resistor in ohm

#define ISNS_200W_RESISTOR      (float) 0.010           ///> buck Current sense resistor in ohm

// Peripheral Assignments
#define IBUCK1                  CEC12                   ///< Card Edge Connector pin this signal is connected to
#define IBUCK1_ADCANxInterrupt  CEC12_ADCANxInterrupt   ///< ADC interrupt service routine function call of the primary current #1 feedback channel
#define IBUCK1_ADCANxIF         CEC12_ADCANxIF          ///< ADC interrupt flag bit of the primary current #1 feedback channel
#define IBUCK1_ADCANxIE         CEC12_ADCANxIE          ///< ADC interrupt enable bit of the primary current #1 feedback channel
#define IBUCK1_ADCANxIP         CEC12_ADCANxIP          ///< ADC interrupt priority bits of the primary current #1 feedback channel
#define IBUCK1_ADCTRIG          PWM1H.Objects.PG->PGxTRIGB ///< Register used for trigger placement
#define IBUCK1_TRGSRC           ADCAN_TRGSRC_PWM1_TRG1  ///< PWM generator ADC Trigger 1 or 2 via PGxTRIGx
#define IBUCK1_ADCCORE          CEC12.Properties.ADCORE ///< ADC Core this ADC input is tied to
#define IBUCK1_ADCDIFF          false                   ///< true = differential input, false = single-ended input
#define IBUCK1_ADCSIGN          false                   ///< true = sample result is signed, false = sample result is unsigned
#define IBUCK1_LVLTRG           false                   ///< true= sampling is level-triggered, false = sampling is edge-triggered
#define IBUCK1_POLARITY         0                       ///< 0 = signal polarity is positive, 1 = signal polarity is negative 

#define IBUCK2                  BEC28
#define IBUCK2_ADCANxInterrupt  BEC28_ADCANxInterrupt   ///< ADC interrupt service routine function call of the primary current #2 feedback channel
#define IBUCK2_ADCANxIF         BEC28_ADCANxIF          ///< ADC interrupt flag bit of the primary current #2 feedback channel
#define IBUCK2_ADCANxIE         BEC28_ADCANxIE          ///< ADC interrupt enable bit of the primary current #2 feedback channel
#define IBUCK2_ADCANxIP         BEC28_ADCANxIP          ///< ADC interrupt priority bits of the primary current #2 feedback channel
#define IBUCK2_ADCTRIG          PWM2H.Objects.PG->PGxTRIGB ///< Register used for trigger placement
#define IBUCK2_TRGSRC           ADCAN_TRGSRC_PWM2_TRG1  ///< PWM generator ADC Trigger 1 or 2 via PGxTRIGx
#define IBUCK2_ADCCORE          BEC28.Properties.ADCORE ///< ADC Core this ADC input is tied to
#define IBUCK2_ADCDIFF          false                   ///< true = differential input, false = single-ended input
#define IBUCK2_ADCSIGN          false                   ///< true = sample result is signed, false = sample result is unsigned
#define IBUCK2_LVLTRG           false                   ///< true= sampling is level-triggered, false = sampling is edge-triggered
#define IBUCK2_POLARITY         0                       ///< 0 = signal polarity is positive, 1 = signal polarity is negative 

#define IBUCK3                   CEC06
#define IBUCK3_ADCANxInterrupt   CEC06_ADCANxInterrupt   ///< ADC interrupt service routine function call of the output current feedback channel
#define IBUCK3_ADCANxIF          CEC06_ADCANxIF          ///< ADC interrupt flag bit of the output current feedback channel
#define IBUCK3_ADCANxIE          CEC06_ADCANxIE          ///< ADC interrupt enable bit of the output current feedback channel
#define IBUCK3_ADCANxIP          CEC06_ADCANxIP          ///< ADC interrupt priority bits of the output current feedback channel
#define IBUCK3_ADCTRIG           PWM3H.Objects.PG->PGxTRIGB ///< Register used for trigger placement
#define IBUCK3_TRGSRC            ADCAN_TRGSRC_PWM3_TRG1  ///< PWM generator ADC Trigger 1 or 2 via PGxTRIGx
#define IBUCK3_ADCCORE           CEC06.Properties.ADCORE ///< ADC Core this ADC input is tied to
#define IBUCK3_ADCDIFF           false                   ///< true = differential input, false = single-ended input
#define IBUCK3_ADCSIGN           false                   ///< true = sample result is signed, false = sample result is unsigned
#define IBUCK3_LVLTRG            false                   ///< true= sampling is level-triggered, false = sampling is edge-triggered
#define IBUCK3_POLARITY          0                       ///< 0 = signal polarity is positive, 1 = signal polarity is negative 

#define IBUCK4                   CEC20
#define IBUCK4_ADCANxInterrupt   CEC20_ADCANxInterrupt   ///< ADC interrupt service routine function call of the output current feedback channel
#define IBUCK4_ADCANxIF          CEC20_ADCANxIF          ///< ADC interrupt flag bit of the output current feedback channel
#define IBUCK4_ADCANxIE          CEC20_ADCANxIE          ///< ADC interrupt enable bit of the output current feedback channel
#define IBUCK4_ADCANxIP          CEC20_ADCANxIP          ///< ADC interrupt priority bits of the output current feedback channel
#define IBUCK4_ADCTRIG           PWM4H.Objects.PG->PGxTRIGB ///< Register used for trigger placement
#define IBUCK4_TRGSRC            ADCAN_TRGSRC_PWM4_TRG1  ///< PWM generator ADC Trigger 1 or 2 via PGxTRIGx
#define IBUCK4_ADCCORE           CEC20.Properties.ADCORE ///< ADC Core this ADC input is tied to
#define IBUCK4_ADCDIFF           false                   ///< true = differential input, false = single-ended input
#define IBUCK4_ADCSIGN           false                   ///< true = sample result is signed, false = sample result is unsigned
#define IBUCK4_LVLTRG            false                   ///< true= sampling is level-triggered, false = sampling is edge-triggered
#define IBUCK4_POLARITY          0                       ///< 0 = signal polarity is positive, 1 = signal polarity is negative 

/** @} */ // end of group phase-current-feedback-mcal ~~~~~~~~~~~~~~~~~~~~~~~~~

// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
/** 
 * @ingroup temperature-feedback-mcal
 * @{ 
 * @brief ADC input assignments of temperature feedback signals
 * 
 * @details
 * In this section the ADC input channels, related ADC result buffers, trigger
 * sources and interrupt vectors are defined. These settings allow the fast 
 * re-assignments of feedback signals in case of hardware changes.
 */

// Peripheral Assignments
#define TEMP1                   CEC39                   ///< Card Edge Connector pin this signal is connected to
#define TEMP1_ADCTRIG           PWM1H.Objects.PG->PGxTRIGB ///< Register used for trigger placement
#define TEMP1_TRGSRC            ADCAN_TRGSRC_PWM1_TRG2  ///< PWM generator ADC Trigger 1 or 2 via PGxTRIGx
#define TEMP1_ADCCORE           CEC39.Properties.ADCORE ///< ADC Core this ADC input is tied to
#define TEMP1_ADCDIFF           false                   ///< true = differential input, false = single-ended input
#define TEMP1_ADCSIGN           false                   ///< true = sample result is signed, false = sample result is unsigned
#define TEMP1_LVLTRG            false                   ///< true= sampling is level-triggered, false = sampling is edge-triggered
#define TEMP1_POLARITY          0                       ///< 0 = signal polarity is positive, 1 = signal polarity is negative 

/** @} */ // end of group temperature-feedback-mcal ~~~~~~~~~~~~~~~~~~~~~~~~~

// Test Pins

#define TP23                    CEC23   // Device Pin #23 is TP23
#define TP24                    CEC24   // Device Pin #24 is TP24
#define TP25                    CEC25   // Device Pin #25 is TP25


/**************************************************************************************************
 * @ingroup control-interrupt-vector-declarations
 * @{
 * @brief Control loop interrupt vector and trigger settings
 * 
 * @details
 *   Control loops are called in dedicated interrupt service routines of PWM events, ADC events
 *   or triggered by timers. This section allows users to set and modify the interrupt service 
 *   routine triggers and their priority to set up and optimize the control system interrupt 
 *   structure.
 * 
 * @note
 *   All available control loop interrupt trigger options are listed in the respective
 *   hardware abstraction layer flags header file
 * 
 * @see
 *   epc9137_r40_flags.h
 * 
 ***************************************************************************************************/
    
// Hardware-dependent defines

#define VLOOP_TRIGGER_MODE      TRIGGER_MODE_ADC        ///< Currently selected voltage loop interrupt vector
#define VLOOP_ISR_PRIORITY      5U                      ///< Voltage loop interrupt vector priority (valid settings between 0...6 with 6 being the highest priority)

#define ILOOP1_TRIGGER_MODE     TRIGGER_MODE_NONE       ///< Currently selected current loop #1 interrupt vector
#define ILOOP1_ISR_PRIORITY     6U                      ///< Current loop #1 interrupt vector priority (valid settings between 0...6 with 6 being the highest priority)

#define ILOOP2_TRIGGER_MODE     TRIGGER_MODE_NONE       ///< Currently selected current loop #2 interrupt vector
#define ILOOP2_ISR_PRIORITY     6U                      ///< Current loop #1 interrupt vector priority (valid settings between 0...6 with 6 being the highest priority)

#if (VLOOP_TRIGGER_MODE == TRIGGER_MODE_ADC)
  #define VLOOP_Interrupt       VOUT_ADCANxInterrupt     ///< Interrupt vector function call label
  #define VLOOP_ISR_IP          VOUT_ADCANxIP            ///< Interrupt vector priority register bits
  #define VLOOP_ISR_IF          VOUT_ADCANxIF            ///< Interrupt vector flag bit register bit
  #define VLOOP_ISR_IE          VOUT_ADCANxIE            ///< Interrupt vector enable bit register bit
#elif (VLOOP_TRIGGER_MODE == TRIGGER_MODE_PWM)
  #define VLOOP_Interrupt       PWM1_Interrupt          ///< Interrupt vector function call label
  #define VLOOP_ISR_IP          PWM1_IP                 ///< Interrupt vector priority register
  #define VLOOP_ISR_IF          PWM1_IF                 ///< Interrupt vector flag bit register bit
  #define VLOOP_ISR_IE          PWM1_IE                 ///< Interrupt vector enable bit register bit
#elif (VLOOP_TRIGGER_MODE == TRIGGER_MODE_TIMER)
  #define VLOOP_Interrupt       _CCT1Interrupt          ///< Interrupt vector function call label
  #define VLOOP_ISR_IP          _CCT1IP                 ///< Interrupt vector priority register
  #define VLOOP_ISR_IF          _CCT1IF                 ///< Interrupt vector flag bit register bit
  #define VLOOP_ISR_IE          _CCT1IE                 ///< Interrupt vector enable bit register bit
#endif

#if (ISNS1_TRIGGER_MODE == TRIGGER_MODE_ADC)
  #define ILOOP1_Interrupt    IBUCK1_ADCANxInterrupt   ///< Interrupt vector function call label
  #define ILOOP1_ISR_IP       IBUCK1_ADCANxIP          ///< Interrupt vector priority register bits
  #define ILOOP1_ISR_IF       IBUCK1_ADCANxIF          ///< Interrupt vector flag bit register bit
  #define ILOOP1_ISR_IE       IBUCK1_ADCANxIE          ///< Interrupt vector enable bit register bit
#elif (ISNS1_TRIGGER_MODE == TRIGGER_MODE_PWM)
  #define ILOOP1_Interrupt    PWM1_Interrupt          ///< Interrupt vector function call label
  #define ILOOP1_ISR_IP       PWM1_IP                 ///< Interrupt vector priority register
  #define ILOOP1_ISR_IF       PWM1_IF                 ///< Interrupt vector flag bit register bit
  #define ILOOP1_ISR_IE       PWM1_IE                 ///< Interrupt vector enable bit register bit
#endif

#if (ISNS2_TRIGGER_MODE == TRIGGER_MODE_ADC)
  #define ILOOP2_Interrupt    IBUCK2_ADCANxInterrupt   ///< Interrupt vector function call label
  #define ILOOP2_ISR_IP       IBUCK2_ADCANxIP          ///< Interrupt vector priority register bits
  #define ILOOP2_ISR_IF       IBUCK2_ADCANxIF          ///< Interrupt vector flag bit register bit
  #define ILOOP2_ISR_IE       IBUCK2_ADCANxIE          ///< Interrupt vector enable bit register bit
#elif (ISNS2_TRIGGER_MODE == TRIGGER_MODE_PWM)
  #define ILOOP2_Interrupt    PWM2_Interrupt          ///< Interrupt vector function call label
  #define ILOOP2_ISR_IP       PWM2_IP                 ///< Interrupt vector priority register
  #define ILOOP2_ISR_IF       PWM2_IF                 ///< Interrupt vector flag bit register bit
  #define ILOOP2_ISR_IE       PWM2_IE                 ///< Interrupt vector enable bit register bit
#endif

/** @} */ // end of group control-interrupt-vector-declarations


#endif	/* ADP1051_240_EVALZ_BOARD_H */

// ________________________
// end if file
