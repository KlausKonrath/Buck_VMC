/* 
 * @file    buck_4ph_options.h
 * @author  M91406
 * @brief   Compile switches selecting board options
 * @date    November 15, 2023
 */

#ifndef BUCK_4PH_OPTIONS_H
#define	BUCK_4PH_OPTIONS_H

/**
 * PLECS Processor-In-Loop Simulation Support
 */
#ifdef __WITH_PIL__

    #include "pil/pil_main.h"

    #define VBULK_OK_Read() PilProbes.Start ///< GPIO port register bit
    #define VOUT__ADCBUF PilProbes.Vout

#else
    
    #define VBULK_OK_Read() CEC32.Methods.Get() ///< Read device pin 
    #define VOUT__ADCBUF CEC09_ADCBUF ///< ADC buffer register for this input

#endif

/**************************************************************************************************
 * @ingroup special-options
 * @{
 * @brief   Global defines used to enable/disable special firmware options
 * 
 * @details
 *  This section is used to enable/disable special options of the firmware. 
 * 
 **************************************************************************************************/

/* CUSTOM RUNTIME OPTIONS */
#define PLANT_MEASUREMENT       false ///< If enabled, replaces the common voltage control loop by a simple P-control loop to perform measurements of the plant transfer function.
#define DBGPIN1_ENABLE          false ///< Enables debug pin indicating control loop execution timing
#define DBGPIN2_ENABLE          false ///< Enables debug pin indicating task scheduler execution timing
#define DBGDAC_ENABLE           false ///< Enables debug DAC output (ot applicable with EPC9528)

#define PWREN_ENABLE            true ///< Enables a POWER ENABLE input pin
#define PWRGOOD_ENABLE          true ///< Enables a POWER GOOD output pin

#define HW_OPEN_LOOP_TEST       false ///< Turns on the converter in open loop with constant duty cycle to get 12V nominal with 40V input

/** @} */ // end of group special-options


/*********************************************************************************
 * @ingroup special-options
 * @def     DEFAULT_OPERATING_MODE
 * @def     DEFAULT_DIRCTRL_MODE
 * @brief   Determines if the converter is operating in down-stream (buck) mode or up-stream (boost) mode by default
 * 
 * @details
 *  At startup, the converter state machine is monitoring the system conditions 
 *  before allowing the power supply to run. This analysis requires a definition
 *  of the default operating mode of the converter.
 * 
 *  - DEFAULT_OPMODE_BUCK = 0
 *    
 *    In this setting the converter is starting up in step-down mode, 
 *    considering the high-voltage port as input source and the low-voltage
 *    port as output. The current feedback is considered to be direct 
 *    proportional (positive)
 *   
 *  - DEFAULT_OPMODE_BOOST = 1
 *    
 *    In this setting the converter is starting up in step-up mode, 
 *    considering the low-voltage port as input source and the high-voltage
 *    port as output. The current feedback is considered to be indirect
 *    proportional (negative)
 *   
 *  - DEFAULT_OPMODE_AUTO = 2
 *    
 *    In this setting the converter is monitoring the high- and low-voltage 
 *    port simultaneously. Which ever exceeds the under voltage lock-out limit
 *    will be considered as input and the power transfer direction will be set
 *    accordingly.
 * 
 * @note
 *   All available control loop interrupt trigger options are listed in the respective
 *   hardware abstraction layer flags header file
 * 
 * @see
 *   adp1051_240_evalz_flags.h
 * 
 **********************************************************************************/
#define DEFAULT_OPERATING_MODE          DEFAULT_OPMODE_BUCK ///< 0 = Buck Converter Mode (default), 1 = Boost Converter Mode, 2 = Auto-Detect Mode (not supported yet)
#define DEFAULT_SWAP_MODE               DIRCTRL_HOT_SWAP    ///< 0 = Soft Swap of conversion mode, 1 = Hot Swap of conversion mode

/*********************************************************************************
 * @ingroup special-options
 * @def     AUTO_START
 * @brief   Determines if the converter is allowed to run as soon as input power has been detected
 * 
 * @details
 *  - When AUTO_START flag is set = true
 *    Forces the power supply state machine to start up the power converter
 *    as soon as input power has been detected and all other self-test have 
 *    been cleared.
 *
 *  - When AUTO_START flag is set = false
 *    Holds the power supply state machine in STANDBY after input power has 
 *    been detected and all other self-test have been cleared. The GO bit 
 *    in the Status word of the power converter data object must be set to 
 *    start the power converter. The GO bit is cleared automatically and must 
 *    be set at every converter start, including when the converter has been 
 *    shut of and reset due to a fault condition.
 * 
 *  **********************************************************************************/
#define AUTO_START                      true    ///< Allow converter to start up automatically

/*********************************************************************************
 * @ingroup special-options
 * @def     ISNS_OFFSET_CALIBRATION_ENABLE
 * @brief   Enables/Disables Current Sense Offset Calibration
 * 
 * @details
 *  Flag indicating if the signal offset of the current sense feedback needs to be calibrated.
 *  The calibration procedure is available as Special Function of the power controller and will be 
 *  called automatically when the option ISNS_OFFSET_CALIBRATION_ENABLE is set to 'true' 
 * 
 * @note
 *  Standby current sense feedback offset calibration is not supported by the MCP6C02 shunt amplifier
 *  device used in EPC9137 due to its limited common mode range, which starts above 2.5 V DC. However,
 *  the common reference voltage of both devices, auto-zero self tuning and high sensing precision
 *  makes calibration negligible.
 **********************************************************************************/
#define ISNS_OFFSET_CALIBRATION_ENABLE  false   ///< Current Sense Offset Calibration is disabled (see notes)

/*********************************************************************************
 * @ingroup special-options
 * @def     SYNCHRONOUS_RECTIFIER_CONTROL
 * @def     AUTO_SYNCH_RECTIFIER_CONTROL
 * @brief   Determines if the converter is allowed to run as soon as input power has been detected
 * 
 * @details
 *  **********************************************************************************/
#define SYNCHRONOUS_RECTIFIER_ENABLE    true    ///< Enable active synchronous rectification
#define SYNCHRONOUS_RECTIFIER_CONTROL   false   ///< Disable support for runtime rectifier control
#define AUTO_SYNCH_RECTIFIER_CONTROL    false   ///< Disable support for automatic runtime rectifier control

  
  
#endif	/* ADP1051_240_EVALZ_OPTIONS_H */

// ________________________
// end if file
