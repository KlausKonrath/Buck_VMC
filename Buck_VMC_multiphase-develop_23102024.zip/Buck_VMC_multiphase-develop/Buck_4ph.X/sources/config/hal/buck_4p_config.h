/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/**
 * @file    buck_4p_config.h
 * @author  M91406
 * @brief   Physical quantity parameter declaration header file 
 * @version 1.0
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef BUCK_4PH_CONFIGURATION_H
#define	BUCK_4PH_CONFIGURATION_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
#include <stddef.h> // include standard definition data types

#include "buck_4p_flags.h" // include list of generic configuration flags

/**************************************************************************************************
 * @ingroup hardware-id-macro
 * @{
 * @brief   Global macro identifying the hardware version supported by 
 * 
 * @details
 *  This global macro is used to identify the hardware version supported by this hardware 
 *  abstraction layer header file. 
 * 
 **************************************************************************************************/
#ifndef __BUCK_4PH__
  #define __BUCK_4PH__
#endif
/** @} */ // end of group hardware-id-macro



/**************************************************************************************************
 * @ingroup pwm-settings
 * @{
 * @brief User-declaration of global defines for PWM signal generator settings
 * 
 * @details
 * This section defines fundamental PWM settings required for the interleaved 4 ph buck converter
 * 160V-to-26V rail power module development board. These settings are determined 
 * by hardware and defined using physical quantities. Pre-compiler macros are used to convert 
 * physical values into binary (integer) numbers to be written to Special Function Registers (SFR).
 * 
 **************************************************************************************************/

#define NO_OF_PHASES                        4U ///< Number of power converter phases of this design
    
#define SWITCHING_FREQUENCY                 (float)100.0e+3 ///< Fixed Switching frequency in [Hz]
#define SAMPLING_DIVIDER                    0U              ///< Sampling frequency divider (divides the switching frequency by [n+1])
#define SAMPLING_OFFSET                     0U              ///< Sampling event offset (delays the first generation of trigger by n switching cycles)

#define PWM_DUTY_MAX                      (float)  0.980   ///> Clamp used to limit controller max duty cycle in [%] of period
#define PWM_DUTY_MIN                      (float)  0.005   ///> Clamp used to limit controller min duty cycle in [%] of period
#define PWM_DUTY_SHIFT                    (uint16_t)   1   ///> The compensator max output is 0x7FFF. If higher duty is needed the output of the compensato will be right shifted befor writhing the duty cycle

// TODO Min duty is currently < tha deadtimes. Verify

#define BUCK_DEAD_TIME_LEADING_EDGE      (float)10.0e-9     ///< Buck Leading Edge Dead Time delay in [sec]
#define BUCK_DEAD_TIME_FALLING_EDGE      (float)35.0e-9     ///< Buck Falling Edge Dead Time delay in [sec]
#define BUCK_LEADING_EDGE_BLANKING       (float)  300e-9    ///< Leading Edge Blanking period in [sec]

// Frequency jitter parameters
//TODO - BECOM: Spread Spectrum enable/disable!!!
#define BUCK_FREQUENCY_JITTER            true              ///< Used to enable/disable PWM frequency jittering for EMC reduction
#define NOM_FREQ                         1000               ///< Value to be written in FSMINPER
#define SCALED_FREQ                      1000               ///< Value to be written in FSCL alwais lower or equal than FSMINPER
#define NUM_JITTER_SAMPLE                100                ///< Number of random numbers used to generate the frequency jitter




/** @} */ // end of group pwm-settings ~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup input-voltage-feedback-settings
 * @{
 * @brief   Declaration of input voltage feedback properties
 * 
 * @details
 *  In this section the input voltage range is specified. 
 *  Physical quantities are used to define values. 
 *  Macros are used to convert given physical values into binary (integer) number to be written into SFRs and variables.
 **************************************************************************************************/

// Feedback Declarations
//TODO - BECOM: Eingangsspannungsbedingungen!!!
#define VIN_UVLO_VOLTAGE        (float)10.000    ///< Input Under Voltage Lock Out Cut Off Threshold in [V] 
#define VIN_OVLO_VOLTAGE        (float)160.000   ///< Input Over Voltage Lock Out Cut Off Threshold in [V] 
#define VIN_HYSTERESIS          (float)1.000     ///< Voltage Extremes Thresholds Hysteresis in [V]
#define VIN_AGC_MINIMUM         (float)27.000    ///< Input Voltage at which the voltage loop is calculated [V] 


#define V_DCDC_MINIMUM_VOLT     (float)3.000     ///< DCDC Voltage at which the voltage loop is released [V] 

/** @} */ // end of group input-voltage-feedback-settings ~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup output-voltage-feedback-settings
 * @{
 * @brief Declaration of output voltage feedback properties
 * 
 * @details
 * In this section the output voltage feedback signal scaling, gain, valid signal limits and nominal
 * operating point is specified. Physical quantities are used to define values. Macros are used to 
 * convert given physical values into binary (integer) number to be written into SFRs and variables.
 * *************************************************************************************************/

// TODO verify what is needed

// Feedback Declarations
//TODO - BECOM: Regelspannung!!!
#define VOUT_NOMINAL             (float)26.000   ///< Nominal output voltage


#define VOUT_OVP_VOLTAGE         (float)30.000   ///< Over Voltage Protection Cut Off Threshold in [V] (when V12 is voltage output)
#define VOUT_UVP_VOLTAGE         (float) 7.500   ///< Under Voltage Protection Cut Off Threshold in [V] (used in battery charging mode only)
#define VOUT_HYSTERESIS          (float) 0.500   ///< Over Voltage Protection Hysteresis

#define VOUT_TOLERANCE_MAX       (float) 5.000   ///< Output voltage regulation tolerance [V][+/-] // TODO verify the correct level
#define VOUT_TOLERANCE_MIN       (float) 4.500   ///< Output voltage regulation tolerance [V][+/-]

/** @} */ // end of group output-voltage-feedback-settings ~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup phase-current-feedback-settings
 * @{
 * @brief Declaration of phase-current feedback properties
 * 
 * @details
 * In this section the phase-current feedback signal scaling, gain, valid signal limits and nominal
 * operating point is specified. Physical quantities are used to define parameter values to ease
 * the system configuration. 
 * 
 * Macros are used to convert given physical values into binary (integer) number to be written
 * into SFRs and variables and being used in runtime calculations.  
 * (see \ref phase-current-feedback-macros for details)
 **************************************************************************************************/

// General Current Sense Feedback Declarations
#define IPRI_MINIMUM            (float)  0.000      ///< absolute minimum phase current
#define IPRI_NOMINAL            (float)  0.000      ///< nominal phase current
#define IPRI_MAXIMUM            (float) 10.000      ///< max primary peak current request from  the voltage loop
#define ISNS_LIMIT_START        (float) 10.200      ///< startup phase current limit
 

//TODO - BECOM: Comparator DAC!!!
#define ISNS_OCP_TRIP_LEVEL     (float) 15.0        ///< absolute maximum phase current tripping the over current limit (immediate)
#define ISNS_OCP_RELEASE_LEVEL  (float) 0.000       ///< current reset level after over current event (immediate)
 
#define ISNS_COMMON_MODE_LIMIT  (float)  4.000      ///< phase current sense common mode voltage minimum in [V]
#define ISNS_COMMON_MODE_HYST   (float)  0.200      ///< phase current sense common mode voltage minimum in [V]
#define OPEN_LOOP_STARTUP       true                ///< flag indicating if minium common mode voltage range needs to be secured before regulation can be trusted
 
#define SYNCCTL_ON_THRESHOLD    (float) 10.000      ///< phase current above which the synchronous rectifier will be turned on
#define SYNCCTL_OFF_THRESHOLD   (float)  8.000      ///< phase current below which the synchronous rectifier will be turned off
#define AUTO_SYNCCTL            false               ///< flag enabling/disabling automatic synchronous rectifier control
 
// TODO verify ADC trigger delay
// Specific Current Sense Feedback Declarations
// Current Sense Phase #1
#if (NO_OF_PHASES >= 1)
#define ISNS1_ADC_TRG_DELAY     (float) 886.0e-9    ///< ADC trigger delay for current sense #1 in [sec]
#define ISNS1_FEEDBACK_OFFSET   (float) 0       ///< current sense #1 feedback offset 
#endif

// Current Sense Phase #2
#if (NO_OF_PHASES >= 2)
#define ISNS2_ADC_TRG_DELAY     (float) 886.0e-9    ///< ADC trigger delay for current sense #2 in [sec]
#define ISNS2_FEEDBACK_OFFSET   (float) 0       ///< current sense #2 feedback offset 
#endif

// Current Sense Phase #3
#if (NO_OF_PHASES >= 3)
#define ISNS3_ADC_TRG_DELAY     (float) 886.0e-9    ///< ADC trigger delay for current sense #3 in [sec]
#define ISNS3_FEEDBACK_OFFSET   (float) 0       ///< current sense #3 feedback offset 
#endif

// Current Sense Phase #4
#if (NO_OF_PHASES >= 4)
#define ISNS4_ADC_TRG_DELAY     (float) 886.0e-9    ///< ADC trigger delay for current sense #4 in [sec]
#define ISNS4_FEEDBACK_OFFSET   (float) 0       ///< current sense #4 feedback offset 
#endif

/** @} */ // end of group phase-current-feedback-settings ~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup temperature-feedback-settings
 * @{ 
 * @brief   Declaration of temperature feedback properties
 * 
 * @details
 * In this section the temperature feedback signal scaling, gain, valid signal limits and nominal
 * operating point is specified. Physical quantities are used to define parameter values to ease
 * the system configuration. 
 * 
 * Macros are used to convert given physical values into binary (integer) number to be written
 * into SFRs and variables and being used in runtime calculations.  
 * (see \ref temperature-feedback-macros for details)
 **************************************************************************************************/
 
// Temperature Feedback Declarations
#define TEMP_FEEDBACK_GAIN      (float) 4.3194  ///< AD590 with 3.48k load gain
#define TEMP_FEEDBACK_OFFSET    (float) 0.950   ///< Signal level at 0? C in [V] (AD590 with 3.48k load offset)

#define TEMP_MINIMUM            (float) -40.0   ///< minimum heat-sink temperature
#define TEMP_NOMINAL            (float)   0.0   ///< nominal heat-sink temperature
#define TEMP_MAXIMUM            (float) 125.0   ///< maximum heat-sink temperature

#define TEMP_OTP_ULIMIT         (float) 100.0   ///< maximum heat-sink temperature to trip over temperature fault (deg C)
#define TEMP_OTP_LLIMIT         (float)  80.0   ///< temperature reset level after over temperature event
#define TEMP_ADC_TRG_DELAY      (float) 0.000   ///< ADC trigger delay for temperature sensor in [sec]

/** @} */ // end of group temperature-feedback-settings ~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup adaptive-control-settings
 * @{
 * @brief Declaration of additional hardware-specific defines required for adaptive gain control
 * 
 * @details
 * In this section additional macros are defined to calculate constant parameters for the
 * adaptive gain modulation algorithm using user defined settings declared in their respective
 * sections. Any change of these parameters will also result in a change of the values of the 
 * gain modulation parameters of this section.
 **************************************************************************************************/

#define AGC_EXECUTION_DELAY     (float)(390.0e-9) ///< AGC Observer Algorithm Execution Time in [sec]

/** @} */ // end of group adaptive-control-settings ~~~~~~~~~~~~~~~~~~~~~~~


/**************************************************************************************************
 * @ingroup startup-timing-settings
 * @{
 * @brief Global defines for soft-start specific parameters
 * 
 * @details
 * This section is used to define power supply startup timing settings. The soft-start sequence 
 * is part of the power controller. It allows to program specific timings for 
 *   - Power On Delay
 *   - Ramp Period 
 *   - Power Good Delay
 * 
 * After the startup has passed these three timing periods, the power supply is ending up in 
 * "normal" operation, continuously regulating the output until a fault is detected or the 
 * operating state is changed for any other reason. When the output voltage reference is changed, 
 * the power control state machine will use the voltage ramp slope defined here to tune from the 
 * recent voltage reference to the new reference value. During this period the BUSY-bit of the 
 * power controller (status word, bit #7) will be set. This status bit will be cleared automatically
 * by the power controller state machine once the new reference value has been applied and the 
 * converter is back in constant regulation mode.
 * 
 * Pre-compiler macros are used to translate physical values into binary (integer) numbers to 
 * be written to SFRs and variables.  
 * (see \ref startup-timing-macros for details)
 * 
 **************************************************************************************************/

#define POWER_ON_DELAY          (float) 200e-3 ///< power on delay in [sec]
#define CHARGE_UP_DELAY         (float) 300e-3 ///< output capacitor charge-up delay in [sec]
#define CHARGE_UP_TIMEOUT       (float) 500e-3 ///< output capacitor charge-up delay timeout in [sec]
#define LVRAMP_PERIOD           (float)  50e-3 ///< voltage ramp-up period of low-voltage output in [sec]
#define HVRAMP_PERIOD           (float)  50e-3 ///< voltage ramp-up period of high-voltage output in [sec]
#define IRAMP_PERIOD            (float)  50e-3 ///< output current ramp-up period in [sec]
#define POWER_GOOD_DELAY        (float) 200e-3 ///< power good delay in [sec]


/** @} */ // end of group startup-timing-settings ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup inrush-settings
 * @{
 * @brief User-declaration of global defines for the Inrush management setting
 * 
 * @details
 * This section defines fundamental Inrush settings required for the interleaved 4 ph buck converter
 * 
 * 
 **************************************************************************************************/
#define EN_DCDC_INRUSH_DELAY    (float) 10e-3   ///<  EN_DCDC_Inrush delay

//TODO - BECOM: Schaltschwelle f�r Bypass!!!
#define INRUSH_DELTAV_THRESHOLD (float) 0.5     ///< Voltage difference between U-Protected and U-DCDC below which the bypass is enabled

/** @} */ // end of group inrush-settings ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


/**************************************************************************************************
 * @ingroup fault-response-settings
 * @{
 * @brief Global defines for fault-monitor related parameters
 * 
 * @details
 * This section is used to define power supply fault object timing settings. The fault monitor 
 * is continuously monitoring declared data objects at the high-priority task frequency defined by 
 * \ref MAIN_EXECUTION_PERIOD. Based on this known interval, filtering delays for fault trip and 
 * fault recovery events to allow users to adjust the fault detection sensitivity.
 * 
 * - Fault Trip Event Delay   
 *   This setting defines for how long a fault condition has to be continuously 
 *   active before the effective fault trip status/event will be triggered.
 * 
 * - Fault Recovery Event Delay   
 *   This setting defines for how long a fault condition has to be continuously
 *   cleared before the effective fault recovery status/event will be triggered.
 * 
 * - Fault Restart Delay (FLTRSTDLY)
 *   In case a detected fault event tripped a power supply shutdown, and all 
 *   active fault conditions have been cleared, a global restart delay counter 
 *   is started, which has to expire before a restart attempt is initiated.
 * 
 * - Fault Restart Cycles
 *   Defines the number of restart attempts during an active fault recovery period.
 *   If no faults are triggered during the recovery period, the respective restart
 *   counter is reset. If new fault events are triggered, the restart counter is 
 *   incremented. If the restart counter reaches the given number of declared restart 
 *   cycles, the system will enter the Fault Latched mode and no further restart 
 *   attempts will be initiated.
 * 
 *************************************************************************************************/

#define UVLO_TRIP_DELAY         (float)    5e-3 ///< under voltage lock out trip delay in [sec]
#define UVLO_RECOVERY_DELAY     (float)  10e-3 ///< under voltage lock out recovery delay in [sec]
#define OVLO_TRIP_DELAY         (float)    5e-3 ///< over voltage lock out trip delay in [sec]
#define OVLO_RECOVERY_DELAY     (float)  10e-3 ///< over voltage lock out recovery delay in [sec]
#define REGERR_TRIP_DELAY       (float)   50e-3 ///< regulation error trip delay in [sec]
#define REGERR_RECOVERY_DELAY   (float)  10e-3 ///< regulation error recovery delay in [sec]
#define OCP_TRIP_DELAY          (float)    2e-3 ///< over current protection trip delay in [sec]
#define OCP_RECOVERY_DELAY      (float)  10e-3 ///< over current protection recovery delay in [sec]
#define OVP_TRIP_DELAY          (float)    5e-3 ///< over voltage protection trip delay in [sec]
#define OVP_RECOVERY_DELAY      (float)  10e-3 ///< over voltage protection recovery delay in [sec]
#define OTP_TRIP_DELAY          (float)    5e-3 ///< over temperature protection trip delay in [sec]
#define OTP_RECOVERY_DELAY      (float)  10e-3 ///< over temperature protection recovery delay in [sec]
#define UVP_TRIP_DELAY          (float)   50e-3 ///< under voltage protection trip delay in [sec]
#define UVP_RECOVERY_DELAY      (float)  10e-3 ///< under voltage protection recovery delay in [sec]

#define FAULT_RESTART_DELAY     (float) 500e-3 ///< under voltage protection recovery delay in [sec]
#define FAULT_RESTART_CYCLES    4U  ///< Maximum number of restart cycles: Fault state will be latched until CPU reset or power cycle

#define OCP_FAULT_REGISTER      PG1STAT ///< Fault Status bit used to detect overcurrent fault triggered by FPCI
#define OCP_FAULT_BIT           10U      ///< Bit position within the above register triggered by FPCI fault

/** @} */ // end of group fault-response-settings ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup current-balancing-settings
 * @{ 
 * @brief   Declaration of current balancing  properties
 * 
 * @details
 * In this section the the current balancing settings are specified.
 * Physical quantities are used to define parameter values to ease the system configuration. 
 * 
 * Macros are used to convert given physical values into binary (integer) number to be written
 * into SFRs and variables and being used in runtime calculations.  
 * (see \ref current-balancing-macros for details)
 **************************************************************************************************/

 
// Current balancing Declarations
#define MAX_DUTY_OFFSET_SEC     (float) 50e-9  ///< Maximum time that can be added to the nominal duty cycle used to drive buck2,3,4
#define MIN_DUTY_OFFSET_SEC     (float) -50e-9 ///< Minimum time that can be added to the nominal duty cycle used to drive buck2,3,4

#define BALANCING_HYSTERESIS    (float) 0.1     ///< Minimum current difference between buck1 and buck2,3,4 above which the balancing is triggered
#define BALANCING_IIR_BITS      (uint16_t)6     ///< Number of bitshift used to implement the IIR filter
#define BALANCING_EXEC_SCALER   (uint16_t)200   ///< Balancing routine is executed at RTOS_6G2_EXECUTION_PERIOD/BALANCING_EXEC_SCALER to have a stable balancing


/** @} */ // end of group temperature-feedback-settings ~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup comm-interrupt-vector-declarations
 * @{
 * @brief   Communication interface interrupt vector Settings
 * 
 * @details
 * Control loops are called in dedicated interrupt service routines of PWM events, ADC events
 * or triggered by timers. This section allows users to set and modify the interrupt service 
 * routine triggers and their priority to set up and optimize the control system interrupt 
 * structure.
 * 
 * *************************************************************************************************/
///NEW UART
//TODO - BECOM: Baudrate!!!
#define VCP_BAUDRATE            UART_BAUDRATE_19200 //UART_BAUDRATE_115200    ///< UART port configuration: Baud rate 115200
#define VCP_DATABITS            UART_DATABITS_8         ///< UART port configuration: 8 data bits
#define VCP_PARITY              UART_PARITY_NONE        ///< UART port configuration: no parity
#define VCP_STOPBITS            UART_STOPBITS_1         ///< UART port configuration: 1 stop bits
#define VCP_FLOWCONRTOL         UART_FLOWCONTROL_NONE   ///< UART port configuration: no flow control

#define VCP_PORT                2U      ///< Number of UART instance used to communicate with the PC

#if (VCP_PORT == 1U)
  #define VcpRxInterrupt        _U1RXInterrupt
  #define VCP_Rx_IP             _U1RXIP ///< Receive interrupt priority register
  #define VCP_Rx_IE             _U1RXIE ///< Receive interrupt enable bit
  #define VCP_Rx_IF             _U1RXIF ///< Receive interrupt flag bit

  #define VcpTxInterrupt        _U1TXInterrupt ///< Transmit interrupt serivce routine label 
  #define VCP_Tx_IP             _U1TXIP ///< Transmit interrupt priority register
  #define VCP_Tx_IE             _U1TXIE ///< Transmit interrupt enable bit
  #define VCP_Tx_IF             _U1TXIF ///< Transmit interrupt flag bit

  #define VcpErrInterrupt       _U1EInterrupt ///< Transmit interrupt serivce routine label 
  #define VCP_ErrIP             _U1EIP ///< Transmit interrupt priority register
  #define VCP_ErrIE             _U1EIE ///< Transmit interrupt enable bit
  #define VCP_ErrIF             _U1EIF ///< Transmit interrupt flag bit

#elif (VCP_PORT == 2U)

  #define VCP_RxInterrupt       _U2RXInterrupt ///< Receive interrupt serivce routine label 
  #define VCP_Rx_IP             _U2RXIP ///< Receive interrupt priority register
  #define VCP_Rx_IE             _U2RXIE ///< Receive interrupt enable bit
  #define VCP_Rx_IF              _U2RXIF ///< Receive interrupt flag bit

  #define VCP_TxInterrupt       _U2TXInterrupt ///< Transmit interrupt serivce routine label 
  #define VCP_Tx_IP             _U2TXIP ///< Transmit interrupt priority register
  #define VCP_Tx_IE             _U2TXIE ///< Transmit interrupt enable bit
  #define VCP_Tx_IF             _U2TXIF ///< Transmit interrupt flag bit

  #define VcpErrInterrupt       _U2EInterrupt ///< Transmit interrupt serivce routine label 
  #define VCP_ErrIP             _U2EIP ///< Transmit interrupt priority register
  #define VCP_ErrIE             _U2EIE ///< Transmit interrupt enable bit
  #define VCP_ErrIF             _U2EIF ///< Transmit interrupt flag bit

#elif (VCP_PORT == 3U)

  #define VCP_RxInterrupt       _U3RXInterrupt ///< Receive interrupt serivce routine label 
  #define VCP_Rx_IP             _U3RXIP ///< Receive interrupt priority register
  #define VCP_Rx_IE             _U3RXIE ///< Receive interrupt enable bit
  #define VCP_Rx_IF              _U3RXIF ///< Receive interrupt flag bit

  #define VCP_TxInterrupt       _U3TXInterrupt ///< Transmit interrupt serivce routine label 
  #define VCP_Tx_IP             _U3TXIP ///< Transmit interrupt priority register
  #define VCP_Tx_IE             _U3TXIE ///< Transmit interrupt enable bit
  #define VCP_Tx_IF             _U3TXIF ///< Transmit interrupt flag bit

  #define VcpErrInterrupt       _U3EInterrupt ///< Transmit interrupt serivce routine label 
  #define VCP_ErrIP             _U3EIP ///< Transmit interrupt priority register
  #define VCP_ErrIE             _U3EIE ///< Transmit interrupt enable bit
  #define VCP_ErrIF             _U3EIF ///< Transmit interrupt flag bit

#endif

#define VCP_RX_ISR_PRIORITY    1U ///< Receive interrupt vector priority (valid settings between 0...6 with 6 being the highest priority)
#define VCP_TX_ISR_PRIORITY    1U ///< Transmit interrupt vector priority (valid settings between 0...6 with 6 being the highest priority)

///END NEW UART

///NEW DMA
#define VCP_TX_DMA              1U      ///< UART port transmit channel DMA support instance
#define VCP_RX_DMA              0U      ///< UART port receive channel DMA support instance

#define VCP_USE_TX_DMA          true    ///< Use DMA for data transmission 
#define VCP_USE_RX_DMA          false   ///< Use DMA for data reception
#define VCP_REDIRECT_PRINTF     false   ///< Redirect printf to print messages to UART
#define VCP_DATA_BYTE_SWAP      false   ///< When true, swaps the order of bytes of 16-bit and 32-bit values

#if (VCP_TX_DMA == 1)
  #define VcpTxDmaInterrupt     _DMA1Interrupt///< Interrupt serivce routine label 
  #define VcpTxDma_IP           _DMA1IP ///< Transmit DMA interrupt priority register
  #define VcpTxDma_IE           _DMA1IE ///< Transmit DMA interrupt enable bit
  #define VcpTxDma_IF           _DMA1IF ///< Transmit DMA interrupt flag bit

#elif (VCP_TX_DMA == 2)
  #define VcpTxDmaInterrupt     _DMA2Interrupt///< Interrupt serivce routine label 
  #define VcpTxDma_IP           _DMA2IP ///< Transmit DMA interrupt priority register
  #define VcpTxDma_IE           _DMA2IE ///< Transmit DMA interrupt enable bit
  #define VcpTxDma_IF           _DMA2IF ///< Transmit DMA interrupt flag bit

#elif (VCP_TX_DMA == 3)
  #define VcpTxDmaInterrupt     _DMA3Interrupt///< Interrupt serivce routine label 
  #define VcpTxDma_IP           _DMA3IP ///< Transmit DMA interrupt priority register
  #define VcpTxDma_IE           _DMA3IE ///< Transmit DMA interrupt enable bit
  #define VcpTxDma_IF           _DMA3IF ///< Transmit DMA interrupt flag bit

#endif

 #define VcpRxDmaInterrupt     _DMA0Interrupt///< Interrupt serivce routine label 
 #define VcpRxDma_IP           _DMA0IP ///< Receive DMA interrupt priority register
 #define VcpRxDma_IE           _DMA0IE ///< Receive DMA interrupt enable bit
 #define VcpRxDma_IF           _DMA0IF ///< Receive DMA interrupt flag bit
///END NEW DMA

#define _CRCxInterrupt          _CRCInterrupt ///< Interrupt serivce routine label 
#define _CRC_IP                 _CRCIP ///< CRC interrupt priority register
#define _CRC_IE                 _CRCIE ///< CRC interrupt enable bit
#define _CRC_IF                 _CRCIF ///< CRC interrupt flag bit
#define _CRCFIFO_FULL           _CRCFUL ///< CRC FIFO Full flag bit

/** @} */ // end of group comm-interrupt-vector-declarations


#endif	

// ________________________
// end if file
