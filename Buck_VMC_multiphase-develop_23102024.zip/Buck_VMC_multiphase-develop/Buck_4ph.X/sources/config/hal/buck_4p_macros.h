/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * @file    buck_4p_macros.h
 * @author  M91406
 * @brief   Physical quantity parameter declaration header file 
 * @version 1.0
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef BUCK_4PH_MACROS_H
#define	BUCK_4PH_MACROS_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
#include <stddef.h> // include standard definition data types
#include <math.h> // include standard math library

#include "config/mcal.h" // include Microcontroller default macros
#include "config/os.h" // include operating system configuration header file
#include "buck_4p_config.h" // include related firmware configuration header file
#include "buck_4p_board.h" // include related circuit configuration header file

/***********************************************************************************
 * @ingroup pwm-macros
 * @{ 
 * @brief Conversion macros for user-declarations of PWM parameters
 * 
 * @details
 * These conversion macros are used to convert user settings defined as physical 
 * quantities into binary (integer) numbers, which will be written to registers and
 * variables and used in calculations throughout the firmware.
 ***********************************************************************************/

// Conversion Macros
#define SWITCHING_PERIOD        (float)(1.0/SWITCHING_FREQUENCY)   ///< Switching period in [sec]
#define PWM_PERIOD              (uint16_t)(float)(SWITCHING_PERIOD / PWM_CLOCK_PERIOD) ///< This sets the switching period of the converter


/* defines for Undervoltage Comparator reference */
#define PWM6_DC_100_PERC             (uint16_t)(PWM_PERIOD)
#define PWM6_DC_50_PERC              (uint16_t)(PWM_PERIOD >> 1)
#define PWM6_DC_25_PERC              (uint16_t)(PWM_PERIOD >> 2)
#define PWM6_DC_8_32_PERC            (uint16_t)3328U
#define PWM6_DC_0_PERC               (uint16_t)0U


#define CONTROL_FREQUENCY       (float) ((SWITCHING_FREQUENCY)/(float)(SAMPLING_DIVIDER + 1)) ///< Sampling frequency in [Hz]
#define CONTROL_PERIOD          (float) ((SWITCHING_FREQUENCY)/(float)(SAMPLING_DIVIDER + 1)) ///< Sampling period in [sec]
#define MPHASE_PHASE_SHIFT      (uint16_t)((float)PWM_PERIOD / (float)NO_OF_PHASES) ///< This sets the phase shift between phases in multiphase converters

#define PWM_DC_MAX             ((uint16_t)((PWM_DUTY_MAX * (float)PWM_PERIOD))>>PWM_DUTY_SHIFT) ///> This sets the minimum duty cycle
#define PWM_DC_MIN             ((uint16_t)((PWM_DUTY_MIN * (float)PWM_PERIOD))>>PWM_DUTY_SHIFT) ///> This sets the maximum duty cycle

#define BUCK_DEAD_TIME_LE    (uint16_t)(BUCK_DEAD_TIME_LEADING_EDGE / (float)PWM_CLOCK_PERIOD) ///< Rising edge dead time [tick = 250ps]
#define BUCK_DEAD_TIME_FE    (uint16_t)(BUCK_DEAD_TIME_FALLING_EDGE / (float)PWM_CLOCK_PERIOD) ///< Falling edge dead time [tick = 250ps]
#define BUCK_LEB_PERIOD      (uint16_t)(BUCK_LEADING_EDGE_BLANKING / (float)PWM_CLOCK_PERIOD) ///< Leading Edge Blanking = n x PWM resolution (here: 50 x 2ns = 100ns)

#define PWM_DC_CORR_MAX         (int16_t)(PWM_DUTY_CYCLE_CORRECTION_MAX * (float)PWM_PERIOD / 100.0) ///> This sets the maximum duty cycle correction

#if BUCK_FREQUENCY_JITTER == 0
#define PWM_CKSEL 1         ///> PWM Generator uses Master clock selected by the MCLKSEL[1:0] 
#else
#define PWM_CKSEL 3        ///> PWM Generator uses Master clock scaled by frequency scaling circuit
#endif

/** @} */ // end of group pwm-macros ~~~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup input-voltage-feedback-macros
 * @{ 
 * @brief Conversion macros of input voltage feedback parameters
 * 
 * @details
 * These conversion macros are used to convert user settings defined as physical 
 * quantities into binary (integer) numbers, which will be written to registers and
 * variables and used in calculations throughout the firmware.
 **************************************************************************************************/
// TODO remove unused macros

#define VIN_FEEDBACK_GAIN   (float)((VIN_DIV_R2) / (VIN_DIV_R1 + VIN_DIV_R2)) // DO NOT CHANGE
#define VIN_MIN             (uint16_t)(VIN_MINIMUM * VIN_FEEDBACK_GAIN / ADC_GRANULARITY)   ///< Minimum input voltage
#define VIN_NOM             (uint16_t)(VIN_NOMINAL * VIN_FEEDBACK_GAIN / ADC_GRANULARITY)   ///< Nominal input voltage
#define VIN_MAX             (uint16_t)(VIN_MAXIMUM * VIN_FEEDBACK_GAIN / ADC_GRANULARITY)   ///< Maximum input voltage
#define VIN_HYST            (uint16_t)(VIN_HYSTERESIS * VIN_FEEDBACK_GAIN / ADC_GRANULARITY)  ///< Protection thresholds hysteresis 
#define VIN_OFFSET          (uint16_t)(VIN_FEEDBACK_OFFSET / ADC_GRANULARITY) ///< Input voltage feedback offset


#define VIN_UVLO_TRIP       (uint16_t)(VIN_UVLO_VOLTAGE * VIN_FEEDBACK_GAIN / ADC_GRANULARITY) ///< Under Voltage Lock Out voltage
#define VIN_UVLO_RELEASE    (uint16_t)((VIN_UVLO_VOLTAGE + VIN_HYSTERESIS) * VIN_FEEDBACK_GAIN / ADC_GRANULARITY) ///< Under Voltage Lock Out voltage
#define VIN_OVLO_TRIP       (uint16_t)(VIN_OVLO_VOLTAGE * VIN_FEEDBACK_GAIN / ADC_GRANULARITY)  ///< Over Voltage Lock Out voltage
#define VIN_OVLO_RELEASE    (uint16_t)((VIN_OVLO_VOLTAGE - VIN_HYSTERESIS) * VIN_FEEDBACK_GAIN / ADC_GRANULARITY)  ///< Over Voltage Lock Out voltage
#define VIN_AGC_MIN         (uint16_t)(VIN_AGC_MINIMUM * VIN_FEEDBACK_GAIN / ADC_GRANULARITY)                     ///< Minimum Input voltage used to calculate the AGC factor vs the current input voltage

#define VIN_RANGE_MAX       (float)(VIN_MAXIMUM - VIN_MINIMUM) ///< Maximum input voltage range in [V]
#define VIN_NORM_INV_G      (float)(1.0/VIN_FEEDBACK_GAIN) ///< Inverted feedback gain required for value normalization
#define VIN_NORM_SCALER     (int16_t)(ceil(log(VIN_NORM_INV_G)/log(2))) ///< VIN normalization  
#define VIN_NORM_FACTOR     (int16_t)((VIN_NORM_INV_G / pow(2.0, VIN_NORM_SCALER)) * (pow(2.0, 15)-1)) ///< VIN normalization factor scaled in Q15

#define VIN_ADC_TRGDLY      (uint16_t)(VIN_ADC_TRG_DELAY / PWM_CLOCK_PERIOD) ///< Input voltage ADC trigger delay

#define VIN_PHYS_CALC_FAC   (uint32_t)((ADC_GRANULARITY / VIN_FEEDBACK_GAIN) * (float)51200.0)

// TODO add additonal macro for Vin prot here
#define VIN_PROT_FEEDBACK_GAIN   (float)((VIN_PROT_DIV_R2) / (VIN_PROT_DIV_R1 + VIN_PROT_DIV_R2)) // DO NOT CHANGE
#define VIN_PROT_PHYS_CALC_FAC   (uint32_t)((ADC_GRANULARITY / VIN_PROT_FEEDBACK_GAIN) * (float)51200.0)

// TODO add additonal macro for V_DCDC here
#define V_DCDC_FEEDBACK_GAIN   (float)((V_DCDC_DIV_R2) / (V_DCDC_DIV_R1 + V_DCDC_DIV_R2)) // DO NOT CHANGE
#define V_DCDC_OFFSET          (uint16_t)(V_DCDC_FEEDBACK_OFFSET / ADC_GRANULARITY) ///< Input voltage feedback offset
#define V_DCDC_ADC_TRGDLY      (uint16_t)(V_DCDC_ADC_TRG_DELAY / PWM_CLOCK_PERIOD) ///< Input voltage ADC trigger delay
#define V_DCDC_PHYS_CALC_FAC   (uint32_t)((ADC_GRANULARITY / V_DCDC_FEEDBACK_GAIN) * (float)51200.0)

#define V_DCDC_MIN_VOLT        (uint16_t)(V_DCDC_MINIMUM_VOLT * V_DCDC_FEEDBACK_GAIN / ADC_GRANULARITY)

// TODO add additonal macro for V_MOTOR here
#define V_MOTOR_FEEDBACK_GAIN   (float)((V_MOTOR_DIV_R2) / (V_MOTOR_DIV_R1 + V_MOTOR_DIV_R2)) // DO NOT CHANGE
#define V_MOTOR_OFFSET          (uint16_t)(V_MOTOR_FEEDBACK_OFFSET / ADC_GRANULARITY) ///< Input voltage feedback offset
#define V_MOTOR_ADC_TRGDLY      (uint16_t)(V_MOTOR_ADC_TRG_DELAY / PWM_CLOCK_PERIOD) ///< Input voltage ADC trigger delay
#define V_MOTOR_PHYS_CALC_FAC   (uint32_t)((ADC_GRANULARITY / V_MOTOR_FEEDBACK_GAIN) * (float)51200.0)

// TODO add additonal macro for V_AUX here
#define V_AUX_FEEDBACK_GAIN   (float)((V_AUX_DIV_R2) / (V_AUX_DIV_R1 + V_AUX_DIV_R2)) // DO NOT CHANGE
#define V_AUX_OFFSET          (uint16_t)(V_AUX_FEEDBACK_OFFSET / ADC_GRANULARITY) ///< Input voltage feedback offset
#define V_AUX_ADC_TRGDLY      (uint16_t)(V_AUX_ADC_TRG_DELAY / PWM_CLOCK_PERIOD) ///< Input voltage ADC trigger delay
#define V_AUX_PHYS_CALC_FAC   (uint32_t)((ADC_GRANULARITY / V_AUX_FEEDBACK_GAIN) * (float)51200.0)

// TODO add additonal macro for V_24VOLT here
#define V_24VOLT_FEEDBACK_GAIN   (float)((V_24VOLT_DIV_R2) / (V_24VOLT_DIV_R1 + V_24VOLT_DIV_R2)) // DO NOT CHANGE
#define V_24VOLT_OFFSET          (uint16_t)(V_24VOLT_FEEDBACK_OFFSET / ADC_GRANULARITY) ///< Input voltage feedback offset
#define V_24VOLT_ADC_TRGDLY      (uint16_t)(V_24VOLT_ADC_TRG_DELAY / PWM_CLOCK_PERIOD) ///< Input voltage ADC trigger delay
#define V_24VOLT_PHYS_CALC_FAC   (uint32_t)((ADC_GRANULARITY / V_24VOLT_FEEDBACK_GAIN) * (float)51200.0)

// TODO add additonal macro for I_200WATT here
#define I_200WATT_OFFSET          (uint16_t)(I_200WATT_FEEDBACK_OFFSET / ADC_GRANULARITY) ///< Input voltage feedback offset
#define I_200WATT_ADC_TRGDLY      (uint16_t)(I_200WATT_ADC_TRG_DELAY / PWM_CLOCK_PERIOD) ///< Input voltage ADC trigger delay

/** @} */ // end of group input-voltage-feedback-macros ~~~~~~~~~~~~~~~~~~~~~~
    
/**************************************************************************************************
 * @ingroup output-voltage-feedback-macros
 * @{ 
 * @brief Conversion macros of output voltage feedback parameters
 * 
 * @details
 * These conversion macros are used to convert user settings defined as physical 
 * quantities into binary (integer) numbers, which will be written to registers and
 * variables and used in calculations throughout the firmware.
 **************************************************************************************************/

#define VOUT_FEEDBACK_GAIN   (float)((VOUT_DIV_R2) / (VOUT_DIV_R1 + VOUT_DIV_R2)) ///< Macro calculating the integer number equivalent of the output voltage feedback gain
 
#define VOUT_NOM             (uint16_t)(VOUT_NOMINAL * VOUT_FEEDBACK_GAIN / ADC_GRANULARITY) ///< Macro calculating the integer number equivalent of the output voltage reference given above in [V]
#define VOUT_OFFSET          (uint16_t)(VOUT_FEEDBACK_OFFSET / ADC_GRANULARITY) ///< Macro calculating the integer number equivalent of the physical, static signal offset of this feedback channel
#define VOUT_HYST            (uint16_t)(VOUT_HYSTERESIS * VOUT_FEEDBACK_GAIN / ADC_GRANULARITY)  ///< Protection thresholds hysteresis

#define VOUT_DEV_TRIP        (uint16_t)(VOUT_TOLERANCE_MAX * VOUT_FEEDBACK_GAIN / ADC_GRANULARITY) ///< Macro calculating the integer number equivalent of the maximum allowed output voltage deviation given above in [V], which will lead to a converter shut down when exceeded.
#define VOUT_DEV_RELEASE     (uint16_t)(VOUT_TOLERANCE_MIN * VOUT_FEEDBACK_GAIN / ADC_GRANULARITY) ///< Macro calculating the integer number equivalent of the maximum allowed output voltage deviation given above in [V], which needs to be underrun before a shut-down converter can recover
 
#define VOUT_OVP_TRIP        (uint16_t)(VOUT_OVP_VOLTAGE * VOUT_FEEDBACK_GAIN / ADC_GRANULARITY)  ///< Over Voltage Protection voltage trip threshold
#define VOUT_OVP_RELEASE     (uint16_t)((VOUT_OVP_VOLTAGE - VOUT_HYSTERESIS) * VOUT_FEEDBACK_GAIN / ADC_GRANULARITY)  ///< Over Voltage Protection voltage release threshold
#define VOUT_UVP_TRIP        (uint16_t)((VOUT_UVP_VOLTAGE * VOUT_FEEDBACK_GAIN) / ADC_GRANULARITY)  ///< Output Under Voltage Protection trip voltage threshold (used in battery charging mode only)
#define VOUT_UVP_RELEASE     (uint16_t)((VOUT_UVP_VOLTAGE + VOUT_HYSTERESIS) * VOUT_FEEDBACK_GAIN / ADC_GRANULARITY)  ///< Output Under Voltage Protection release voltage threshold (used in battery charging mode only)

#define VOUT_RANGE_MAX       (float)(VOUT_MAXIMUM - VOUT_MINIMUM) ///< Maximum input voltage range in [V]
#define VOUT_NORM_INV_G      (float)(1.0/VOUT_FEEDBACK_GAIN) ///< Inverted feedback gain required for value normalization
#define VOUT_NORM_SCALER     (int16_t)(ceil(log(VOUT_NORM_INV_G)/log(2))) ///< VOUT normalization  
#define VOUT_NORM_FACTOR     (int16_t)((VOUT_NORM_INV_G / pow(2.0, VOUT_NORM_SCALER)) * (pow(2.0, 15)-1)) ///< VOUT normalization factor scaled in Q15

#define VOUT_ADC_TRGDLY      (uint16_t)(VOUT_ADC_TRG_DELAY / PWM_CLOCK_PERIOD) ///< Macro calculating the integer number equivalent of the signal chain time delay between internal PWM timebase and effective switching edge of the leading FET

#define VOUT_PHYS_CALC_FAC   (uint32_t)((ADC_GRANULARITY / VOUT_FEEDBACK_GAIN) * (float)51200.0)

#define VIN_REG_ERR_EN       (uint16_t)(VOUT_NOMINAL * VIN_FEEDBACK_GAIN / ADC_GRANULARITY)   /// Macro calculating the min input voltage below which the regualato fault is disabled

/** @} */ // end of group output-voltage-feedback-macros ~~~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup phase-current-feedback-macros
 * @{ 
 * @brief Conversion macros of phase current feedback parameters
 * 
 * @details
 * These conversion macros are used to convert user settings defined as physical 
 * quantities into binary (integer) numbers, which will be written to registers and
 * variables and used in calculations throughout the firmware.
 **************************************************************************************************/

// Phase Current Feedback Settings Conversion Macros
#define ISNS_FEEDBACK_GAIN  (float)  (ISNS_RESISTOR*ISNS_GAIN)          ///< Phase current gain in V/A
#define ISNS_OCL_START      (uint16_t)((ISNS_LIMIT_START * ISNS_FEEDBACK_GAIN) / ADC_GRANULARITY)  ///< Output Current Reference
#define ISNS_CMOD_LIMIT     (uint16_t)(ISNS_COMMON_MODE_LIMIT * VOUT_FEEDBACK_GAIN / ADC_GRANULARITY) ///< Common Mode Voltage Limit specifies the minimum output voltage required before the current sense feedback becomes reliable
#define ISNS_CMOD_HYST      (uint16_t)(ISNS_COMMON_MODE_HYST * VOUT_FEEDBACK_GAIN / ADC_GRANULARITY) ///< Common Mode Voltage Hysteresis specifies the minimum output voltage required before the current sense feedback becomes reliable
#define ISNS_BLNC_LIMIT     (int16_t)(ISNS_BALANCING_LIMIT / PWM_CLOCK_PERIOD)     ///< Duty cycle offset limit for current balancing in [PWM ticks]
#define ISNS_BLNC_HYST      (int16_t)(ISNS_BALANCING_HYST / PWM_CLOCK_PERIOD)     ///< Duty cycle offset hysteresis for current balancing in [PWM ticks]

#define ISNS_PHYS_CALC_FAC   (uint32_t)((ADC_GRANULARITY / ISNS_FEEDBACK_GAIN) * (float)512000.0) 

#define ISNS_200W_FEEDBACK_GAIN  (float)  (ISNS_200W_RESISTOR*ISNS_GAIN)          ///< Phase current gain in V/A
#define ISNS_200W_PHYS_CALC_FAC_K   (uint32_t)(4126U) 
#define ISNS_200W_PHYS_CALC_FAC_D   (uint32_t)(1278976U)

#define IPRI_MIN            (int16_t)((IPRI_MINIMUM * ISNS_FEEDBACK_GAIN) / ADC_GRANULARITY)  ///< Lower Runtime Current Limit
#define IPRI_NOM            (int16_t)((IPRI_NOMINAL * ISNS_FEEDBACK_GAIN) / ADC_GRANULARITY)  ///< Current Feedback Baseline
#define IPRI_MAX            (int16_t)((IPRI_MAXIMUM * ISNS_FEEDBACK_GAIN) / ADC_GRANULARITY)  ///< Upper Runtime Current Limit
#define ISNS_START          (int16_t)((ISNS_LIMIT_START * ISNS_FEEDBACK_GAIN) / ADC_GRANULARITY)  ///< Upper Runtime Current Limit
#define ISNS_OCP_TRIP       (int16_t)((ISNS_OCP_TRIP_LEVEL * ISNS_FEEDBACK_GAIN) / ADC_GRANULARITY)  ///< Over Current Limit
#define ISNS_OCP_RELEASE    (int16_t)((ISNS_OCP_RELEASE_LEVEL * ISNS_FEEDBACK_GAIN) / ADC_GRANULARITY)  ///< Over Current Release Level
 
#define SYNCTHLD_ON         (uint16_t)((SYNCCTL_ON_THRESHOLD * ISNS_FEEDBACK_GAIN) / ADC_GRANULARITY) ///< Phase Current above which the synchronous rectifier will be turned on
#define SYNCTHLD_OFF        (uint16_t)((SYNCCTL_OFF_THRESHOLD * ISNS_FEEDBACK_GAIN) / ADC_GRANULARITY) ///< Phase Current below which the synchronous rectifier will be turned off
 
#define ISNS_NORM_INV_G     (float)(1.0/ISNS_FEEDBACK_GAIN) ///< Inverted feedback gain required for value normalization
#define ISNS_NORM_SCALER    (int16_t)(ceil(log(ISNS_NORM_INV_G)/log(2))) ///< ISNS normalization  
#define ISNS_NORM_FACTOR    (int16_t)((ISNS_NORM_INV_G / pow(2.0, ISNS_NORM_SCALER)) * (pow(2.0, 15)-1)) ///< ISNS normalization factor scaled in Q15
 
#if (NO_OF_PHASES > 0) 
#define ISNS1_OFFSET        (uint16_t)(ISNS1_FEEDBACK_OFFSET / ADC_GRANULARITY) ///< Phase current feedback signal offset in [V] converted to integer
#define ISNS1_ADC_TRGDLY    (uint16_t)(ISNS1_ADC_TRG_DELAY / PWM_CLOCK_PERIOD) ///< ADC trigger delay of phase current #1 sense input in [s] converted to integer
#endif



/** @} */ // end of group phase-current-feedback-macros ~~~~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup temperature-feedback-macros
 * @{ 
 * @brief Conversion macros of temperature feedback parameters
 * 
 * @details
 * These conversion macros are used to convert user settings defined as physical 
 * quantities into binary (integer) numbers, which will be written to registers and
 * variables and used in calculations throughout the firmware.
 **************************************************************************************************/

#define TEMP_MIN            (uint16_t)(TEMP_MINIMUM * TEMP_FEEDBACK_GAIN + TEMP_FEEDBACK_OFFSET)  // Temperature Range Minimum
#define TEMP_NOM            (uint16_t)(TEMP_NOMINAL * TEMP_FEEDBACK_GAIN + TEMP_FEEDBACK_OFFSET)  // Temperature Range Zero ? C Point
#define TEMP_MAX            (uint16_t)(TEMP_MAXIMUM * TEMP_FEEDBACK_GAIN + TEMP_FEEDBACK_OFFSET)  // Temperature Range Maximum

#define TEMP_OTP_TRIP       (uint16_t)(TEMP_OTP_ULIMIT * TEMP_FEEDBACK_GAIN + TEMP_FEEDBACK_OFFSET)  // Over Temperature Limit
#define TEMP_OTP_RELEASE    (uint16_t)(TEMP_OTP_LLIMIT * TEMP_FEEDBACK_GAIN + TEMP_FEEDBACK_OFFSET)  // Over Temperature Release Level    

#define TEMP_NORM_INV_G     (float)(1.0/TEMP_FEEDBACK_GAIN) ///< Inverted feedback gain required for value normalization
#define TEMP_NORM_SCALER    (int16_t)(ceil(log(TEMP_NORM_INV_G)/log(2))) ///< ISNS normalization  
#define TEMP_NORM_FACTOR    (int16_t)((TEMP_NORM_INV_G / pow(2.0, TEMP_NORM_SCALER)) * (pow(2.0, 15)-1)) ///< ISNS normalization factor scaled in Q15
#define TEMP_OFFSET         (uint16_t)(TEMP_FEEDBACK_OFFSET / ADC_GRANULARITY) ///< Phase current feedback signal offset in [V] converted to integer
#define TEMP_ADC_TRGDLY     (uint16_t)(TEMP_ADC_TRG_DELAY / PWM_CLOCK_PERIOD) ///< ADC trigger delay of phase current #2 sense input in [s] converted to integer
        
/** @} */ // end of group temperature-feedback-macros ~~~~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup adaptive-control-macros
 * @{ 
 * @brief Conversion macros of phase current feedback parameters
 * 
 * @details
 * These conversion macros are used to convert user settings defined as physical 
 * quantities into binary (integer) numbers, which will be written to registers and
 * variables and used in calculations throughout the firmware.
 **************************************************************************************************/

#define VL_MINIMUM         (float)(VIN_UVLO_VOLTAGE - VOUT_RANGE_MAX) ///< Minimum input voltage - maximum output voltage
#define VL_NOMINAL         (float)(VIN_NOMINAL      - VOUT_NOMINAL) ///< Nominal input voltage - nominal output voltage
#define VL_MAXIMUM         (float)(VIN_RANGE_MAX    - 0) ///< Maximum input voltage - 0

// To calculate the voltage across the inductor, input and output voltage ADC results need to be normalized. The normalization factor is determined here
// Each input voltage sample has to be multiplied with this scaling factor to allow the calculation of the instantaneous voltage across the inductor
#define VIN_NORM_FCT       (float)(VOUT_FEEDBACK_GAIN / VIN_FEEDBACK_GAIN)   ///< VIN-2-VOUT Normalization Factor
#define AGC_IO_NORM_SCALER (int16_t)(ceil(log(VIN_NORM_FCT)/log(2))) ///< Nominal VL Q15 scaler  
#define AGC_IO_NORM_FACTOR (int16_t)((VIN_NORM_FCT / pow(2.0, AGC_IO_NORM_SCALER)) * (pow(2.0, 15)-1)) ///< Nominal VL Q15 factor 

// The AGC compare value is defined at nominal input voltage and output voltage 
// The maximum modulation factor is normalized to fractional '1' to prevent number overruns
#define AGC_FACTOR_MAX     (float)(VL_NOMINAL / VL_MINIMUM) ///< Floating point number of the maximum limit of the adaptive gain modulation factor (float)
#define AGC_NOM_SCALER     (uint16_t)(ceil(log(AGC_FACTOR_MAX)/log(2))) ///< Bit-shift scaler of the floating point number of the maximum limit of the adaptive gain modulation factor
#define AGC_NOM_FACTOR     (uint16_t)(0x7FFF >> AGC_NOM_SCALER) ///< Fractional of the floating point number of the maximum limit of the adaptive gain modulation factor
#define AGC_MEDIAN         (int16_t)(((int16_t)(((float)VIN_NOM * VIN_NORM_FCT) - VOUT_NOM))>>AGC_NOM_SCALER) ///< Adaptive gain modulation factor at nominal operating point

// Additional execution time calculation to be considered in trigger delay and overall control timing
#define AGC_EXEC_DLY       (uint16_t)(AGC_EXECUTION_DELAY / PWM_CLOCK_PERIOD) ///< Macro calculating the integer number equivalent of the AGC algorithm computation time

/** @} */ // end of group adaptive-control-macros ~~~~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup startup-timing-macros
 * @{ 
 * @brief Conversion Macros of Startup Timing Settings
 * 
 * @details
 * These conversion macros are used to convert user settings defined as physical 
 * quantities into binary (integer) numbers, which will be written to registers and
 * variables and used in calculations throughout the firmware.
 **************************************************************************************************/

#define START_POD          (uint16_t)(((float)    POWER_ON_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0)
#define START_CUD          (uint16_t)(((float)   CHARGE_UP_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0)
#define START_CUD_TO       (uint16_t)(((float) CHARGE_UP_TIMEOUT / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0)
#define START_LVRAMP_PER   (uint16_t)(((float)     LVRAMP_PERIOD / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0)
#define START_HVRAMP_PER   (uint16_t)(((float)     HVRAMP_PERIOD / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0)
#define START_LVREF_STEP   (uint16_t)( (float)           VOUT_NOM / (float)(START_LVRAMP_PER + 1.0))
#define START_HVREF_STEP   (uint16_t)( (float)           VIN_NOM / (float)(START_HVRAMP_PER + 1.0))
#define START_IRAMP_PER    (uint16_t)(((float)      IRAMP_PERIOD / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0)
#define START_IREF_STEP    (uint16_t)( (float)(IPRI_MAX-ISNS_START) / (float)(START_IRAMP_PER + 1.0))
#define START_PGD          (uint16_t)(((float)  POWER_GOOD_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0)


/** @} */ // end of group startup-timing-macros ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

/**************************************************************************************************
 * @ingroup inrush-settings-macros
 * @{ 
 * @brief Conversion Macros of Startup Timing Settings
 * 
 * @details
 * These conversion macros are used to convert user settings defined as physical 
 * quantities into binary (integer) numbers, which will be written to registers and
 * variables and used in calculations throughout the firmware.
 **************************************************************************************************/

 #define ENABLE_DCDC_INRUSH     (uint16_t)(((float)  EN_DCDC_INRUSH_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0)
 #define INRUSH_VIN_THRESHOLD   (uint16_t)(INRUSH_DELTAV_THRESHOLD* VIN_FEEDBACK_GAIN / ADC_GRANULARITY)

 /** @} */ // end of group inrush-settings-macros ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        
/**************************************************************************************************
 * @ingroup fault-response-macros
 * @{ 
 * @brief Conversion Macros of Fault Response Timing Settings
 * 
 * @details
 * These conversion macros are used to convert user settings defined as physical 
 * quantities into binary (integer) numbers, which will be written to registers and
 * variables and used in calculations throughout the firmware.
 **************************************************************************************************/

#define UVLO_TDLY   (uint16_t)(((float)      UVLO_TRIP_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0) ///< under voltage lock out trip delay conversion macro
#define UVLO_RDLY   (uint16_t)(((float)  UVLO_RECOVERY_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0) ///< under voltage lock out recovery delay conversion macro
#define OVLO_TDLY   (uint16_t)(((float)      OVLO_TRIP_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0) ///< over voltage lock out trip delay conversion macro
#define OVLO_RDLY   (uint16_t)(((float)  OVLO_RECOVERY_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0) ///< over voltage lock out recovery delay conversion macro
#define REGERR_TDLY (uint16_t)(((float)    REGERR_TRIP_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0) ///< regulation error trip delay conversion macro
#define REGERR_RDLY (uint16_t)(((float)REGERR_RECOVERY_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0) ///< regulation error recovery delay conversion macro
#define OCP_TDLY    (uint16_t)(((float)       OCP_TRIP_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0) ///< over current protection trip Delay conversion macro
#define OCP_RDLY    (uint16_t)(((float)   OCP_RECOVERY_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0) ///< over current protection recovery delay conversion macro
#define OVP_TDLY    (uint16_t)(((float)       OVP_TRIP_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0) ///< over voltage protection trip Delay conversion macro
#define OVP_RDLY    (uint16_t)(((float)   OVP_RECOVERY_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0) ///< over voltage protection recovery delay conversion macro
#define OTP_TDLY    (uint16_t)(((float)       OTP_TRIP_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0) ///< over temperature protection trip Delay conversion macro
#define OTP_RDLY    (uint16_t)(((float)   OTP_RECOVERY_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0) ///< over temperature protection recovery delay conversion macro
#define UVP_TDLY    (uint16_t)(((float)       UVP_TRIP_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0) ///< under voltage protection trip Delay conversion macro
#define UVP_RDLY    (uint16_t)(((float)   UVP_RECOVERY_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0) ///< under voltage protection recovery delay conversion macro

#define FLTRSTDLY   (uint16_t)(((float)  FAULT_RESTART_DELAY / (float)RTOS_6G2_EXECUTION_PERIOD)-1.0) ///< under voltage protection recovery delay conversion macro

/** @} */ // end of group fault-response-macros ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    

/**************************************************************************************************
 * @ingroup current_balancing-macros
 * @{
 * @brief Parameters to adjust the current balancing controller
 * 
 * @details
 * 
 * 
 *************************************************************************************************/

#define MAX_DUTY_OFFSET     (int16_t)(MAX_DUTY_OFFSET_SEC / (float)PWM_CLOCK_PERIOD)
#define MIN_DUTY_OFFSET     (int16_t)(MIN_DUTY_OFFSET_SEC / (float)PWM_CLOCK_PERIOD)
#define BALANCING_HYST      (int16_t)(BALANCING_HYSTERESIS*ISNS_FEEDBACK_GAIN/ADC_GRANULARITY)


/** @} */ // end of group current_balancing-macros ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


#endif	

// ________________________
// end if file
