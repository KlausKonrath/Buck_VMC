/* 
 * File:   p33c_plib_uart_typedef.h
 * Author: M91406
 *
 * Created on February 28, 2024, 5:02 PM
 */

#ifndef P33C_PLIB_UART_TYPEDEF_H
#define	P33C_PLIB_UART_TYPEDEF_H


/**********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @struct  PLIB33C_UART_NUMBER_t
 * @brief   This data structure is the list of the Uart instances
 * @extends PLIB_UART_OBJECT_t
 *********************************************************************************/
enum PLIB33C_UART_NUMBER_e {
	UART_NONE  = 0,
    UART_NUM_1 = 1,
	UART_NUM_2 = 2,
	UART_NUM_3 = 3,
	UART_NUM_4 = 4,
	UART_NUM_5 = 5,
	UART_NUM_6 = 6,
	UART_NUM_7 = 7,
	UART_NUM_8 = 8
};
typedef enum PLIB33C_UART_NUMBER_e PLIB33C_UART_NUMBER_t;

/**********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @struct  PLIB33C_UART_DATA_BITS_t
 * @brief   This data structure is the list of the Uart data bits
 * @extends PLIB_UART_OBJECT_t
 *********************************************************************************/
enum PLIB33C_UART_DATA_BITS_e {
    UART_DATABITS_7 = 7,    ///< Asynchronous 7-bit UART
    UART_DATABITS_8 = 8    ///< Asynchronous 8-bit UART
}; ///< UART data bit length
typedef enum PLIB33C_UART_DATA_BITS_e PLIB33C_UART_DATA_BITS_t; ///< UART data bit length data type

/**********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @struct  PLIB33C_UART_PARITY_t
 * @brief   This data structure is the list of the Uart parity
 * @extends PLIB_UART_OBJECT_t
 *********************************************************************************/
enum PLIB33C_UART_PARITY_e {
    UART_PARITY_NONE = 0,   ///< No data parity mode
    UART_PARITY_ODD  = 1,   ///< Odd data parity mode
    UART_PARITY_EVEN = 2    ///< Even data parity mode
}; ///< UART data parity mode
typedef enum PLIB33C_UART_PARITY_e PLIB33C_UART_PARITY_t; ///< UART data parity mode data type

/**********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @struct  PLIB33C_UART_STOP_BITS_t
 * @brief   This data structure is the list of the Uart stop bits
 * @extends PLIB_UART_OBJECT_t
 *********************************************************************************/
enum PLIB33C_UART_STOP_BITS_e {
    UART_STOPBITS_1  = 1,   ///< Single stop bit mode
    UART_STOPBITS_15 = 2,   ///< 1 1/2 stop bit mode
    UART_STOPBITS_2  = 3    ///< Dual stop bit mode
}; ///< UART number of stop bits
typedef enum PLIB33C_UART_STOP_BITS_e PLIB33C_UART_STOP_BITS_t; ///< UART number of stop bits data type

/**********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @struct  PLIB33C_UART_FLOWCONTROL_t
 * @brief   This data structure is the list of the Uart flow control
 * @extends PLIB_UART_OBJECT_t
 *********************************************************************************/
enum PLIB33C_UART_FLOWCONTROL_e {
    UART_FLOWCONTROL_NONE     = 0,  ///< No Flow control mechanism is used
    UART_FLOWCONTROL_HARDWARE = 1,  ///< Flow control mode using RTS/CTS
    UART_FLOWCONTROL_XON_XOFF = 2   ///< FLow control mode using XOn/XOff
}; ///< UART flow control selection
typedef enum PLIB33C_UART_FLOWCONTROL_e PLIB33C_UART_FLOWCONTROL_t; ///< UART flow control selection data type

/**********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @struct  PLIB33C_UART_BAUDRATE_t
 * @brief   This data structure is the list of the Uart baud rates
 * @extends PLIB_UART_OBJECT_t
 *********************************************************************************/
enum PLIB33C_UART_BAUDRATE_e {
    UART_BAUDRATE_75     = 75,      ///< Baud rate = 75 of signal units per second
    UART_BAUDRATE_150    = 150,     ///< Baud rate = 150 of signal units per second
    UART_BAUDRATE_300    = 300,     ///< Baud rate = 300 of signal units per second
    UART_BAUDRATE_600    = 600,     ///< Baud rate = 600 of signal units per second
    UART_BAUDRATE_1200   = 1200,    ///< Baud rate = 1200 of signal units per second
    UART_BAUDRATE_2400   = 2400,    ///< Baud rate = 2400 of signal units per second
    UART_BAUDRATE_4800   = 4800,    ///< Baud rate = 4800 of signal units per second
    UART_BAUDRATE_7200   = 7200,    ///< Baud rate = 7200 of signal units per second
    UART_BAUDRATE_9600   = 9600,    ///< Baud rate = 9800 of signal units per second
    UART_BAUDRATE_14400  = 14400,   ///< Baud rate = 14400 of signal units per second
    UART_BAUDRATE_19200  = 19200,   ///< Baud rate = 19200 of signal units per second
    UART_BAUDRATE_38400  = 38400,   ///< Baud rate = 38400 of signal units per second
    UART_BAUDRATE_56000  = 56000,   ///< Baud rate = 56000 of signal units per second
    UART_BAUDRATE_57600  = 57600,   ///< Baud rate = 57600 of signal units per second
    UART_BAUDRATE_115200 = 115200,  ///< Baud rate = 115200 of signal units per second
    UART_BAUDRATE_128000 = 128000,  ///< Baud rate = 128000 of signal units per second
    UART_BAUDRATE_230400 = 230400,  ///< Baud rate = 230400 of signal units per second
    UART_BAUDRATE_256000 = 256000,  ///< Baud rate = 256000 of signal units per second
    UART_BAUDRATE_460800 = 460800,  ///< Baud rate = 460800 of signal units per second
    UART_BAUDRATE_921600 = 921600   ///< Baud rate = 921600 of signal units per second
}; ///< UART baud rate selection
typedef enum PLIB33C_UART_BAUDRATE_e PLIB33C_UART_BAUDRATE_t; ///< UART baud rate selection data type

/**********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @struct  PLIB33C_UART_INSTANCE_STATUS_t
 * @brief   This data structure holds the uart instance status
 * @extends PLIB_UART_OBJECT_t
 *********************************************************************************/
struct PLIB33C_UART_STATUS_s {
    
    unsigned Ready : 1;    ///< Bit 0: (READ ONLY) READY bit indicating that interface has been configured
    unsigned Busy  : 1;    ///< Bit 1: (READ ONLY) BUSY bit indicating that interface is occupied by internal procedure
    unsigned PortOpen : 1; ///< Bit 2: (READ ONLY) PORT_OPEN bit indicating if UART port is open or closed
    unsigned : 1;   ///< Bit 3:  (reserved)
    unsigned : 1;   ///< Bit 4:  (reserved)
    unsigned : 1;   ///< Bit 5:  (reserved)
    unsigned : 1;   ///< Bit 6:  (reserved)
    unsigned : 1;   ///< Bit 7:  (reserved)

    unsigned : 1;   ///< Bit 8:  (reserved)
    unsigned : 1;   ///< Bit 9:  (reserved)
    unsigned : 1;   ///< Bit 10: (reserved)
    unsigned ByteSwap: 1;       ///< Bit 11: Control bit enabling/disabling option to swap order of bytes of word and doubleword values
    unsigned StdioRedirect: 1;  ///< Bit 12: Control bit enabling/disabling option to redirect printf to Uart
    unsigned RxDmaEnable: 1;    ///< Bit 13: Control bit enabling/disabling DMA support for the receive channel (UART must be re-initialized after change)
    unsigned TxDmaEnable: 1;    ///< Bit 14: Control bit enabling/disabling DMA support for the transmit channel (UART must be re-initialized after change)
    unsigned : 1;   ///< Bit 15: (reserved)
    
};
typedef struct PLIB33C_UART_STATUS_s PLIB33C_UART_STATUS_t;

/**********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @struct  PLIB33C_UART_INTERFACE_CHANNEL_t
 * @brief   This data structure holds the uart interface channel available
 * @extends PLIB_UART_OBJECT_t
 *********************************************************************************/
struct PLIB33C_UART_INTERFACE_CHANNEL_s {
    uint16_t DmaInstance;     ///< DMA instance of interface
    const P33C_GPIO_t* Io;    ///< GPIO configuration 
};
typedef struct PLIB33C_UART_INTERFACE_CHANNEL_s PLIB33C_UART_INTERFACE_CHANNEL_t;

/**********************************************************************************
 * @ingroup p33c-plib-uart-properties-private
 * @struct  PLIB33C_UART_INTERFACE_t
 * @brief   This data structure provides the Uart interface data object
 * @extends PLIB_UART_OBJECT_t
 *********************************************************************************/
struct PLIB33C_UART_INTERFACE_s {
    
    PLIB33C_UART_INTERFACE_CHANNEL_t RxD;   ///< UART Receive Channel Configuration
    PLIB33C_UART_INTERFACE_CHANNEL_t TxD;   ///< UART Receive Channel Configuration
    PLIB33C_UART_NUMBER_t UartInstance; ///< UART instance of interface (e.g. 1 for UART #1, 2 for UART #2, etc.)
    
}; ///< UART interface data object
typedef struct PLIB33C_UART_INTERFACE_s PLIB33C_UART_INTERFACE_t;   ///< UART interface data object

struct PLIB33C_UART_SETTINGS_s {
	PLIB33C_UART_BAUDRATE_t     Baudrate;       ///< User Uart Baud Rate
    PLIB33C_UART_DATA_BITS_t    DataBits;       ///< User Uart Data Bits
	PLIB33C_UART_PARITY_t	 	Parity;         ///< User Uart Parity
    PLIB33C_UART_STOP_BITS_t    StopBits;       ///< User Uart Stop Bits
    PLIB33C_UART_FLOWCONTROL_t  FlowControl;    ///< User Uart Flow Control
}; ///< UART settings data object
typedef struct PLIB33C_UART_SETTINGS_s PLIB33C_UART_SETTINGS_t;   ///< UART settings data object

/**********************************************************************************
 * @ingroup p33c-plib-uart-properties
 * @struct PLIB_UART_OBJECT_s
 * @brief This data structure is a collection of parameters that the user can configure. This data object can be initialize as follows.
 * @code {.c}
	PLIB_UART_OBJECT_t uartConfig = {
                .Baudrate = UART_BAUDRATE_115200,
                .DataBits = UART_DATABITS_8,
                .Parity = UART_PARITY_NONE,
                .StopBits = UART_STOPBITS_1,
                .FlowControl = UART_FLOWCONTROL_NONE,
                .CommPort.uart = UART_NUM_2,
                .CommPort.TxD.Io.Port = 2,
                .CommPort.TxD.Io.Pin = 12,
                .CommPort.TxD.Io.RPid = 60,
                .CommPort.RxD.Io.Port = 2,
                .CommPort.RxD.Io.Pin = 13,
                .CommPort.RxD.Io.RPid = 61,
                .CommPort.status.TxDmaEnable = true,
                .CommPort.TxD.TxDma = 1,
                .StdioRedirect = true
            };
			
	@endcode
 *********************************************************************************/
struct UART_s {
    PLIB33C_UART_STATUS_t       Status;     ///< Status word of the UART object
    PLIB33C_UART_SETTINGS_t     Settings;   ///< User UART interface settings
    PLIB33C_UART_INTERFACE_t    CommPort;   ///< User Uart and DMA Communication Ports
}; // Generic UART object 
typedef struct UART_s UART_t; ///< Generic UART object data type



#endif	/* P33C_PLIB_UART_TYPEDEF_H */

