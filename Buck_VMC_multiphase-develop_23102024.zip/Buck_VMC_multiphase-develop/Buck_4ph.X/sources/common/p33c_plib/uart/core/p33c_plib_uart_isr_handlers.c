/*
    (c) 2023 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

#include <xc.h> // include processor files - each processor file is guarded.  
#include "../IUartHandler.h"


extern PLIB33C_DATA_STATUS_t plib33cDataStatus[];

extern uint16_t plib33c_Uart_RingBufferSet(uint16_t uartInstanceIndex, PLIB33C_UART_RINGBUFFER_t* const ringbuf, uint8_t data); 
extern bool plib33c_Uart_RingBufferGet(uint16_t uartInstance, PLIB33C_UART_RINGBUFFER_t* const ringbuf, uint8_t* bytePointer); 

#if defined (U1MODE)
int __attribute__((weak)) plib33c_Uart_U1RxInterruptHandler(void){
    return(1);
}
#endif
#if defined (U2MODE)
int __attribute__((weak)) plib33c_Uart_U2RxInterruptHandler(void){
    return(1);
}
#endif
#if defined (U3MODE)
int __attribute__((weak)) plib33c_Uart_U3RxInterruptHandler(void){ return(1); }
#endif
#if defined (U4MODE)
int __attribute__((weak)) plib33c_Uart_U4RxInterruptHandler(void){ return(1); }
#endif
#if defined (U5MODE)
int __attribute__((weak)) plib33c_Uart_U5RxInterruptHandler(void){ return(1); }
#endif
#if defined (U6MODE)
int __attribute__((weak)) plib33c_Uart_U6RxInterruptHandler(void){ return(1); }
#endif
#if defined (U7MODE)
int __attribute__((weak)) plib33c_Uart_U7RxInterruptHandler(void){ return(1); }
#endif
#if defined (U8MODE)
int __attribute__((weak)) plib33c_Uart_U8RxInterruptHandler(void){ return(1); }
#endif

#if defined (U1MODE)
/**********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Asynchronous UART Receive event used to parse incoming data 
 * 
 * @details
 * This interrupt is used to read each incoming byte while building up the 
 * contents of rx buffer.
 * ********************************************************************************/
void __attribute__((__interrupt__, weak, no_auto_psv)) _U1RXInterrupt(void)
{
    P33C_UART_INSTANCE_t* uart; 

    uart = p33c_UartInstance_GetHandle(1);
 
    // Reset the interrupt flag bit
    _U1RXIF = false;
    
    plib33cDataStatus[0].bits.rxByteReceived = 1;
    // read byte from buffer parsing for frames
    while (false == uart->UxSTAH.bits.URXBE) 
    { 
        plib33c_Uart_RingBufferSet(1, &plib33cReceiveRingBuffer[0], uart->UxRXREG.value);
    }
    
    plib33c_Uart_U1RxInterruptHandler();
    
    return;
}
#endif

#if defined (U2MODE)
/**********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Asynchronous UART Receive event used to parse incoming data 
 * 
 * @details
 * This interrupt is used to read each incoming byte while building up the 
 * contents of rx buffer.
 * ********************************************************************************/
void __attribute__((__interrupt__, weak, no_auto_psv)) _U2RXInterrupt(void)
{
    P33C_UART_INSTANCE_t* uart; 
        
    uart = p33c_UartInstance_GetHandle(2);
 
    // Reset the interrupt flag bit
    _U2RXIF = false;
    
    plib33cDataStatus[1].bits.rxByteReceived = 1;
    // read byte from buffer parsing for frames
    while (!(uart->UxSTAH.bits.URXBE)) 
    { 
        plib33c_Uart_RingBufferSet(2, &plib33cReceiveRingBuffer[1], uart->UxRXREG.value);
    }
    
    plib33c_Uart_U2RxInterruptHandler();
    return;
}

#endif

#if defined (U3MODE)
/**********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Asynchronous UART Receive event used to parse incoming data 
 * 
 * @details
 * This interrupt is used to read each incoming byte while building up the 
 * contents of rx buffer.
 * ********************************************************************************/
void __attribute__((__interrupt__, weak, no_auto_psv)) _U3RXInterrupt(void)
{
    P33C_UART_INSTANCE_t* uart; 
    
    uart = p33c_UartInstance_GetHandle(3);
 
    // Reset the interrupt flag bit
    _U3RXIF = false;
    
    plib33cDataStatus[2].bits.rxByteReceived = 1;
    // read byte from buffer parsing for frames
    while (!(uart->UxSTAH.bits.URXBE)) 
    { 
        plib33c_Uart_RingBufferSet(3, &plib33cReceiveRingBuffer[2], uart->UxRXREG.value);
    }
    
    plib33c_Uart_U3RxInterruptHandler();
    
    return;
}
#endif

#if defined (U4MODE)
/**********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Asynchronous UART Receive event used to parse incoming data 
 * 
 * @details
 * This interrupt is used to read each incoming byte while building up the 
 * contents of rx buffer.
 * ********************************************************************************/
void __attribute__((__interrupt__, weak, no_auto_psv)) _U4RXInterrupt(void)
{
    P33C_UART_INSTANCE_t* uart; 
    
    uart = p33c_UartInstance_GetHandle(4);
 
    // Reset the interrupt flag bit
    _U4RXIF = false;
    
    plib33cDataStatus[3].bits.rxByteReceived = 1;
    // read byte from buffer parsing for frames
    while (!(uart->UxSTAH.bits.URXBE)) 
    { 
        plib33c_Uart_RingBufferSet(4, &plib33cReceiveRingBuffer[3], uart->UxRXREG.value);
    }
    plib33c_Uart_U4RxInterruptHandler();
    
    return;
}
#endif

#if defined (U5MODE)
/**********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Asynchronous UART Receive event used to parse incoming data 
 * 
 * @details
 * This interrupt is used to read each incoming byte while building up the 
 * contents of rx buffer.
 * ********************************************************************************/
void __attribute__((__interrupt__, weak, no_auto_psv)) _U5RXInterrupt(void)
{
    P33C_UART_INSTANCE_t* uart; 
    
    uart = p33c_UartInstance_GetHandle(5);
 
    // Reset the interrupt flag bit
    _U5RXIF = false;
    
    plib33cDataStatus[4].bits.rxByteReceived = 1;
    // read byte from buffer parsing for frames
    while (!(uart->UxSTAH.bits.URXBE)) 
    { 
        plib33c_Uart_RingBufferSet(5, &plib33cReceiveRingBuffer[4], uart->UxRXREG.value);
    }
    plib33c_Uart_U5RxInterruptHandler();
    
    return;
}
#endif

#if defined (U6MODE)
/**********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Asynchronous UART Receive event used to parse incoming data 
 * 
 * @details
 * This interrupt is used to read each incoming byte while building up the 
 * contents of rx buffer.
 * ********************************************************************************/
void __attribute__((__interrupt__, weak, no_auto_psv)) _U6RXInterrupt(void)
{
    P33C_UART_INSTANCE_t* uart; 
    
    uart = p33c_UartInstance_GetHandle(6);
 
    // Reset the interrupt flag bit
    _U6RXIF = false;
    
    plib33cDataStatus[5].bits.rxByteReceived = 1;
    // read byte from buffer parsing for frames
    while (!(uart->UxSTAH.bits.URXBE)) 
    { 
        plib33c_Uart_RingBufferSet(6, &plib33cReceiveRingBuffer[5], uart->UxRXREG.value);
    }

    plib33c_Uart_U6RxInterruptHandler();
    
    return;
}
#endif

#if defined (U7MODE)
/**********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Asynchronous UART Receive event used to parse incoming data 
 * 
 * @details
 * This interrupt is used to read each incoming byte while building up the 
 * contents of rx buffer.
 * ********************************************************************************/
void __attribute__((__interrupt__, weak, no_auto_psv)) _U7RXInterrupt(void)
{
    P33C_UART_INSTANCE_t* uart; 
    
    uart = p33c_UartInstance_GetHandle(7);
 
    // Reset the interrupt flag bit
    _U7RXIF = false;
    
    plib33cDataStatus[6].bits.rxByteReceived = 1;
    // read byte from buffer parsing for frames
    while (!(uart->UxSTAH.bits.URXBE)) 
    { 
        plib33c_Uart_RingBufferSet(7, &plib33cReceiveRingBuffer[6], uart->UxRXREG.value);
    }
    plib33c_Uart_U7RxInterruptHandler();
    return;
}
#endif

#if defined (U8MODE)
/**********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief   Asynchronous UART Receive event used to parse incoming data 
 * 
 * @details
 * This interrupt is used to read each incoming byte while building up the 
 * contents of rx buffer.
 * ********************************************************************************/
void __attribute__((__interrupt__, weak, no_auto_psv)) _U8RXInterrupt(void)
{
    P33C_UART_INSTANCE_t* uart; 
    
    uart = p33c_UartInstance_GetHandle(8);
 
    // Reset the interrupt flag bit
    _U8RXIF = false;
    
    plib33cDataStatus[7].bits.rxByteReceived = 1;
    // read byte from buffer parsing for frames
    while (!(uart->UxSTAH.bits.URXBE)) 
    { 
        plib33c_Uart_RingBufferSet(8, &plib33cReceiveRingBuffer[7], uart->UxRXREG.value);
    }
    plib33c_Uart_U8RxInterruptHandler();
    return;
}
#endif


#if defined (U1MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U1TXInterrupt(void) 
{ _U1TXIF = 0; };
#endif
#if defined (U2MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U2TXInterrupt(void) 
{ _U2TXIF = 0; };
#endif
#if defined (U3MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U3TXInterrupt(void) 
{ _U3TXIF = 0; };
#endif
#if defined (U4MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U4TXInterrupt(void) 
{ _U4TXIF = 0; };
#endif
#if defined (U5MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U5TXInterrupt(void) 
{ _U5TXIF = 0; };
#endif
#if defined (U6MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U6TXInterrupt(void) 
{ _U6TXIF = 0; };
#endif
#if defined (U7MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U7TXInterrupt(void) 
{ _U7TXIF = 0; };
#endif
#if defined (U8MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U8TXInterrupt(void) 
{ _U8TXIF = 0; };
#endif
/**********************************************************************************/
#if defined (DMACH0)
void __attribute__((__interrupt__, weak, no_auto_psv)) _DMA0Interrupt(void)
{    _DMA0IF = false; }
#endif
#if defined (DMACH1)
void __attribute__((__interrupt__, weak, no_auto_psv)) _DMA1Interrupt(void)
{    _DMA1IF = false; }
#endif
#if defined (DMACH2)
void __attribute__((__interrupt__, weak, no_auto_psv)) _DMA2Interrupt(void)
{    _DMA2IF = false; }
#endif
#if defined (DMACH3)
void __attribute__((__interrupt__, weak, no_auto_psv)) _DMA3Interrupt(void)
{    _DMA3IF = false; }
#endif
#if defined (DMACH4)
void __attribute__((__interrupt__, weak, no_auto_psv)) _DMA4Interrupt(void)
{    _DMA4IF = false; }
#endif
#if defined (DMACH5)
void __attribute__((__interrupt__, weak, no_auto_psv)) _DMA5Interrupt(void)
{    _DMA5IF = false; }
#endif
#if defined (DMACH6)
void __attribute__((__interrupt__, weak, no_auto_psv)) _DMA6Interrupt(void)
{    _DMA6IF = false; }
#endif
#if defined (DMACH7)
void __attribute__((__interrupt__, weak, no_auto_psv)) _DMA7Interrupt(void)
{    _DMA7IF = false; }
#endif

#if defined (U1MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U1EInterrupt(void)
{
    Nop();
    _U1EIF=0;
}
#endif
#if defined (U2MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U2EInterrupt(void)
{
    Nop();
    _U2EIF=0;
}
#endif
#if defined (U3MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U3EInterrupt(void)
{
    Nop();
    _U3EIF=0;
}
#endif
#if defined (U4MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U4EInterrupt(void)
{
    Nop();
    _U4EIF=0;
}
#endif
#if defined (U5MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U5EInterrupt(void)
{
    Nop();
    _U5EIF=0;
}
#endif
#if defined (U6MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U6EInterrupt(void)
{
    Nop();
    _U6EIF=0;
}
#endif
#if defined (U7MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U7EInterrupt(void)
{
    Nop();
    _U7EIF=0;
}
#endif
#if defined (U8MODE)
void __attribute__((__interrupt__, weak, no_auto_psv)) _U8EInterrupt(void)
{
    Nop();
    _U8EIF=0;
}
#endif

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief  Enable Uart interrupt
 * @param  interfaceCommPort    Pointer to UART interface object of type PLIB33C_UART_INTERFACE_t
 * @return 0 = failure, Transmit pin enable was not successful
 * @return 1 = success, Transmit pin enable was successful
 * 
 * @details This function enable the interrupt of the configured Uart 
* 
 *********************************************************************************/
int plib33c_Uart_InterruptEnable(UART_t* uartConfig) 
{
	int retval = 1;

#if defined(U1MODE)
    if(uartConfig->CommPort.UartInstance == 1)
    {
        _U1EIP = 4;
        _U1EIF = 0;
        _U1EIE = true;
        _U1RXIP = 4;
        _U1RXIF = 0;
        _U1RXIE = true;
    }
    if(uartConfig->Status.TxDmaEnable)
    {
        _U1TXIP = 2;
        _U1TXIF = 0;
        _U1TXIE = true;
    }
#endif
    
#if defined(U2MODE) 
    if(uartConfig->CommPort.UartInstance == 2)
    {
        _U2EIP = 4;
        _U2EIF = 0;
        _U2EIE = true;
        _U2RXIP = 4;
        _U2RXIF = 0;
        _U2RXIE = true;
    }
    if(uartConfig->Status.TxDmaEnable)
    {
        _U2TXIP = 2;
        _U2TXIF = 0;
        _U2TXIE = true;
    }
#endif

#if defined(U3MODE)   
    if(uartConfig->CommPort.UartInstance == 3)
    {
        _U3EIP = 4;
        _U3EIF = 0;
        _U3EIE = true;
        _U3RXIP = 4;
        _U3RXIF = 0;
        _U3RXIE = true;
    }
    if(uartConfig->Status.TxDmaEnable)
    {
        _U3TXIP = 2;
        _U3TXIF = 0;
        _U3TXIE = true;
    }
#endif
    
#if defined(U4MODE)
    if(uartConfig->CommPort.UartInstance == 4)
    {
        _U4EIP = 4;
        _U4EIF = 0;
        _U4EIE = true;
        _U4RXIP = 4;
        _U4RXIF = 0;
        _U4RXIE = true;
    }
    if(uartConfig->Status.TxDmaEnable)
    {
        _U4TXIP = 2;
        _U4TXIF = 0;
        _U4TXIE = true;
    }
#endif
    
#if defined(U5MODE)  
    if(uartConfig->CommPort.UartInstance == 5)
    {
        _U5EIP = 4;
        _U5EIF = 0;
        _U5EIE = true;
        _U5RXIP = 4;
        _U5RXIF = 0;
        _U5RXIE = true;
    }
    if(uartConfig->Status.TxDmaEnable)
    {
        _U5TXIP = 2;
        _U5TXIF = 0;
        _U5TXIE = true;
    }
#endif

#if defined(U6MODE)   
    if(uartConfig->CommPort.UartInstance == 6)
    {
        _U6EIP = 4;
        _U6EIF = 0;
        _U6EIE = true;
        _U6RXIP = 4;
        _U6RXIF = 0;
        _U6RXIE = true;
    }
    if(uartConfig->Status.TxDmaEnable)
    {
        _U6TXIP = 2;
        _U6TXIF = 0;
        _U6TXIE = true;
    }
#endif    

#if defined(U7MODE)  
    if(uartConfig->CommPort.UartInstance == 7)
    {
        _U7EIP = 4;
        _U7EIF = 0;
        _U7EIE = true;
        _U7RXIP = 4;
        _U7RXIF = 0;
        _U7RXIE = true;
    }
    if(uartConfig->Status.TxDmaEnable)
    {
        _U7TXIP = 2;
        _U7TXIF = 0;
        _U7TXIE = true;
    }
#endif

#if defined(U8MODE)
    if(uartConfig->CommPort.UartInstance == 8)
    {
        _U8EIP = 4;
        _U8EIF = 0;
        _U8EIE = true;
        _U8RXIP = 4;
        _U8RXIF = 0;
        _U8RXIE = true;
    }
    if(uartConfig->Status.TxDmaEnable)
    {
        _U8TXIP = 2;
        _U8TXIF = 0;
        _U8TXIE = true;
    }
#endif  
    
    return(retval);
}


/*********************************************************************************
 * @ingroup p33c-plib-uart-methods-private
 * @brief  Enable DMA interrupt
 * @param  interfaceCommPort      Pointer to UART interface object of type PLIB33C_UART_INTERFACE_t
 * @return 0 = failure, Transmit pin enable was not successful
 * @return 1 = success, Transmit pin enable was successful
 * 
 * @details This function enable the interrupt of the configured DMA  
 *********************************************************************************/
int plib33c_DMA_InterruptEnable(UART_t* uartConfig) 
{
	int retval = 1;

#if defined(DMACH0)
    if((uartConfig->CommPort.TxD.DmaInstance == 0 && uartConfig->Status.TxDmaEnable)){
    _DMA0IP = 4;
    _DMA0IE = true;
    _DMA0IF = 0;
    }
#endif
    
#if defined(DMACH1)  
    if((uartConfig->CommPort.TxD.DmaInstance == 1 && uartConfig->Status.TxDmaEnable)){
    _DMA1IP = 4;
    _DMA1IE = true;
    _DMA1IF = 0;
    }
#endif

#if defined(DMACH2)    
    if((uartConfig->CommPort.TxD.DmaInstance == 2 && uartConfig->Status.TxDmaEnable)){
    _DMA2IP = 4;
    _DMA2IE = true;
    _DMA2IF = 0;
    }
#endif
    
#if defined(DMACH3)
    if((uartConfig->CommPort.TxD.DmaInstance == 3 && uartConfig->Status.TxDmaEnable)){
    _DMA3IP = 4;
    _DMA3IE = true;
    _DMA3IF = 0;
    }
#endif
    
#if defined(DMACH4)    
    if((uartConfig->CommPort.TxD.DmaInstance == 4 && uartConfig->Status.TxDmaEnable)){
    _DMA4IP = 4;
    _DMA4IE = true;
    _DMA4IF = 0;
    }
#endif

#if defined(DMACH5)    
    if((uartConfig->CommPort.TxD.DmaInstance == 5 && uartConfig->Status.TxDmaEnable)){
    _DMA5IP = 4;
    _DMA5IE = true;
    _DMA5IF = 0;
    }
#endif    

#if defined(DMACH6)    
    if((uartConfig->CommPort.TxD.DmaInstance == 6 && uartConfig->Status.TxDmaEnable)){
    _DMA6IP = 4;
    _DMA6IE = true;
    _DMA6IF = 0;
    }
#endif

#if defined(DMACH7)    
    if((uartConfig->CommPort.TxD.DmaInstance == 7 && uartConfig->Status.TxDmaEnable)){
    _DMA7IP = 4;
    _DMA7IE = true;
    _DMA7IF = 0;
    }
#endif  
    
    return(retval);
}

// _______________________
// end of file
