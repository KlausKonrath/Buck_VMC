

#include "IUartHandler.h"

extern int plib33c_Uart_CommPortInitialize(UART_t* uartConfig);
extern int plib33c_Uart_DataBufferInitialize(UART_t* uartConfig, UART_BUFFER_t* interfaceSendBuffer, UART_BUFFER_t* interfaceReceiveBuffer);
extern int plib33c_Uart_InterruptEnable(UART_t* uartConfig);
extern int plib33c_DMA_InterruptEnable(UART_t* uartConfig);
extern int plib33c_Uart_DmaDataTransferInitialize(UART_t* uartConfig); 

extern bool plib33c_Uart_RingBufferGet(uint16_t uartInstance, PLIB33C_UART_RINGBUFFER_t * const ringbuf, uint8_t *bytePointer); 
extern bool plib33c_Uart_OperationCompleteDma(uint16_t dmaInstance);
 
extern PLIB33C_DATA_STATUS_t plib33cDataStatus[];
extern UART_BUFFER_t plib33cUartSendBuffer[];

/* ********************************************************************************************** */
/* ********************************************************************************************** */
/* ********************************************************************************************** */

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods
 * @brief   Initializes a given UART port by resetting all its registers to default 
 *          as well as the data buffers that user configure
 * @param   uartConfig Properties of the UART communication port
 * @param   interfaceSendBuffer  Pointer to UART send buffer object of type PLIB33C_UART_SEND_BUFFER_t
 * @param   interfaceReceiveBuffer  Pointer to UART receive buffer object of type PLIB33C_UART_RECEIVE_BUFFER_t
 * @param   pinRxD  Pointer to GPIO receive pin
 * @param   pinTxD  Pointer to GPIO transmit pin
 * @return  0 = failure, Initializing UART port was not successful
 * @return  1 = success, Initializing UART port was successful
 * 
 * @details
 *  This function initializes the specified UART port along with the DMA. 
 *  The data buffers and handlers were also initialize, as well as the
 *  pins for the Uart RxD and TxD.
 * 
 *********************************************************************************/
int plib33c_Uart_Initialize(UART_t* uartConfig, UART_BUFFER_t* interfaceSendBuffer, UART_BUFFER_t* interfaceReceiveBuffer) 
{
	int retval = 1;

    // Initialize interface as handed in via uartConfig
    retval &= plib33c_Uart_CommPortInitialize(uartConfig);
    
    //Power On the module
    retval &= p33c_UartInstance_PowerOn(uartConfig->CommPort.UartInstance);
    
    // Reset all SFRs to default
    retval &= p33c_UartInstance_SetConfig(uartConfig->CommPort.UartInstance, uartConfigClear);
    
    // Initialize TxD DMA support if enabled
    if((uartConfig->Status.TxDmaEnable))
    {
        retval &= plib33c_Uart_DmaDataTransferInitialize(uartConfig);
        retval &= plib33c_DMA_InterruptEnable(uartConfig);  
    }
    
    // Initialize UART interrupts
    retval &= plib33c_Uart_InterruptEnable(uartConfig);
    
    // Map the RxD and TxD I/O pins
    retval &= plib33c_Uart_RemapRxPin(uartConfig, uartConfig->CommPort.RxD.Io);
    retval &= plib33c_Uart_RemapTxPin(uartConfig, uartConfig->CommPort.TxD.Io);
    
    // Initialize receive and transmit data buffer byte arrays
    retval &= plib33c_Uart_DataBufferInitialize(uartConfig, interfaceSendBuffer, interfaceReceiveBuffer); 
    
    // Initialize STDIO support if enabled
    if (uartConfig->Status.StdioRedirect ==  true){
        __C30_UART = uartConfig->CommPort.UartInstance;
    }
    
    // Set status bits and flags
    uartConfig->Status.Busy = false;
    uartConfig->Status.PortOpen = false;
    uartConfig->Status.Ready = true;
    
    plib33cDataStatus[uartConfig->CommPort.UartInstance - 1].bits.Ready = true;
   
    return(retval);
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods
 * @brief  Opens the Uart communication
 * @param  uartConfig   Uart property configuration of unsigned integer of the UART Object PLIB_UART_OBJECT_t
 * @return 0 = failure, Opening communication was not successful
 * @return 1 = success, Opening communication was successful
 * 
 * @details 
 *  Opens the uart communications with the respective settings specified 
 *  by the user.
 * 
 *********************************************************************************/
int plib33c_Uart_Start(UART_t* uartConfig) 
{
    int retval = 1;
    
    retval &= plib33c_Uart_OpenPort(uartConfig->CommPort.UartInstance, uartConfig->Settings.Baudrate,
            uartConfig->Settings.DataBits, uartConfig->Settings.Parity, uartConfig->Settings.StopBits,
            uartConfig->Settings.FlowControl);
    
    plib33cDataStatus[uartConfig->CommPort.UartInstance - 1].bits.Enable = true;
    
    return(retval);
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods
 * @brief   Send the data via Uart
 * @param   uartConfig   Uart property configuration of unsigned integer of the UART Object PLIB_UART_OBJECT_t
 * @param   startAddr   transmit/send buffer start address
 * @param   length      length of size of the buffer that needs to be sent
 * @return  0 = failure, Initializing UART data buffer was not successful
 * @return  1 = success, Initializing UART data buffer was successful
 * @details 
 *  This function send the data to the Uart. Sending the data can be 
 *  through Uart only or with the DMA interface depending on the user 
 *  configuration.
 **********************************************************************************/
int plib33c_Uart_SendData(UART_t* uartConfig, uint8_t* ptrData, uint16_t dataLength)
{
    int retval = 1;
    uint16_t index = uartConfig->CommPort.UartInstance - 1;
    
    if(uartConfig->Status.TxDmaEnable)
    {
        plib33cDataStatus[index].bits.txDataSent = false;
        retval &= plib33c_Uart_SendBufferDma(uartConfig, ptrData, dataLength);
        plib33cDataStatus[index].bits.txDataSent = true;
    }
    else
    {
        plib33cDataStatus[index].bits.txDataSent = false;
        retval &= plib33c_Uart_SendBuffer(uartConfig->CommPort.UartInstance, ptrData, dataLength);
        plib33cDataStatus[index].bits.txDataSent = true;
    }
    
    Nop();
    Nop();
    Nop();
    
    return(retval);
}

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods
 * @brief   Process the Receive data
 * @param   uartConfig   Uart property configuration of unsigned integer of the UART Object PLIB_UART_OBJECT_t
 * @return _rxChar Returns the processed received byte
 * @details 
 *  This function returns the received character or byte. It calls the 
 *  plib_Uart_RingBufferGet function to keep the ring buffer updated of 
 *  the position of the byte being processed.
 *********************************************************************************/
uint8_t plib33c_Uart_ReceiveData(UART_t* uartConfig)
{
    
    uint8_t rxChar = 0;
    uint16_t index = uartConfig->CommPort.UartInstance - 1;

    if(plib33c_Uart_RingBufferGet(index, &plib33cReceiveRingBuffer[index], &rxChar))
    {
        return(rxChar);
    }
    
    return(0);
}    

/*********************************************************************************
 * @ingroup p33c-plib-uart-methods
 * @brief  Disables the uart communication
 * @param  uartInstance Index of UART peripheral instance of type unsigned integer
 * @return 0 = failure, Disabling uart communication was not successful
 * @return 1 = success, Disabling uart communication was successful
 * 
 * @details 
 *  Closes the uart communications with the respective settings 
 *  specified by the user.
 *********************************************************************************/
int plib33c_Uart_Close(UART_t* uartConfig)
{
    int retval = 1;
    
    if (uartConfig == NULL) { return(0); }
    
    // Disable UART - write directly to registers
    retval &= plib33c_Uart_Disable(uartConfig->CommPort.UartInstance);
    
    plib33cDataStatus[uartConfig->CommPort.UartInstance - 1].bits.Ready = false;
    plib33cDataStatus[uartConfig->CommPort.UartInstance - 1].bits.Enable = false;
    
	return (retval);
}

// ___________________
// end of file
