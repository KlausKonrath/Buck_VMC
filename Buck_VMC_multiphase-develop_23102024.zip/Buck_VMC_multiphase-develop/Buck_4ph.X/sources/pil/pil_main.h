/* 
 * @file    pil_main.h
 * @author  beat arnet, Plexim
 * @date    January 22, 2020
 */

#ifndef PIL_MAIN_H
#define	PIL_MAIN_H

#include "config/mcal.h" // include mcal header file to derive ADC and DAC reference voltage and resolution
#include "pil.h" // include PIL framwork API header file

// Analog-to-Digital Converter values from PLECS are multiplied by (2^SCALEIN_BIT)/INPUT_SCALING
#define INPUT_SCALING   ADC_REFERENCE  // Input values are scaled to ADC reference voltage (3.3V)
#define SCALEIN_BIT     (uint16_t)ADC_RESOLUTION // Bit resolution of input values representing ADC results (12bit)

// I/O state values are multiplied by OUTPUT_SCALING/(2^SCALEOUT) and sent to PLECS
// Output values are not scaled but passed on 1:1 with factor =1.0 and no bit shift
#define OUTPUT_SCALING  1.0 
#define SCALEOUT_BIT    0U

// Digital-to-Analog Converter values from PLECS are multiplied by (2^SCALEDAC_BIT)/DAC_SCALING
#define DAC_SCALING     DAC_REFERENCE
#define SCALEDAC_BIT    (uint16_t)DAC_RESOLUTION  

struct PIL_PROBES_s
{
    // Variables from PLECS
    PIL_OVERRIDE_PROBE(uint16_t, Vin_prot, SCALEIN_BIT, INPUT_SCALING, ""); 
    PIL_OVERRIDE_PROBE(uint16_t, Vin, SCALEIN_BIT, INPUT_SCALING, ""); 
    PIL_OVERRIDE_PROBE(uint16_t, Vout, SCALEIN_BIT, INPUT_SCALING, "");  
    PIL_OVERRIDE_PROBE(uint16_t, Ibuck1, SCALEIN_BIT, INPUT_SCALING, "");  
    PIL_OVERRIDE_PROBE(uint16_t, Ibuck2,SCALEIN_BIT, INPUT_SCALING, "");  
    PIL_OVERRIDE_PROBE(uint16_t, Ibuck3, SCALEIN_BIT, INPUT_SCALING, "");  
    PIL_OVERRIDE_PROBE(uint16_t, Ibuck4, SCALEIN_BIT, INPUT_SCALING, "");  
    PIL_OVERRIDE_PROBE(uint16_t, Start, 0, 1, "");  
    // Add more input here
    
    // Variables to PLECS
    PIL_READ_PROBE(uint16_t ,PG1DC,SCALEOUT_BIT,OUTPUT_SCALING, ""); 
    PIL_READ_PROBE(uint16_t ,PG2DC,SCALEOUT_BIT,OUTPUT_SCALING, ""); 
    PIL_READ_PROBE(uint16_t ,PG3DC,SCALEOUT_BIT,OUTPUT_SCALING, ""); 
    PIL_READ_PROBE(uint16_t ,PG4DC,SCALEOUT_BIT,OUTPUT_SCALING, ""); 
    PIL_READ_PROBE(uint16_t ,PG1triga,SCALEOUT_BIT,OUTPUT_SCALING, ""); 
    PIL_READ_PROBE(uint16_t ,PG1trigb,SCALEOUT_BIT,OUTPUT_SCALING, ""); 
    PIL_READ_PROBE(uint16_t ,PG2triga,SCALEOUT_BIT,OUTPUT_SCALING, ""); 
    PIL_READ_PROBE(uint16_t ,PG2trigb,SCALEOUT_BIT,OUTPUT_SCALING, ""); 
    PIL_READ_PROBE(uint16_t ,PG3triga,SCALEOUT_BIT,OUTPUT_SCALING, ""); 
    PIL_READ_PROBE(uint16_t ,PG3trigb,SCALEOUT_BIT,OUTPUT_SCALING, ""); 
    PIL_READ_PROBE(uint16_t ,PG4trigb,SCALEOUT_BIT,OUTPUT_SCALING, ""); 
    PIL_READ_PROBE(uint16_t ,PGxdtl,SCALEOUT_BIT,OUTPUT_SCALING, ""); 
    PIL_READ_PROBE(uint16_t ,PGxdth,SCALEOUT_BIT,OUTPUT_SCALING, ""); 
    PIL_READ_PROBE(uint16_t ,Pgx_ovr,SCALEOUT_BIT,OUTPUT_SCALING, ""); // Used to send override bits PG3OVRH,PG3OVRL,PG2OVRH,PG2OVRL,PG1OVRH,PG1OVRL
    PIL_READ_PROBE(uint16_t ,DAC1dath,SCALEDAC_BIT,DAC_SCALING, "");
    PIL_READ_PROBE(uint16_t ,Inrush,SCALEOUT_BIT,OUTPUT_SCALING, "");
    //PIL_READ_PROBE(uint16_t ,DEBUG2,SCALEOUT_BIT,OUTPUT_SCALING, "");
  

    
}; 
typedef struct PIL_PROBES_s PilProbes_t;

extern PilProbes_t PilProbes;
extern PIL_Handle_t PilHandle;
extern PIL_Obj_t PilObj;

extern void PollUart(PIL_Handle_t aHandle);
extern void PilCallback(PIL_Handle_t aPilHandle, PIL_CtrlCallbackReq_t aCallbackReq);
extern void PilInitialize(void);

#endif	/* MAIN_H */

