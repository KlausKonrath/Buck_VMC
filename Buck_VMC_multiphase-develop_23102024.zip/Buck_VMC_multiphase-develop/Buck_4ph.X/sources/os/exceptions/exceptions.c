/*
 * @file    exceptions.c
 * @author  M91406
 * @date    June 29, 2023, 10:14 AM
 */

#include "exceptions.h" // include RTOS exception header file

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-variables
 * @brief   Persistent data object used to capture CPU exception event details
 * 
 * @details
 *  This public data object is used to capture the status of the 
 *  CPU reset and interrupt registers and/or task queue status in case  
 *  of a non-interruptible CPU exception event. This information will 
 *  be preserved during a soft CPU reset to be available afterwards for 
 *  analysis.
 *
 *********************************************************************************/
volatile __attribute__((__persistent__)) CPU_EXCEPTION_t CpuExceptionLog; ///< data structure used as buffer for trap monitoring 

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-variables
 * @brief   Persistent variable used to capture default interrupt vector event details 
 *
 * @details
 *   The global variable 'IrqExceptionLog' is used to capture the status of
 *   the interrupt enable and interrupt flag registers in case of an 
 *   rouge interrupt event occurs. This information will be available 
 *   after the event got parsed for analysis.
 *
*********************************************************************************/
volatile __attribute__((__persistent__)) IRQ_EXCEPTION_t IrqExceptionLog; ///< data structure used as buffer for default interrupt vector monitoring 

/**********************************************************************************
 * @ingroup os-layer-exc-properties-public-variables
 * @brief   Persistent data object used to capture exception event details
 * 
 * @details
 *  This public data object is used to capture the status of the 
 *  task scheduler and active task queue in case of a task execution 
 *  exception event. This information will be preserved during a soft 
 *  CPU reset to be available afterwards for analysis.
 *
 *********************************************************************************/
volatile __attribute__((__persistent__)) TASK_EXCEPTION_t TaskExceptionLog; ///< data structure used as buffer for captured task exception information

/**************************************************************************************************
 * @ingroup os-layer-exc-functions-public 
 * @brief   Centralized CPU exception handler routine
 * @param   ex:  Exception information of type CPU_EXCEPTION_t
 * 
 * @details
 *  This routine centralizes all CPU exceptions and is invoked automatically by the 
 *  respective CPU trap interrupt service routine. The parameter ex (Exception) includes
 *  all status information of CPU interrupt status and control bits, the CPU Reset 
 *  register and last known application task ID and its interrupt level.
 * 
 *  Users may override this public function in proprietary user code to tailor  
 *  the trap vector response in accordance with application requirements.
 *
 *************************************************************************************************/
void __attribute__((weak)) CpuExceptionHandler(CPU_EXCEPTION_t ex)
{
    CpuExceptionLog = ex; // store exception event information
    
    #if __DEBUG
    Nop(); // These Nop()s can be used to place breakpoints 
    Nop(); // during debugging.
    Nop();
    #endif
    
    return;
}

/*********************************************************************************
 * @ingroup os-layer-exc-functions-public
 * @brief   Default interrupt service routine for initialized and enabled interrupt 
 *          vectors without interrupt vector destination
 * @param   ex:  Exception information of type IRQ_EXCEPTION_t
 * 
 * @details
 *  Hardware interrupt vectors, which are enabled but don't have a dedicated
 *  interrupt service routine assigned/declared, will be redirected to the 
 *  default interrupt vector. If this vector also doesn't have an assigned service 
 *  routine, the CPU will be forced into a soft reset, effectively terminating
 *  the execution of the most recent firmware, initiating a reboot.
 *  
 *  This interrupt vector service routine captures interrupts without assigned
 *  service routine and allows developers to capture, trace and resolve the active 
 *  interrupt vector, which tripped the default interrupt routine, effectively
 *  preventing non-deterministic CPU resets.
 *  
 *  Users may override this public function in proprietary user code to tailor 
 *  the trap vector response in accordance with application requirements.
 *
 **********************************************************************************/
void __attribute__((weak)) InterruptExceptionHandler(IRQ_EXCEPTION_t ex)
{
    IrqExceptionLog = ex; // store exception event information
    
    #if __DEBUG
    Nop(); // These Nop()s can be used to place breakpoints 
    Nop(); // during debugging.
    Nop();
    #endif
    
    return;
}

/**************************************************************************************************
 * @ingroup os-layer-exc-functions-public
 * @brief   Centralized task exception handler routine
 * @param   ex:  Exception information of type TASK_EXCEPTION_t
 * 
 * @details
 *  This routine centralizes all Task conflict resp. task queue timeout exceptions and 
 *  is invoked automatically by the task scheduler. The parameter ex (Exception) includes
 *  ID and queue type of the task triggering the conflict.
 * 
 *  Users may override this public function in proprietary user code to tailor  
 *  the trap vector response in accordance with application requirements.
 *
 *************************************************************************************************/
void __attribute__((weak)) TaskExceptionHandler(TASK_EXCEPTION_t ex)
{
    TaskExceptionLog = ex; // store exception event information
    
    #if __DEBUG
    Nop(); // These Nop()s can be used to place breakpoints 
    Nop(); // during debugging.
    Nop();
    #endif
    
    return;
}

// __________________________
// end of file
