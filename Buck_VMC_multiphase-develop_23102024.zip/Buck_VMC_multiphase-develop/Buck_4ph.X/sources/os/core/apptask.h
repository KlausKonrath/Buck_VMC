/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/**
 * @file    apptask.h
 * @author  M91406
 * @brief   Header file providing type declarations of a user task object
 * @date    01/12/2022
 * @details
 *   Revision history: 
 *    1.0     initial release
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef RTOS_APPTASK_TYPEDEF_H
#define	RTOS_APPTASK_TYPEDEF_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types

/***********************************************************************************
 * @ingroup os-layer-core-exe-properties-public-data-types-objects
 * @brief   Application task classification of its execution priority.
 * @details
 *  The real time operating system supports two preemptive execution priority
 *  levels. This enumeration defines levels.
 *
 ***********************************************************************************/
enum APPTASK_CLASS_e {
    
    APP_CLASS_NONE          = 0x0000,   ///<  Task execution priority is level #0 (no priority assignment)
    APP_CLASS_LOW_PRIORITY  = 0x0001,   ///<  Task execution priority is level #1 (low priority)
	APP_CLASS_HIGH_PRIORITY = 0x0002    ///<  Task execution priority is level #2 (high priority)
       
};
typedef enum APPTASK_CLASS_e APPTASK_CLASS_t;  ///< DESCRIPTION

/***********************************************************************************
 * @ingroup	os-layer-core-exe-properties-public-data-types-objects
 * @extends	APPLICATION_TASK_s
 * @brief	Application task execution status
 *
 * @details
 *  Application task execution status is a common status word of which
 *  the low-byte is covering status bits, which are set and cleared 
 *  automatically by the RTOS. 
 *
 *  The high-byte provides control bits allowing user code to influence
 *  the execution of the application task, such as temporarily enable/disable 
 *  the execution without disrupting the overall task scheduling.
 *
 **********************************************************************************/
struct APPTASK_STATUS_s {
    
	bool Busy          : 1; ///< Bit 0:  Status bit indicating the task is busy
	unsigned           : 1; ///< Bit 1:  (reserved)
	unsigned           : 1; ///< Bit 2:  (reserved)
	unsigned           : 1; ///< Bit 3:  (reserved)
	unsigned           : 1; ///< Bit 4:  (reserved)
	unsigned           : 1; ///< Bit 5:  (reserved)
	unsigned           : 1; ///< Bit 6:  (reserved)
	unsigned           : 1; ///< Bit 7:  (reserved)

	unsigned           : 1; ///< Bit 8:  (reserved)
	unsigned           : 1; ///< Bit 9:  (reserved)
	unsigned           : 1; ///< Bit 10: (reserved)
	unsigned           : 1; ///< Bit 11: (reserved)
	unsigned           : 1; ///< Bit 12: (reserved)
	unsigned           : 1; ///< Bit 13: (reserved)
	unsigned           : 1; ///< Bit 14: (reserved)
	bool Enabled       : 1; ///< Bit 15: Control bit enabling the execution of the task execute function
        
}; ///<  DESCRIPTION
typedef struct APPTASK_STATUS_s APPTASK_STATUS_t; ///<  DESCRIPTION

/***********************************************************************************
 * @ingroup os-layer-core-exe-properties-public-data-types-objects
 * @extends APPLICATION_TASK_s
 * @brief 	Application task execution link
 * @details
 *  ADD_DETAILED_DESCRIPTION
 *
 **********************************************************************************/
struct APPTASK_TASKLINK_s {
    
    uint16_t (*Initialize)(void);  ///< Function pointer to INITIALIZE routine
    uint16_t (*Start)(void);       ///< Function pointer to START routine
    uint16_t (*Execute)(void);     ///< Function pointer to EXECUTE routine
    uint16_t (*Stop)(void);        ///< Function pointer to STOP routine
    uint16_t (*Dispose)(void);     ///< Function pointer to DISPOSE routine
    
    uint16_t (*Exception)(void);   ///< Function pointer to EXCEPTION handling routine
        
}__attribute__((aligned)); ///<  DESCRIPTION
typedef struct APPTASK_TASKLINK_s APPTASK_TASKLINK_t; ///<  DESCRIPTION

/***********************************************************************************
 * @ingroup os-layer-core-exe-properties-public-data-types-objects
 * @extends APPLICATION_TASK_s
 * @brief 	Application task execution events
 * @details
 *  ADD_DETAILED_DESCRIPTION
 *
 **********************************************************************************/
struct APPTASK_TASKEVENTS_s {
    
    uint16_t (*Exception)(void);   ///< Function pointer to EXCEPTION handling routine
        
}__attribute__((aligned)); ///<  DESCRIPTION
typedef struct APPTASK_TASKEVENTS_s APPTASK_TASKEVENTS_t; ///<  DESCRIPTION

/***********************************************************************************
 * @ingroup os-layer-core-exe-properties-public-data-types-objects
 * @extends APPLICATION_TASK_s
 * @brief 	Application task execution
 * @details
 *  ADD_DETAILED_DESCRIPTION
 *
 **********************************************************************************/
struct APPTASK_EXECUTION_s {
    
	int32_t Counter;   ///< Execution period counter (read only)
	int32_t Period;    ///< Task execution period defined in multiples of OS task execution base clock ticks (e.g. 100us)
	int32_t Offset;    ///< Task execution period offset defined in multiples of OS task execution base clock ticks (e.g. 100us)
        
}; ///<  DESCRIPTION
typedef struct APPTASK_EXECUTION_s APPTASK_EXECUTION_t; ///<  DESCRIPTION

/***********************************************************************************
 * @ingroup os-layer-core-exe-properties-public-data-types-objects
 * @extends APPLICATION_TASK_s
 * @brief 	Application task execution statistics
 * @details
 *  ADD_DETAILED_DESCRIPTION
 *
 **********************************************************************************/
struct APPTASK_STATISTICS_s {
    
    uint32_t ExecTime; ///< Execution time in CPU ticks of the most recent task execution (read only)
	uint32_t AvgTime;  ///< Moving average execution time of the task object (read only)
	uint32_t MaxTime;  ///< Maximum execution time of the task object (latched tracking, reset in software)
        
}; ///<  DESCRIPTION
typedef struct APPTASK_STATISTICS_s APPTASK_STATISTICS_t; ///<  DESCRIPTION

/***********************************************************************************
 * @ingroup os-layer-core-exe-properties-public-data-types-objects
 * @extends APPLICATION_TASK_s
 * @brief 	Application task execution properties
 * @details
 *  ADD_DETAILED_DESCRIPTION
 *
 **********************************************************************************/
struct APPTASK_PROPERTIES_s {

    APPTASK_EXECUTION_t  TimeBase;        ///< Execution time settings of the application task object
    APPTASK_CLASS_t      PriorityClass; ///< Execution priority class of the application task object (low priority, high priority)
    uint16_t             TaskID;        ///< READ ONLY: Application task identifier asigned by the RTOS
    uint16_t             ReturnValue;   ///< READ ONLY: Application task latest return value
    
}; ///<  DESCRIPTION
typedef struct APPTASK_PROPERTIES_s APPTASK_PROPERTIES_t; ///<  DESCRIPTION

#endif	/* RTOS_APPTASK_TYPEDEF_H */

// end of file
