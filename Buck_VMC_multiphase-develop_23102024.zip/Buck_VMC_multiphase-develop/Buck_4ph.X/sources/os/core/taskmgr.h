/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/**
 * @file    taskmgr.h
 * @author  M91406
 * @brief   RTOS 6G2 type definitions header file
 * @date    01/12/2022
 * @details
 *   Revision history: 
 *     1.0    initial release
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef RTOS_TASKMGR_TYPEDEF_H
#define	RTOS_TASKMGR_TYPEDEF_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include <stdint.h> // include standard integer data types
#include <stdbool.h> // include standard boolean data types
#include <dsp.h> // include DSP data types

/***********************************************************************************
 * @ingroup os-layer-core-exe-properties-public-data-types
 * @extends OS_TASK_MANAGER_s
 * @brief   Task manager status word
 * @details
 *  // To-Do: ADD_DETAILED_DESCRIPTION
 *
 **********************************************************************************/
struct OS_TASKMGR_STATUS_s {

    unsigned LpActive   : 1; ///< Bit 0: Flag indicating that high-priority task queue is executed frequently
    unsigned HpActive   : 1; ///< Bit 1: Flag indicating that low-priority task queue is executed frequently
    unsigned LpTimeout  : 1; ///< Bit 2: Flag indicating that a low-priority queue timeout occured (not implemented yet)
    unsigned HpTimeout  : 1; ///< Bit 3: Flag indicating that a high-priority queue timeout occured (not implemented yet)
    unsigned : 1; ///< Bit 4:  (reserved)
    unsigned : 1; ///< Bit 5:  (reserved)
    unsigned : 1; ///< Bit 6:  (reserved)
    unsigned BootComplete : 1; ///< Bit 7: Flag indicating if boot routine has been executed successfully

    unsigned : 1; ///< Bit 8:  (reserved)
    unsigned : 1; ///< Bit 9:  (reserved)
    unsigned : 1; ///< Bit 10: (reserved)
    unsigned : 1; ///< Bit 11: (reserved)
    unsigned : 1; ///< Bit 12: (reserved)
    unsigned Statistics : 1; ///< Bit 13: When set, enables capturing of execution time tracking statistics
    unsigned Suspend    : 1; ///< Bit 14: When set, skips the execution of application tasks but keeps running the OS
    unsigned Disable    : 1; ///< Bit 15: When set, causes the execution of main() to be terminated resulting in a CPU reset

}__attribute__((packed)); ///< Task manager data status

/***********************************************************************************
 * @ingroup os-layer-core-exe-properties-public-data-types
 * @brief   Task Manager Data Status
 **********************************************************************************/
union OS_TASKMGR_STATUS_u {
    struct OS_TASKMGR_STATUS_s bits; ///< Status word bitfield
    uint16_t value; ///< Status word value
}__attribute__((aligned (2)));

typedef union OS_TASKMGR_STATUS_u OS_TASKMGR_STATUS_t; ///< Task manager data status data type

/***********************************************************************************
 * @ingroup os-layer-core-exe-properties-public-data-types
 * @extends OS_TASK_MANAGER_s
 * @brief   Task scheduler time-base parameters
 * @details
 *  // To-Do: ADD_DETAILED_DESCRIPTION
 *
 **********************************************************************************/
struct OS_TASKMGR_TIMEBASE_s {
    
	int32_t Counter;  ///<  Operating system task execution tick counter
	int32_t Period;   ///<  Operating system task execution period
        
}; ///<  DESCRIPTION
typedef struct OS_TASKMGR_TIMEBASE_s OS_TASKMGR_TIMEBASE_t; ///<  DESCRIPTION

/***********************************************************************************
 * @ingroup os-layer-core-exe-properties-public-data-types
 * @extends OS_TASK_MANAGER_s
 * @brief   Data structure holding CPU load runtime information
 * @details
 *  // To-Do: ADD_DETAILED_DESCRIPTION
 *
 **********************************************************************************/
struct OS_TASKMGR_CPU_LOAD_s {
    
	fractional CpuLoad; ///<  Operating system task execution tick counter
        
}; ///<  DESCRIPTION
typedef struct OS_TASKMGR_CPU_LOAD_s OS_TASKMGR_CPU_LOAD_t; ///<  DESCRIPTION

/***********************************************************************************
 * @ingroup os-layer-core-exe-properties-public-data-types
 * @extends OS_TASK_MANAGER_s
 * @brief   Data structure holding information about most recently executed task
 * @details
 *  // To-Do: ADD_DETAILED_DESCRIPTION
 *
 **********************************************************************************/
struct OS_TASKMGR_TASKINFO_s {
    
	uint16_t QueueType;    ///<  Execution queue type of the most recently executed task
	uint16_t QueueMode;    ///<  Execution queue type of the most recently executed task
	uint16_t TaskId;       ///<  ID of the most recently executed task
        
}; ///<  DESCRIPTION
typedef struct OS_TASKMGR_TASKINFO_s OS_TASKMGR_TASKINFO_t; ///<  DESCRIPTION

/***********************************************************************************
 * @ingroup os-layer-core-exe-properties-public-data-types
 * @brief   Data structure wrapping up tasks list of different priorities
 * @details
 *  // To-Do: ADD_DETAILED_DESCRIPTION
 *
 **********************************************************************************/
struct OS_TASK_MANAGER_s {
    
    OS_TASKMGR_STATUS_t   Status;   ///< Task manager status word
    OS_TASKMGR_CPU_LOAD_t CpuLoad;  ///< Task manager CPU load metering result
    OS_TASKMGR_TIMEBASE_t Timebase; ///< Task manager time base monitor
    OS_TASKMGR_TASKINFO_t TaskInfo; ///< Task manager most recent task execution tracker
};
typedef struct OS_TASK_MANAGER_s OS_TASK_MANAGER_t;

#endif	/* RTOS_TASKMGR_TYPEDEF_H */

// ______________________
// end of file
