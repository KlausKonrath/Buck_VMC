/*
 * @file    taskerrors.c
 * @brief   Real time operating system task conflict handlers
 * @author  M91406
 * @date    06/23/2023, 10:49 AM
 * @version 1.0.6
 */

#include <stdint.h> // include standard integer types header file
#include <stdbool.h> // include standard boolean types header file

#include "taskerrors.h"  // include task exceptions event data object header file
#include "inlines.h"     // include scheduler inline functions hwader file
#include "../IAppTask.h" // include exception event call inline function header file

/*********************************************************************************
 * @ingroup os-layer-core-int-functions-public
 * @param   exception   Exception ID of type OS_TASKEX_TYPE_t identifying the type of exception
 * @param   task        Pointer to the application task data object triggering this exception
 * @brief   Default event routine for task exception handling
 * 
 * @details
 *  Task exceptions are invoked by issues in the task execution scheme of the 
 *  main scheduler. The detectable events include
 * 
 *   - OS_TASKEX_LOW_PRIORITY_TIMEOUT: Low-Priority Queue becomes Unresponsive 
 *   - OS_TASKEX_HIGH_PRIORITY_TIMEOUT: High-Priority Queue become unresponsive
 *   - OS_TASKEX_HIGH_PRIORITY_QUOTA_VIOLATION: High-Priority Queue execution exceeded the allowed time quota of one scheduler period
 *   - OS_TASKEX_TASK_RET_ERROR: Application Task returned a failure/false 
 *  
 * @note
 *  Not every exception is able to identify the task triggering the exception.
 *  Queue events are only identifying the event itself and parameter 'task' will 
 *  be a NULL pointer. 
 * 
 **********************************************************************************/
void DefaultTaskException(OS_TASKEX_TYPE_t exception, IApplicationTask_t* task)
{
    switch (exception)
    {
        case OS_TASKEX_LOW_PRIORITY_TIMEOUT:  taskManager.Status.bits.LpTimeout = 1; break;
        case OS_TASKEX_HIGH_PRIORITY_TIMEOUT: taskManager.Status.bits.HpTimeout = 1; break;
        case OS_TASKEX_UNKNOWN: break;
        default: break;
    }
    
    TASK_EXCEPTION_t ex;

    ex.ExId = exception;

    // This if statement was required to prevent a compiler warning to be thrown
    // in case parameter 'task' is NULL
    if (task != NULL)
    {
        ex.TaskInfo = task; // Assign task pointer
        if (ex.TaskInfo->Functions.Exception != NULL) { ex.TaskInfo->Functions.Exception(); }
        else { InvokeTaskException(ex); }
    }
    else 
    {
        ex.TaskInfo = NULL; // Clear data pointer
        InvokeTaskException(ex);
    }
}

// ___________________________
// end of file
