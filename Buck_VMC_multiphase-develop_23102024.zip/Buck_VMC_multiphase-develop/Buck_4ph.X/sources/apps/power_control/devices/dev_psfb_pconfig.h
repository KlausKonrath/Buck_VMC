/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * @file   dev_psfb_pconfig.h
 * @author M91406
 * @brief 
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef PSFB_CONVERTER_PERIPHERAL_CONFIGURATION_H
#define	PSFB_CONVERTER_PERIPHERAL_CONFIGURATION_H

#include <xc_pral.h> // include processor files - each processor file is guarded.  
#include "dev_buck_4ph_typedef.h"

// High Speed PWM Configuration
extern uint16_t PWM_ModuleInitialize(volatile POWER_CONTROLLER_t* pcInstance);
extern uint16_t PWM_GeneratorInitialize(volatile POWER_CONTROLLER_t* pcInstance);
extern uint16_t PWM_Start(volatile POWER_CONTROLLER_t* pcInstance);
extern uint16_t PWM_Stop(volatile POWER_CONTROLLER_t* pcInstance);
extern uint16_t psfbPWM_Suspend(volatile POWER_CONTROLLER_t* pcInstance);
extern uint16_t psfbPWM_Resume(volatile POWER_CONTROLLER_t* pcInstance);

extern P33C_PWM_INSTANCE_t pgConfigPWM;
extern P33C_PWM_MODULE_t PwmModuleConfig;

// High Speed DAC Configuration
extern uint16_t DAC_ModuleInitialize(volatile POWER_CONTROLLER_t* pcInstance);
extern uint16_t DAC_GeneratorInitialize(volatile POWER_CONTROLLER_t* pcInstance);

extern P33C_DAC_MODULE_t psfbDacModuleConfig;
extern P33C_DAC_INSTANCE_t psfbDacInstanceConfig;
extern P33C_DAC_MODULE_t psfbDacModuleInitConfig;

// High Speed ADC Configuration
extern uint16_t ADC_ModuleInitialize(void);
extern uint16_t ADC_Channel_Initialize(volatile CONVERTER_ADC_INPUT_t* adcInstance);
extern uint16_t ADC_Start(void);

// Power Supply I/O Configuration
extern uint16_t GPIO_Initialize(volatile POWER_CONTROLLER_t* pcInstance);
extern uint16_t converterGPIO_Set(volatile CONVERTER_GPIO_INSTANCE_t* gpioInstance);
extern uint16_t converterGPIO_Clear(volatile CONVERTER_GPIO_INSTANCE_t* gpioInstance);
extern bool     converterGPIO_GetPinState(volatile CONVERTER_GPIO_INSTANCE_t* gpioInstance);


#endif	/* PSFB_CONVERTER_PERIPHERAL_CONFIGURATION_H */
