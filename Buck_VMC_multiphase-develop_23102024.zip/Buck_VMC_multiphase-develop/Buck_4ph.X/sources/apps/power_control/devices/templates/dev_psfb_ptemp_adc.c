/* 
 * @file   dev_psfb_ptemp_adc.c
 * @author M91406
 * @brief
 * Revision history: 
 */


#include <xc_pral.h> // include peripheral register abstraction layer drivers
#include "dev_psfb_ptemp_adc.h" // include peripheral register configuration values header

// ADC module default configuration

// ADC input instance default configuration
