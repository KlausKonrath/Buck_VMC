/* 
 * @file   dev_psfb_ptemp_dac.c
 * @author M91406
 * @brief
 * Revision history: 
 */

#include <xc_pral.h> // include peripheral register abstraction layer drivers
#include "dev_psfb_ptemp_dac.h" // include peripheral register configuration values header
/****************************************************************************************************
 * @ingroup lib-layer-psfb-ptemplate-properties-variables
 * @var psfbDacModuleConfig
 * @brief DAC module default configuration
 *****************************************************************************************************/
volatile P33C_DAC_MODULE_t psfbDacModuleConfig = 
{
    .DACCTRL1L.value = 0x0000, // DACCTRL1L: DAC CONTROL 1 LOW REGISTER
    .DACCTRL2L.value = 0x0000, // DACCTRL2L: DAC CONTROL 2 LOW REGISTER
    .DACCTRL2H.value = 0x0000  // DACCTRL2H: DAC CONTROL 2 HIGH REGISTER
};
/****************************************************************************************************
 * @ingroup lib-layer-psfb-ptemplate-properties-variables
 * @var psfbDacInstanceConfig
 * @brief DAC generator default configuration
 *****************************************************************************************************/
// DAC generator default configuration
volatile P33C_DAC_INSTANCE_t psfbDacInstanceConfig = 
{
    .DACxCONL.value = REG_DACxCONL, // DACxCONL: DACx CONTROL LOW REGISTER
    .DACxCONH.value = REG_DACxCONH, // DACxCONH: DACx CONTROL HIGH REGISTER
    .DACxDATL.value = 0x0000,       // DACxDATH: DACx DATA HIGH REGISTER
    .DACxDATH.value = 0x0000,       // DACxDATL: DACx DATA LOW REGISTER
    .SLPxCONL.value = REG_SLPxCONL, // SLPxCONL: DACx SLOPE CONTROL LOW REGISTE
    .SLPxCONH.value = REG_SLPxCONH, // SLPxCONH: DACx SLOPE CONTROL HIGH REGISTE
    .SLPxDAT.value = 0x0000         // SLPxCONL: DACx SLOPE CONTROL LOW REGISTER
};
/****************************************************************************************************
 * @ingroup lib-layer-psfb-ptemplate-properties-variables
 * @var psfbDacModuleInitConfig
 * @brief DAC generator initial configuration
 *****************************************************************************************************/
volatile P33C_DAC_MODULE_t psfbDacModuleInitConfig = 
{
    .DACCTRL1L.value = REG_DACCTRL1L,  // DACCTRL1L: DAC CONTROL 1 LOW REGISTER
    .DACCTRL2L.value = REG_DACCTRL2L,  // DACCTRL2L: DAC CONTROL 2 LOW REGISTER
    .DACCTRL2H.value = REG_DACCTRL2H   // DACCTRL2H: DAC CONTROL 2 HIGH REGISTER
};




