/*
 * @file   pwr_control.c
 * @author M91406
 * @date   March 12, 2020, 11:55 AM
 */

#include <xc_pral.h>
#include "common/p33c_flib/p33c_flib.h"

#include "apps/fault_handler/drivers/IFaultHandler.h"
#include "apps/fault_handler/app_fault_monitor.h"
#include "app_power_control.h"
#include "./devices/dev_psfb_pconfig.h" 
#include "./devices/dev_psfb_converter.h"

/**************************************************************************************************
 * @ingroup app-layer-power-control-properties-public
 * @var volatile struct PSFB_POWER_CONTROLLER_s psfb;
 * @brief Global data object for a PSFB Converter 
 * 
 * @details
 * The 'psfb' data object holds all status, control and monitoring values of the PSFB Converter
 * power controller. The PSFB_POWER_CONTROLLER_t data structure is defined in dev_psfb_converter.h.
 * Please refer to the comments on top of this file for further information.
 * 
 **************************************************************************************************/

volatile POWER_CONTROLLER_t buck_4ph;

/* PRIVATE FUNCTION PROTOTYPES */
uint16_t appPowerSupply_ConverterObjectInitialize(void);
uint16_t appPowerSupply_SwitchNodeInitialize(void);
uint16_t appPowerSupply_GpioInitialize(void);
uint16_t appPowerSupply_FeedbackInitialize(void);
uint16_t appPowerSupply_StartupInitialize(void);
uint16_t appPowerSupply_ControllerInitialize(void);
uint16_t appPowerSupply_PeripheralsInitialize(void);
uint16_t appPowerSupply_CustomFunctionInitialize(void);
uint16_t appPowerSupply_InterruptsInitialize(void);
uint16_t appPowerSupply_CurrentBalancing(void);

/* PRIVATE INTERNAL FUNCTION PROTOTYPES */
static uint16_t appPowerSupply_DataCapture(void);

static _Bool st_OverCurr = false;
static _Bool st_UnderVolt = false;

extern uint16_t CompVoltage;

uint32_t CounterRefreshTick = 0U;

/*******************************************************************************
 * @ingroup app-layer-power-control-functions-public
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief   Calls the application layer power controller initialization
 *  
 * @details
 * The power control application layer is the proprietary user code layer
 * used to tailor the generic power converter device driver to the specific 
 * hardware of this design. The initialization routine covers three levels
 * 
 * - Converter Object Configuration
 * - Controller Configuration
 * - Peripheral Set Configuration
 * - Interrupt Vector Configuration
 * 
 * Once all modules have been configured successfully, the power converter 
 * object is started with control loops and PWM outputs disabled. However, 
 * the PWM module will start triggering the ADC to allow the standby monitoring
 * of system conditions to allow the firmware to decide if it is safe to start
 * up the power converter. 
 * 
 *********************************************************************************/
uint16_t appPowerSupply_Initialize(void)
{ 
    uint16_t retval=1;

    // Run initialization sequence
    retval &= appPowerSupply_ConverterObjectInitialize();
    retval &= appPowerSupply_SwitchNodeInitialize();
    retval &= appPowerSupply_GpioInitialize();
    retval &= appPowerSupply_FeedbackInitialize();
    retval &= appPowerSupply_StartupInitialize();
    retval &= appPowerSupply_ControllerInitialize();
    retval &= appPowerSupply_PeripheralsInitialize();
    retval &= appPowerSupply_CustomFunctionInitialize();
    retval &= appPowerSupply_InterruptsInitialize();
   
    
    /* disable 200W */
    converterGPIO_Set(&buck_4ph.Gpio.Dis_U_200Watt);
    
    
    return(retval); 
}

/*******************************************************************************
 * @ingroup app-layer-power-control-functions-public
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief This is the top-level function call calling the most recent state machine response
 * 
 * @details
 * After initialization, the proprietary user code has to call this function 
 * on a deterministic, constant time base. In each execution step this function
 * will call the power control state machines of each supported/included power
 * supply unit. 
 * 
 *********************************************************************************/
uint16_t appPowerSupply_Execute(void)
{ 
    uint16_t retval=1;
    static uint16_t delay_counter = 0;
    static _Bool st_200W_EnaDone = false;


    /* check undervoltage condition */
    if(((buck_4ph.Data.Vin_phys > (CompVoltage + 200U)) && (st_UnderVolt == true)) && (st_OverCurr == false))
    {
        /* resume power supply */
        appPowerSupply_Resume();  
        
        /* clear undervoltage marker */
        st_UnderVolt = false;
        
        /* clear interrupt flags */
        CNFCbits.CNFC14 = 0U;
        IFS1bits.CNCIF = 0U;
    
        /* enable interrupt */
        IEC1bits.CNCIE = 1U;
    }
    else
    {
        /* do nothing */
    }
    
    // Capture data values, which are not captured by the controller automatically
    retval &= appPowerSupply_DataCapture();
    
    // Runs the current balancing loop only if the converter is active
    if (buck_4ph.StateId.bits.opstate_id >= CONVERTER_OPSTATE_RAMPUP)
    {
        retval &= appPowerSupply_CurrentBalancing();
    }
    
    // Execute Converter state machine
    retval &= drv_Converter_Execute(&buck_4ph);
        
    // Proprietary, application-/ hardware-specific state machine extensions.
    if (buck_4ph.StateId.bits.opstate_id >= CONVERTER_OPSTATE_ONLINE)
    {
        if(buck_4ph.Data.Vin >= VIN_REG_ERR_EN)
        {
            fltobj_Buck_RegErr.Status.bits.Enabled = true; // Enable regulation error fault 
        }
        else
        {
            fltobj_Buck_RegErr.Status.bits.Enabled = false; // Enable regulation error fault
        }
        
        
        if(st_200W_EnaDone == false)
        {
            if(delay_counter >= 500U)
            {
                /* enable 200W */
                converterGPIO_Clear(&buck_4ph.Gpio.Dis_U_200Watt);

                /* set marker */
                st_200W_EnaDone = true;

                delay_counter = 0;
            }
            else
            {
                delay_counter++;
            }
        }
        else
        {
            /* 200W driver already enabled - do nothing */
        }
    }
    else
    {
        delay_counter = 0;
        
        /* clear marker */
        st_200W_EnaDone = false;
        
        // Disable regulation error fault
        fltobj_Buck_RegErr.Status.bits.Enabled = false;
        
    }
 
    // Disable regulation error when the input voltage is too low and the duty is clamped at maximum
    if (buck_4ph.VLoop.controller->status.bits.upper_saturation_event)
    {
        fltobj_Buck_RegErr.Status.bits.FaultActive = 0;
        fltobj_Buck_RegErr.Status.bits.FaultStatus = 0;
        fltobj_Buck_RegErr.Status.bits.Enabled = false;
    }
    
    return(retval); 
}

/*******************************************************************************
 * @ingroup app-layer-power-control-functions-public
 * @return  Unsigned Integer (0=failure, 1=success)
 * 
 * @brief  This function calls the psfb converter device driver function dispose the power supply 
 *
 * @details
 * This function exposes the Power Converter dispose function of the device driver.
 * 
 *********************************************************************************/
uint16_t appPowerSupply_Dispose(void)
{ 
    uint16_t retval=1;
    
    buck_4ph.Status.value = 0;
    buck_4ph.Data.Vin = 0;
    buck_4ph.Data.Vout = 0;

    buck_4ph.StateId.value = (uint32_t)CONVERTER_OPSTATE_INITIALIZE; // Set state machine
    
    return(retval); 
}

/*******************************************************************************
 * @ingroup app-layer-power-control-functions-public
 * @return  Unsigned Integer (0=failure, 1=success)
 * 
 * @brief   This function calls the converter device driver function starting the power supply 
 *  
 * @details
 * This function exposes the Power Converter Start function of the device driver.
 * 
 *********************************************************************************/
uint16_t appPowerSupply_Start(void)
{ 
    uint16_t retval=1;
    
    retval = drv_Converter_Start(&buck_4ph);
    
    return(retval); 
}

/*******************************************************************************
 * @ingroup app-layer-power-control-functions-public
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief This function calls the psfb converter device driver function stopping the power supply 
 *  
 * @details
 *  This function exposes the Power Converter Stop function of the device driver.
 * 
 * @note
 *  The STOP function terminates the state machine and all peripherals used by
 *  the power controller. This includes the PWM and ADC peripheral modules and 
 *  will therefore also stop all data acquisition. 
 *  If you are trying to stop the power supply but keep its state machine and
 *  data acquisition running, use the SUSPEND function instead
 *********************************************************************************/
uint16_t appPowerSupply_Stop(void)
{ 
    uint16_t retval=1;

    retval = drv_Converter_Stop(&buck_4ph);

    return(retval); 
}

/*******************************************************************************
 * @ingroup app-layer-power-control-functions-public
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief This function stops the power supply operation
 *  
 * @details
 *  The SUSPEND function stops the power supply operation but keep its state machine
 *  and data acquisition running.
 *********************************************************************************/
uint16_t appPowerSupply_Suspend(void)
{ 
    uint16_t retval=1;

    /* disable 200W */
//    converterGPIO_Set(&buck_4ph.Gpio.Dis_U_200Watt);
    
    psfbPWM_Suspend(&buck_4ph);                    // Immediately turns off PWMs
    retval = drv_Converter_Suspend(&buck_4ph); // Shut down the Converter immediately

    return(retval); 
}

/*******************************************************************************
 * @ingroup app-layer-power-control-functions-public
 * @return  Unsigned Integer (0=failure, 1=success)
 *
 * @brief    This function resumes the power supply operation
 *  
 *@details
 *  This function calls the psfb converter device driver function recovering
 *  the power supply operation from a previously initiated shut-down.
 *********************************************************************************/
uint16_t appPowerSupply_Resume(void)
{ 
    uint16_t retval=0;
    
    retval = drv_Converter_Resume(&buck_4ph);  // Resume power supply operation
    
    return(retval); 
}

/* *************************************************************************************************
 * PRIVATE FUNCTIONS
 * ************************************************************************************************/

/*********************************************************************************
 * @ingroup app-layer-power-control-functions-private
 * @fn      uint16_t appPowerSupply_DataCapture(void)
 * @brief   Captures runtime data not captured automatically by other firmware modules
 * @return  unsigned integer (0=failure, 1=success)
 * @details
 *  Function appPowerSupply_DataCapture is used to capture runtime data from
 *  ADC inputs which are not used for direct control of the power supply and/or
 *  are used to calculate additional data which is required for system analysis
 *  functions such as fault management, system monitoring and/or communication. 
 * 
 **********************************************************************************/
static uint16_t appPowerSupply_DataCapture(void) 
{
    static uint8_t ct_TimeSliceTo1ms = 0x00U;
    uint16_t retval=1;
    
    if(ct_TimeSliceTo1ms >= 10U)
    {
        /* clear counter */
        ct_TimeSliceTo1ms = 0x00U;
        
        /* increment Refresh Tick counter - every 1ms */
        CounterRefreshTick++;
    }
    else
    {
        /* increment counter */
        ct_TimeSliceTo1ms++;
    }
    
    // Vout
    buck_4ph.Data.Vout = *buck_4ph.Feedback.ad_vout.adc_buffer;
    /* calculation of physical Vout Value [10mV] */
    buck_4ph.Data.Vout_phys =  (uint16_t)((uint32_t)((uint32_t)buck_4ph.Data.Vout * (uint32_t)VOUT_PHYS_CALC_FAC) >> 9U);
      
    // Vin
    buck_4ph.Data.Vin = *buck_4ph.Feedback.ad_vin.adc_buffer;
    /* calculation of physical Vin Value [10mV] */
    buck_4ph.Data.Vin_phys = (uint16_t)((uint32_t)((uint32_t)buck_4ph.Data.Vin * (uint32_t)VIN_PHYS_CALC_FAC) >> 9U);
       
    // V_dcdc
    buck_4ph.Data.V_dcdc = *buck_4ph.Feedback.ad_v_dcdc.adc_buffer;
    /* calculation of physical V_dcdc Value [10mV] */
    buck_4ph.Data.V_dcdc_phys = (uint16_t)((uint32_t)((uint32_t)buck_4ph.Data.V_dcdc * (uint32_t)V_DCDC_PHYS_CALC_FAC) >> 9U);
            
    //V_motor
    buck_4ph.Data.V_motor = *buck_4ph.Feedback.ad_v_motor.adc_buffer;
    /* calculation of physical V_motor Value [10mV] */
    buck_4ph.Data.V_motor_phys = (uint16_t)((uint32_t)((uint32_t)buck_4ph.Data.V_motor * (uint32_t)V_MOTOR_PHYS_CALC_FAC) >> 9U);
    
    //V_aux
    buck_4ph.Data.V_aux = *buck_4ph.Feedback.ad_v_aux.adc_buffer;
    /* calculation of physical V_aux Value [10mV] */
    buck_4ph.Data.V_aux_phys = (uint16_t)((uint32_t)((uint32_t)buck_4ph.Data.V_aux * (uint32_t)V_AUX_PHYS_CALC_FAC) >> 9U);
             
    //V_24V
    buck_4ph.Data.V_24volt = *buck_4ph.Feedback.ad_v_24volt.adc_buffer;
    /* calculation of physical V_24volt Value [10mV] */
    buck_4ph.Data.V_24volt_phys = (uint16_t)((uint32_t)((uint32_t)buck_4ph.Data.V_24volt * (uint32_t)V_24VOLT_PHYS_CALC_FAC) >> 9U);
    
    //Vin_prot
    buck_4ph.Data.Vin_prot = *buck_4ph.Feedback.ad_vin_prot.adc_buffer;
    /* calculation of physical Vin_prot Value [10mV] */
    buck_4ph.Data.Vin_prot_phys = (uint16_t)((uint32_t)((uint32_t)buck_4ph.Data.Vin_prot * (uint32_t)VIN_PROT_PHYS_CALC_FAC) >> 9U);
    
    //Ibuck1
    buck_4ph.Data.Ibuck1 = *buck_4ph.Feedback.ad_ibuck1.adc_buffer;  
    /* calculation of physical Ibuck1 Value [1mA] */
    buck_4ph.Data.Ibuck1_phys = (uint16_t)((uint32_t)((uint32_t)buck_4ph.Data.Ibuck1 * (uint32_t)ISNS_PHYS_CALC_FAC) >> 9U);
    
    //Ibuck2
    buck_4ph.Data.Ibuck2 = *buck_4ph.Feedback.ad_ibuck2.adc_buffer;
    /* calculation of physical Ibuck2 Value [1mA] */
    buck_4ph.Data.Ibuck2_phys = (uint16_t)((uint32_t)((uint32_t)buck_4ph.Data.Ibuck2 * (uint32_t)ISNS_PHYS_CALC_FAC) >> 9U);
    
    //Ibuck3
    buck_4ph.Data.Ibuck3 = *buck_4ph.Feedback.ad_ibuck3.adc_buffer;  
    /* calculation of physical Ibuck3 Value [1mA] */
    buck_4ph.Data.Ibuck3_phys = (uint16_t)((uint32_t)((uint32_t)buck_4ph.Data.Ibuck3 * (uint32_t)ISNS_PHYS_CALC_FAC) >> 9U);
    
    //Ibuck4
    buck_4ph.Data.Ibuck4 = *buck_4ph.Feedback.ad_ibuck4.adc_buffer; 
    /* calculation of physical Ibuck4 Value [1mA] */
    buck_4ph.Data.Ibuck4_phys = (uint16_t)((uint32_t)((uint32_t)buck_4ph.Data.Ibuck4 * (uint32_t)ISNS_PHYS_CALC_FAC) >> 9U);
    
    //I_200W
    buck_4ph.Data.I_200watt = *buck_4ph.Feedback.ad_i_200watt.adc_buffer;
    if(buck_4ph.Data.I_200watt >= 310U)
    {
    
        buck_4ph.Data.I_200watt_phys = (uint16_t)((uint32_t)((uint32_t)((uint32_t)buck_4ph.Data.I_200watt * (uint32_t)ISNS_200W_PHYS_CALC_FAC_K) - (uint32_t)ISNS_200W_PHYS_CALC_FAC_D) >> 9U);      
    }
    else
    {
        buck_4ph.Data.I_200watt_phys = 0U;
    }
    return(retval); 
}

/* @@<function_name>
 * ********************************************************************************
 * Summary:
 * 
 * Parameters:
 * 
 * Returns:
 * 
 * Description:
 * 
 * ********************************************************************************/
uint16_t appPowerSupply_CurrentBalancing(void) 
{
    uint16_t retval=1;
    static uint16_t ibuck1_tmp,ibuck2_tmp,ibuck3_tmp,ibuck4_tmp,scaler=0;
    
    buck_4ph.Balancing.IBuck1_iir+=(*buck_4ph.Balancing.ptrIBuck1Master)-(buck_4ph.Balancing.IBuck1_iir>>buck_4ph.Balancing.Iir_filter_lenght);
    buck_4ph.Balancing.IBuck2_iir+=(*buck_4ph.Balancing.ptrIBuck2Slave)-(buck_4ph.Balancing.IBuck2_iir>>buck_4ph.Balancing.Iir_filter_lenght);
    buck_4ph.Balancing.IBuck3_iir+=(*buck_4ph.Balancing.ptrIBuck3Slave)-(buck_4ph.Balancing.IBuck3_iir>>buck_4ph.Balancing.Iir_filter_lenght);
    buck_4ph.Balancing.IBuck4_iir+=(*buck_4ph.Balancing.ptrIBuck4Slave)-(buck_4ph.Balancing.IBuck4_iir>>buck_4ph.Balancing.Iir_filter_lenght);
    
    if(++scaler>=BALANCING_EXEC_SCALER)
    {
        scaler=0;
        
        // Currents filtered value
        ibuck1_tmp=(buck_4ph.Balancing.IBuck1_iir>>buck_4ph.Balancing.Iir_filter_lenght);
        ibuck2_tmp=(buck_4ph.Balancing.IBuck2_iir>>buck_4ph.Balancing.Iir_filter_lenght);
        ibuck3_tmp=(buck_4ph.Balancing.IBuck3_iir>>buck_4ph.Balancing.Iir_filter_lenght);
        ibuck4_tmp=(buck_4ph.Balancing.IBuck4_iir>>buck_4ph.Balancing.Iir_filter_lenght);

    #ifdef __WITH_PIL__
        //PilProbes.DEBUG1=ibuck2_tmp-ibuck1_tmp;
    #endif

        if(ibuck2_tmp>(ibuck1_tmp+BALANCING_HYST))
        {
            if(buck_4ph.Balancing.Buck2_dc_offset>buck_4ph.Balancing.Minimum_DC_offset)
            {
                buck_4ph.Balancing.Buck2_dc_offset--;
            }
        }
        else
        {
            if(ibuck2_tmp<(ibuck1_tmp-BALANCING_HYST))
            {
            if(buck_4ph.Balancing.Buck2_dc_offset<buck_4ph.Balancing.Maximum_DC_offset)
                {
                    buck_4ph.Balancing.Buck2_dc_offset++;
                }
            }
        }
        
        if(ibuck3_tmp>(ibuck1_tmp+BALANCING_HYST))
        {
            if(buck_4ph.Balancing.Buck3_dc_offset>buck_4ph.Balancing.Minimum_DC_offset)
            {
                buck_4ph.Balancing.Buck3_dc_offset--;
            }
        }
        else
        {
            if(ibuck3_tmp<(ibuck1_tmp-BALANCING_HYST))
            {
            if(buck_4ph.Balancing.Buck3_dc_offset<buck_4ph.Balancing.Maximum_DC_offset)
                {
                    buck_4ph.Balancing.Buck3_dc_offset++;
                }
            }
        }
        
        if(ibuck4_tmp>(ibuck1_tmp+BALANCING_HYST))
        {
            if(buck_4ph.Balancing.Buck4_dc_offset>buck_4ph.Balancing.Minimum_DC_offset)
            {
                buck_4ph.Balancing.Buck4_dc_offset--;
            }
        }
        else
        {
            if(ibuck4_tmp<(ibuck1_tmp-BALANCING_HYST))
            {
            if(buck_4ph.Balancing.Buck4_dc_offset<buck_4ph.Balancing.Maximum_DC_offset)
                {
                    buck_4ph.Balancing.Buck4_dc_offset++;
                }
            }
        }
    }
    
    return(retval);
    
//    isns0_iir+=buck.data.i_sns[0]-(isns0_iir>>8);
//    isns0=(isns0_iir>>8);
//    
//    isns1_iir+=buck.data.i_sns[1]-(isns1_iir>>8);
//    isns1=(isns1_iir>>8);
//    
//    // Current balancing is only executed in nominal running mode
//    if(buck.mode != BUCK_STATE_ONLINE) 
//        return;
//    
//    // if current in phase #1 is higher than phase current #2...
//    if(isns0 > isns1) 
//    { // .. add 1 tick to phase #2 duty cycle
//        if(offset<8)
//        {
//            offset++;
//        }
//        //offset = ((++offset>0x07) ? 0x07 : offset);
//    }
//    else 
//    {    
//        if(isns1 > isns0)
//        { // .. sub 1 tick from phase #2 duty cycle
//            if(offset>-8)
//            {
//                offset--;
//            }
//            //offset = ((--offset<0x00) ? 0x00 : offset);
//        }
//    }
//
//    // TODO remove just a double check
//    if(offset>8 || offset<-8)
//    {
//        offset=0;
//    }
//    
//    buck.v_loop.controller->Ports.AltTarget.Offset = (uint16_t)offset;

}

// ________________________
// end of file

void __attribute__((interrupt, no_auto_psv)) _CMP2Interrupt(void) 
{
    /* check comparator state */
    if(DAC2CONLbits.CMPSTAT == 1)
    {
        /* immediately shut off of all PWMs */
        appPowerSupply_Suspend();
        
        /* set marker for overcurrent event triggered */
        st_OverCurr = true;
    }
    
    /* clear interrupt flag */
    IFS4bits.CMP2IF = 0;  
}


void __attribute__((interrupt, no_auto_psv)) _CNCInterrupt(void) 
{

    /* immediately shut off of all PWMs */
    appPowerSupply_Suspend(); 
    
    /* set marker for undervoltage detection */
    st_UnderVolt = true;
    
    /* set Vin Voltage exact to comparator voltage to avoid disturbance */
    buck_4ph.Data.Vin_phys = CompVoltage;
    
    /* clear interrupt flags */
    CNFCbits.CNFC14 = 0U;
    IFS1bits.CNCIF = 0U;
    
    /* disable interrupt */
    IEC1bits.CNCIE = 0U;
}
