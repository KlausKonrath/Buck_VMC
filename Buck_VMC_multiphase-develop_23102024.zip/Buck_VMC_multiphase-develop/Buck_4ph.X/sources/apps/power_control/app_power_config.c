/*
 * @file   app_power_config.c
 * @author M91406
 *
 * Created on November 9, 2020, 2:53 PM
 */

#include <xc_pral.h>
#include "config/hal.h" // include hardware abstraction layer
#include "./app_power_control.h"
#include "./devices/dev_buck_4ph_typedef.h"   // include  Converter type definitions
#include "./devices/dev_psfb_converter.h" // include  Converter object header
#include "./devices/dev_psfb_pconfig.h"
#include "./drivers/vout_loop_vmc.h"   
#include "./drivers/vout_loop_agc.h"   
#include "./drivers/buck_4ph_register_update.h"   

#include "common/p33c_flib/moving_average.h"

#ifdef __WITH_PIL__
#include "pil/pil_main.h"

#endif


/***********************************************************************************
 * @ingroup app-layer-power-control-functions-private
 * @param	None
 * @brief  This function initializes the  converter device driver instance
 * @return unsigned integer (0=failure, 1=success)
 *  
 * @details
 *  This function initialize the  converter object status, reset the converter state 
 *  machine, set reference values, clear the runtime data, initialize the switch node,
 *  and setup the feedback channels and start-up settings.
 **********************************************************************************/
uint16_t appPowerSupply_ConverterObjectInitialize(void)
{
    uint16_t retval = 1;
        
    // Initialize PSFB Converter Object Status
    buck_4ph.Status.bits.adc_active = false; ///< Clear ADC STARTED flag
    buck_4ph.Status.bits.pwm_active = false; ///< Clear PWM STARTED flag
    buck_4ph.Status.bits.fault_active = true; ///< Set global FAULT flag
    buck_4ph.Status.bits.cs_calib_complete = false; ///< Clear Current Sense Calibration Ready flag bit
    buck_4ph.Status.bits.cs_calib_enable = false; ///< Disable current sense calibration 
    buck_4ph.Status.bits.autorun = true;    ///< Allow the PSFB PFC Converter to start automatically when cleared of faults. 
    buck_4ph.Status.bits.Enabled = false;   ///< Disable PSFB Converter
    buck_4ph.Status.bits.suspend = true;    ///< Set SUSPEND flag bit to keep power supply on hold until startup conditions are cleared
    
    // Set Initial State Machine State
    buck_4ph.StateId.value = (uint32_t)CONVERTER_OPSTATE_INITIALIZE; ///< Reset PSFB State Machine
    
    // Set Reference values -> 26 Volt
    buck_4ph.SetValues.v_ref = VOUT_NOM; // Set voltage loop reference
    
    // Reset duty cycle offset values
    buck_4ph.Balancing.Buck2_dc_offset=0;
    buck_4ph.Balancing.Buck3_dc_offset=0;
    buck_4ph.Balancing.Buck4_dc_offset=0;
    
    // Clear Runtime Data
    buck_4ph.Data.Vout = 0;  
    buck_4ph.Data.Vin = VIN_UVLO_TRIP;
    buck_4ph.Data.V_dcdc = 0;
    buck_4ph.Data.V_motor = 0;
    buck_4ph.Data.V_aux = 0;
    buck_4ph.Data.V_24volt = 0;
    buck_4ph.Data.I_200watt = 0;
    buck_4ph.Data.Ibuck1 = 0;    
    buck_4ph.Data.Ibuck2 = 0;     
    buck_4ph.Data.Ibuck3 = 0;     
    buck_4ph.Data.Ibuck4 = 0;
    
    // Clear physical Runtime Data
    buck_4ph.Data.Vout_phys = 0;  
    buck_4ph.Data.Vin_phys = 0;
    buck_4ph.Data.V_dcdc_phys = 0;
    buck_4ph.Data.V_motor_phys = 0;
    buck_4ph.Data.V_aux_phys = 0;
    buck_4ph.Data.V_24volt_phys = 0;
    buck_4ph.Data.I_200watt_phys = 0;
    buck_4ph.Data.Ibuck1_phys = 0;    
    buck_4ph.Data.Ibuck2_phys = 0;     
    buck_4ph.Data.Ibuck3_phys = 0;     
    buck_4ph.Data.Ibuck4_phys = 0;  

    return(retval);
    
}

/*******************************************************************************
 * @ingroup app-layer-power-control-functions-private
 * @brief  This function initializes the switch node of the buck converter device driver instance 
 * @return unsigned integer (0=failure, 1=success)
 *  
 * @details
 *  This function initializes the switch node of the buck converter object by 
 *  assigning it to a specific PWM generator instance and setting the associated 
 *  GPIO pins. Further, users need to specify basic parameters like commutation 
 *  mode (synchronous or asynchronous drive), switching frequency, phase shift,
 *  duty ratio clamping values, dead times, leading edge blanking and ADC 
 *  trigger offsets to compensate propagation delays of FET drivers and feedback
 *  bandwidth limitations.
 *********************************************************************************/
uint16_t appPowerSupply_SwitchNodeInitialize(void)
{
    uint16_t retval = 1;
    
    // Initialize switch node for buck #1
    buck_4ph.SwNode1.pwm_instance = PWM1H.Properties.PG;
    buck_4ph.SwNode1.sync_drive = true;
    buck_4ph.SwNode1.dac_instance = 1;  // Same comparator is used to turn off all PWMs
    buck_4ph.SwNode1.dac_threshold = ISNS_OCP_TRIP;
    buck_4ph.SwNode1.gpio_instance = PWM1H.Properties.Port;
    buck_4ph.SwNode1.gpio_high = PWM1H.Properties.Pin;

    if (buck_4ph.SwNode1.sync_drive)
    {
        buck_4ph.SwNode1.gpio_low = PWM1L.Properties.Pin;
        buck_4ph.SwNode1.dead_time_rising = BUCK_DEAD_TIME_LE;
        buck_4ph.SwNode1.dead_time_falling = BUCK_DEAD_TIME_FE;
    }
    else
    {
        buck_4ph.SwNode1.dead_time_rising = 0;
        buck_4ph.SwNode1.dead_time_falling = 0;
    }
    
    buck_4ph.SwNode1.master_period_enable = false;
    buck_4ph.SwNode1.Period = PWM_PERIOD;
    buck_4ph.SwNode1.PhaseShift_TrigA_Init = PWM_PERIOD/NO_OF_PHASES; // Used to trigger PWM2 start of cycle
    buck_4ph.SwNode1.LebPeriod = BUCK_LEB_PERIOD;
    buck_4ph.SwNode1.trigger_offset = SAMPLING_OFFSET;
    buck_4ph.SwNode1.trigger_scaler = SAMPLING_DIVIDER;
    buck_4ph.SwNode1.high_resolution_enable = PWM_CLOCK_HIGH_RESOLUTION;    
    
    // Initialize switch node for buck #2
    buck_4ph.SwNode2.pwm_instance = PWM2H.Properties.PG;
    buck_4ph.SwNode2.sync_drive = true;
    buck_4ph.SwNode2.dac_instance = 1;
    buck_4ph.SwNode2.gpio_instance = PWM2H.Properties.Port;
    buck_4ph.SwNode2.gpio_high = PWM2H.Properties.Pin;

    if (buck_4ph.SwNode2.sync_drive)
    {
        buck_4ph.SwNode2.gpio_low = PWM2L.Properties.Pin;
        buck_4ph.SwNode2.dead_time_rising = BUCK_DEAD_TIME_LE;
        buck_4ph.SwNode2.dead_time_falling = BUCK_DEAD_TIME_FE;
    }
    else
    {
        buck_4ph.SwNode2.dead_time_rising = 0;
        buck_4ph.SwNode2.dead_time_falling = 0;
    }
    
    buck_4ph.SwNode2.master_period_enable = false;
    buck_4ph.SwNode2.Period = PWM_PERIOD;
    buck_4ph.SwNode2.PhaseShift_TrigA_Init = (PWM_PERIOD/NO_OF_PHASES); // Used to trigger PWM3 start of cycle
    buck_4ph.SwNode2.LebPeriod = BUCK_LEB_PERIOD;
    buck_4ph.SwNode2.trigger_offset = SAMPLING_OFFSET;
    buck_4ph.SwNode2.trigger_scaler = SAMPLING_DIVIDER;
    buck_4ph.SwNode2.high_resolution_enable = PWM_CLOCK_HIGH_RESOLUTION; 
    
    // Initialize switch node for buck #3
    buck_4ph.SwNode3.pwm_instance = PWM3H.Properties.PG; 
    buck_4ph.SwNode3.sync_drive = true;
    buck_4ph.SwNode3.dac_instance = 1;
    buck_4ph.SwNode3.gpio_instance = PWM3H.Properties.Port;
    buck_4ph.SwNode3.gpio_high = PWM3H.Properties.Pin;

    if (buck_4ph.SwNode3.sync_drive)
    {
        buck_4ph.SwNode3.gpio_low = PWM3L.Properties.Pin;
        buck_4ph.SwNode3.dead_time_rising = BUCK_DEAD_TIME_LE;
        buck_4ph.SwNode3.dead_time_falling = BUCK_DEAD_TIME_FE;
    }
    else
    {
        buck_4ph.SwNode3.dead_time_rising = 0;
        buck_4ph.SwNode3.dead_time_falling = 0;
    }
    
    buck_4ph.SwNode3.master_period_enable = false;
    buck_4ph.SwNode3.Period = PWM_PERIOD;
    buck_4ph.SwNode3.PhaseShift_TrigA_Init = (PWM_PERIOD/NO_OF_PHASES); // Used to trigger PWM4 start of cycle
    buck_4ph.SwNode3.LebPeriod = BUCK_LEB_PERIOD;
    buck_4ph.SwNode3.trigger_offset = SAMPLING_OFFSET;
    buck_4ph.SwNode3.trigger_scaler = SAMPLING_DIVIDER;
    buck_4ph.SwNode3.high_resolution_enable = PWM_CLOCK_HIGH_RESOLUTION; 
    
    // Initialize switch node for buck #4
    buck_4ph.SwNode4.pwm_instance = PWM4H.Properties.PG; 
    buck_4ph.SwNode4.sync_drive = true;
    buck_4ph.SwNode4.dac_instance = 1;
    buck_4ph.SwNode4.gpio_instance = PWM4H.Properties.Port;
    buck_4ph.SwNode4.gpio_high = PWM4H.Properties.Pin;

    if (buck_4ph.SwNode4.sync_drive)
    {
        buck_4ph.SwNode4.gpio_low = PWM4L.Properties.Pin;
        buck_4ph.SwNode4.dead_time_rising = BUCK_DEAD_TIME_LE;
        buck_4ph.SwNode4.dead_time_falling = BUCK_DEAD_TIME_FE;
    }
    else
    {
        buck_4ph.SwNode4.dead_time_rising = 0;
        buck_4ph.SwNode4.dead_time_falling = 0;
    }
    
    buck_4ph.SwNode4.master_period_enable = false;
    buck_4ph.SwNode4.Period = PWM_PERIOD;
    buck_4ph.SwNode4.PhaseShift_TrigA_Init = 0; // Not used
    buck_4ph.SwNode4.LebPeriod = BUCK_LEB_PERIOD;
    buck_4ph.SwNode4.trigger_offset = SAMPLING_OFFSET;
    buck_4ph.SwNode4.trigger_scaler = SAMPLING_DIVIDER;
    buck_4ph.SwNode4.high_resolution_enable = PWM_CLOCK_HIGH_RESOLUTION; 
    
    return(retval);
    
}

/*******************************************************************************
 * @ingroup app-layer-power-control-functions-private
 * @brief  This function initializes the IO functions of the buck converter device driver instance 
 * @return unsigned integer (0=failure, 1=success)
 *  
 * @details
 *  This function initializes the optional Input/Output functions of the buck
 *  converter device driver instance used to provide external sequencing control,
 *  such as ENABLE Input and Power Good Output. These optional features can be 
 *  individually enabled and mapped to any available device GPIO.
 *********************************************************************************/
uint16_t appPowerSupply_GpioInitialize(void)
{
    uint16_t retval = 1;

    // Initialize additional GPIOs 
    
    // ~~~ PowerGood_5V_Buck ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    buck_4ph.Gpio.PowerGood_5V_Buck.Enabled = true;                     // this converter  support external enable control
    buck_4ph.Gpio.PowerGood_5V_Buck.IoPin = PGOOD_5V_BUCK;              // Device GPIO object
    buck_4ph.Gpio.PowerGood_5V_Buck.Polarity = 0;                       // This pin is ACTIVE HIGH (only required if io_type = OUTPUT)
    buck_4ph.Gpio.PowerGood_5V_Buck.IoType = 1;                         // This pin is configured as INPUT
    // ~~~ PowerGood_5V_Buck END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // ~~~ PowerGood_FC_Dart_Buck ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    buck_4ph.Gpio.PowerGood_FC_Dart_Buck.Enabled = true;                // This converter supports an additional POWER GOOD output
    buck_4ph.Gpio.PowerGood_FC_Dart_Buck.IoPin = PGOOD_FC_DART_BUCK;
    buck_4ph.Gpio.PowerGood_FC_Dart_Buck.Polarity = 0;                  // This pin is ACTIVE HIGH (only required if I/O Type = OUTPUT)
     buck_4ph.Gpio.PowerGood_FC_Dart_Buck.IoType = 1;                   // This pin is configured as INPUT
    // ~~~ PowerGood_FC_Dart_Buck END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // ~~~ PowerGood_Aux_Buck ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    buck_4ph.Gpio.PowerGood_Aux_Buck.Enabled = true;                    // This converter supports an additional POWER GOOD output
    buck_4ph.Gpio.PowerGood_Aux_Buck.IoPin = PGOOD_AUX_BUCK;
    buck_4ph.Gpio.PowerGood_Aux_Buck.Polarity = 0;                      // This pin is ACTIVE HIGH (only required if I/O Type = OUTPUT)
    buck_4ph.Gpio.PowerGood_Aux_Buck.IoType = 1;                        // This pin is configured as INPUT
    // ~~~ PowerGood_Aux_Buck END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
    
    // ~~~ PowerGood_200Watt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    buck_4ph.Gpio.PowerGood_200Watt.Enabled = true;                     // This converter supports an additional POWER GOOD output
    buck_4ph.Gpio.PowerGood_200Watt.IoPin = PGOOD_200WATT;
    buck_4ph.Gpio.PowerGood_200Watt.Polarity = 0;                       // This pin is ACTIVE HIGH (only required if I/O Type = OUTPUT)
    buck_4ph.Gpio.PowerGood_200Watt.IoType = 1;                         // This pin is configured as INPUT
    // ~~~ PowerGood_200Watt END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
    
    // ~~~ Variant ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    buck_4ph.Gpio.Variant.Enabled = true;                               // This converter supports an additional POWER GOOD output
    buck_4ph.Gpio.Variant.IoPin = VARIANT;
    buck_4ph.Gpio.Variant.Polarity = 0;                                 // This pin is ACTIVE HIGH (only required if I/O Type = OUTPUT)
    buck_4ph.Gpio.Variant.IoType = 1;                                   // This pin is configured as INPUT
    // ~~~ Variant END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
    
    // ~~~ Sync_200Watt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    buck_4ph.Gpio.Sync_200Watt.Enabled = true;                          // this converter  support external enable control
    buck_4ph.Gpio.Sync_200Watt.IoPin = SYNC_200WATT;                    // Device GPIO object
    buck_4ph.Gpio.Sync_200Watt.Polarity = 0;                            // This pin is ACTIVE HIGH (only required if io_type = OUTPUT)
    buck_4ph.Gpio.Sync_200Watt.IoType = 0;                              // This pin is configured as OUTPUT
    // ~~~ Sync_200Watt END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // ~~~ Dis_U_200Watt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    buck_4ph.Gpio.Dis_U_200Watt.Enabled = true;                         // this converter  support external enable control
    buck_4ph.Gpio.Dis_U_200Watt.IoPin = DIS_U_200WATT;                  // Device GPIO object
    buck_4ph.Gpio.Dis_U_200Watt.Polarity = 0;                           // This pin is ACTIVE HIGH (only required if io_type = OUTPUT)
    buck_4ph.Gpio.Dis_U_200Watt.IoType = 0;                             // This pin is configured as OUTPUT
    // ~~~ Dis_U_200Watt END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // ~~~ EN_Inrush OUTPUT ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    buck_4ph.Gpio.EN_Inrush.Enabled = true; 
    buck_4ph.Gpio.EN_Inrush.IoPin = EN_INRUSH;
    buck_4ph.Gpio.EN_Inrush.Polarity = 0;                               // This pin is ACTIVE HIGH (only required if I/O Type = OUTPUT)
    buck_4ph.Gpio.EN_Inrush.IoType = 0;                                 // This pin is configured as OUTPUT
    // ~~~ EN_Inrush OUTPUT END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // ~~~ EN_Bypass OUTPUT ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    buck_4ph.Gpio.EN_Bypass.Enabled = true; 
    buck_4ph.Gpio.EN_Bypass.IoPin = EN_BYPASS;
    buck_4ph.Gpio.EN_Bypass.Polarity = 0;                               // This pin is ACTIVE HIGH (only required if I/O Type = OUTPUT)
    buck_4ph.Gpio.EN_Bypass.IoType = 0;                                 // This pin is configured as OUTPUT
    // ~~~ EN_Bypass OUTPUT END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // ~~~ EN_DCDC_Inrush OUTPUT ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    buck_4ph.Gpio.EN_DCDC_Inrush.Enabled = true; 
    buck_4ph.Gpio.EN_DCDC_Inrush.IoPin = EN_DCDC_INRUSH;
    buck_4ph.Gpio.EN_DCDC_Inrush.Polarity = 0;                          // This pin is ACTIVE HIGH (only required if I/O Type = OUTPUT)
    buck_4ph.Gpio.EN_DCDC_Inrush.IoType = 0;                            // This pin is configured as OUTPUT
    // ~~~ EN_DCDC_Inrush OUTPUT END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // ~~~ EN_DCDC_Idealdiode OUTPUT ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    buck_4ph.Gpio.EN_DCDC_Idealdiode.Enabled = true; 
    buck_4ph.Gpio.EN_DCDC_Idealdiode.IoPin = EN_DCDC_IDEAL_DIODE;
    buck_4ph.Gpio.EN_DCDC_Idealdiode.Polarity = 0;                      // This pin is ACTIVE HIGH (only required if I/O Type = OUTPUT)
    buck_4ph.Gpio.EN_DCDC_Idealdiode.IoType = 0;                        // This pin is configured as OUTPUT
    // ~~~ EN_DCDC_Idealdiode OUTPUT END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // ~~~ V_Comparator ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    buck_4ph.Gpio.V_Comparator.Enabled = true;                               // This converter supports an additional POWER GOOD output
    buck_4ph.Gpio.V_Comparator.IoPin = V_COMP;
    buck_4ph.Gpio.V_Comparator.Polarity = 0;                                 // This pin is ACTIVE HIGH (only required if I/O Type = OUTPUT)
    buck_4ph.Gpio.V_Comparator.IoType = 1;                                   // This pin is configured as INPUT
    // ~~~ V_Comparator END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 
    return(retval);
    
}

/*******************************************************************************
 * @ingroup app-layer-power-control-functions-private
 * @brief  This function initializes the feedback channels of the buck converter device driver instance 
 * @return unsigned integer (0=failure, 1=success)
 *  
 * @details
 *  This function initializes the supported feedback channels of the buck
 *  converter device driver instance used for system monitoring and control.
 *  A buck converter instance supports the following standard feedback 
 *  channels:
 * 
 * - Input Voltage:    (used for protection and advanced linearization control)
 * - Output Voltage:   (used for output voltage control)
 * - Inductor Current
 * - Temperature
 * 
 *********************************************************************************/
uint16_t appPowerSupply_FeedbackInitialize(void)
{
    uint16_t retval = 1;

    // Initialize Feedback Channels
    
    // ~~~ I-200W FEEDBACK ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    buck_4ph.Feedback.ad_i_200watt.enabled = true;   // Use this channel

    buck_4ph.Feedback.ad_i_200watt.adc_input = I_200WATT.Properties.ADCAN;
    buck_4ph.Feedback.ad_i_200watt.adc_core = I_200WATT.Properties.ADCORE;
    buck_4ph.Feedback.ad_i_200watt.trigger_source = I_200WATT_TRGSRC;
    buck_4ph.Feedback.ad_i_200watt.gpio_instance = I_200WATT.Properties.Port;

    #ifdef __WITH_PIL__
//    buck_4ph.Feedback.ad_i_200watt.adc_buffer = &PilProbes.V_dcdc;
    #else 
    buck_4ph.Feedback.ad_i_200watt.adc_buffer = p33c_Gpio_GetAnalogInputBuffer(I_200WATT.Properties.ADCAN);
    #endif

    buck_4ph.Feedback.ad_i_200watt.differential_input = false;
    buck_4ph.Feedback.ad_i_200watt.interrupt_enable = true;
    buck_4ph.Feedback.ad_i_200watt.early_interrupt_enable = true;
    buck_4ph.Feedback.ad_i_200watt.level_trigger = true;
    buck_4ph.Feedback.ad_i_200watt.signed_result = false;
    
    if (p33c_Gpio_IsAnalog(&I_200WATT)) I_200WATT.Methods.SetAnalog();
    else I_200WATT.Methods.SetDigital();
    
    // ~~~ I-200W FEEDBACK END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // ~~~ 24V VOLTAGE FEEDBACK ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    buck_4ph.Feedback.ad_v_24volt.enabled = true;   // Use this channel

    buck_4ph.Feedback.ad_v_24volt.adc_input = V_24VOLT.Properties.ADCAN;
    buck_4ph.Feedback.ad_v_24volt.adc_core = V_24VOLT.Properties.ADCORE;
    buck_4ph.Feedback.ad_v_24volt.trigger_source = V_24VOLT_TRGSRC;
    buck_4ph.Feedback.ad_v_24volt.gpio_instance = V_24VOLT.Properties.Port;

    #ifdef __WITH_PIL__
//    buck_4ph.Feedback.ad_v_24volt.adc_buffer = &PilProbes.V_dcdc;
    #else 
    buck_4ph.Feedback.ad_v_24volt.adc_buffer = p33c_Gpio_GetAnalogInputBuffer(V_24VOLT.Properties.ADCAN);
    #endif

    buck_4ph.Feedback.ad_v_24volt.differential_input = false;
    buck_4ph.Feedback.ad_v_24volt.interrupt_enable = true;
    buck_4ph.Feedback.ad_v_24volt.early_interrupt_enable = true;
    buck_4ph.Feedback.ad_v_24volt.level_trigger = true;
    buck_4ph.Feedback.ad_v_24volt.signed_result = false;
    
    if (p33c_Gpio_IsAnalog(&V_24VOLT)) V_24VOLT.Methods.SetAnalog();
    else V_24VOLT.Methods.SetDigital();
    
    // ~~~ 24V VOLTAGE FEEDBACK END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // ~~~ AUX VOLTAGE FEEDBACK ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    buck_4ph.Feedback.ad_v_aux.enabled = true;   // Use this channel

    buck_4ph.Feedback.ad_v_aux.adc_input = V_AUX.Properties.ADCAN;
    buck_4ph.Feedback.ad_v_aux.adc_core = V_AUX.Properties.ADCORE;
    buck_4ph.Feedback.ad_v_aux.trigger_source = V_AUX_TRGSRC;
    buck_4ph.Feedback.ad_v_aux.gpio_instance = V_AUX.Properties.Port;

    #ifdef __WITH_PIL__
//    buck_4ph.Feedback.ad_v_aux.adc_buffer = &PilProbes.V_dcdc;
    #else 
    buck_4ph.Feedback.ad_v_aux.adc_buffer = p33c_Gpio_GetAnalogInputBuffer(V_AUX.Properties.ADCAN);
    #endif

    buck_4ph.Feedback.ad_v_aux.differential_input = false;
    buck_4ph.Feedback.ad_v_aux.interrupt_enable = true;
    buck_4ph.Feedback.ad_v_aux.early_interrupt_enable = true;
    buck_4ph.Feedback.ad_v_aux.level_trigger = true;
    buck_4ph.Feedback.ad_v_aux.signed_result = false;
    
    if (p33c_Gpio_IsAnalog(&V_AUX)) V_AUX.Methods.SetAnalog();
    else V_AUX.Methods.SetDigital();
    
    // ~~~ AUX VOLTAGE FEEDBACK END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    
    // ~~~ MOTOR VOLTAGE FEEDBACK ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    buck_4ph.Feedback.ad_v_motor.enabled = true;   // Use this channel

    buck_4ph.Feedback.ad_v_motor.adc_input = V_MOTOR.Properties.ADCAN;
    buck_4ph.Feedback.ad_v_motor.adc_core = V_MOTOR.Properties.ADCORE;
    buck_4ph.Feedback.ad_v_motor.trigger_source = V_MOTOR_TRGSRC;
    buck_4ph.Feedback.ad_v_motor.gpio_instance = V_MOTOR.Properties.Port;

    #ifdef __WITH_PIL__
//    buck_4ph.Feedback.ad_v_motor.adc_buffer = &PilProbes.V_dcdc;
    #else 
    buck_4ph.Feedback.ad_v_motor.adc_buffer = p33c_Gpio_GetAnalogInputBuffer(V_MOTOR.Properties.ADCAN);
    #endif

    buck_4ph.Feedback.ad_v_motor.differential_input = false;
    buck_4ph.Feedback.ad_v_motor.interrupt_enable = true;
    buck_4ph.Feedback.ad_v_motor.early_interrupt_enable = true;
    buck_4ph.Feedback.ad_v_motor.level_trigger = true;
    buck_4ph.Feedback.ad_v_motor.signed_result = false;
    
    if (p33c_Gpio_IsAnalog(&V_MOTOR)) V_MOTOR.Methods.SetAnalog();
    else V_MOTOR.Methods.SetDigital();
    
    // ~~~ MOTOR VOLTAGE FEEDBACK END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // ~~~ DCDC VOLTAGE FEEDBACK ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    buck_4ph.Feedback.ad_v_dcdc.enabled = true;   // Use this channel

    buck_4ph.Feedback.ad_v_dcdc.adc_input = V_DCDC.Properties.ADCAN;
    buck_4ph.Feedback.ad_v_dcdc.adc_core = V_DCDC.Properties.ADCORE;
    buck_4ph.Feedback.ad_v_dcdc.trigger_source = V_DCDC_TRGSRC;
    buck_4ph.Feedback.ad_v_dcdc.gpio_instance = V_DCDC.Properties.Port;

    #ifdef __WITH_PIL__
//    buck_4ph.Feedback.ad_v_dcdc.adc_buffer = &PilProbes.V_dcdc;
    #else 
    buck_4ph.Feedback.ad_v_dcdc.adc_buffer = p33c_Gpio_GetAnalogInputBuffer(V_DCDC.Properties.ADCAN);
    #endif

    buck_4ph.Feedback.ad_v_dcdc.differential_input = false;
    buck_4ph.Feedback.ad_v_dcdc.interrupt_enable = true;
    buck_4ph.Feedback.ad_v_dcdc.early_interrupt_enable = true;
    buck_4ph.Feedback.ad_v_dcdc.level_trigger = true;
    buck_4ph.Feedback.ad_v_dcdc.signed_result = false;
    
    if (p33c_Gpio_IsAnalog(&V_DCDC)) V_DCDC.Methods.SetAnalog();
    else V_DCDC.Methods.SetDigital();
    
    // ~~~ DCDC VOLTAGE FEEDBACK END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // ~~~ PROTECTED INPUT VOLTAGE FEEDBACK ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    buck_4ph.Feedback.ad_vin_prot.enabled = true;   // Use this channel

    buck_4ph.Feedback.ad_vin_prot.adc_input = VIN_PROT.Properties.ADCAN;
    buck_4ph.Feedback.ad_vin_prot.adc_core = VIN_PROT.Properties.ADCORE;
    buck_4ph.Feedback.ad_vin_prot.trigger_source = VIN_PROT_TRGSRC;
    buck_4ph.Feedback.ad_vin_prot.gpio_instance = VIN_PROT.Properties.Port;

    #ifdef __WITH_PIL__
    buck_4ph.Feedback.ad_vin_prot.adc_buffer = &PilProbes.Vin_prot;
    #else 
    buck_4ph.Feedback.ad_vin_prot.adc_buffer = p33c_Gpio_GetAnalogInputBuffer(VIN_PROT.Properties.ADCAN);
    #endif

    buck_4ph.Feedback.ad_vin_prot.differential_input = false;
    buck_4ph.Feedback.ad_vin_prot.interrupt_enable = true;
    buck_4ph.Feedback.ad_vin_prot.early_interrupt_enable = true;
    buck_4ph.Feedback.ad_vin_prot.level_trigger = true;
    buck_4ph.Feedback.ad_vin_prot.signed_result = false;
    
    if (p33c_Gpio_IsAnalog(&VIN_PROT)) VIN_PROT.Methods.SetAnalog();
    else VIN_PROT.Methods.SetDigital();
    
    // ~~~ PROTECTED INPUT VOLTAGE FEEDBACK END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // ~~~ INPUT VOLTAGE FEEDBACK ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    buck_4ph.Feedback.ad_vin.enabled = true;   // Use this channel

    buck_4ph.Feedback.ad_vin.adc_input = VIN.Properties.ADCAN;
    buck_4ph.Feedback.ad_vin.adc_core = VIN.Properties.ADCORE;
    buck_4ph.Feedback.ad_vin.trigger_source = VIN_TRGSRC;
    buck_4ph.Feedback.ad_vin.gpio_instance = VIN.Properties.Port;

    #ifdef __WITH_PIL__
    buck_4ph.Feedback.ad_vin.adc_buffer = &PilProbes.Vin;
    #else 
    buck_4ph.Feedback.ad_vin.adc_buffer = p33c_Gpio_GetAnalogInputBuffer(VIN.Properties.ADCAN);
    #endif

    buck_4ph.Feedback.ad_vin.differential_input = false;
    buck_4ph.Feedback.ad_vin.interrupt_enable = true;
    buck_4ph.Feedback.ad_vin.early_interrupt_enable = true;
    buck_4ph.Feedback.ad_vin.level_trigger = true;
    buck_4ph.Feedback.ad_vin.signed_result = false;
    
    if (p33c_Gpio_IsAnalog(&VIN)) VIN.Methods.SetAnalog();
    else VIN.Methods.SetDigital();
    
    // ~~~ INPUT VOLTAGE FEEDBACK END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // ~~~ OUTPUT VOLTAGE FEEDBACK ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    buck_4ph.Feedback.ad_vout.enabled = true;   // Use this channel

    buck_4ph.Feedback.ad_vout.adc_input = VOUT.Properties.ADCAN;
    buck_4ph.Feedback.ad_vout.adc_core = VOUT.Properties.ADCORE;
    buck_4ph.Feedback.ad_vout.trigger_source = VOUT_TRGSRC;
    buck_4ph.Feedback.ad_vout.gpio_instance = VOUT.Properties.Port;

    #ifdef __WITH_PIL__
    buck_4ph.Feedback.ad_vout.adc_buffer = &PilProbes.Vout;
    #else 
    buck_4ph.Feedback.ad_vout.adc_buffer = p33c_Gpio_GetAnalogInputBuffer(VOUT.Properties.ADCAN);
    #endif

    buck_4ph.Feedback.ad_vout.differential_input = false;
    buck_4ph.Feedback.ad_vout.interrupt_enable = true;
    buck_4ph.Feedback.ad_vout.early_interrupt_enable = true;
    buck_4ph.Feedback.ad_vout.level_trigger = true;
    buck_4ph.Feedback.ad_vout.signed_result = false;
    
    if (p33c_Gpio_IsAnalog(&VOUT)) VOUT.Methods.SetAnalog();
    else VOUT.Methods.SetDigital();
    
    // ~~~ OUTPUT VOLTAGE FEEDBACK END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    
    // ~~~ BUCK1 CURRENT FEEDBACK ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    buck_4ph.Feedback.ad_ibuck1.enabled = true;   // Use this channel

    buck_4ph.Feedback.ad_ibuck1.adc_input = IBUCK1.Properties.ADCAN;
    buck_4ph.Feedback.ad_ibuck1.adc_core = IBUCK1.Properties.ADCORE;
    buck_4ph.Feedback.ad_ibuck1.trigger_source = IBUCK1_TRGSRC;
    buck_4ph.Feedback.ad_ibuck1.gpio_instance = IBUCK1.Properties.Port;

    #ifdef __WITH_PIL__
    buck_4ph.Feedback.ad_ibuck1.adc_buffer = &PilProbes.Ibuck1;
    #else
    buck_4ph.Feedback.ad_ibuck1.adc_buffer = p33c_Gpio_GetAnalogInputBuffer(IBUCK1.Properties.ADCAN);
    #endif

    buck_4ph.Feedback.ad_ibuck1.differential_input = false;
    buck_4ph.Feedback.ad_ibuck1.interrupt_enable = false;
    buck_4ph.Feedback.ad_ibuck1.early_interrupt_enable = false;
    buck_4ph.Feedback.ad_ibuck1.level_trigger = false;
    buck_4ph.Feedback.ad_ibuck1.signed_result = false;

    if (p33c_Gpio_IsAnalog(&IBUCK1)) IBUCK1.Methods.SetAnalog();
    else IBUCK1.Methods.SetDigital();
    
    // ~~~ BUCK1 CURRENT FEEDBACK END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    
    // ~~~ BUCK2 CURRENT FEEDBACK ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    buck_4ph.Feedback.ad_ibuck2.enabled = true;   // Use this channel

    buck_4ph.Feedback.ad_ibuck2.adc_input = IBUCK2.Properties.ADCAN;
    buck_4ph.Feedback.ad_ibuck2.adc_core = IBUCK2.Properties.ADCORE;
    buck_4ph.Feedback.ad_ibuck2.trigger_source = IBUCK2_TRGSRC;
    buck_4ph.Feedback.ad_ibuck2.gpio_instance = IBUCK2.Properties.Port;

    #ifdef __WITH_PIL__
    buck_4ph.Feedback.ad_ibuck2.adc_buffer = &PilProbes.Ibuck2;
    #else
    buck_4ph.Feedback.ad_ibuck2.adc_buffer = p33c_Gpio_GetAnalogInputBuffer(IBUCK2.Properties.ADCAN);
    #endif
    
    buck_4ph.Feedback.ad_ibuck2.differential_input = false;
    buck_4ph.Feedback.ad_ibuck2.interrupt_enable = false;
    buck_4ph.Feedback.ad_ibuck2.early_interrupt_enable = false;
    buck_4ph.Feedback.ad_ibuck2.level_trigger = false;
    buck_4ph.Feedback.ad_ibuck2.signed_result = false;

    if (p33c_Gpio_IsAnalog(&IBUCK2)) IBUCK2.Methods.SetAnalog();
    else IBUCK2.Methods.SetDigital();
   
    // ~~~ BUCK2 CURRENT FEEDBACK END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    
    // ~~~ BUCK3 CURRENT FEEDBACK ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    buck_4ph.Feedback.ad_ibuck3.enabled = true;   // Use this channel

    buck_4ph.Feedback.ad_ibuck3.adc_input = IBUCK3.Properties.ADCAN;
    buck_4ph.Feedback.ad_ibuck3.adc_core = IBUCK3.Properties.ADCORE;
    buck_4ph.Feedback.ad_ibuck3.trigger_source = IBUCK3_TRGSRC;
    buck_4ph.Feedback.ad_ibuck3.gpio_instance = IBUCK3.Properties.Port;

    #ifdef __WITH_PIL__
    buck_4ph.Feedback.ad_ibuck3.adc_buffer = &PilProbes.Ibuck3;
    #else
    buck_4ph.Feedback.ad_ibuck3.adc_buffer = p33c_Gpio_GetAnalogInputBuffer(IBUCK3.Properties.ADCAN);
    #endif

    buck_4ph.Feedback.ad_ibuck3.differential_input = false;
    buck_4ph.Feedback.ad_ibuck3.interrupt_enable = false;
    buck_4ph.Feedback.ad_ibuck3.early_interrupt_enable = false;
    buck_4ph.Feedback.ad_ibuck3.level_trigger = false;
    buck_4ph.Feedback.ad_ibuck3.signed_result = false;

    if (p33c_Gpio_IsAnalog(&IBUCK3)) IBUCK3.Methods.SetAnalog();
    else IBUCK3.Methods.SetDigital();
    
    // ~~~ BUCK3 CURRENT FEEDBACK  END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // ~~~ BUCK4 CURRENT FEEDBACK ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    buck_4ph.Feedback.ad_ibuck4.enabled = true;   // Use this channel

    buck_4ph.Feedback.ad_ibuck4.adc_input = IBUCK4.Properties.ADCAN;
    buck_4ph.Feedback.ad_ibuck4.adc_core = IBUCK4.Properties.ADCORE;
    buck_4ph.Feedback.ad_ibuck4.trigger_source = IBUCK4_TRGSRC;
    buck_4ph.Feedback.ad_ibuck4.gpio_instance = IBUCK4.Properties.Port;

    #ifdef __WITH_PIL__
    buck_4ph.Feedback.ad_ibuck4.adc_buffer = &PilProbes.Ibuck4;
    #else
    buck_4ph.Feedback.ad_ibuck4.adc_buffer = p33c_Gpio_GetAnalogInputBuffer(IBUCK4.Properties.ADCAN);
    #endif

    buck_4ph.Feedback.ad_ibuck4.differential_input = false;
    buck_4ph.Feedback.ad_ibuck4.interrupt_enable = false;
    buck_4ph.Feedback.ad_ibuck4.early_interrupt_enable = false;
    buck_4ph.Feedback.ad_ibuck4.level_trigger = false;
    buck_4ph.Feedback.ad_ibuck4.signed_result = false;

    if (p33c_Gpio_IsAnalog(&IBUCK4)) IBUCK4.Methods.SetAnalog();
    else IBUCK4.Methods.SetDigital();
    
    // ~~~ BUCK4 CURRENT FEEDBACK  END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    return(retval);
}

/*******************************************************************************
 * @ingroup app-layer-power-control-functions-private
 * @brief  This function initializes the startup configuration of the buck converter device driver instance 
 * @return unsigned integer (0=failure, 1=success)
 *  
 * @details
 *  This function initializes the startup configuration of the buck converter 
 *  device driver instance. A buck converter instance supports the following 
 *  startup options:
 * 
 * - Power-On Delay:   
 *   User-specified delay before the output voltage is ramping up
 * 
 * - VRamp-Up Period:  
 *   User specified output voltage ramp-up period in which the output voltage 
 *   is ramped up linearly from 0 to nominal output voltage
 * 
 * - IRamp-Up Period:  
 *   User specified output current ramp-up period; This function is only 
 *   available in average current mode control and only if a current limit 
 *   is hit during a voltage ramp-up and the output voltage cannot reach the 
 *   nominal level. under these conditions the state machine will switch over
 *   to state IRamp-Up and linearly increase the current limit up to the 
 *   allowed absolute maximum current. 
 *   This mode has been introduced especially for battery chargers or when
 *   converters are powering up against large capacitive loads.
 * 
 * - Power Good Delay: 
 *   User-specified period during which the output must stand stable before 
 *   the output is considered to be reliable
 * 
 * optional:
 * - Open Loop Startup: 
 *   Specific startup mode in average current mode control, where the PWM 
 *   output is increased manually in open loop while the output is monitored.
 *   This mode was introduced to bridge limited common mode voltage ranges
 *   of certain current sense circuits, which require a certain, minimum 
 *   voltage to be applied across the sense points before they start to 
 *   produce reliable feedback signals.
 * 
 *********************************************************************************/
uint16_t appPowerSupply_StartupInitialize(void)
{
    uint16_t retval = 1;

    // Initialize Startup Settings
    
    buck_4ph.StartUp.power_on_delay.counter = 0;
    buck_4ph.StartUp.power_on_delay.period = START_POD;
    buck_4ph.StartUp.power_on_delay.timeout_counter = 0; // Clear timeout counter
    buck_4ph.StartUp.power_on_delay.timeout = START_POD; // Set timeout counter threshold
    
    buck_4ph.StartUp.power_good_delay.counter = 0;
    buck_4ph.StartUp.power_good_delay.period = START_PGD;
    buck_4ph.StartUp.power_good_delay.timeout_counter = 0; // Clear timeout counter
    buck_4ph.StartUp.power_good_delay.timeout = START_PGD ; // Set timeout counter threshold 
    
    buck_4ph.StartUp.inrush_delay.counter = 0;
    buck_4ph.StartUp.inrush_delay.period = ENABLE_DCDC_INRUSH;
    buck_4ph.StartUp.inrush_delay.timeout_counter = 0; // Clear timeout counter
    buck_4ph.StartUp.inrush_delay.timeout = ENABLE_DCDC_INRUSH ; // Set timeout counter threshold 
    
    // Voltage ramp-up settings
    buck_4ph.StartUp.v_ramp.period = START_LVRAMP_PER;
    buck_4ph.StartUp.v_ramp.ref_inc_step = START_LVREF_STEP;
    
//    if (psfb.SetValues.control_mode == PSFB_CONTROL_MODE_ACMC) 
//    {
//        psfb.StartUp.i_ramp.counter = 0;
//        psfb.StartUp.i_ramp.period = IPFC_IRAMP_PER;
//        psfb.StartUp.i_ramp.ref_inc_step = IPFC_IREF_STEP;
//        psfb.StartUp.i_ramp.reference = 0;
//    }
    
    
    
    return(retval);
}

/***********************************************************************************
 * @ingroup app-layer-power-control-functions-private
 * @param	None
 * @brief  This function initializes the control system feedback loop objects
 * @return 0=failure
 * @return 1=success
 * 
 * @details
 * This function allows the user to set up and initialize the loop configuration. This 
 * includes the following setup.
 *     - Initialize Default Loop Configuration
 *     - Set Controller Object of Voltage Loop
 *     - Configure Voltage Loop Controller Object
 *     - Configure controller input/output ports
 *     - Data Input/Output Limit Configuration
 *     - ADC Trigger Control Configuration
 *     - Data Provider Configuration
 *     - Cascaded Function Configuration
 *     - Initialize Advanced Control Settings 
 *     - Custom Advanced Control Settings
 * 
 **********************************************************************************/
uint16_t appPowerSupply_ControllerInitialize(void) 
{
    uint16_t retval = 1;
        
    // ~~~ VOLTAGE LOOP CONFIGURATION ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    // Initialize Default Loop Configuration
    buck_4ph.VLoop.feedback_offset = 0; // Output voltage sense feedback offset
    //psfb.vout48_loop.reference = PSFB_VOUT_REF; // Output voltage reference value NOT USED
    buck_4ph.VLoop.trigger_offset = VOUT_ADC_TRGDLY;//((IPFC_PWM_PERIOD >> 1) + IPFC_VOUT_ADC_TRGDLY);
    
    buck_4ph.VLoop.minimum = PWM_DC_MIN; // Minimum phase value
    buck_4ph.VLoop.maximum = PWM_DC_MAX; // Maximum phase value

     // Set Controller Object of Voltage Loop
    buck_4ph.VLoop.controller = &vout_loop_vmc;                  // Voltage loop object
    buck_4ph.VLoop.ctrl_Initialize = &vout_loop_vmc_Initialize;  // VOltage loop object Initialize function
    buck_4ph.VLoop.ctrl_Update = &vout_loop_vmc_Update;          // Voltage loop object Update function
    buck_4ph.VLoop.ctrl_Reset = &vout_loop_vmc_Reset;            // Voltage loop object Reset function
    buck_4ph.VLoop.ctrl_Precharge = &vout_loop_vmc_Precharge;    // Voltage loop object Pre-Charge function

    // Configure Voltage Loop Controller Object
    buck_4ph.VLoop.ctrl_Initialize(&vout_loop_vmc);   // Call Initialization Routine setting histories and scaling
    
    
    
    buck_4ph.VLoop.controller->Ports.Source.ptrAddress = buck_4ph.Feedback.ad_vout.adc_buffer; // Output Voltage is Common Source
    buck_4ph.VLoop.controller->Ports.Source.Offset = 0; // Output Voltage feedback signal offset 
    buck_4ph.VLoop.controller->Ports.Source.NormScaler = 0; // Output voltage normalization factor bit-shift scaler 
    buck_4ph.VLoop.controller->Ports.Source.NormFactor = 0x7FFF; // Output voltage normalization factor fractional
    
    // Configure controller output ports
 
    buck_4ph.VLoop.controller->Ports.Target.ptrAddress = &buck_4ph.SetValues.nominal_duty; // Voltage loop target NOT USED

    

    buck_4ph.VLoop.controller->Ports.Target.Offset = 0; // Static primary output value offset
    buck_4ph.VLoop.controller->Ports.Target.NormScaler = 0; // Primary control output normalization factor bit-shift scaler 
    buck_4ph.VLoop.controller->Ports.Target.NormFactor = 0x7FFF; // Primary control output normalization factor fractional 
 
    
    // Configure controller control ports
    buck_4ph.VLoop.controller->Ports.ptrControlReference = &buck_4ph.SetValues.v_ref; // Set pointer to Reference
    
    // Data Input/Output Limit Configuration
    buck_4ph.VLoop.controller->Limits.MinOutput = buck_4ph.VLoop.minimum;
    buck_4ph.VLoop.controller->Limits.MaxOutput = buck_4ph.VLoop.maximum;
    buck_4ph.VLoop.controller->Limits.AltMinOutput = 0; // not used
    buck_4ph.VLoop.controller->Limits.AltMaxOutput = 0; // not used

    // ADC Trigger Control Configuration

    buck_4ph.VLoop.controller->ADCTriggerControl.ptrADCTriggerARegister = &buck_4ph.SetValues.nominal_adc_trigger; 
    buck_4ph.VLoop.controller->ADCTriggerControl.ADCTriggerAOffset = buck_4ph.VLoop.trigger_offset;
    buck_4ph.VLoop.controller->ADCTriggerControl.ptrADCTriggerBRegister = NULL;
    buck_4ph.VLoop.controller->ADCTriggerControl.ADCTriggerBOffset = VOUT_ADC_TRGDLY; 
        
    // Data Provider Configuration
    buck_4ph.VLoop.controller->DataProviders.ptrDProvControlInput = NULL; 
    buck_4ph.VLoop.controller->DataProviders.ptrDProvControlInputCompensated = NULL; 
    buck_4ph.VLoop.controller->DataProviders.ptrDProvControlError = NULL;
    buck_4ph.VLoop.controller->DataProviders.ptrDProvControlOutput = NULL;
    
    // Pre target update hook function
    buck_4ph.VLoop.controller->ExtensionHooks.ptrExtHookPreTargetWriteFunction = &pwm_register_update;
    buck_4ph.VLoop.controller->ExtensionHooks.ExtHookPreTargetWriteFunctionParam = PWM_DUTY_SHIFT;
    
    
    // Initialize AGC 
    buck_4ph.VLoop.controller->GainControl.ptrAgcObserverFunction = &vout_loop_AGCFactorUpdate; // Pointer to AGC Factor Update function
    buck_4ph.VLoop.controller->Ports.AltSource.ptrAddress=buck_4ph.Feedback.ad_vin.adc_buffer;  // Input  Voltage is used to calculate the AGC factor VIN_AGC_MIN/Vin
    buck_4ph.VLoop.controller->GainControl.AgcMedian=VIN_AGC_MIN;                               // Input voltage at which AGC factor is 0x7FFF (~1)
    
            // Custom Advanced Control Settings - Not used
    buck_4ph.VLoop.controller->Advanced.usrParam1 = buck_4ph.SwNode1.pwm_instance-1; // Buck 1 PWM instance used by the hook function to update the duty cycle and TRIGB
    buck_4ph.VLoop.controller->Advanced.usrParam2 = buck_4ph.SwNode2.pwm_instance-1; // Buck 2 PWM instance used by the hook function to update the duty cycle and TRIGB
    buck_4ph.VLoop.controller->Advanced.usrParam3 = buck_4ph.SwNode3.pwm_instance-1; // Buck 3 PWM instance used by the hook function to update the duty cycle and TRIGB
    buck_4ph.VLoop.controller->Advanced.usrParam4 = buck_4ph.SwNode4.pwm_instance-1; // Buck 4 PWM instance used by the hook function to update the duty cycle and TRIGB
    buck_4ph.VLoop.controller->Advanced.usrParam5 = &buck_4ph.Balancing.Buck2_dc_offset; // Used by the hook function to add the duty cycle offset to buck 2 PWM
    buck_4ph.VLoop.controller->Advanced.usrParam6 = &buck_4ph.Balancing.Buck3_dc_offset; // Used by the hook function to add the duty cycle offset to buck 3 PWM
    buck_4ph.VLoop.controller->Advanced.usrParam7 = &buck_4ph.Balancing.Buck4_dc_offset; // Used by the hook function to add the duty cycle offset to buck 4 PWM
    
    
    
    // Reset Controller Status
    buck_4ph.VLoop.controller->status.bits.enabled = false; // Keeps controller disabled
    buck_4ph.VLoop.controller->status.bits.swap_source = false; // use SOURCE as major control input
    buck_4ph.VLoop.controller->status.bits.swap_target = false; // use TARGET as major control output
    buck_4ph.VLoop.controller->status.bits.invert_input = false; // Do not invert input value
    buck_4ph.VLoop.controller->status.bits.lower_saturation_event = false; // Reset Anti-Windup Minimum Status bit
    buck_4ph.VLoop.controller->status.bits.upper_saturation_event = false; // Reset Anti-Windup Minimum Status bits
    buck_4ph.VLoop.controller->status.bits.agc_enabled = false;   // Enable Adaptive Gain Modulation by default

    // ~~~ VOLTAGE LOOP CONFIGURATION END ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    return(retval);
}

/***********************************************************************************
 * @ingroup app-layer-power-control-functions-private
 * @param	None
 * @brief  This function is used to load peripheral configuration templates from the power controller device driver
 * @return 0=failure
 * @return 1=success
 * 
 * @details
 * This function hand over the peripheral configuration to the buck converter driver
 * 
 **********************************************************************************/
uint16_t appPowerSupply_PeripheralsInitialize(void)
{
   uint16_t retval=1;
    
    retval &= drv_Converter_Initialize(&buck_4ph);
 
    // User peripheral configuration extension 
    // ToDo: debugging code should be incorporated into peripheral templates if still required


       
    return(retval);
}

/***********************************************************************************
 * @ingroup app-layer-power-control-functions-private
 * @param	None
 * @brief   Custom feature and/or data object initialization
 * @return  0=failure
 * @return  1=success
 * 
 * @details
 *  This function can be used to initialize proprietary features or 
 *  data objects, which are not part of the common power supply state 
 *  machine.
 * 
 **********************************************************************************/
uint16_t appPowerSupply_CustomFunctionInitialize(void)
{
    uint16_t retval=1;
    
    buck_4ph.Balancing.Maximum_DC_offset=MAX_DUTY_OFFSET;
    buck_4ph.Balancing.Minimum_DC_offset=MIN_DUTY_OFFSET;
    buck_4ph.Balancing.Minimum_delta_current=BALANCING_HYST;
    buck_4ph.Balancing.Iir_filter_lenght=BALANCING_IIR_BITS;
    
    
#ifdef __WITH_PIL__
    buck_4ph.Balancing.ptrIBuck1Master= &PilProbes.Ibuck1;
    buck_4ph.Balancing.ptrIBuck2Slave = &PilProbes.Ibuck2;
    buck_4ph.Balancing.ptrIBuck3Slave = &PilProbes.Ibuck3;
    buck_4ph.Balancing.ptrIBuck4Slave = &PilProbes.Ibuck4;
#else
    buck_4ph.Balancing.ptrIBuck1Master= p33c_Gpio_GetAnalogInputBuffer(IBUCK1.Properties.ADCAN);
    buck_4ph.Balancing.ptrIBuck2Slave = p33c_Gpio_GetAnalogInputBuffer(IBUCK2.Properties.ADCAN);
    buck_4ph.Balancing.ptrIBuck3Slave = p33c_Gpio_GetAnalogInputBuffer(IBUCK3.Properties.ADCAN);
    buck_4ph.Balancing.ptrIBuck4Slave = p33c_Gpio_GetAnalogInputBuffer(IBUCK4.Properties.ADCAN);
#endif
 
    return(retval);
}

/*******************************************************************************
 * @ingroup app-layer-power-control-functions-private
 * @fn	uint16_t appPowerSupply_InterruptsInitialize(void)
 * @brief  This function is used to initialize the interrupt service events of the control loop
 * @return 0=failure
 * @return 1=success
 * 
 * @details
 * This function initializes and enables the control loop interrupt(s) of the
 * cycle-by-cycle real-time control. These interrupts are commonly synchronous
 * to the switching process and therefore triggered by ADC conversion or PWM 
 * event interrupts. The interrupt service routines are called on high levels 
 * overriding the recently executed processes to maintain real-time accuracy
 * of the feedback loop response.
 * 
 *********************************************************************************/
uint16_t appPowerSupply_InterruptsInitialize(void)
{
    uint16_t retval=1;

    // Initialize Control Interrupt
    #if (VLOOP_TRIGGER_MODE != TRIGGER_MODE_NONE)
    VLOOP_ISR_IP = VLOOP_ISR_PRIORITY;
    VLOOP_ISR_IF = 0;
    VLOOP_ISR_IE = 1;
    #endif
    
    #if (ISNS1_TRIGGER_MODE != TRIGGER_MODE_NONE)
    ILOOP1_ISR_IP = ILOOP1_ISR_PRIORITY;
    ILOOP1_ISR_IF = 0;
    ILOOP1_ISR_IE = 0;
    #endif
        
    retval &= (VLOOP_ISR_IE); // Return INTERRUPT_ENABLE flag bit
    
    return(retval);
}

// ________________________
// end of file

