/* 
 * @file    app_comm.h
 * @author  M91406
 * @date    February 27, 2024
 */

#ifndef APPLICATION_LAYER_COMMUNICATION_H
#define	APPLICATION_LAYER_COMMUNICATION_H

#include <stdint.h> // include standard integer number data types

extern int appComm_Initialize(void);
extern int appComm_Execute(void);
extern int appComm_Start(void);
extern int appComm_Stop(void);

#endif	/* APPLICATION_LAYER_COMMUNICATION_H */

