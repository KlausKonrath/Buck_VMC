/* 
 * @file    app_comm.c
 * @author  M91406
 * @date    February 27, 2024
 */

#include <xc_pral.h> // include device peripheral register abstraction layer

#include "config/apps.h"
#include "config/hal.h"
#include "app_comm_protocol.h"
#include "svc/svc_comm_engine.h"
#include "common\I2C\I2C.h"

#define TRANSMIT_DELAY  25U // Task call interval multiplier determines status message interval

/*********************************************************************************
 * @ingroup apps-layer-comm-functions-public
 * @brief   Initializes a UART peripheral instance with settings derived from HAL
 * @return  unsigned integer (0=failure, 1=success)
**********************************************************************************/
int appComm_Initialize(void)
{
    int retval = 1;

    Nop();
    Nop();
    Nop();
    
    /* initialization of UART interface */
    retval &= plib33c_Uart_Initialize(&Comm, &TxDataBuffer, &RxDataBuffer);
    VCP_Rx_IE = 0;

    /* initialization of I2C Interface */
    I2C_Initialize();
    
    return(retval);
}

/*********************************************************************************
 * @ingroup apps-layer-comm-functions-public
 * @brief   Periodically called main function of a UART communication
 * @return  unsigned integer (0=failure, 1=success)
**********************************************************************************/
int appComm_Execute(void)
{
    int retval = 1;
    
    Nop();
    Nop();
    Nop();
    
    // Do not read from / write to UART when interface is disabled
    if (Comm.Status.PortOpen)
    {
        // Check for incoming data every execution cycles
        retval &= CommDmaReceive(&Comm);

        // If data is ready to be sent to the buffer 
        retval &= CommDmaTransmit(&Comm);
    }
    
    /* call I2C handler */
    I2C_Handler();
    
    return(retval);
}

/*********************************************************************************
 * @ingroup apps-layer-comm-functions-public
 * @brief   Start function of a UART interface, opening the port
 * @return  unsigned integer (0=failure, 1=success)
**********************************************************************************/
int appComm_Start(void)
{
    int retval = 1;

    // Capture DMA channel instance used by application
    P33C_UART_INSTANCE_t* uart = p33c_UartInstance_GetHandle(Comm.CommPort.UartInstance);
    P33C_DMA_INSTANCE_t* dma = p33c_DmaInstance_GetHandle(Comm.CommPort.RxD.DmaInstance);
    
    dma->DMACHx.bits.CHEN = 0;
    dma->DMAINTx.bits.CHSEL = plib33cUartDmaTrgRx[Comm.CommPort.UartInstance - 1]; // 04h = UART1 Receiver (= DMATRG_UART1_RX)
    dma->DMASRCx.value = (uint16_t)&uart->UxRXREG;  // Read from UART RxD Buffer
    dma->DMADSTx.value = (uint16_t)&rxBufferDma[0][0]; // Write to RxD DMA Buffer Array

    dma->DMACHx.bits.SIZE = 1;    // Data Size Selection = Byte (8-bit)
    dma->DMACHx.bits.RELOAD = 0;  // Address and Count Reload = DMASRCn, DMADSTn and DMACNTn are not reloaded on the start of the next operation
    dma->DMACHx.bits.SAMODE = 0b00; // Source Address Mode Selection, = DMASRCn remains unchanged after a transfer completion
    dma->DMACHx.bits.DAMODE = 0b01; // Source Address Mode Selection, = DMASRCn is incremented by SIZE after a transfer completion
    dma->DMACHx.bits.TRMODE = 0b01; // Transfer Mode Selection = Repeated One-Shot
    dma->DMACHx.bits.CHEN = 1;    // Enable DAM channel to continuously receive messages
    
    retval &= plib33c_Uart_Start(&Comm);
    Comm.Status.PortOpen = retval;
    
    VCP_Rx_IE = 0;

    return(retval);
}

/*********************************************************************************
 * @ingroup apps-layer-comm-functions-public
 * @brief   Stop function of a UART interface, closing the port
 * @return  unsigned integer (0=failure, 1=success)
**********************************************************************************/
int appComm_Stop(void)
{
    int retval = 1;
    
    retval &= plib33c_Uart_Close(&Comm);
    Comm.Status.PortOpen = (1 - retval);
    
    return(retval);
}

// ______________________________________
// end of file
