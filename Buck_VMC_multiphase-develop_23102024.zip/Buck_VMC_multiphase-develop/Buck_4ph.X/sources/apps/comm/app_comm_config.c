/* 
 * @file    app_comm_config.c
 * @author  M91406
 * @date    February 27, 2024
 */

#include "config/hal.h"
#include "common/p33c_plib/uart/IUartHandler.h"
#include "app_comm_config.h"

UART_t Comm = {
    
    // Hardware-Interface Configuration
    .CommPort.UartInstance = VCP_PORT,          // UART interface derived from HAL 
    .CommPort.RxD.Io = &VCP_RX,                 // UART interface RX I/O pin derived from HAL 
    .CommPort.RxD.DmaInstance = VCP_RX_DMA,     // UART interface RX DMA channel derived from HAL 
    .CommPort.TxD.Io = &VCP_TX,                 // UART interface TX I/O pin derived from HAL 
    .CommPort.TxD.DmaInstance = VCP_TX_DMA,     // UART interface TX DMA channel derived from HAL 

    // UART-Interface Parameter Configuration
    .Settings.Baudrate = VCP_BAUDRATE,          // Baud rate derived from HAL 
    .Settings.DataBits = VCP_DATABITS,          // Data bit count derived from HAL 
    .Settings.Parity = VCP_PARITY,              // Parity bit mode derived from HAL 
    .Settings.StopBits = VCP_STOPBITS,          // Stop bit count derived from HAL 
    .Settings.FlowControl = VCP_FLOWCONRTOL,    // Flow control mode derived from HAL 
    
    .Status.RxDmaEnable = VCP_USE_RX_DMA,       // Use DMA to receive data
    .Status.TxDmaEnable = VCP_USE_TX_DMA,       // Use DMA to send data
    .Status.StdioRedirect = VCP_REDIRECT_PRINTF, // Redirect printf to this UART
    .Status.ByteSwap = VCP_DATA_BYTE_SWAP       // Swap order of bytes of 16-bit and 32-bit values
};

// Data buffer for frame data processing
uint8_t CmdBuffer[RX_BUFFER_SIZE];
uint16_t CmdBufferSize = RX_BUFFER_SIZE; // (sizeof(CmdBuffer)/sizeof(CmdBuffer[0]))

// Transmit-Buffer Declaration
uint8_t  txBufferDma[TX_BUFFER_COUNT][TX_BUFFER_SIZE];
uint16_t txBufferSize = TX_BUFFER_SIZE; // (sizeof(txBufferDma)/sizeof(txBufferDma[0][0]))

UART_BUFFER_t TxDataBuffer = 
{
    .ArrayPointer = 0,
    .BufferPointer = 0,
    .ptrData = &txBufferDma[0][0],
    .Size = TX_BUFFER_SIZE, 
    .Ready = false
};

// Receive-Buffer Declaration
uint8_t rxBufferDma[RX_BUFFER_COUNT][RX_BUFFER_SIZE];
uint16_t rxBufferSize = RX_BUFFER_SIZE; // (sizeof(rxBufferDma)/sizeof(rxBufferDma[0][0]))

UART_BUFFER_t RxDataBuffer = 
{
    .ArrayPointer = 0,
    .BufferPointer = 0,
    .ptrData = &rxBufferDma[0][0],
    .Size = RX_BUFFER_SIZE,
    .Ready = false
};

// ______________________________________
// end of file



